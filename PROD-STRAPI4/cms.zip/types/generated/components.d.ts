import type { Schema, Attribute } from '@strapi/strapi';

export interface AboutBottomSection extends Schema.Component {
  collectionName: 'components_about_bottom_sections';
  info: {
    displayName: 'bottom section';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    bottom_button: Attribute.Component<'common.button'>;
  };
}

export interface AboutHistoryPoints extends Schema.Component {
  collectionName: 'components_about_history_points';
  info: {
    displayName: 'history points';
    description: '';
  };
  attributes: {
    image: Attribute.Media;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    date: Attribute.Date;
    show_date: Attribute.Boolean & Attribute.DefaultTo<true>;
  };
}

export interface AboutHistorySection extends Schema.Component {
  collectionName: 'components_about_history_sections';
  info: {
    displayName: 'history section';
  };
  attributes: {
    heading: Attribute.String;
    title: Attribute.String;
    points: Attribute.Component<'about.history-points', true>;
  };
}

export interface AboutMember extends Schema.Component {
  collectionName: 'components_about_members';
  info: {
    displayName: 'member';
  };
  attributes: {
    name: Attribute.String;
    role: Attribute.String;
    image: Attribute.Media;
    facebook_link: Attribute.String;
    twiter_link: Attribute.String;
    instagram_link: Attribute.String;
    linkedIn_link: Attribute.String;
  };
}

export interface AboutMembersSection extends Schema.Component {
  collectionName: 'components_about_members_sections';
  info: {
    displayName: 'Members section';
    description: '';
  };
  attributes: {
    heading: Attribute.String;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    members: Attribute.Component<'about.member', true>;
    show_section: Attribute.Boolean &
      Attribute.Required &
      Attribute.DefaultTo<true>;
  };
}

export interface AboutPoints extends Schema.Component {
  collectionName: 'components_about_points';
  info: {
    displayName: 'points';
  };
  attributes: {
    image: Attribute.Media;
    title: Attribute.String;
    description: Attribute.Text;
  };
}

export interface AboutSecondSection extends Schema.Component {
  collectionName: 'components_about_second_sections';
  info: {
    displayName: 'second section';
    description: '';
  };
  attributes: {
    heading: Attribute.String;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    points: Attribute.Component<'about.points', true>;
    description1: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'custom';
        }
      >;
    image: Attribute.Media;
  };
}

export interface AboutThirdSection extends Schema.Component {
  collectionName: 'components_about_third_sections';
  info: {
    displayName: 'third section';
    description: '';
  };
  attributes: {
    image: Attribute.Media;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    isImageLeft: Attribute.Boolean & Attribute.DefaultTo<false>;
  };
}

export interface AboutVisionAndMissionList extends Schema.Component {
  collectionName: 'components_about_vision_and_mission_lists';
  info: {
    displayName: 'vision and mission list';
  };
  attributes: {
    image: Attribute.Media;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface AboutVisionAndMission extends Schema.Component {
  collectionName: 'components_about_vision_and_missions';
  info: {
    displayName: 'vision and mission';
  };
  attributes: {
    title: Attribute.String;
    vision_and_mission_list: Attribute.Component<
      'about.vision-and-mission-list',
      true
    >;
  };
}

export interface AdventureCertified extends Schema.Component {
  collectionName: 'components_adventure_certifieds';
  info: {
    displayName: 'certified';
  };
  attributes: {
    title: Attribute.String;
    image: Attribute.Media;
    cards: Attribute.Component<'live-session.live-card', true>;
  };
}

export interface AdventureForm extends Schema.Component {
  collectionName: 'components_adventure_form';
  info: {
    displayName: 'adventure form';
  };
  attributes: {
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
  };
}

export interface AdventureHeroSection extends Schema.Component {
  collectionName: 'components_adventure_hero_sections';
  info: {
    displayName: 'Hero Section';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    adventure_hero_section_button: Attribute.Component<'common.button'>;
    image: Attribute.Media;
    mobile_image: Attribute.Media;
  };
}

export interface AdventureStripe extends Schema.Component {
  collectionName: 'components_adventure_stripes';
  info: {
    displayName: 'stripe';
  };
  attributes: {
    title: Attribute.String;
    stripe_button: Attribute.Component<'common.button'>;
  };
}

export interface AuthorSocialLink extends Schema.Component {
  collectionName: 'components_author_social_links';
  info: {
    displayName: 'Social Link';
    description: '';
  };
  attributes: {
    name: Attribute.String;
    link: Attribute.String;
  };
}

export interface BlogBottomSection extends Schema.Component {
  collectionName: 'components_blog_bottom_sections';
  info: {
    displayName: 'Bottom section';
    description: '';
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    description: Attribute.Text;
  };
}

export interface BlogFollowUs extends Schema.Component {
  collectionName: 'components_blog_follow_uses';
  info: {
    displayName: 'Follow us';
  };
  attributes: {
    name: Attribute.String;
    link: Attribute.String;
  };
}

export interface BlogKeyTakeaways extends Schema.Component {
  collectionName: 'components_blog_key_takeaways';
  info: {
    displayName: 'Key takeaways';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface ButtonButtonImageText extends Schema.Component {
  collectionName: 'components_button_button_image_texts';
  info: {
    displayName: 'ButtonImageText';
    description: '';
  };
  attributes: {
    image: Attribute.Media;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    button_image_text_button: Attribute.Component<'common.button'>;
  };
}

export interface ButtonButtonText extends Schema.Component {
  collectionName: 'components_button_button_texts';
  info: {
    displayName: 'ButtonText';
    description: '';
  };
  attributes: {
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    button_text_button: Attribute.Component<'common.button'>;
  };
}

export interface ButtonButton extends Schema.Component {
  collectionName: 'components_button_buttons';
  info: {
    displayName: 'Button';
  };
  attributes: {
    buttonText: Attribute.String;
    buttonLink: Attribute.String;
  };
}

export interface ButtonNewsletter extends Schema.Component {
  collectionName: 'components_button_newsletters';
  info: {
    displayName: 'Newsletter';
    description: '';
  };
  attributes: {
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
  };
}

export interface CareersBottomSection extends Schema.Component {
  collectionName: 'components_careers_bottom_sections';
  info: {
    displayName: 'bottom_section';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    career_bottom_button: Attribute.Component<'common.button'>;
  };
}

export interface CareersGlassdoorSection extends Schema.Component {
  collectionName: 'components_careers_glassdoor_sections';
  info: {
    displayName: 'Glassdoor Section';
  };
  attributes: {
    title: Attribute.String;
    image: Attribute.Media;
    mobileImage: Attribute.Media;
  };
}

export interface CareersHeroSection extends Schema.Component {
  collectionName: 'components_careers_hero_sections';
  info: {
    displayName: 'Hero Section';
    description: '';
  };
  attributes: {
    heading: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    title: Attribute.String;
    button: Attribute.Component<'button.button'>;
  };
}

export interface CareersHero extends Schema.Component {
  collectionName: 'components_careers_heroes';
  info: {
    displayName: 'Hero';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    career_button: Attribute.Component<'common.button'>;
  };
}

export interface CareersProjectList extends Schema.Component {
  collectionName: 'components_careers_project_lists';
  info: {
    displayName: 'Project list';
  };
  attributes: {
    image: Attribute.Media;
    title: Attribute.String;
    buttonText: Attribute.String;
  };
}

export interface CareersWhyChooseUsList extends Schema.Component {
  collectionName: 'components_careers_why_choose_us_lists';
  info: {
    displayName: 'why choose us list';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    image: Attribute.Media;
  };
}

export interface CareersWhyChooseUs extends Schema.Component {
  collectionName: 'components_careers_why_choose_uses';
  info: {
    displayName: 'Why Choose us';
    description: '';
  };
  attributes: {
    sectionTitle: Attribute.String;
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    description: Attribute.Text;
    project_list: Attribute.Component<'careers.project-list', true>;
  };
}

export interface CaseStudyAferrCaseStudiesSection extends Schema.Component {
  collectionName: 'components_cs_case_studies';
  info: {
    displayName: 'Aferr Case Studies Section';
    description: 'Case studies section matching AferrMaster.jsx CaseStudiesSection component';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    description: Attribute.Text;
    case_study_categories: Attribute.Component<
      'case-study.case-study-category',
      true
    >;
  };
}

export interface CaseStudyAferrCta extends Schema.Component {
  collectionName: 'components_cs_aferr_cta';
  info: {
    displayName: 'Aferr CTA';
    description: 'CTA component following case study pattern for Aferr Master templates';
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    description: Attribute.Text;
    button: Attribute.Component<'common.button'>;
    background_type: Attribute.Enumeration<['gradient', 'image', 'color']> &
      Attribute.DefaultTo<'gradient'>;
    background_image_desktop: Attribute.Media;
    background_image_mobile: Attribute.Media;
    background_image: Attribute.Media;
    gradient_overlay: Attribute.Text;
    background_color: Attribute.String;
    text_color: Attribute.Enumeration<['white', 'black', 'custom']> &
      Attribute.DefaultTo<'white'>;
    custom_text_color: Attribute.String;
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
  };
}

export interface CaseStudyAferrDetailsSection2 extends Schema.Component {
  collectionName: 'components_cs_aferr_details_2';
  info: {
    displayName: 'Aferr Details Section 2';
    description: 'Second details section without stats quadrants - clean image display';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    button: Attribute.Component<'common.button'>;
  };
}

export interface CaseStudyAferrDetailsSection extends Schema.Component {
  collectionName: 'components_cs_aferr_details';
  info: {
    displayName: 'Aferr Details Section';
    description: 'Details section matching AferrMaster.jsx DetailsSection component';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    media_type: Attribute.Enumeration<['image', 'video']> &
      Attribute.DefaultTo<'image'>;
    image: Attribute.Media;
    video: Attribute.Media;
    video_thumbnail: Attribute.Media;
    button: Attribute.Component<'common.button'>;
    stats_quadrants: Attribute.Component<
      'case-study.aferr-stats-quadrant',
      true
    > &
      Attribute.SetMinMax<{
        max: 4;
      }>;
  };
}

export interface CaseStudyAferrFinalCta extends Schema.Component {
  collectionName: 'components_cs_aferr_final_cta';
  info: {
    displayName: 'Aferr Final CTA';
    description: 'Final CTA section matching AferrMaster.jsx FinalCTASection component';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    background_image_desktop: Attribute.Media;
    background_image_mobile: Attribute.Media;
    background_image: Attribute.Media;
    gradient_overlay: Attribute.String;
    button: Attribute.Component<'common.button'>;
  };
}

export interface CaseStudyAferrHeroSection extends Schema.Component {
  collectionName: 'components_cs_aferr_hero';
  info: {
    displayName: 'Aferr Hero Section';
    description: 'Hero section matching AferrMaster.jsx HeroSection component';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    description: Attribute.Text;
    background_image: Attribute.Media;
    gradient_overlay: Attribute.String;
    button: Attribute.Component<'common.button'>;
  };
}

export interface CaseStudyAferrStatsQuadrant extends Schema.Component {
  collectionName: 'components_cs_aferr_stats_quadrant';
  info: {
    displayName: 'Stats Quadrant';
    description: 'Individual stats quadrant for the details section';
  };
  attributes: {
    stat_value: Attribute.String & Attribute.Required;
    stat_description: Attribute.String & Attribute.Required;
    position: Attribute.Enumeration<
      ['top-left', 'top-right', 'bottom-left', 'bottom-right']
    > &
      Attribute.Required;
  };
}

export interface CaseStudyAferrStatsSection extends Schema.Component {
  collectionName: 'components_cs_aferr_stats';
  info: {
    displayName: 'Aferr Stats Section';
    description: 'Statistics section matching AferrMaster.jsx StatsSection component';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    stats_cards: Attribute.Component<'case-study.stat-card', true>;
  };
}

export interface CaseStudyAferrVideoCarousel extends Schema.Component {
  collectionName: 'components_cs_aferr_video';
  info: {
    displayName: 'Aferr Video Carousel';
    description: 'Video carousel section matching AferrMaster.jsx VideoCarousel component';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    video_cards: Attribute.Component<'newsroom.video-card', true>;
  };
}

export interface CaseStudyAudiobookSeriesTemplate extends Schema.Component {
  collectionName: 'components_cs_audiobook_template';
  info: {
    displayName: 'Dialogue Series Template';
    description: 'Template for Dialogue series with relevant components';
  };
  attributes: {
    hero_section: Attribute.Component<'case-study.hero-section'>;
    company_overview_section: Attribute.Component<'case-study.company-overview'>;
    key_challenges_section: Attribute.Component<'case-study.key-challenges'>;
    solutions_section: Attribute.Component<'case-study.solutions'>;
    solutions_banner: Attribute.Component<'case-study.solutions-banner'>;
    impact_section: Attribute.Component<'case-study.impact'>;
    testimonial_section: Attribute.Component<'case-study.testimonial'>;
    cta_header_section: Attribute.Component<'case-study.cta-header-section'>;
    cta_section: Attribute.Relation<
      'case-study.audiobook-series-template',
      'manyToMany',
      'api::cta.cta'
    >;
    references_section: Attribute.Component<'case-study.references'>;
  };
}

export interface CaseStudyBrands extends Schema.Component {
  collectionName: 'components_case_study_brands';
  info: {
    displayName: 'brands';
  };
  attributes: {
    title: Attribute.String;
    brands: Attribute.Relation<
      'case-study.brands',
      'oneToMany',
      'api::logo.logo'
    >;
  };
}

export interface CaseStudyCaseStudyCategory extends Schema.Component {
  collectionName: 'components_cs_case_study_category';
  info: {
    displayName: 'Case Study Category';
    description: 'Individual case study category with case studies';
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    case_studies: Attribute.Component<'case-study.case-study-item', true>;
  };
}

export interface CaseStudyCaseStudyCta extends Schema.Component {
  collectionName: 'components_cs_detail_cta';
  info: {
    displayName: 'Case Study CTA';
    description: 'CTA component specifically for case study pages';
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    description: Attribute.Text;
    button: Attribute.Component<'common.button'>;
    background_type: Attribute.Enumeration<['gradient', 'image', 'color']> &
      Attribute.DefaultTo<'gradient'>;
    background_image_desktop: Attribute.Media;
    background_image_mobile: Attribute.Media;
    background_image: Attribute.Media;
    gradient_overlay: Attribute.Text;
    background_color: Attribute.String;
    text_color: Attribute.Enumeration<['white', 'black', 'custom']> &
      Attribute.DefaultTo<'white'>;
    custom_text_color: Attribute.String;
    spacing: Attribute.Component<'common.spacing'>;
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
  };
}

export interface CaseStudyCaseStudyItem extends Schema.Component {
  collectionName: 'components_cs_case_study_item';
  info: {
    displayName: 'Case Study Item';
    description: 'Individual case study item';
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    description: Attribute.Text;
    image: Attribute.Media;
    button: Attribute.Component<'common.button'>;
  };
}

export interface CaseStudyCaseStudySeriesTemplate extends Schema.Component {
  collectionName: 'components_cs_case_study_template';
  info: {
    displayName: 'Case Study Series Template';
    description: 'Template for Case Study Series with all components from CaseStudyDetail.jsx';
  };
  attributes: {
    hero_section: Attribute.Component<'case-study.hero-section'>;
    company_overview_section: Attribute.Component<'case-study.company-overview'>;
    key_challenges_section: Attribute.Component<'case-study.key-challenges'>;
    solutions_section: Attribute.Component<'case-study.solutions'>;
    solutions_banner: Attribute.Component<'case-study.solutions-banner'>;
    impact_section: Attribute.Component<'case-study.impact'>;
    testimonial_section: Attribute.Component<'case-study.testimonial'>;
    cta_header_section: Attribute.Component<'case-study.cta-header-section'>;
    cta_section: Attribute.Relation<
      'case-study.case-study-series-template',
      'manyToMany',
      'api::cta.cta'
    >;
    references_section: Attribute.Component<'case-study.references'>;
  };
}

export interface CaseStudyCompanyOverview extends Schema.Component {
  collectionName: 'components_cs_detail_company';
  info: {
    displayName: 'Company Overview';
    description: 'Company overview section for case study pages with custom icons';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String & Attribute.DefaultTo<'COMPANY OVERVIEW'>;
    company_card_enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    company_card_label: Attribute.String & Attribute.DefaultTo<'Company'>;
    company_card_icon: Attribute.Media;
    industry_card_enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    industry_card_label: Attribute.String & Attribute.DefaultTo<'Industry'>;
    industry_card_icon: Attribute.Media;
    location_card_enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    location_card_label: Attribute.String & Attribute.DefaultTo<'Location'>;
    location_card_icon: Attribute.Media;
    company_name: Attribute.String;
    industry: Attribute.String;
    location: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface CaseStudyCtaHeaderSection extends Schema.Component {
  collectionName: 'components_cs_cta_header';
  info: {
    displayName: 'CTA Header Section';
    description: 'Header and description section above CTAs';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    spacing: Attribute.Component<'common.spacing'>;
  };
}

export interface CaseStudyFirstSectionSwiperList extends Schema.Component {
  collectionName: 'components_case_study_first_section_swiper_lists';
  info: {
    displayName: 'first section swiper list';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    video: Attribute.String;
    image: Attribute.Media;
  };
}

export interface CaseStudyGetStarted extends Schema.Component {
  collectionName: 'components_case_study_get_starteds';
  info: {
    displayName: 'get started';
  };
  attributes: {
    title: Attribute.String;
    case_study_get_started_button: Attribute.Component<'common.button'>;
  };
}

export interface CaseStudyHeroSection extends Schema.Component {
  collectionName: 'components_cs_detail_hero';
  info: {
    displayName: 'Hero Section';
    description: 'Hero section for case study pages with background image or solid color support';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String & Attribute.Required;
    category: Attribute.String & Attribute.DefaultTo<'Success Story'>;
    description: Attribute.Text;
    background_image: Attribute.Media;
    background_image_desktop: Attribute.Media;
    background_image_mobile: Attribute.Media;
    background_color: Attribute.String & Attribute.DefaultTo<''>;
    gradient_overlay: Attribute.Text &
      Attribute.DefaultTo<'linear-gradient(to right, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0.3) 100%)'>;
    title_text_color: Attribute.String & Attribute.DefaultTo<''>;
    category_background_color: Attribute.String & Attribute.DefaultTo<''>;
  };
}

export interface CaseStudyImpactStat extends Schema.Component {
  collectionName: 'components_cs_detail_stat';
  info: {
    displayName: 'Impact Stat';
    description: 'Individual statistic for impact section';
  };
  attributes: {
    number: Attribute.String & Attribute.Required;
    title: Attribute.String & Attribute.Required;
    description: Attribute.Text;
    detailed_description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface CaseStudyImpact extends Schema.Component {
  collectionName: 'components_cs_detail_impact';
  info: {
    displayName: 'Impact Section';
    description: 'Impact section with text and statistics for case study pages';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String & Attribute.DefaultTo<'THE IMPACT'>;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    stats: Attribute.Component<'case-study.impact-stat', true>;
    spacing: Attribute.Component<'common.spacing'>;
  };
}

export interface CaseStudyJournalSeriesTemplate extends Schema.Component {
  collectionName: 'components_cs_journal_template';
  info: {
    displayName: 'Journal Series Template';
    description: 'Template for Journal Series with all components from CaseStudyDetail.jsx';
  };
  attributes: {
    hero_section: Attribute.Component<'case-study.hero-section'>;
    company_overview_section: Attribute.Component<'case-study.company-overview'>;
    key_challenges_section: Attribute.Component<'case-study.key-challenges'>;
    solutions_section: Attribute.Component<'case-study.solutions'>;
    solutions_banner: Attribute.Component<'case-study.solutions-banner'>;
    impact_section: Attribute.Component<'case-study.impact'>;
    testimonial_section: Attribute.Component<'case-study.testimonial'>;
    cta_header_section: Attribute.Component<'case-study.cta-header-section'>;
    cta_section: Attribute.Relation<
      'case-study.journal-series-template',
      'manyToMany',
      'api::cta.cta'
    >;
    references_section: Attribute.Component<'case-study.references'>;
  };
}

export interface CaseStudyKeyChallenges extends Schema.Component {
  collectionName: 'components_cs_detail_challenges';
  info: {
    displayName: 'Key Challenges';
    description: 'Key challenges section for case study pages';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String & Attribute.DefaultTo<'KEY CHALLENGES'>;
    content: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    image_square: Attribute.Media;
    image_wide: Attribute.Media;
    spacing: Attribute.Component<'common.spacing'>;
  };
}

export interface CaseStudyPayOffsList extends Schema.Component {
  collectionName: 'components_case_study_pay_offs_lists';
  info: {
    displayName: 'pay offs list';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.String;
  };
}

export interface CaseStudyPayOffsSection extends Schema.Component {
  collectionName: 'components_case_study_pay_offs_sections';
  info: {
    displayName: 'pay offs section';
  };
  attributes: {
    title: Attribute.String;
    list: Attribute.Component<'case-study.pay-offs-list', true>;
  };
}

export interface CaseStudyReferences extends Schema.Component {
  collectionName: 'components_cs_references';
  info: {
    displayName: 'References';
    description: 'References section for case study pages';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String & Attribute.DefaultTo<'References'>;
    references: Attribute.Component<'glossary.reference', true>;
    spacing: Attribute.Component<'common.spacing'>;
  };
}

export interface CaseStudyResearchSeriesTemplate extends Schema.Component {
  collectionName: 'components_cs_research_template';
  info: {
    displayName: 'Research Series Template';
    description: 'Template for Research Series with all components from CaseStudyDetail.jsx';
  };
  attributes: {
    hero_section: Attribute.Component<'case-study.hero-section'>;
    company_overview_section: Attribute.Component<'case-study.company-overview'>;
    key_challenges_section: Attribute.Component<'case-study.key-challenges'>;
    solutions_section: Attribute.Component<'case-study.solutions'>;
    solutions_banner: Attribute.Component<'case-study.solutions-banner'>;
    impact_section: Attribute.Component<'case-study.impact'>;
    testimonial_section: Attribute.Component<'case-study.testimonial'>;
    cta_section: Attribute.Relation<
      'case-study.research-series-template',
      'manyToOne',
      'api::cta.cta'
    >;
    references_section: Attribute.Component<'case-study.references'>;
  };
}

export interface CaseStudySolutionsBanner extends Schema.Component {
  collectionName: 'components_cs_detail_banner';
  info: {
    displayName: 'Solutions Banner';
    description: 'Solutions banner section for case study pages';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String;
    description: Attribute.Text;
    button: Attribute.Component<'common.button'>;
    button_type: Attribute.Enumeration<['link', 'popup', 'form']> &
      Attribute.DefaultTo<'link'>;
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
    background_image: Attribute.Media;
    gradient_overlay: Attribute.Text;
    spacing: Attribute.Component<'common.spacing'>;
  };
}

export interface CaseStudySolutions extends Schema.Component {
  collectionName: 'components_cs_detail_solutions';
  info: {
    displayName: 'Solutions';
    description: 'Solutions section for case study pages';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    title: Attribute.String & Attribute.DefaultTo<'OUR SOLUTIONS'>;
    content: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    testimonial: Attribute.Component<'case-study.testimonial'>;
    additional_content: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    additional_image: Attribute.Media;
    spacing: Attribute.Component<'common.spacing'>;
  };
}

export interface CaseStudyStatCard extends Schema.Component {
  collectionName: 'components_cs_stat_card';
  info: {
    displayName: 'Stat Card';
    description: 'Individual statistics card';
  };
  attributes: {
    stat_value: Attribute.String & Attribute.Required;
    stat_description: Attribute.String & Attribute.Required;
  };
}

export interface CaseStudyTeamSectionList extends Schema.Component {
  collectionName: 'components_case_study_team_section_lists';
  info: {
    displayName: 'team section list';
  };
  attributes: {
    title: Attribute.String;
    video: Attribute.String;
    image: Attribute.Media;
    logo: Attribute.Media;
  };
}

export interface CaseStudyTeamSection extends Schema.Component {
  collectionName: 'components_case_study_team_sections';
  info: {
    displayName: 'team section';
  };
  attributes: {
    title: Attribute.String;
    team_section_list: Attribute.Component<
      'case-study.team-section-list',
      true
    >;
  };
}

export interface CaseStudyTestimonial extends Schema.Component {
  collectionName: 'components_cs_detail_testimonial';
  info: {
    displayName: 'Testimonial';
    description: 'Testimonial component for case study pages';
  };
  attributes: {
    enabled: Attribute.Boolean & Attribute.DefaultTo<true>;
    quote: Attribute.Text & Attribute.Required;
    author_name: Attribute.String;
    author_designation: Attribute.String;
    author_image: Attribute.Media;
    spacing: Attribute.Component<'common.spacing'>;
  };
}

export interface CaseStudyTestimonials extends Schema.Component {
  collectionName: 'components_case_study_testimonials';
  info: {
    displayName: 'testimonials';
  };
  attributes: {
    title: Attribute.String;
    testimonials: Attribute.Relation<
      'case-study.testimonials',
      'oneToMany',
      'api::testimonial.testimonial'
    >;
  };
}

export interface CommonAppDownload extends Schema.Component {
  collectionName: 'components_common_app_downloads';
  info: {
    displayName: 'app download';
    description: '';
  };
  attributes: {
    sectionTitle: Attribute.String;
    title: Attribute.String;
    playstoreButtonText: Attribute.String;
    applestoreButtonText: Attribute.String;
    image: Attribute.Media;
    playstoreButtonLink: Attribute.Text;
    applestoreButtonLink: Attribute.Text;
  };
}

export interface CommonBanner extends Schema.Component {
  collectionName: 'components_contact_banners';
  info: {
    displayName: 'Banner';
    description: '';
  };
  attributes: {
    title: Attribute.String;
  };
}

export interface CommonButton extends Schema.Component {
  collectionName: 'components_common_buttons';
  info: {
    displayName: 'Button';
    description: '';
  };
  attributes: {
    button_text: Attribute.String;
    button_link: Attribute.String;
    button_target: Attribute.Enumeration<['_self', '_blank']> &
      Attribute.DefaultTo<'_self'>;
    button_icon: Attribute.String;
  };
}

export interface CommonDownloadApp extends Schema.Component {
  collectionName: 'components_common_download_apps';
  info: {
    displayName: 'Download app';
    description: '';
  };
  attributes: {
    android: Attribute.Media;
    ios: Attribute.Media;
    android_link: Attribute.String;
    ios_link: Attribute.String;
  };
}

export interface CommonEditor extends Schema.Component {
  collectionName: 'components_common_editors';
  info: {
    displayName: 'Editor';
  };
  attributes: {
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface CommonFooter extends Schema.Component {
  collectionName: 'components_common_footers';
  info: {
    displayName: 'footer';
    description: '';
  };
  attributes: {
    footer_description: Attribute.Text;
    copyright: Attribute.String;
    logo: Attribute.Media;
  };
}

export interface CommonFormField extends Schema.Component {
  collectionName: 'components_common_form_fields';
  info: {
    displayName: 'formField';
  };
  attributes: {
    placeholder: Attribute.String;
    type: Attribute.Enumeration<['text', 'email', 'number', 'textarea']>;
  };
}

export interface CommonSocialMedia extends Schema.Component {
  collectionName: 'components_common_social_medias';
  info: {
    displayName: 'Social media';
  };
  attributes: {
    name: Attribute.String;
    link: Attribute.String;
  };
}

export interface CommonSpacing extends Schema.Component {
  collectionName: 'components_common_spacings';
  info: {
    displayName: 'Spacing';
    description: 'Component for controlling section spacing';
  };
  attributes: {
    top: Attribute.String & Attribute.DefaultTo<'80px'>;
    bottom: Attribute.String & Attribute.DefaultTo<'80px'>;
  };
}

export interface CommonThankYou extends Schema.Component {
  collectionName: 'components_common_thank_yous';
  info: {
    displayName: 'Thank you';
    description: '';
  };
  attributes: {
    image: Attribute.Media;
    heading: Attribute.String;
    description: Attribute.Text;
  };
}

export interface CommonTopStickyStripe extends Schema.Component {
  collectionName: 'components_common_top_sticky_stripes';
  info: {
    displayName: 'Top Sticky Stripe';
    description: '';
  };
  attributes: {
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    visible: Attribute.Boolean & Attribute.DefaultTo<true>;
    top_sticky_stripe_button: Attribute.Component<'common.button'>;
  };
}

export interface CommonZohoForm extends Schema.Component {
  collectionName: 'components_common_zoho_forms';
  info: {
    displayName: 'zoho_form';
  };
  attributes: {
    zoho_form_type: Attribute.Enumeration<['button', 'form']> &
      Attribute.DefaultTo<'button'>;
    zoho_form_button: Attribute.Component<'common.button'>;
    onload_function: Attribute.Text;
    onsubmit_function: Attribute.Text;
    zoho_form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface ContactSecondSection extends Schema.Component {
  collectionName: 'components_contact_second_sections';
  info: {
    displayName: 'second section';
  };
  attributes: {
    heading: Attribute.String;
    title: Attribute.String;
    description: Attribute.Text;
    image: Attribute.Media;
  };
}

export interface GameDownloadAppDownloadButtons extends Schema.Component {
  collectionName: 'components_game_download_app_download_buttons';
  info: {
    displayName: 'app download buttons';
  };
  attributes: {
    buttonText: Attribute.String;
    buttonLink: Attribute.Text;
  };
}

export interface GameDownloadAppDownload extends Schema.Component {
  collectionName: 'components_game_download_app_downloads';
  info: {
    displayName: 'app download';
    description: '';
  };
  attributes: {
    sectionTitle: Attribute.String;
    title: Attribute.String;
    playstoreButtonText: Attribute.String;
    applestoreButtonText: Attribute.String;
    image: Attribute.Media;
    playstoreButtonLink: Attribute.Text;
    applestoreButtonLink: Attribute.Text;
  };
}

export interface GameDownloadFeatureList extends Schema.Component {
  collectionName: 'components_game_download_feature_lists';
  info: {
    displayName: 'feature list';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    icon: Attribute.String;
  };
}

export interface GameDownloadFeatures extends Schema.Component {
  collectionName: 'components_game_download_features';
  info: {
    displayName: 'features';
  };
  attributes: {
    title: Attribute.String;
    featureList: Attribute.Component<'game-download.feature-list', true>;
  };
}

export interface GameDownloadMinimalDashboard extends Schema.Component {
  collectionName: 'components_game_download_minimal_dashboards';
  info: {
    displayName: 'minimal-dashboard';
  };
  attributes: {
    sectionTitle: Attribute.String;
    title: Attribute.String;
    overviewList: Attribute.Component<'game-download.overview-list', true>;
    appDownloadButtons: Attribute.Component<
      'game-download.app-download-buttons',
      true
    >;
    image1: Attribute.Media;
    image2: Attribute.Media;
  };
}

export interface GameDownloadOverviewList extends Schema.Component {
  collectionName: 'components_game_download_overview_lists';
  info: {
    displayName: 'overview-list';
  };
  attributes: {
    overviewPoint: Attribute.String;
  };
}

export interface GameBanner extends Schema.Component {
  collectionName: 'components_game_banners';
  info: {
    displayName: 'Banner';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    subHeading: Attribute.Text;
  };
}

export interface GameBrandSection extends Schema.Component {
  collectionName: 'components_game_brand_sections';
  info: {
    displayName: 'Brand Section';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    brands: Attribute.Relation<
      'game.brand-section',
      'oneToMany',
      'api::logo.logo'
    >;
    title2: Attribute.String;
    title_icon: Attribute.String;
    brands2: Attribute.Relation<
      'game.brand-section',
      'oneToMany',
      'api::logo.logo'
    >;
    brands3: Attribute.Relation<
      'game.brand-section',
      'oneToMany',
      'api::logo.logo'
    >;
  };
}

export interface GameBrand extends Schema.Component {
  collectionName: 'components_game_brands';
  info: {
    displayName: 'Brand';
  };
  attributes: {
    image: Attribute.Media;
  };
}

export interface GameButton extends Schema.Component {
  collectionName: 'components_game_buttons';
  info: {
    displayName: 'Button';
  };
  attributes: {
    text: Attribute.String;
    link: Attribute.String;
  };
}

export interface GameDownloadApp extends Schema.Component {
  collectionName: 'components_game_download_apps';
  info: {
    displayName: 'Download App';
    description: '';
  };
  attributes: {
    heading: Attribute.String;
    title: Attribute.String;
    image: Attribute.Media;
    playstoreButtonText: Attribute.String;
    playstoreButtonLink: Attribute.String;
    applestoreButtonText: Attribute.String;
    applestoreButtonLink: Attribute.String;
  };
}

export interface GameFacilitatorsLoveAboutEvivve extends Schema.Component {
  collectionName: 'components_game_facilitators_love_about_evivves';
  info: {
    displayName: 'Facilitators love about Evivve';
  };
  attributes: {
    title: Attribute.String;
  };
}

export interface GamePlayCategory extends Schema.Component {
  collectionName: 'components_game_play_categories';
  info: {
    displayName: 'Play Category';
    description: '';
  };
  attributes: {
    heading: Attribute.String;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    game_button: Attribute.Component<'common.button'>;
  };
}

export interface GameTestimonial extends Schema.Component {
  collectionName: 'components_game_testimonials';
  info: {
    displayName: 'Testimonial';
    description: '';
  };
  attributes: {
    title1: Attribute.String;
    testimonials: Attribute.Relation<
      'game.testimonial',
      'oneToMany',
      'api::testimonial.testimonial'
    >;
    title2: Attribute.String;
    title_icon: Attribute.String;
  };
}

export interface GlossaryDarkEditor extends Schema.Component {
  collectionName: 'components_glossary_dark_editors';
  info: {
    displayName: 'dark_editor';
  };
  attributes: {
    dark_editor: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface GlossaryLightEditor extends Schema.Component {
  collectionName: 'components_glossary_light_editors';
  info: {
    displayName: 'light_editor';
    description: '';
  };
  attributes: {
    light_editor: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface GlossaryReference extends Schema.Component {
  collectionName: 'components_glossary_references';
  info: {
    displayName: 'reference';
  };
  attributes: {
    reference_editor: Attribute.RichText;
  };
}

export interface HomeBrand extends Schema.Component {
  collectionName: 'components_home_brands';
  info: {
    displayName: 'Brand';
    description: '';
  };
  attributes: {
    title1: Attribute.String;
    client_logos: Attribute.Relation<
      'home.brand',
      'oneToMany',
      'api::logo.logo'
    >;
    title2: Attribute.String;
    title_icon: Attribute.String;
    client_logos2: Attribute.Relation<
      'home.brand',
      'oneToMany',
      'api::logo.logo'
    >;
    client_logos3: Attribute.Relation<
      'home.brand',
      'oneToMany',
      'api::logo.logo'
    >;
  };
}

export interface HomeButton extends Schema.Component {
  collectionName: 'components_home_buttons';
  info: {
    displayName: 'button';
  };
  attributes: {
    button_text: Attribute.String;
    button_link: Attribute.String;
  };
}

export interface HomeCommunityPoints extends Schema.Component {
  collectionName: 'components_home_community_points';
  info: {
    displayName: 'Community Points';
  };
  attributes: {
    icon: Attribute.String;
    title: Attribute.String;
  };
}

export interface HomeCommunity extends Schema.Component {
  collectionName: 'components_home_communities';
  info: {
    displayName: 'Community';
    description: '';
  };
  attributes: {
    heading: Attribute.String;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    points: Attribute.Component<'home.community-points', true>;
    image: Attribute.Media;
    community_button: Attribute.Component<'common.button'>;
  };
}

export interface HomeEarning extends Schema.Component {
  collectionName: 'components_home_earnings';
  info: {
    displayName: 'Earning';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    earning_button: Attribute.Component<'common.button'>;
  };
}

export interface HomeGetStarted extends Schema.Component {
  collectionName: 'components_home_get_starteds';
  info: {
    displayName: 'Get Started';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    get_started_button: Attribute.Component<'common.button'>;
  };
}

export interface HomeHowItWorksStepAnimateText extends Schema.Component {
  collectionName: 'components_home_how_it_works_step_animate_texts';
  info: {
    displayName: 'How It Works Step Animate Text';
  };
  attributes: {
    text: Attribute.String;
  };
}

export interface HomeHowItWorksStepPoints extends Schema.Component {
  collectionName: 'components_home_how_it_works_step_points';
  info: {
    displayName: 'How It Works Step Points';
  };
  attributes: {
    icon: Attribute.String;
    title: Attribute.String;
  };
}

export interface HomeHowItWorksStep extends Schema.Component {
  collectionName: 'components_home_how_it_works_steps';
  info: {
    displayName: 'How It Works Step';
    description: '';
  };
  attributes: {
    step_info: Attribute.String;
    title: Attribute.String;
    description1: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    description2: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    textanimate: Attribute.Component<
      'home.how-it-works-step-animate-text',
      true
    >;
    points: Attribute.Component<'home.how-it-works-step-points', true>;
    tooltip_text: Attribute.Text;
    how_it_work_buttons: Attribute.Component<'common.button', true>;
  };
}

export interface HomeHowItWorks extends Schema.Component {
  collectionName: 'components_home_how_it_works';
  info: {
    displayName: 'How It Works';
  };
  attributes: {
    title: Attribute.String;
  };
}

export interface HomeTestimonial extends Schema.Component {
  collectionName: 'components_home_testimonials';
  info: {
    displayName: 'Testimonial';
  };
  attributes: {
    title: Attribute.String;
    testimonials: Attribute.Relation<
      'home.testimonial',
      'oneToMany',
      'api::testimonial.testimonial'
    >;
  };
}

export interface HomeTopSection extends Schema.Component {
  collectionName: 'components_home_top_sections';
  info: {
    displayName: 'Top section';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    videoUrl: Attribute.String;
    background_image: Attribute.Media;
    mobile_background_image: Attribute.Media;
    button1_text: Attribute.String;
    button1_link: Attribute.String;
    button2_text: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    bg_video: Attribute.Media;
    show_video_or_image: Attribute.Enumeration<['video', 'image']> &
      Attribute.DefaultTo<'image'>;
  };
}

export interface KnowledgeBase3CardCtaItem extends Schema.Component {
  collectionName: 'components_knowledge_base_3_card_cta_items';
  info: {
    displayName: '3 Card Cta Item';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    link_title: Attribute.String;
    link_href: Attribute.Text;
    link_target: Attribute.Enumeration<['_blank', '_self']>;
  };
}

export interface KnowledgeBase3CardsCtas extends Schema.Component {
  collectionName: 'components_knowledge_base_3_cards_ctas';
  info: {
    displayName: '3 Cards Ctas';
    description: '';
  };
  attributes: {
    card: Attribute.Component<'knowledge-base.3-card-cta-item', true> &
      Attribute.SetMinMax<{
        min: 1;
        max: 3;
      }>;
  };
}

export interface KnowledgeBaseFeaturedFaqItem extends Schema.Component {
  collectionName: 'components_knowledge_base_featured_faq_items';
  info: {
    displayName: 'Featured FAQ Item';
  };
  attributes: {
    question: Attribute.Text;
    answer: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface KnowledgeBaseFeaturedFaq extends Schema.Component {
  collectionName: 'components_knowledge_base_featured_faqs';
  info: {
    displayName: 'Featured FAQ';
  };
  attributes: {
    title: Attribute.String;
    faq: Attribute.Component<'knowledge-base.featured-faq-item', true>;
  };
}

export interface KnowledgeBaseTopics extends Schema.Component {
  collectionName: 'components_topics';
  info: {
    displayName: 'Knowledge Base Topics';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    knowledge_bases: Attribute.Relation<
      'knowledge-base.topics',
      'oneToMany',
      'api::knowledge-base.knowledge-base'
    >;
  };
}

export interface LabsApproachCards extends Schema.Component {
  collectionName: 'components_labs_approach_cards';
  info: {
    displayName: 'Approach Cards';
    description: '';
  };
  attributes: {
    background_video: Attribute.Media;
    background_color: Attribute.Text;
    icon: Attribute.Media;
    title: Attribute.String;
    button_link: Attribute.String;
    description: Attribute.String;
  };
}

export interface LabsApproachSection extends Schema.Component {
  collectionName: 'components_labs_approach_sections';
  info: {
    displayName: 'Approach Section';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    cards: Attribute.Component<'labs.approach-cards', true>;
  };
}

export interface LabsCta extends Schema.Component {
  collectionName: 'components_labs_ctas';
  info: {
    displayName: 'CTA';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    labs_CTA_button: Attribute.Component<'common.button'>;
    background_video: Attribute.Media;
    button_type: Attribute.Enumeration<['link', 'form']> &
      Attribute.DefaultTo<'link'>;
  };
}

export interface LabsEvidenceBasedStrategyFeatures extends Schema.Component {
  collectionName: 'components_labs_evidence_based_strategy_features';
  info: {
    displayName: 'Evidence Based Strategy Features';
  };
  attributes: {
    icon: Attribute.Media;
    title: Attribute.String;
    pill: Attribute.String;
    image: Attribute.Media;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface LabsEvidenceBasedStrategy extends Schema.Component {
  collectionName: 'components_labs_evidence_based_strategies';
  info: {
    displayName: 'Evidence Based Strategy';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    features: Attribute.Component<
      'labs.evidence-based-strategy-features',
      true
    >;
  };
}

export interface LabsFaqList extends Schema.Component {
  collectionName: 'components_labs_faq_lists';
  info: {
    displayName: 'faq_list';
  };
  attributes: {
    question: Attribute.String;
    answer: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface LabsFaq extends Schema.Component {
  collectionName: 'components_labs_faqs';
  info: {
    displayName: 'FAQ';
  };
  attributes: {
    title: Attribute.String;
    faq_list: Attribute.Component<'labs.faq-list', true>;
  };
}

export interface LabsHeroSection extends Schema.Component {
  collectionName: 'components_labs_hero_sections';
  info: {
    displayName: 'Hero Section';
    description: '';
  };
  attributes: {
    sub_title: Attribute.String;
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    labs_hero_section_button: Attribute.Component<'common.button'>;
    background_video: Attribute.Media;
    button_type: Attribute.Enumeration<['link', 'form']> &
      Attribute.DefaultTo<'link'>;
  };
}

export interface LabsInsideLabsFeatures extends Schema.Component {
  collectionName: 'components_labs_inside_labs_features';
  info: {
    displayName: 'Inside Labs Features';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    icon: Attribute.Media;
  };
}

export interface LabsInsideLabsSection extends Schema.Component {
  collectionName: 'components_labs_inside_labs_sections';
  info: {
    displayName: 'Inside Labs Section';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    features: Attribute.Component<'labs.inside-labs-features', true>;
  };
}

export interface LabsModelsAndFrameworksList extends Schema.Component {
  collectionName: 'components_labs_M_F_lists';
  info: {
    displayName: 'Models and Frameworks List';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    icon: Attribute.Media;
    image: Attribute.Media;
  };
}

export interface LabsModelsAndFrameworksSection extends Schema.Component {
  collectionName: 'components_labs_M_F_sections';
  info: {
    displayName: 'Models and Frameworks Section';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    list: Attribute.Component<'labs.models-and-frameworks-list', true>;
  };
}

export interface LabsNeuroScience extends Schema.Component {
  collectionName: 'components_labs_neuro_sciences';
  info: {
    displayName: 'Neuro Science';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    bg_design_image: Attribute.Media;
    features: Attribute.Component<'labs.neuro-scince-features', true>;
  };
}

export interface LabsNeuroScinceFeatures extends Schema.Component {
  collectionName: 'components_labs_neuro_scince_features';
  info: {
    displayName: 'Neuro Scince Features';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface LabsScienceBackedApproachCards extends Schema.Component {
  collectionName: 'components_labs_science_backed_approach_cards';
  info: {
    displayName: 'Science Backed Approach Cards';
  };
  attributes: {
    show_content_or_image: Attribute.Enumeration<['content', 'image']> &
      Attribute.DefaultTo<'content'>;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    color: Attribute.String;
    image: Attribute.Media;
  };
}

export interface LabsScienceBackedApproach extends Schema.Component {
  collectionName: 'components_labs_science_backed_approaches';
  info: {
    displayName: 'Science Backed Approach';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbarBaloon';
        }
      >;
    cards: Attribute.Component<'labs.science-backed-approach-cards', true> &
      Attribute.SetMinMax<{
        min: 8;
        max: 8;
      }>;
  };
}

export interface LabsStatsSection extends Schema.Component {
  collectionName: 'components_labs_stats_sections';
  info: {
    displayName: 'Stats Section';
  };
  attributes: {
    sub_title: Attribute.String;
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface LandingPageAdventure extends Schema.Component {
  collectionName: 'components_landing_page_adventures';
  info: {
    displayName: 'Adventure';
  };
  attributes: {
    hero_section: Attribute.Component<'adventure.hero-section'>;
    brands: Attribute.Component<'masterclass.template-4-brands'>;
    experience: Attribute.Component<'live-session.experience-section'>;
    certified: Attribute.Component<'adventure.certified'>;
    pay_offs_section: Attribute.Component<'case-study.pay-offs-section'>;
    stripe: Attribute.Component<'adventure.stripe'>;
    testimonial_section: Attribute.Component<'home.testimonial'>;
    faq: Attribute.Component<'masterclass.faq'>;
    form: Attribute.Component<'adventure.form'>;
  };
}

export interface LandingPageLiveSession extends Schema.Component {
  collectionName: 'components_landing_page_live_sessions';
  info: {
    displayName: 'Live-Session';
  };
  attributes: {
    Banner: Attribute.Component<'live-session.hero-banner'>;
    brands: Attribute.Component<'masterclass.template-4-brands'>;
    experience: Attribute.Component<'live-session.experience-section'>;
    join: Attribute.Component<'live-session.join-section'>;
    stripe_image: Attribute.Media & Attribute.Required;
    adventure: Attribute.Component<'live-session.adventure-section'>;
    join_stripe: Attribute.Component<'live-session.join-stripe'>;
    testimonial_section: Attribute.Component<'home.testimonial'>;
    faq: Attribute.Component<'masterclass.faq'>;
    form: Attribute.Component<'live-session.form'>;
  };
}

export interface LandingPageMasterclass extends Schema.Component {
  collectionName: 'components_landing_page_masterclasses';
  info: {
    displayName: 'masterclass';
    description: '';
  };
  attributes: {
    animations: Attribute.Component<'masterclass.animations'>;
    show_custom_navbar: Attribute.Boolean & Attribute.DefaultTo<false>;
    show_intro_animation: Attribute.Boolean & Attribute.DefaultTo<true>;
    custom_navbar: Attribute.Component<'masterclass.custom-navbar'>;
    agenda: Attribute.Component<'masterclass.join'>;
    industry_experts: Attribute.Component<'masterclass.industry-experts'>;
    count: Attribute.Component<'masterclass.count', true>;
    brands: Attribute.Component<'masterclass.brands'>;
    certifications: Attribute.Component<'masterclass.certifications'>;
    register: Attribute.Component<'masterclass.register'>;
    faq: Attribute.Component<'masterclass.faq'>;
  };
}

export interface LandingPageTemplate2 extends Schema.Component {
  collectionName: 'components_landing_page_template_2s';
  info: {
    displayName: 'template-2';
  };
  attributes: {
    animations: Attribute.Component<'masterclass.template-2-animations'>;
    show_custom_navbar: Attribute.Boolean & Attribute.DefaultTo<false>;
    show_intro_animation: Attribute.Boolean & Attribute.DefaultTo<true>;
    custom_navbar: Attribute.Component<'masterclass.custom-navbar'>;
    agenda: Attribute.Component<'masterclass.join'>;
    content: Attribute.Component<'masterclass.weeks-session'>;
    hosts: Attribute.Component<'masterclass.industry-experts'>;
    count: Attribute.Component<'masterclass.count', true>;
    brands: Attribute.Component<'masterclass.brands'>;
    testimonials: Attribute.Component<'masterclass.certifications'>;
    get_certified_now: Attribute.Component<'masterclass.get-certified-now'>;
    register: Attribute.Component<'masterclass.register'>;
    new_register: Attribute.Component<'masterclass.new-register'>;
    faq: Attribute.Component<'masterclass.faq'>;
  };
}

export interface LandingPageTemplate4 extends Schema.Component {
  collectionName: 'components_landing_page_template_4s';
  info: {
    displayName: 'template-4';
  };
  attributes: {
    first_section: Attribute.Component<'masterclass.template-4-first-section'>;
    why_choose: Attribute.Component<'masterclass.template-4-first-section'>;
    agenda: Attribute.Component<'masterclass.template-4-agenda'>;
    hosts: Attribute.Component<'masterclass.industry-experts'>;
    count: Attribute.Component<'masterclass.count', true>;
    brands: Attribute.Component<'masterclass.template-4-brands'>;
    what_you_get: Attribute.Component<'masterclass.what-you-get'>;
    consult_section: Attribute.Component<'masterclass.consult'>;
    content: Attribute.Component<'masterclass.weeks-session'>;
    case_stalwart: Attribute.Component<'masterclass.case-study-stalwart'>;
    core: Attribute.Component<'masterclass.core-advantage'>;
    testimonials: Attribute.Component<'masterclass.certifications'>;
    get_certified_now: Attribute.Component<'masterclass.get-certified-now'>;
    faq: Attribute.Component<'masterclass.faq'>;
    form: Attribute.Component<'masterclass.template-4-form'>;
  };
}

export interface LandingPageTemplate5 extends Schema.Component {
  collectionName: 'components_landing_page_template_5s';
  info: {
    displayName: 'template-5';
  };
  attributes: {
    content: Attribute.Component<'masterclass.template5-content'>;
    pay_offs_section: Attribute.Component<'case-study.pay-offs-section'>;
    get_started: Attribute.Component<'case-study.get-started'>;
  };
}

export interface LandingPageTemplate3 extends Schema.Component {
  collectionName: 'components_landing_page_template3s';
  info: {
    displayName: 'template3';
  };
  attributes: {
    aferr_model: Attribute.Component<'masterclass.aferr-model'>;
    advantages: Attribute.Component<'masterclass.template-3-advantages'>;
    preview: Attribute.Component<'masterclass.template3-preview'>;
    dive_deep: Attribute.Component<'masterclass.dive-deep'>;
    why_download: Attribute.Component<'masterclass.why-download'>;
    brands: Attribute.Component<'masterclass.brands'>;
    faq: Attribute.Component<'masterclass.faq'>;
  };
}

export interface LiveSessionAdventureSection extends Schema.Component {
  collectionName: 'components_live_session_adventure_sections';
  info: {
    displayName: 'adventure_section';
    icon: 'arrowRight';
  };
  attributes: {
    title: Attribute.Text;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media & Attribute.Required;
    adventure_cards: Attribute.Component<'live-session.live-card', true>;
  };
}

export interface LiveSessionExperienceSection extends Schema.Component {
  collectionName: 'components_live_session_experience_sections';
  info: {
    displayName: 'experience_section';
    icon: 'arrowRight';
  };
  attributes: {
    title: Attribute.Text;
    experience_cards: Attribute.Component<'live-session.live-card', true>;
  };
}

export interface LiveSessionForm extends Schema.Component {
  collectionName: 'components_live_session_form';
  info: {
    displayName: 'live session form';
  };
  attributes: {
    title: Attribute.String;
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
  };
}

export interface LiveSessionHeroBanner extends Schema.Component {
  collectionName: 'components_live_session_hero_banners';
  info: {
    displayName: 'hero-banner';
    icon: 'arrowUp';
    description: '';
  };
  attributes: {
    title: Attribute.Text;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    images: Attribute.Component<'live-session.swiper-images', true>;
    banner_image: Attribute.Media & Attribute.Required;
    button: Attribute.Component<'common.button'>;
    highlighted_title: Attribute.String;
  };
}

export interface LiveSessionJoinSection extends Schema.Component {
  collectionName: 'components_live_session_join_sections';
  info: {
    displayName: 'join_section';
    icon: 'arrowRight';
  };
  attributes: {
    title: Attribute.Text;
    join_cards: Attribute.Component<'live-session.live-card', true>;
  };
}

export interface LiveSessionJoinStripe extends Schema.Component {
  collectionName: 'components_live_session_join_stripes';
  info: {
    displayName: 'join-stripe';
    icon: 'arrowUp';
  };
  attributes: {
    title: Attribute.Text;
    image: Attribute.Media & Attribute.Required;
    button: Attribute.Component<'common.button'>;
  };
}

export interface LiveSessionLiveCard extends Schema.Component {
  collectionName: 'components_live_session_live_cards';
  info: {
    displayName: 'live_card';
    icon: 'arrowRight';
  };
  attributes: {
    title: Attribute.Text;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    icon: Attribute.Media & Attribute.Required;
  };
}

export interface LiveSessionSwiperImages extends Schema.Component {
  collectionName: 'components_live_session_swiper_images';
  info: {
    displayName: 'swiper-images';
    icon: 'arrowRight';
  };
  attributes: {
    image: Attribute.Media & Attribute.Required;
  };
}

export interface MasterclassAdvantagesList extends Schema.Component {
  collectionName: 'components_masterclass_advantages_lists';
  info: {
    displayName: 'advantages_list';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
  };
}

export interface MasterclassAdvantages extends Schema.Component {
  collectionName: 'components_masterclass_advantages';
  info: {
    displayName: 'advantages';
    icon: 'connector';
  };
  attributes: {
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface MasterclassAferrHero extends Schema.Component {
  collectionName: 'components_masterclass_aferr_heroes';
  info: {
    displayName: 'Aferr Hero';
    description: 'Hero section for Aferr Master landing page';
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    subtitle: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    hero_image: Attribute.Media;
    cta_button: Attribute.Component<'common.button'>;
    secondary_button: Attribute.Component<'common.button'>;
    hero_video: Attribute.String;
    hero_stats: Attribute.Component<'masterclass.count', true>;
  };
}

export interface MasterclassAferrModel extends Schema.Component {
  collectionName: 'components_masterclass_aferr_model_s';
  info: {
    displayName: 'Aferr Model ';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    aferr_model_button: Attribute.Component<'common.button'>;
    image: Attribute.Media;
  };
}

export interface MasterclassAnimations extends Schema.Component {
  collectionName: 'components_masterclass_animations';
  info: {
    displayName: 'Animations';
    description: '';
  };
  attributes: {
    bg_img_1: Attribute.Media;
    bg_img_2: Attribute.Media;
    evivve_logo: Attribute.Media;
    fav_logo: Attribute.Media;
    e_logo: Attribute.Media;
    masterclass_logo: Attribute.Media;
    mobile_logo: Attribute.Media;
    screen1: Attribute.Component<'masterclass.screen1'>;
    screen2: Attribute.Component<'masterclass.screen2'>;
    screen3: Attribute.Component<'masterclass.screen3'>;
    screen4_button_text: Attribute.String;
  };
}

export interface MasterclassBrands extends Schema.Component {
  collectionName: 'components_masterclass_brands';
  info: {
    displayName: 'brands';
    description: '';
  };
  attributes: {
    title1: Attribute.String;
    brands1: Attribute.Relation<
      'masterclass.brands',
      'oneToMany',
      'api::logo.logo'
    >;
    brands2: Attribute.Relation<
      'masterclass.brands',
      'oneToMany',
      'api::logo.logo'
    >;
    brands3: Attribute.Relation<
      'masterclass.brands',
      'oneToMany',
      'api::logo.logo'
    >;
    title2: Attribute.String;
    title_icon: Attribute.String;
  };
}

export interface MasterclassCaseStudyStalwart extends Schema.Component {
  collectionName: 'components_masterclass_case_study_stalwarts';
  info: {
    displayName: 'Case study stalwart';
    icon: 'cog';
  };
  attributes: {
    title: Attribute.String;
    display: Attribute.Boolean;
    case_study: Attribute.Component<'masterclass.case-study', true>;
  };
}

export interface MasterclassCaseStudy extends Schema.Component {
  collectionName: 'components_masterclass_case_studies';
  info: {
    displayName: 'Case Study';
    icon: 'cog';
  };
  attributes: {
    category: Attribute.String;
    study_title: Attribute.String;
    image: Attribute.Media;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    read_more: Attribute.Component<'common.button'>;
  };
}

export interface MasterclassCertificationsCard extends Schema.Component {
  collectionName: 'components_masterclass_certifications_cards';
  info: {
    displayName: 'certifications_card';
  };
  attributes: {
    name: Attribute.String;
    description: Attribute.Text;
    image: Attribute.Media;
    bg_color: Attribute.String;
  };
}

export interface MasterclassCertifications extends Schema.Component {
  collectionName: 'components_masterclass_certifications';
  info: {
    displayName: 'certifications';
  };
  attributes: {
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    display: Attribute.Boolean;
    cards: Attribute.Component<'masterclass.certifications-card', true>;
  };
}

export interface MasterclassConsultCards extends Schema.Component {
  collectionName: 'components_masterclass_consult_cards';
  info: {
    displayName: 'consult cards';
    icon: 'earth';
  };
  attributes: {
    card_title: Attribute.String;
    image: Attribute.Media;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    list: Attribute.Component<'masterclass.phase-list', true>;
    sub_title: Attribute.String;
  };
}

export interface MasterclassConsult extends Schema.Component {
  collectionName: 'components_masterclass_consults';
  info: {
    displayName: 'consult';
    icon: 'check';
  };
  attributes: {
    title: Attribute.String;
    display: Attribute.Boolean;
    default_images: Attribute.Media;
    active_images: Attribute.Media;
    cards: Attribute.Component<'masterclass.consult-cards', true>;
  };
}

export interface MasterclassCoreAdvantage extends Schema.Component {
  collectionName: 'components_masterclass_core_advantage';
  info: {
    displayName: 'Core advantage';
    icon: 'command';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    display: Attribute.Boolean;
    image: Attribute.Media;
    list: Attribute.Component<'masterclass.advantages', true>;
    core_button: Attribute.Component<'common.button'>;
  };
}

export interface MasterclassCount extends Schema.Component {
  collectionName: 'components_masterclass_counts';
  info: {
    displayName: 'count';
  };
  attributes: {
    count_number: Attribute.String;
    count_text: Attribute.String;
  };
}

export interface MasterclassCustomNavbar extends Schema.Component {
  collectionName: 'components_masterclass_custom_navbars';
  info: {
    displayName: 'custom navbar';
  };
  attributes: {
    links: Attribute.JSON;
  };
}

export interface MasterclassDiveDeepList extends Schema.Component {
  collectionName: 'components_masterclass_dive_deep_lists';
  info: {
    displayName: 'dive deep list';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface MasterclassDiveDeep extends Schema.Component {
  collectionName: 'components_masterclass_dive_deeps';
  info: {
    displayName: 'dive deep';
  };
  attributes: {
    title: Attribute.String;
    dive_deep_list: Attribute.Component<'masterclass.dive-deep-list', true>;
  };
}

export interface MasterclassExpertsList extends Schema.Component {
  collectionName: 'components_masterclass_experts_lists';
  info: {
    displayName: 'experts list';
    description: '';
  };
  attributes: {
    name: Attribute.String;
    designation: Attribute.String;
    image: Attribute.Media;
    description: Attribute.Text;
    linkedin_url: Attribute.String;
  };
}

export interface MasterclassFaqList extends Schema.Component {
  collectionName: 'components_masterclass_faq_lists';
  info: {
    displayName: 'faq list';
  };
  attributes: {
    question: Attribute.String;
    answer: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface MasterclassFaq extends Schema.Component {
  collectionName: 'components_masterclass_faqs';
  info: {
    displayName: 'faq';
  };
  attributes: {
    title: Attribute.String;
    display: Attribute.Boolean;
    faq_list: Attribute.Component<'masterclass.faq-list', true>;
  };
}

export interface MasterclassGetCertifiedNow extends Schema.Component {
  collectionName: 'components_masterclass_get_certified_nows';
  info: {
    displayName: 'get certified now';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    display: Attribute.Boolean;
    list: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    get_certified_now_button: Attribute.Component<'common.button'>;
    button_type: Attribute.Enumeration<['link', 'popup']> &
      Attribute.DefaultTo<'link'>;
  };
}

export interface MasterclassIndustryExperts extends Schema.Component {
  collectionName: 'components_masterclass_industry_experts';
  info: {
    displayName: 'industry experts';
  };
  attributes: {
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    experts_list: Attribute.Component<'masterclass.experts-list', true>;
  };
}

export interface MasterclassJoin extends Schema.Component {
  collectionName: 'components_masterclass_joins';
  info: {
    displayName: 'join';
  };
  attributes: {
    title: Attribute.String;
    image: Attribute.Media;
    what_you_can_expect_title: Attribute.String;
    what_you_can_expect_list: Attribute.Component<
      'masterclass.what-you-can-expect-list',
      true
    >;
    time_and_date: Attribute.Component<'masterclass.when-and-where'>;
  };
}

export interface MasterclassNewRegister extends Schema.Component {
  collectionName: 'components_masterclass_new_register_s';
  info: {
    displayName: 'new register ';
  };
  attributes: {
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
    title: Attribute.String;
    image: Attribute.Media;
    quote: Attribute.Text;
    company_image: Attribute.Media;
    name: Attribute.String;
    designation: Attribute.String;
    brands_title: Attribute.String;
    brands: Attribute.Relation<
      'masterclass.new-register',
      'oneToMany',
      'api::logo.logo'
    >;
  };
}

export interface MasterclassPhaseList extends Schema.Component {
  collectionName: 'components_masterclass_phase_lists';
  info: {
    displayName: 'phase list';
    icon: 'bold';
  };
  attributes: {
    data: Attribute.Text;
  };
}

export interface MasterclassRegister extends Schema.Component {
  collectionName: 'components_masterclass_registers';
  info: {
    displayName: 'register';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    register_button: Attribute.Component<'common.button'>;
    zoho_form_type: Attribute.Enumeration<['button', 'form']> &
      Attribute.DefaultTo<'button'>;
    register_form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
  };
}

export interface MasterclassScreen1 extends Schema.Component {
  collectionName: 'components_masterclass_screen1s';
  info: {
    displayName: 'screen1';
  };
  attributes: {
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    button_text: Attribute.String;
    image: Attribute.Media;
  };
}

export interface MasterclassScreen2 extends Schema.Component {
  collectionName: 'components_masterclass_screen2s';
  info: {
    displayName: 'screen2';
  };
  attributes: {
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    button_text: Attribute.String;
    image: Attribute.Media;
  };
}

export interface MasterclassScreen3 extends Schema.Component {
  collectionName: 'components_masterclass_screen3s';
  info: {
    displayName: 'screen3';
    description: '';
  };
  attributes: {
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    date: Attribute.Date;
    button_text: Attribute.String;
    video: Attribute.Media;
    time: Attribute.String;
    video_thumbnail: Attribute.Media;
  };
}

export interface MasterclassTemplate2Animations extends Schema.Component {
  collectionName: 'components_masterclass_t_2_animations';
  info: {
    displayName: 't-2-animations';
    description: '';
  };
  attributes: {
    bg_img_1: Attribute.Media;
    bg_img_2: Attribute.Media;
    evivve_logo: Attribute.Media;
    fav_logo: Attribute.Media;
    e_logo: Attribute.Media;
    masterclass_logo: Attribute.Media;
    mobile_logo: Attribute.Media;
    screen1: Attribute.Component<'masterclass.screen1'>;
    screen2: Attribute.Component<'masterclass.screen2'>;
    screen3: Attribute.Component<'template-2.screen-3'>;
    screen4_button_text: Attribute.String;
  };
}

export interface MasterclassTemplate3Advantages extends Schema.Component {
  collectionName: 'components_masterclass_template3_advantages';
  info: {
    displayName: 'Template 3 Advantages';
  };
  attributes: {
    title: Attribute.String;
    advantages_list: Attribute.Component<'masterclass.advantages-list', true>;
  };
}

export interface MasterclassTemplate4Agenda extends Schema.Component {
  collectionName: 'components_masterclass_template_4_agenda';
  info: {
    displayName: 'template 4 agenda';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    upcoming_programs_title: Attribute.String;
    upcoming_programs: Attribute.Component<
      'masterclass.upcoming-program',
      true
    >;
  };
}

export interface MasterclassTemplate4Animations extends Schema.Component {
  collectionName: 'components_masterclass_t_4_animations';
  info: {
    displayName: 't-4-animations';
    description: '';
  };
  attributes: {
    bg_img_1: Attribute.Media;
    bg_img_2: Attribute.Media;
    evivve_logo: Attribute.Media;
    fav_logo: Attribute.Media;
    e_logo: Attribute.Media;
    masterclass_logo: Attribute.Media;
    mobile_logo: Attribute.Media;
    screen1: Attribute.Component<'masterclass.screen1'>;
    screen2: Attribute.Component<'masterclass.screen2'>;
  };
}

export interface MasterclassTemplate4Brands extends Schema.Component {
  collectionName: 'components_masterclass_template_4_brands';
  info: {
    displayName: 'template 4 brands';
  };
  attributes: {
    title: Attribute.String;
    brands: Attribute.Relation<
      'masterclass.template-4-brands',
      'oneToMany',
      'api::logo.logo'
    >;
  };
}

export interface MasterclassTemplate4FirstSection extends Schema.Component {
  collectionName: 'components_masterclass_t4_first_sections';
  info: {
    displayName: 'template-4-first-section';
  };
  attributes: {
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    first_section_button: Attribute.Component<'common.button'>;
    button_type: Attribute.Enumeration<['link', 'popup']> &
      Attribute.DefaultTo<'link'>;
    image: Attribute.Media;
  };
}

export interface MasterclassTemplate4Form extends Schema.Component {
  collectionName: 'components_masterclass_t_4_form';
  info: {
    displayName: 'template 4 form';
  };
  attributes: {
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
  };
}

export interface MasterclassTemplate3Preview extends Schema.Component {
  collectionName: 'components_masterclass_template3_previews';
  info: {
    displayName: 'template3 preview';
  };
  attributes: {
    title: Attribute.String;
    preview_list: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    preview_form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
    button_text: Attribute.String;
    image: Attribute.Media;
  };
}

export interface MasterclassTemplate5Content extends Schema.Component {
  collectionName: 'components_masterclass_template5_contents';
  info: {
    displayName: 'template5 content';
  };
  attributes: {
    title: Attribute.String;
    image: Attribute.Media;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onsubmit: Attribute.String;
    form_onload: Attribute.String;
    video: Attribute.String;
    video_description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface MasterclassUpcomingProgram extends Schema.Component {
  collectionName: 'components_masterclass_upcoming_programs';
  info: {
    displayName: 'upcoming program';
    description: '';
  };
  attributes: {
    month: Attribute.String;
    level: Attribute.String;
    dates: Attribute.String;
    location: Attribute.String;
    time: Attribute.String;
    show_tagline: Attribute.Boolean & Attribute.DefaultTo<false>;
    tagline: Attribute.String;
    upcoming_program_button: Attribute.Component<'common.button'>;
    button_type: Attribute.Enumeration<['link', 'popup']> &
      Attribute.DefaultTo<'link'>;
    overwrite_bgcolor: Attribute.Boolean & Attribute.DefaultTo<false>;
    bgcolor: Attribute.String;
    divider_color: Attribute.String;
  };
}

export interface MasterclassWeeksSessionCard extends Schema.Component {
  collectionName: 'components_masterclass_weeks_session_cards';
  info: {
    displayName: 'weeks session card';
  };
  attributes: {
    title: Attribute.String;
    list: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface MasterclassWeeksSession extends Schema.Component {
  collectionName: 'components_masterclass_weeks_sessions';
  info: {
    displayName: 'weeks session';
  };
  attributes: {
    title: Attribute.String;
    display: Attribute.Boolean;
    weeks_session_card: Attribute.Component<
      'masterclass.weeks-session-card',
      true
    >;
  };
}

export interface MasterclassWhatYouCanExpectList extends Schema.Component {
  collectionName: 'components_masterclass_what_you_can_expect_lists';
  info: {
    displayName: 'what you can expect list';
  };
  attributes: {
    list: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface MasterclassWhatYouGetList extends Schema.Component {
  collectionName: 'components_masterclass_what_you_get_lists';
  info: {
    displayName: 'what you get list';
  };
  attributes: {
    icon: Attribute.Media;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    button: Attribute.Component<'common.button'>;
  };
}

export interface MasterclassWhatYouGet extends Schema.Component {
  collectionName: 'components_masterclass_what_you_gets';
  info: {
    displayName: 'what you get';
  };
  attributes: {
    title: Attribute.String;
    what_you_get_list: Attribute.Component<
      'masterclass.what-you-get-list',
      true
    >;
  };
}

export interface MasterclassWhenAndWhere extends Schema.Component {
  collectionName: 'components_masterclass_when_and_wheres';
  info: {
    displayName: 'when and where';
  };
  attributes: {
    title: Attribute.String;
    date: Attribute.Date;
    template2_date: Attribute.Text;
    time: Attribute.String;
    image: Attribute.Media;
  };
}

export interface MasterclassWhyDownloadList extends Schema.Component {
  collectionName: 'components_masterclass_why_download_lists';
  info: {
    displayName: 'why download list';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface MasterclassWhyDownload extends Schema.Component {
  collectionName: 'components_masterclass_why_downloads';
  info: {
    displayName: 'why download';
  };
  attributes: {
    title: Attribute.String;
    why_dowload_list: Attribute.Component<
      'masterclass.why-download-list',
      true
    >;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface NewPlayNowBottomSection extends Schema.Component {
  collectionName: 'components_new_play_now_bottom_sections';
  info: {
    displayName: 'Bottom Section';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    title_highlight: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    new_play_now_bottom_section_button: Attribute.Component<'common.button'>;
    button_type: Attribute.Enumeration<['form', 'link']> &
      Attribute.DefaultTo<'link'>;
  };
}

export interface NewPlayNowFeatureCard extends Schema.Component {
  collectionName: 'components_new_play_now_feature_cards';
  info: {
    displayName: 'Feature Card';
  };
  attributes: {
    icon: Attribute.Media;
    title: Attribute.String;
    description: Attribute.Text;
  };
}

export interface NewPlayNowFeatureSection extends Schema.Component {
  collectionName: 'components_new_play_now_feature_sections';
  info: {
    displayName: 'Feature Section';
  };
  attributes: {
    title: Attribute.String;
    cards: Attribute.Component<'new-play-now.feature-card', true>;
  };
}

export interface NewPlayNowForm extends Schema.Component {
  collectionName: 'components_new_play_now_forms';
  info: {
    displayName: 'Form';
  };
  attributes: {
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
  };
}

export interface NewPlayNowGameListCard extends Schema.Component {
  collectionName: 'components_new_play_now_game_list_cards';
  info: {
    displayName: 'Game List Card';
    description: '';
  };
  attributes: {
    description: Attribute.Text;
    image: Attribute.Media;
    bg_design: Attribute.Media;
    bg_linear_color: Attribute.String;
    text_shadow_color: Attribute.String;
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface NewPlayNowGameListSection extends Schema.Component {
  collectionName: 'components_new_play_now_game_list_sections';
  info: {
    displayName: 'Game List Section';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    Cards: Attribute.Component<'new-play-now.game-list-card', true>;
  };
}

export interface NewPlayNowHeroSection extends Schema.Component {
  collectionName: 'components_new_play_now_hero_sections';
  info: {
    displayName: 'Hero Section';
    description: '';
  };
  attributes: {
    sub_title: Attribute.String;
    title: Attribute.String;
    new_play_now_hero_button: Attribute.Component<'common.button'>;
    image: Attribute.Media;
    button_type: Attribute.Enumeration<['form', 'link']> &
      Attribute.DefaultTo<'link'>;
  };
}

export interface NewPlayNowStepsCard extends Schema.Component {
  collectionName: 'components_new_play_now_steps_cards';
  info: {
    displayName: 'Steps Card';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    image: Attribute.Media;
  };
}

export interface NewPlayNowStepsSection extends Schema.Component {
  collectionName: 'components_new_play_now_steps_sections';
  info: {
    displayName: 'Steps Section';
  };
  attributes: {
    title: Attribute.String;
    cards: Attribute.Component<'new-play-now.steps-card', true>;
  };
}

export interface NewPlayNowWelcome extends Schema.Component {
  collectionName: 'components_new_play_now_welcomes';
  info: {
    displayName: 'Welcome';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    video: Attribute.Media;
  };
}

export interface NewPricingCreditsHeader extends Schema.Component {
  collectionName: 'components_new_pricing_credits_headers';
  info: {
    displayName: 'credits header';
  };
  attributes: {
    icon: Attribute.Media;
    title: Attribute.String;
  };
}

export interface NewPricingCredits extends Schema.Component {
  collectionName: 'components_new_pricing_credits';
  info: {
    displayName: 'credits';
    description: '';
  };
  attributes: {
    segment: Attribute.String;
    price: Attribute.String;
    discount: Attribute.String;
    discount_green_color_text: Attribute.Boolean & Attribute.DefaultTo<true>;
  };
}

export interface NewPricingFaq extends Schema.Component {
  collectionName: 'components_new_pricing_faqs';
  info: {
    displayName: 'faq';
  };
  attributes: {
    question: Attribute.Text;
    answer: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface NewPricingGetInTouch extends Schema.Component {
  collectionName: 'components_new_pricing_get_in_touches';
  info: {
    displayName: 'get in touch';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    get_in_touch_button: Attribute.Component<'common.button'>;
    image: Attribute.Media;
  };
}

export interface NewPricingHowCreditsWork extends Schema.Component {
  collectionName: 'components_new_pricing_how_credits_works';
  info: {
    displayName: 'how credits work';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    how_credits_work_button: Attribute.Component<'common.button'>;
    desktop_image: Attribute.Media;
    mobile_image: Attribute.Media;
  };
}

export interface NewPricingList extends Schema.Component {
  collectionName: 'components_new_pricing_lists';
  info: {
    displayName: 'list';
    description: '';
  };
  attributes: {
    text: Attribute.String;
  };
}

export interface NewPricingNewPricingCard extends Schema.Component {
  collectionName: 'components_new_pricing_new_pricing_cards';
  info: {
    displayName: 'new pricing card';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    list: Attribute.Component<'new-pricing.list', true>;
    new_pricing_card_button: Attribute.Component<'common.button'>;
    most_popular: Attribute.Boolean & Attribute.DefaultTo<false>;
    tag_line: Attribute.String;
    price_and_credits: Attribute.String;
  };
}

export interface NewsroomAward extends Schema.Component {
  collectionName: 'components_newsroom_awards';
  info: {
    displayName: 'award';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    name: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    award_button: Attribute.Component<'common.button'>;
    image: Attribute.Media;
  };
}

export interface NewsroomBrands extends Schema.Component {
  collectionName: 'components_newsroom_brands';
  info: {
    displayName: 'brands';
  };
  attributes: {
    title1: Attribute.String;
    title2: Attribute.String;
    title_icon: Attribute.String;
    brands1: Attribute.Relation<
      'newsroom.brands',
      'oneToMany',
      'api::logo.logo'
    >;
    brands2: Attribute.Relation<
      'newsroom.brands',
      'oneToMany',
      'api::logo.logo'
    >;
    brands3: Attribute.Relation<
      'newsroom.brands',
      'oneToMany',
      'api::logo.logo'
    >;
    brands_button: Attribute.Component<'common.button'>;
  };
}

export interface NewsroomFeatureData extends Schema.Component {
  collectionName: 'components_newsroom_feature_data';
  info: {
    displayName: 'feature data';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    publisher_name: Attribute.String;
    date: Attribute.Date;
    feature_button: Attribute.Component<'common.button'>;
    image: Attribute.Media;
  };
}

export interface NewsroomMediaCard extends Schema.Component {
  collectionName: 'components_newsroom_media_cards';
  info: {
    displayName: 'media card';
    description: '';
  };
  attributes: {
    publisher_name: Attribute.String;
    date: Attribute.Date;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    media_card_button: Attribute.Component<'common.button'>;
  };
}

export interface NewsroomSection1 extends Schema.Component {
  collectionName: 'components_newsroom_section1s';
  info: {
    displayName: 'Section1';
  };
  attributes: {
    title: Attribute.String;
    feature_data: Attribute.Component<'newsroom.feature-data'>;
    data: Attribute.Component<'newsroom.media-card', true>;
  };
}

export interface NewsroomSection2 extends Schema.Component {
  collectionName: 'components_newsroom_section2s';
  info: {
    displayName: 'section2';
  };
  attributes: {
    title: Attribute.String;
    award: Attribute.Component<'newsroom.award', true>;
  };
}

export interface NewsroomSection3 extends Schema.Component {
  collectionName: 'components_newsroom_section3s';
  info: {
    displayName: 'section3';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    press_releases: Attribute.Relation<
      'newsroom.section3',
      'oneToMany',
      'api::press-release.press-release'
    >;
  };
}

export interface NewsroomSection4 extends Schema.Component {
  collectionName: 'components_newsroom_section4s';
  info: {
    displayName: 'section4';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    section4_button: Attribute.Component<'common.button'>;
  };
}

export interface NewsroomVideoCard extends Schema.Component {
  collectionName: 'components_newsroom_video_cards';
  info: {
    displayName: 'video card';
  };
  attributes: {
    video_embed_src_link: Attribute.Text;
    title: Attribute.String;
  };
}

export interface NewsroomVideosSection extends Schema.Component {
  collectionName: 'components_newsroom_videos_sections';
  info: {
    displayName: 'videos section';
  };
  attributes: {
    title: Attribute.String;
    video_card: Attribute.Component<'newsroom.video-card', true>;
  };
}

export interface OnboardingScreen1 extends Schema.Component {
  collectionName: 'components_onboarding_screen1s';
  info: {
    displayName: 'Screen1';
  };
  attributes: {
    title: Attribute.String;
    button_text: Attribute.String;
    background_image: Attribute.Media;
    persons_image: Attribute.Media;
    mobile_background_image: Attribute.Media;
    mobile_persons_image: Attribute.Media;
  };
}

export interface OnboardingScreen2 extends Schema.Component {
  collectionName: 'components_onboarding_screen2s';
  info: {
    displayName: 'Screen2';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    button_text: Attribute.String;
    background_image: Attribute.Media;
    persons_image: Attribute.Media;
    mobile_persons_image: Attribute.Media;
    mobile_background_image: Attribute.Media;
  };
}

export interface OnboardingScreen3 extends Schema.Component {
  collectionName: 'components_onboarding_screen3s';
  info: {
    displayName: 'Screen3';
    description: '';
  };
  attributes: {
    background_image: Attribute.Media;
    mobile_background_image: Attribute.Media;
    title: Attribute.String;
    description: Attribute.RichText;
    button1_text: Attribute.String;
    button2_text: Attribute.String;
  };
}

export interface PopupPopup extends Schema.Component {
  collectionName: 'components_popup_popups';
  info: {
    displayName: 'Popup';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    image: Attribute.Media;
    popup_button: Attribute.Component<'common.button'>;
  };
}

export interface PricingBrandSection extends Schema.Component {
  collectionName: 'components_pricing_brand_sections';
  info: {
    displayName: 'Brand section';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    title2: Attribute.String;
    title_icon: Attribute.String;
    brands: Attribute.Relation<
      'pricing.brand-section',
      'oneToMany',
      'api::logo.logo'
    >;
    brands2: Attribute.Relation<
      'pricing.brand-section',
      'oneToMany',
      'api::logo.logo'
    >;
    brands3: Attribute.Relation<
      'pricing.brand-section',
      'oneToMany',
      'api::logo.logo'
    >;
    pricing_brands_button: Attribute.Component<'common.button'>;
  };
}

export interface PricingBrand extends Schema.Component {
  collectionName: 'components_pricing_brands';
  info: {
    displayName: 'brand';
  };
  attributes: {
    image: Attribute.Media;
  };
}

export interface PricingCommitment extends Schema.Component {
  collectionName: 'components_pricing_commitments';
  info: {
    displayName: 'commitment';
    description: '';
  };
  attributes: {
    name: Attribute.String;
    description: Attribute.String;
    icon: Attribute.String & Attribute.Required;
  };
}

export interface PricingContact extends Schema.Component {
  collectionName: 'components_pricing_contacts';
  info: {
    displayName: 'Contact';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    image: Attribute.Media;
    contact_section_button: Attribute.Component<'common.button'>;
  };
}

export interface PricingCustomPlan extends Schema.Component {
  collectionName: 'components_pricing_custom_plans';
  info: {
    displayName: 'Custom Plan';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    custom_plan_button: Attribute.Component<'common.button'>;
  };
}

export interface PricingFaqSection extends Schema.Component {
  collectionName: 'components_pricing_faq_sections';
  info: {
    displayName: 'faq section';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    faq: Attribute.Component<'pricing.faq', true>;
    heading_text: Attribute.String;
    link_text: Attribute.String;
    link_target: Attribute.Enumeration<['_self', '_blank']>;
    link_url: Attribute.String;
  };
}

export interface PricingFaq extends Schema.Component {
  collectionName: 'components_pricing_faqs';
  info: {
    displayName: 'Faq';
    description: '';
  };
  attributes: {
    question: Attribute.String;
    answer: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface PricingPlanFeatures extends Schema.Component {
  collectionName: 'components_pricing_plan_features';
  info: {
    displayName: 'Plan features';
    description: '';
  };
  attributes: {
    name: Attribute.String;
    applicable: Attribute.Boolean & Attribute.DefaultTo<true>;
    show_tooltip: Attribute.Boolean & Attribute.DefaultTo<false>;
    tooltip_text: Attribute.Text;
  };
}

export interface PricingPlan extends Schema.Component {
  collectionName: 'components_pricing_plans';
  info: {
    displayName: 'Plan';
    description: '';
  };
  attributes: {
    plan_name: Attribute.String;
    description: Attribute.String;
    most_popular: Attribute.Boolean & Attribute.DefaultTo<false>;
    plan_features: Attribute.Component<'pricing.plan-features', true>;
    price: Attribute.Component<'pricing.price', true>;
    price_text: Attribute.String;
    pricing_button: Attribute.Component<'common.button'>;
    isYearly: Attribute.Boolean &
      Attribute.Required &
      Attribute.DefaultTo<true>;
  };
}

export interface PricingPrice extends Schema.Component {
  collectionName: 'components_pricing_prices';
  info: {
    displayName: 'price';
  };
  attributes: {
    price: Attribute.Integer;
    plan_type: Attribute.String;
  };
}

export interface PricingTestimonialSection extends Schema.Component {
  collectionName: 'components_pricing_testimonial_sections';
  info: {
    displayName: 'Testimonial section';
  };
  attributes: {
    heading: Attribute.String;
    title: Attribute.String;
    testimonials: Attribute.Component<'pricing.testimonial', true>;
  };
}

export interface PricingTestimonial extends Schema.Component {
  collectionName: 'components_pricing_testimonials';
  info: {
    displayName: 'testimonial';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'custom';
        }
      >;
    by: Attribute.String;
    role: Attribute.String;
    image: Attribute.Media;
  };
}

export interface SharedMetaSocial extends Schema.Component {
  collectionName: 'components_shared_meta_socials';
  info: {
    displayName: 'metaSocial';
    icon: 'project-diagram';
    description: '';
  };
  attributes: {
    socialNetwork: Attribute.Enumeration<['Facebook', 'Twitter', 'LinkedIn']> &
      Attribute.Required;
    title: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        maxLength: 60;
      }>;
    description: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        maxLength: 65;
      }>;
    image: Attribute.Media;
  };
}

export interface SharedSeo extends Schema.Component {
  collectionName: 'components_shared_seos';
  info: {
    displayName: 'seo';
    icon: 'search';
  };
  attributes: {
    metaTitle: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        maxLength: 60;
      }>;
    metaDescription: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 50;
        maxLength: 160;
      }>;
    metaImage: Attribute.Media;
    metaSocial: Attribute.Component<'shared.meta-social', true>;
    keywords: Attribute.Text;
    metaRobots: Attribute.String;
    structuredData: Attribute.JSON;
    metaViewport: Attribute.String;
    canonicalURL: Attribute.String;
  };
}

export interface Template2Screen3 extends Schema.Component {
  collectionName: 'components_template_2_screen_3s';
  info: {
    displayName: 'screen 3';
  };
  attributes: {
    title: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    button_text: Attribute.String;
    video: Attribute.Media;
    video_thumbnail: Attribute.Media;
  };
}

export interface TestimonialBottomSection extends Schema.Component {
  collectionName: 'components_testimonial_bottom_sections';
  info: {
    displayName: 'Bottom section';
    description: '';
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    description: Attribute.Text;
    bottom_button: Attribute.Component<'common.button'>;
  };
}

export interface TestimonialBrandsSection extends Schema.Component {
  collectionName: 'components_testimonial_brands_sections';
  info: {
    displayName: 'Brands Section';
    description: '';
  };
  attributes: {
    title1: Attribute.String;
    title2: Attribute.String;
    title_icon: Attribute.String;
    brands: Attribute.Relation<
      'testimonial.brands-section',
      'oneToMany',
      'api::logo.logo'
    >;
    brands2: Attribute.Relation<
      'testimonial.brands-section',
      'oneToMany',
      'api::logo.logo'
    >;
    brands3: Attribute.Relation<
      'testimonial.brands-section',
      'oneToMany',
      'api::logo.logo'
    >;
  };
}

export interface TestimonialBrands extends Schema.Component {
  collectionName: 'components_testimonial_brands';
  info: {
    displayName: 'Brands';
  };
  attributes: {
    image: Attribute.Media;
  };
}

export interface TestimonialTestimonialsSection extends Schema.Component {
  collectionName: 'components_testimonial_testimonials_sections';
  info: {
    displayName: 'Testimonials section';
  };
  attributes: {
    title: Attribute.String;
  };
}

export interface UseCaseBanner extends Schema.Component {
  collectionName: 'components_use_case_banners';
  info: {
    displayName: 'banner';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    image: Attribute.Media;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    mobile_image: Attribute.Media;
  };
}

export interface UseCaseBenefitsDetails extends Schema.Component {
  collectionName: 'components_use_case_benefits_details';
  info: {
    displayName: 'benefits-details';
  };
  attributes: {
    image: Attribute.Media;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface UseCaseBenefits extends Schema.Component {
  collectionName: 'components_use_case_benefits';
  info: {
    displayName: 'benefits';
  };
  attributes: {
    title: Attribute.String;
    benefits_detials: Attribute.Component<'use-case.benefits-details', true>;
  };
}

export interface UseCaseCkeditor extends Schema.Component {
  collectionName: 'components_use_case_ckeditors';
  info: {
    displayName: 'ckeditor';
  };
  attributes: {
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface UseCaseExplore extends Schema.Component {
  collectionName: 'components_use_case_explores';
  info: {
    displayName: 'explore';
  };
  attributes: {
    image: Attribute.Media;
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

export interface UseCaseFeatures extends Schema.Component {
  collectionName: 'components_use_case_features';
  info: {
    displayName: 'features';
  };
  attributes: {
    title: Attribute.String;
    subTitle: Attribute.String;
    subTitle_highlight: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
  };
}

export interface UseCaseReadySection extends Schema.Component {
  collectionName: 'components_use_case_ready_sections';
  info: {
    displayName: 'ready-section';
    description: '';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    ready_section_button: Attribute.Component<'common.button'>;
  };
}

export interface UseCaseSwiperDescription extends Schema.Component {
  collectionName: 'components_use_case_swiper_descriptions';
  info: {
    displayName: 'swiper descriptions';
    description: '';
  };
  attributes: {
    swiper: Attribute.Component<'use-case.swiper', true>;
  };
}

export interface UseCaseSwiper extends Schema.Component {
  collectionName: 'components_use_case_swipers';
  info: {
    displayName: 'swiper';
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
  };
}

declare module '@strapi/types' {
  export module Shared {
    export interface Components {
      'about.bottom-section': AboutBottomSection;
      'about.history-points': AboutHistoryPoints;
      'about.history-section': AboutHistorySection;
      'about.member': AboutMember;
      'about.members-section': AboutMembersSection;
      'about.points': AboutPoints;
      'about.second-section': AboutSecondSection;
      'about.third-section': AboutThirdSection;
      'about.vision-and-mission-list': AboutVisionAndMissionList;
      'about.vision-and-mission': AboutVisionAndMission;
      'adventure.certified': AdventureCertified;
      'adventure.form': AdventureForm;
      'adventure.hero-section': AdventureHeroSection;
      'adventure.stripe': AdventureStripe;
      'author.social-link': AuthorSocialLink;
      'blog.bottom-section': BlogBottomSection;
      'blog.follow-us': BlogFollowUs;
      'blog.key-takeaways': BlogKeyTakeaways;
      'button.button-image-text': ButtonButtonImageText;
      'button.button-text': ButtonButtonText;
      'button.button': ButtonButton;
      'button.newsletter': ButtonNewsletter;
      'careers.bottom-section': CareersBottomSection;
      'careers.glassdoor-section': CareersGlassdoorSection;
      'careers.hero-section': CareersHeroSection;
      'careers.hero': CareersHero;
      'careers.project-list': CareersProjectList;
      'careers.why-choose-us-list': CareersWhyChooseUsList;
      'careers.why-choose-us': CareersWhyChooseUs;
      'case-study.aferr-case-studies-section': CaseStudyAferrCaseStudiesSection;
      'case-study.aferr-cta': CaseStudyAferrCta;
      'case-study.aferr-details-section-2': CaseStudyAferrDetailsSection2;
      'case-study.aferr-details-section': CaseStudyAferrDetailsSection;
      'case-study.aferr-final-cta': CaseStudyAferrFinalCta;
      'case-study.aferr-hero-section': CaseStudyAferrHeroSection;
      'case-study.aferr-stats-quadrant': CaseStudyAferrStatsQuadrant;
      'case-study.aferr-stats-section': CaseStudyAferrStatsSection;
      'case-study.aferr-video-carousel': CaseStudyAferrVideoCarousel;
      'case-study.audiobook-series-template': CaseStudyAudiobookSeriesTemplate;
      'case-study.brands': CaseStudyBrands;
      'case-study.case-study-category': CaseStudyCaseStudyCategory;
      'case-study.case-study-cta': CaseStudyCaseStudyCta;
      'case-study.case-study-item': CaseStudyCaseStudyItem;
      'case-study.case-study-series-template': CaseStudyCaseStudySeriesTemplate;
      'case-study.company-overview': CaseStudyCompanyOverview;
      'case-study.cta-header-section': CaseStudyCtaHeaderSection;
      'case-study.first-section-swiper-list': CaseStudyFirstSectionSwiperList;
      'case-study.get-started': CaseStudyGetStarted;
      'case-study.hero-section': CaseStudyHeroSection;
      'case-study.impact-stat': CaseStudyImpactStat;
      'case-study.impact': CaseStudyImpact;
      'case-study.journal-series-template': CaseStudyJournalSeriesTemplate;
      'case-study.key-challenges': CaseStudyKeyChallenges;
      'case-study.pay-offs-list': CaseStudyPayOffsList;
      'case-study.pay-offs-section': CaseStudyPayOffsSection;
      'case-study.references': CaseStudyReferences;
      'case-study.research-series-template': CaseStudyResearchSeriesTemplate;
      'case-study.solutions-banner': CaseStudySolutionsBanner;
      'case-study.solutions': CaseStudySolutions;
      'case-study.stat-card': CaseStudyStatCard;
      'case-study.team-section-list': CaseStudyTeamSectionList;
      'case-study.team-section': CaseStudyTeamSection;
      'case-study.testimonial': CaseStudyTestimonial;
      'case-study.testimonials': CaseStudyTestimonials;
      'common.app-download': CommonAppDownload;
      'common.banner': CommonBanner;
      'common.button': CommonButton;
      'common.download-app': CommonDownloadApp;
      'common.editor': CommonEditor;
      'common.footer': CommonFooter;
      'common.form-field': CommonFormField;
      'common.social-media': CommonSocialMedia;
      'common.spacing': CommonSpacing;
      'common.thank-you': CommonThankYou;
      'common.top-sticky-stripe': CommonTopStickyStripe;
      'common.zoho-form': CommonZohoForm;
      'contact.second-section': ContactSecondSection;
      'game-download.app-download-buttons': GameDownloadAppDownloadButtons;
      'game-download.app-download': GameDownloadAppDownload;
      'game-download.feature-list': GameDownloadFeatureList;
      'game-download.features': GameDownloadFeatures;
      'game-download.minimal-dashboard': GameDownloadMinimalDashboard;
      'game-download.overview-list': GameDownloadOverviewList;
      'game.banner': GameBanner;
      'game.brand-section': GameBrandSection;
      'game.brand': GameBrand;
      'game.button': GameButton;
      'game.download-app': GameDownloadApp;
      'game.facilitators-love-about-evivve': GameFacilitatorsLoveAboutEvivve;
      'game.play-category': GamePlayCategory;
      'game.testimonial': GameTestimonial;
      'glossary.dark-editor': GlossaryDarkEditor;
      'glossary.light-editor': GlossaryLightEditor;
      'glossary.reference': GlossaryReference;
      'home.brand': HomeBrand;
      'home.button': HomeButton;
      'home.community-points': HomeCommunityPoints;
      'home.community': HomeCommunity;
      'home.earning': HomeEarning;
      'home.get-started': HomeGetStarted;
      'home.how-it-works-step-animate-text': HomeHowItWorksStepAnimateText;
      'home.how-it-works-step-points': HomeHowItWorksStepPoints;
      'home.how-it-works-step': HomeHowItWorksStep;
      'home.how-it-works': HomeHowItWorks;
      'home.testimonial': HomeTestimonial;
      'home.top-section': HomeTopSection;
      'knowledge-base.3-card-cta-item': KnowledgeBase3CardCtaItem;
      'knowledge-base.3-cards-ctas': KnowledgeBase3CardsCtas;
      'knowledge-base.featured-faq-item': KnowledgeBaseFeaturedFaqItem;
      'knowledge-base.featured-faq': KnowledgeBaseFeaturedFaq;
      'knowledge-base.topics': KnowledgeBaseTopics;
      'labs.approach-cards': LabsApproachCards;
      'labs.approach-section': LabsApproachSection;
      'labs.cta': LabsCta;
      'labs.evidence-based-strategy-features': LabsEvidenceBasedStrategyFeatures;
      'labs.evidence-based-strategy': LabsEvidenceBasedStrategy;
      'labs.faq-list': LabsFaqList;
      'labs.faq': LabsFaq;
      'labs.hero-section': LabsHeroSection;
      'labs.inside-labs-features': LabsInsideLabsFeatures;
      'labs.inside-labs-section': LabsInsideLabsSection;
      'labs.models-and-frameworks-list': LabsModelsAndFrameworksList;
      'labs.models-and-frameworks-section': LabsModelsAndFrameworksSection;
      'labs.neuro-science': LabsNeuroScience;
      'labs.neuro-scince-features': LabsNeuroScinceFeatures;
      'labs.science-backed-approach-cards': LabsScienceBackedApproachCards;
      'labs.science-backed-approach': LabsScienceBackedApproach;
      'labs.stats-section': LabsStatsSection;
      'landing-page.adventure': LandingPageAdventure;
      'landing-page.live-session': LandingPageLiveSession;
      'landing-page.masterclass': LandingPageMasterclass;
      'landing-page.template-2': LandingPageTemplate2;
      'landing-page.template-4': LandingPageTemplate4;
      'landing-page.template-5': LandingPageTemplate5;
      'landing-page.template3': LandingPageTemplate3;
      'live-session.adventure-section': LiveSessionAdventureSection;
      'live-session.experience-section': LiveSessionExperienceSection;
      'live-session.form': LiveSessionForm;
      'live-session.hero-banner': LiveSessionHeroBanner;
      'live-session.join-section': LiveSessionJoinSection;
      'live-session.join-stripe': LiveSessionJoinStripe;
      'live-session.live-card': LiveSessionLiveCard;
      'live-session.swiper-images': LiveSessionSwiperImages;
      'masterclass.advantages-list': MasterclassAdvantagesList;
      'masterclass.advantages': MasterclassAdvantages;
      'masterclass.aferr-hero': MasterclassAferrHero;
      'masterclass.aferr-model': MasterclassAferrModel;
      'masterclass.animations': MasterclassAnimations;
      'masterclass.brands': MasterclassBrands;
      'masterclass.case-study-stalwart': MasterclassCaseStudyStalwart;
      'masterclass.case-study': MasterclassCaseStudy;
      'masterclass.certifications-card': MasterclassCertificationsCard;
      'masterclass.certifications': MasterclassCertifications;
      'masterclass.consult-cards': MasterclassConsultCards;
      'masterclass.consult': MasterclassConsult;
      'masterclass.core-advantage': MasterclassCoreAdvantage;
      'masterclass.count': MasterclassCount;
      'masterclass.custom-navbar': MasterclassCustomNavbar;
      'masterclass.dive-deep-list': MasterclassDiveDeepList;
      'masterclass.dive-deep': MasterclassDiveDeep;
      'masterclass.experts-list': MasterclassExpertsList;
      'masterclass.faq-list': MasterclassFaqList;
      'masterclass.faq': MasterclassFaq;
      'masterclass.get-certified-now': MasterclassGetCertifiedNow;
      'masterclass.industry-experts': MasterclassIndustryExperts;
      'masterclass.join': MasterclassJoin;
      'masterclass.new-register': MasterclassNewRegister;
      'masterclass.phase-list': MasterclassPhaseList;
      'masterclass.register': MasterclassRegister;
      'masterclass.screen1': MasterclassScreen1;
      'masterclass.screen2': MasterclassScreen2;
      'masterclass.screen3': MasterclassScreen3;
      'masterclass.template-2-animations': MasterclassTemplate2Animations;
      'masterclass.template-3-advantages': MasterclassTemplate3Advantages;
      'masterclass.template-4-agenda': MasterclassTemplate4Agenda;
      'masterclass.template-4-animations': MasterclassTemplate4Animations;
      'masterclass.template-4-brands': MasterclassTemplate4Brands;
      'masterclass.template-4-first-section': MasterclassTemplate4FirstSection;
      'masterclass.template-4-form': MasterclassTemplate4Form;
      'masterclass.template3-preview': MasterclassTemplate3Preview;
      'masterclass.template5-content': MasterclassTemplate5Content;
      'masterclass.upcoming-program': MasterclassUpcomingProgram;
      'masterclass.weeks-session-card': MasterclassWeeksSessionCard;
      'masterclass.weeks-session': MasterclassWeeksSession;
      'masterclass.what-you-can-expect-list': MasterclassWhatYouCanExpectList;
      'masterclass.what-you-get-list': MasterclassWhatYouGetList;
      'masterclass.what-you-get': MasterclassWhatYouGet;
      'masterclass.when-and-where': MasterclassWhenAndWhere;
      'masterclass.why-download-list': MasterclassWhyDownloadList;
      'masterclass.why-download': MasterclassWhyDownload;
      'new-play-now.bottom-section': NewPlayNowBottomSection;
      'new-play-now.feature-card': NewPlayNowFeatureCard;
      'new-play-now.feature-section': NewPlayNowFeatureSection;
      'new-play-now.form': NewPlayNowForm;
      'new-play-now.game-list-card': NewPlayNowGameListCard;
      'new-play-now.game-list-section': NewPlayNowGameListSection;
      'new-play-now.hero-section': NewPlayNowHeroSection;
      'new-play-now.steps-card': NewPlayNowStepsCard;
      'new-play-now.steps-section': NewPlayNowStepsSection;
      'new-play-now.welcome': NewPlayNowWelcome;
      'new-pricing.credits-header': NewPricingCreditsHeader;
      'new-pricing.credits': NewPricingCredits;
      'new-pricing.faq': NewPricingFaq;
      'new-pricing.get-in-touch': NewPricingGetInTouch;
      'new-pricing.how-credits-work': NewPricingHowCreditsWork;
      'new-pricing.list': NewPricingList;
      'new-pricing.new-pricing-card': NewPricingNewPricingCard;
      'newsroom.award': NewsroomAward;
      'newsroom.brands': NewsroomBrands;
      'newsroom.feature-data': NewsroomFeatureData;
      'newsroom.media-card': NewsroomMediaCard;
      'newsroom.section1': NewsroomSection1;
      'newsroom.section2': NewsroomSection2;
      'newsroom.section3': NewsroomSection3;
      'newsroom.section4': NewsroomSection4;
      'newsroom.video-card': NewsroomVideoCard;
      'newsroom.videos-section': NewsroomVideosSection;
      'onboarding.screen1': OnboardingScreen1;
      'onboarding.screen2': OnboardingScreen2;
      'onboarding.screen3': OnboardingScreen3;
      'popup.popup': PopupPopup;
      'pricing.brand-section': PricingBrandSection;
      'pricing.brand': PricingBrand;
      'pricing.commitment': PricingCommitment;
      'pricing.contact': PricingContact;
      'pricing.custom-plan': PricingCustomPlan;
      'pricing.faq-section': PricingFaqSection;
      'pricing.faq': PricingFaq;
      'pricing.plan-features': PricingPlanFeatures;
      'pricing.plan': PricingPlan;
      'pricing.price': PricingPrice;
      'pricing.testimonial-section': PricingTestimonialSection;
      'pricing.testimonial': PricingTestimonial;
      'shared.meta-social': SharedMetaSocial;
      'shared.seo': SharedSeo;
      'template-2.screen-3': Template2Screen3;
      'testimonial.bottom-section': TestimonialBottomSection;
      'testimonial.brands-section': TestimonialBrandsSection;
      'testimonial.brands': TestimonialBrands;
      'testimonial.testimonials-section': TestimonialTestimonialsSection;
      'use-case.banner': UseCaseBanner;
      'use-case.benefits-details': UseCaseBenefitsDetails;
      'use-case.benefits': UseCaseBenefits;
      'use-case.ckeditor': UseCaseCkeditor;
      'use-case.explore': UseCaseExplore;
      'use-case.features': UseCaseFeatures;
      'use-case.ready-section': UseCaseReadySection;
      'use-case.swiper-description': UseCaseSwiperDescription;
      'use-case.swiper': UseCaseSwiper;
    }
  }
}

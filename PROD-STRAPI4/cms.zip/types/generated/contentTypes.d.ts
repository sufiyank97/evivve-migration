import type { Schema, Attribute } from '@strapi/strapi';

export interface AdminPermission extends Schema.CollectionType {
  collectionName: 'admin_permissions';
  info: {
    name: 'Permission';
    description: '';
    singularName: 'permission';
    pluralName: 'permissions';
    displayName: 'Permission';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    action: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    actionParameters: Attribute.JSON & Attribute.DefaultTo<{}>;
    subject: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    properties: Attribute.JSON & Attribute.DefaultTo<{}>;
    conditions: Attribute.JSON & Attribute.DefaultTo<[]>;
    role: Attribute.Relation<'admin::permission', 'manyToOne', 'admin::role'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface AdminUser extends Schema.CollectionType {
  collectionName: 'admin_users';
  info: {
    name: 'User';
    description: '';
    singularName: 'user';
    pluralName: 'users';
    displayName: 'User';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    firstname: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    lastname: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    username: Attribute.String;
    email: Attribute.Email &
      Attribute.Required &
      Attribute.Private &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    password: Attribute.Password &
      Attribute.Private &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    resetPasswordToken: Attribute.String & Attribute.Private;
    registrationToken: Attribute.String & Attribute.Private;
    isActive: Attribute.Boolean &
      Attribute.Private &
      Attribute.DefaultTo<false>;
    roles: Attribute.Relation<'admin::user', 'manyToMany', 'admin::role'> &
      Attribute.Private;
    blocked: Attribute.Boolean & Attribute.Private & Attribute.DefaultTo<false>;
    preferedLanguage: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'admin::user', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'admin::user', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface AdminRole extends Schema.CollectionType {
  collectionName: 'admin_roles';
  info: {
    name: 'Role';
    description: '';
    singularName: 'role';
    pluralName: 'roles';
    displayName: 'Role';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    code: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    description: Attribute.String;
    users: Attribute.Relation<'admin::role', 'manyToMany', 'admin::user'>;
    permissions: Attribute.Relation<
      'admin::role',
      'oneToMany',
      'admin::permission'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'admin::role', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'admin::role', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface AdminApiToken extends Schema.CollectionType {
  collectionName: 'strapi_api_tokens';
  info: {
    name: 'Api Token';
    singularName: 'api-token';
    pluralName: 'api-tokens';
    displayName: 'Api Token';
    description: '';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    description: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }> &
      Attribute.DefaultTo<''>;
    type: Attribute.Enumeration<['read-only', 'full-access', 'custom']> &
      Attribute.Required &
      Attribute.DefaultTo<'read-only'>;
    accessKey: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    lastUsedAt: Attribute.DateTime;
    permissions: Attribute.Relation<
      'admin::api-token',
      'oneToMany',
      'admin::api-token-permission'
    >;
    expiresAt: Attribute.DateTime;
    lifespan: Attribute.BigInteger;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::api-token',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::api-token',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface AdminApiTokenPermission extends Schema.CollectionType {
  collectionName: 'strapi_api_token_permissions';
  info: {
    name: 'API Token Permission';
    description: '';
    singularName: 'api-token-permission';
    pluralName: 'api-token-permissions';
    displayName: 'API Token Permission';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    action: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    token: Attribute.Relation<
      'admin::api-token-permission',
      'manyToOne',
      'admin::api-token'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::api-token-permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::api-token-permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface AdminTransferToken extends Schema.CollectionType {
  collectionName: 'strapi_transfer_tokens';
  info: {
    name: 'Transfer Token';
    singularName: 'transfer-token';
    pluralName: 'transfer-tokens';
    displayName: 'Transfer Token';
    description: '';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    description: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }> &
      Attribute.DefaultTo<''>;
    accessKey: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    lastUsedAt: Attribute.DateTime;
    permissions: Attribute.Relation<
      'admin::transfer-token',
      'oneToMany',
      'admin::transfer-token-permission'
    >;
    expiresAt: Attribute.DateTime;
    lifespan: Attribute.BigInteger;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::transfer-token',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::transfer-token',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface AdminTransferTokenPermission extends Schema.CollectionType {
  collectionName: 'strapi_transfer_token_permissions';
  info: {
    name: 'Transfer Token Permission';
    description: '';
    singularName: 'transfer-token-permission';
    pluralName: 'transfer-token-permissions';
    displayName: 'Transfer Token Permission';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    action: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    token: Attribute.Relation<
      'admin::transfer-token-permission',
      'manyToOne',
      'admin::transfer-token'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::transfer-token-permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::transfer-token-permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUploadFile extends Schema.CollectionType {
  collectionName: 'files';
  info: {
    singularName: 'file';
    pluralName: 'files';
    displayName: 'File';
    description: '';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String & Attribute.Required;
    alternativeText: Attribute.String;
    caption: Attribute.String;
    width: Attribute.Integer;
    height: Attribute.Integer;
    formats: Attribute.JSON;
    hash: Attribute.String & Attribute.Required;
    ext: Attribute.String;
    mime: Attribute.String & Attribute.Required;
    size: Attribute.Decimal & Attribute.Required;
    url: Attribute.String & Attribute.Required;
    previewUrl: Attribute.String;
    provider: Attribute.String & Attribute.Required;
    provider_metadata: Attribute.JSON;
    related: Attribute.Relation<'plugin::upload.file', 'morphToMany'>;
    folder: Attribute.Relation<
      'plugin::upload.file',
      'manyToOne',
      'plugin::upload.folder'
    > &
      Attribute.Private;
    folderPath: Attribute.String &
      Attribute.Required &
      Attribute.Private &
      Attribute.SetMinMax<{
        min: 1;
      }>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::upload.file',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::upload.file',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUploadFolder extends Schema.CollectionType {
  collectionName: 'upload_folders';
  info: {
    singularName: 'folder';
    pluralName: 'folders';
    displayName: 'Folder';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMax<{
        min: 1;
      }>;
    pathId: Attribute.Integer & Attribute.Required & Attribute.Unique;
    parent: Attribute.Relation<
      'plugin::upload.folder',
      'manyToOne',
      'plugin::upload.folder'
    >;
    children: Attribute.Relation<
      'plugin::upload.folder',
      'oneToMany',
      'plugin::upload.folder'
    >;
    files: Attribute.Relation<
      'plugin::upload.folder',
      'oneToMany',
      'plugin::upload.file'
    >;
    path: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMax<{
        min: 1;
      }>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::upload.folder',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::upload.folder',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginI18NLocale extends Schema.CollectionType {
  collectionName: 'i18n_locale';
  info: {
    singularName: 'locale';
    pluralName: 'locales';
    collectionName: 'locales';
    displayName: 'Locale';
    description: '';
  };
  options: {
    draftAndPublish: false;
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.SetMinMax<{
        min: 1;
        max: 50;
      }>;
    code: Attribute.String & Attribute.Unique;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::i18n.locale',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::i18n.locale',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUsersPermissionsPermission
  extends Schema.CollectionType {
  collectionName: 'up_permissions';
  info: {
    name: 'permission';
    description: '';
    singularName: 'permission';
    pluralName: 'permissions';
    displayName: 'Permission';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    action: Attribute.String & Attribute.Required;
    role: Attribute.Relation<
      'plugin::users-permissions.permission',
      'manyToOne',
      'plugin::users-permissions.role'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::users-permissions.permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::users-permissions.permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUsersPermissionsRole extends Schema.CollectionType {
  collectionName: 'up_roles';
  info: {
    name: 'role';
    description: '';
    singularName: 'role';
    pluralName: 'roles';
    displayName: 'Role';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 3;
      }>;
    description: Attribute.String;
    type: Attribute.String & Attribute.Unique;
    permissions: Attribute.Relation<
      'plugin::users-permissions.role',
      'oneToMany',
      'plugin::users-permissions.permission'
    >;
    users: Attribute.Relation<
      'plugin::users-permissions.role',
      'oneToMany',
      'plugin::users-permissions.user'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::users-permissions.role',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::users-permissions.role',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUsersPermissionsUser extends Schema.CollectionType {
  collectionName: 'up_users';
  info: {
    name: 'user';
    description: '';
    singularName: 'user';
    pluralName: 'users';
    displayName: 'User';
  };
  options: {
    draftAndPublish: false;
    timestamps: true;
  };
  attributes: {
    username: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 3;
      }>;
    email: Attribute.Email &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    provider: Attribute.String;
    password: Attribute.Password &
      Attribute.Private &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    resetPasswordToken: Attribute.String & Attribute.Private;
    confirmationToken: Attribute.String & Attribute.Private;
    confirmed: Attribute.Boolean & Attribute.DefaultTo<false>;
    blocked: Attribute.Boolean & Attribute.DefaultTo<false>;
    role: Attribute.Relation<
      'plugin::users-permissions.user',
      'manyToOne',
      'plugin::users-permissions.role'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::users-permissions.user',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::users-permissions.user',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginMenusMenu extends Schema.CollectionType {
  collectionName: 'menus';
  info: {
    name: 'Menu';
    displayName: 'Menu';
    singularName: 'menu';
    pluralName: 'menus';
    tableName: 'menus';
  };
  options: {
    draftAndPublish: false;
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    slug: Attribute.UID<'plugin::menus.menu', 'title'> & Attribute.Required;
    items: Attribute.Relation<
      'plugin::menus.menu',
      'oneToMany',
      'plugin::menus.menu-item'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::menus.menu',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::menus.menu',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginMenusMenuItem extends Schema.CollectionType {
  collectionName: 'menu_items';
  info: {
    name: 'MenuItem';
    displayName: 'Menu Item';
    singularName: 'menu-item';
    pluralName: 'menu-items';
    tableName: 'menu_items';
  };
  options: {
    draftAndPublish: false;
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    order: Attribute.Integer;
    title: Attribute.String & Attribute.Required;
    url: Attribute.String;
    target: Attribute.Enumeration<['_blank', '_parent', '_self', '_top']>;
    root_menu: Attribute.Relation<
      'plugin::menus.menu-item',
      'manyToOne',
      'plugin::menus.menu'
    > &
      Attribute.Required;
    parent: Attribute.Relation<
      'plugin::menus.menu-item',
      'oneToOne',
      'plugin::menus.menu-item'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::menus.menu-item',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::menus.menu-item',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginPublisherAction extends Schema.CollectionType {
  collectionName: 'actions';
  info: {
    singularName: 'action';
    pluralName: 'actions';
    displayName: 'actions';
  };
  options: {
    draftAndPublish: false;
    comment: '';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    executeAt: Attribute.DateTime;
    mode: Attribute.String;
    entityId: Attribute.Integer;
    entitySlug: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::publisher.action',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::publisher.action',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiAboutAbout extends Schema.SingleType {
  collectionName: 'abouts';
  info: {
    singularName: 'about';
    pluralName: 'abouts';
    displayName: 'About';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    banner: Attribute.Component<'common.banner'>;
    second_section: Attribute.Component<'about.second-section'>;
    third_section: Attribute.Component<'about.third-section', true>;
    history_section: Attribute.Component<'about.history-section'>;
    member_section: Attribute.Component<'about.members-section'>;
    bottom_section: Attribute.Component<'about.bottom-section'>;
    seo: Attribute.Component<'shared.seo'>;
    vision_and_mission: Attribute.Component<'about.vision-and-mission'>;
    about_description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::about.about',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::about.about',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiAudioBookAudioBook extends Schema.CollectionType {
  collectionName: 'audio_books';
  info: {
    singularName: 'audio-book';
    pluralName: 'audio-books';
    displayName: 'Audio Book';
    description: 'Individual audio book series entries';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    slug: Attribute.UID<'api::audio-book.audio-book', 'title'>;
    templates: Attribute.DynamicZone<['case-study.audiobook-series-template']>;
    seo: Attribute.Component<'shared.seo'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::audio-book.audio-book',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::audio-book.audio-book',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiAudioBookLandingAudioBookLanding extends Schema.SingleType {
  collectionName: 'audio_book_landing';
  info: {
    singularName: 'audio-book-landing';
    pluralName: 'audio-book-landings';
    displayName: 'Audio Book Landing';
    description: 'Landing page for audio books';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    seo: Attribute.Component<'shared.seo'>;
    hero_section: Attribute.Component<'case-study.hero-section'>;
    brands_section: Attribute.Component<'case-study.brands'>;
    details_section: Attribute.Component<'case-study.aferr-details-section'>;
    details_section_2: Attribute.Component<'case-study.aferr-details-section-2'>;
    case_studies_section: Attribute.Component<'case-study.aferr-case-studies-section'>;
    video_carousel_section: Attribute.Component<'case-study.aferr-video-carousel'>;
    stats_section: Attribute.Component<'case-study.aferr-stats-section'>;
    final_cta_section: Attribute.Component<'case-study.aferr-final-cta'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::audio-book-landing.audio-book-landing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::audio-book-landing.audio-book-landing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiAuthorAuthor extends Schema.CollectionType {
  collectionName: 'authors';
  info: {
    singularName: 'author';
    pluralName: 'authors';
    displayName: 'Author';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    name: Attribute.String;
    location: Attribute.String;
    image: Attribute.Media;
    skill: Attribute.String;
    bio: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    social_links: Attribute.Component<'author.social-link', true>;
    blogs: Attribute.Relation<
      'api::author.author',
      'oneToMany',
      'api::blog.blog'
    >;
    slug: Attribute.UID<'api::author.author', 'name'>;
    newsletter_section: Attribute.Component<'button.newsletter'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    glossaries: Attribute.Relation<
      'api::author.author',
      'oneToMany',
      'api::glossary.glossary'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::author.author',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::author.author',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiBlogBlog extends Schema.CollectionType {
  collectionName: 'blogs';
  info: {
    singularName: 'blog';
    pluralName: 'blogs';
    displayName: 'Blog';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    image: Attribute.Media;
    categories: Attribute.Relation<
      'api::blog.blog',
      'manyToMany',
      'api::category.category'
    >;
    slug: Attribute.UID<'api::blog.blog', 'title'>;
    tags: Attribute.Relation<'api::blog.blog', 'manyToMany', 'api::tag.tag'>;
    author: Attribute.Relation<
      'api::blog.blog',
      'manyToOne',
      'api::author.author'
    >;
    blog_comments: Attribute.Relation<
      'api::blog.blog',
      'oneToMany',
      'api::blog-comment.blog-comment'
    >;
    description_type: Attribute.DynamicZone<
      [
        'common.editor',
        'button.button-image-text',
        'button.button-text',
        'button.newsletter',
        'common.button',
        'blog.key-takeaways'
      ]
    >;
    seo: Attribute.Component<'shared.seo'>;
    ctas: Attribute.Relation<'api::blog.blog', 'manyToMany', 'api::cta.cta'>;
    schema: Attribute.JSON;
    publish_date: Attribute.Date;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::blog.blog', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::blog.blog', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiBlogCommentBlogComment extends Schema.CollectionType {
  collectionName: 'blog_comments';
  info: {
    singularName: 'blog-comment';
    pluralName: 'blog-comments';
    displayName: 'Blog Comment';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    blog: Attribute.Relation<
      'api::blog-comment.blog-comment',
      'manyToOne',
      'api::blog.blog'
    >;
    name: Attribute.String;
    email: Attribute.String;
    website: Attribute.String;
    comment: Attribute.Text;
    approve_by_admin: Attribute.Boolean & Attribute.DefaultTo<false>;
    parent_comment: Attribute.String & Attribute.DefaultTo<'null'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::blog-comment.blog-comment',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::blog-comment.blog-comment',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiBlogPageBlogPage extends Schema.SingleType {
  collectionName: 'blog_pages';
  info: {
    singularName: 'blog-page';
    pluralName: 'blog-pages';
    displayName: 'Blog Page';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    description: Attribute.Text;
    bottom_section: Attribute.Component<'blog.bottom-section'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    ctas: Attribute.Relation<
      'api::blog-page.blog-page',
      'oneToMany',
      'api::cta.cta'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::blog-page.blog-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::blog-page.blog-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiBookADemoBookADemo extends Schema.SingleType {
  collectionName: 'book_a_demos';
  info: {
    singularName: 'book-a-demo';
    pluralName: 'book-a-demos';
    displayName: 'Book A Demo';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    image: Attribute.Media;
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
    brands_section: Attribute.Component<'case-study.brands'>;
    pay_offs_section: Attribute.Component<'case-study.pay-offs-section'>;
    seo: Attribute.Component<'shared.seo'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::book-a-demo.book-a-demo',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::book-a-demo.book-a-demo',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiCareerCareer extends Schema.SingleType {
  collectionName: 'careers';
  info: {
    singularName: 'career';
    pluralName: 'careers';
    displayName: 'Career';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    hero_section: Attribute.Component<'careers.hero'>;
    brand_section: Attribute.Component<'home.brand'>;
    testimonial_section: Attribute.Component<'home.testimonial'>;
    bottom_section: Attribute.Component<'careers.bottom-section'>;
    schema: Attribute.JSON;
    seo: Attribute.Component<'shared.seo'>;
    show_zoho_careers: Attribute.Boolean;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::career.career',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::career.career',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiCaseStudyCaseStudy extends Schema.CollectionType {
  collectionName: 'case_studies';
  info: {
    singularName: 'case-study';
    pluralName: 'case-studies';
    displayName: 'Case Study';
    description: 'Individual case study entries';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    slug: Attribute.UID<'api::case-study.case-study', 'title'>;
    templates: Attribute.DynamicZone<['case-study.case-study-series-template']>;
    seo: Attribute.Component<'shared.seo'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::case-study.case-study',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::case-study.case-study',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiCaseStudyLandingCaseStudyLanding extends Schema.SingleType {
  collectionName: 'case_study_landing';
  info: {
    singularName: 'case-study-landing';
    pluralName: 'case-study-landings';
    displayName: 'Case Study Landing';
    description: 'Landing page for case studies';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    seo: Attribute.Component<'shared.seo'>;
    hero_section: Attribute.Component<'case-study.hero-section'>;
    brands_section: Attribute.Component<'case-study.brands'>;
    details_section: Attribute.Component<'case-study.aferr-details-section'>;
    details_section_2: Attribute.Component<'case-study.aferr-details-section-2'>;
    case_studies_section: Attribute.Component<'case-study.aferr-case-studies-section'>;
    video_carousel_section: Attribute.Component<'case-study.aferr-video-carousel'>;
    stats_section: Attribute.Component<'case-study.aferr-stats-section'>;
    final_cta_section: Attribute.Component<'case-study.aferr-final-cta'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::case-study-landing.case-study-landing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::case-study-landing.case-study-landing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiCategoryCategory extends Schema.CollectionType {
  collectionName: 'categories';
  info: {
    singularName: 'category';
    pluralName: 'categories';
    displayName: 'Category';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    slug: Attribute.UID<'api::category.category', 'title'>;
    newsletter_section: Attribute.Component<'button.newsletter'>;
    blogs: Attribute.Relation<
      'api::category.category',
      'manyToMany',
      'api::blog.blog'
    >;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::category.category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::category.category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiCommonCommon extends Schema.SingleType {
  collectionName: 'commons';
  info: {
    singularName: 'common';
    pluralName: 'commons';
    displayName: 'Common';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    logo: Attribute.Media;
    favIcon: Attribute.Media;
    social_media: Attribute.Component<'common.social-media', true>;
    download_app: Attribute.Component<'common.download-app'>;
    footer: Attribute.Component<'common.footer'>;
    top_sticky_stripe: Attribute.Component<'common.top-sticky-stripe'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::common.common',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::common.common',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiContactContact extends Schema.CollectionType {
  collectionName: 'contacts';
  info: {
    singularName: 'contact';
    pluralName: 'contacts';
    displayName: 'Contact';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    name: Attribute.String;
    email: Attribute.Email;
    phoneNumber: Attribute.String;
    message: Attribute.Text;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::contact.contact',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::contact.contact',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiContactPageContactPage extends Schema.SingleType {
  collectionName: 'contact_pages';
  info: {
    singularName: 'contact-page';
    pluralName: 'contact-pages';
    displayName: 'Contact page';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    banner: Attribute.Component<'common.banner'>;
    second_section: Attribute.Component<'contact.second-section'>;
    thankYou: Attribute.Component<'common.thank-you'>;
    formFields: Attribute.Component<'common.form-field', true>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    zoho_form_type: Attribute.Enumeration<['button', 'form']> &
      Attribute.DefaultTo<'button'>;
    zoho_form_button: Attribute.Component<'common.button'>;
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::contact-page.contact-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::contact-page.contact-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiCookiePolicyCookiePolicy extends Schema.SingleType {
  collectionName: 'cookie_policies';
  info: {
    singularName: 'cookie-policy';
    pluralName: 'cookie-policies';
    displayName: 'Cookie Policy';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::cookie-policy.cookie-policy',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::cookie-policy.cookie-policy',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiCtaCta extends Schema.CollectionType {
  collectionName: 'ctas';
  info: {
    singularName: 'cta';
    pluralName: 'ctas';
    displayName: 'cta';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    description_type: Attribute.DynamicZone<
      [
        'button.button-image-text',
        'button.button-text',
        'button.newsletter',
        'common.app-download',
        'popup.popup',
        'common.button',
        'knowledge-base.3-cards-ctas',
        'case-study.case-study-cta',
        'case-study.aferr-cta'
      ]
    >;
    title: Attribute.String;
    use_cases: Attribute.Relation<
      'api::cta.cta',
      'manyToMany',
      'api::use-case.use-case'
    >;
    blogs: Attribute.Relation<'api::cta.cta', 'manyToMany', 'api::blog.blog'>;
    glossaries: Attribute.Relation<
      'api::cta.cta',
      'manyToMany',
      'api::glossary.glossary'
    >;
    press_releases: Attribute.Relation<
      'api::cta.cta',
      'manyToMany',
      'api::press-release.press-release'
    >;
    release_notes: Attribute.Relation<
      'api::cta.cta',
      'manyToMany',
      'api::release-note.release-note'
    >;
    knowledge_bases: Attribute.Relation<
      'api::cta.cta',
      'manyToMany',
      'api::knowledge-base.knowledge-base'
    >;
    case_studies: Attribute.Relation<
      'api::cta.cta',
      'manyToMany',
      'api::case-study.case-study'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::cta.cta', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::cta.cta', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiDialogueDialogue extends Schema.CollectionType {
  collectionName: 'dialogues';
  info: {
    singularName: 'dialogue';
    pluralName: 'dialogues';
    displayName: 'Dialogue';
    description: 'Individual dialogue series entries';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    slug: Attribute.UID<'api::dialogue.dialogue', 'title'>;
    templates: Attribute.DynamicZone<['case-study.audiobook-series-template']>;
    seo: Attribute.Component<'shared.seo'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::dialogue.dialogue',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::dialogue.dialogue',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiDialogueLandingDialogueLanding extends Schema.SingleType {
  collectionName: 'dialogue_landing';
  info: {
    singularName: 'dialogue-landing';
    pluralName: 'dialogue-landings';
    displayName: 'Dialogue Landing';
    description: 'Landing page for dialogues';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    seo: Attribute.Component<'shared.seo'>;
    hero_section: Attribute.Component<'case-study.hero-section'>;
    brands_section: Attribute.Component<'case-study.brands'>;
    details_section: Attribute.Component<'case-study.aferr-details-section'>;
    details_section_2: Attribute.Component<'case-study.aferr-details-section-2'>;
    case_studies_section: Attribute.Component<'case-study.aferr-case-studies-section'>;
    video_carousel_section: Attribute.Component<'case-study.aferr-video-carousel'>;
    stats_section: Attribute.Component<'case-study.aferr-stats-section'>;
    final_cta_section: Attribute.Component<'case-study.aferr-final-cta'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::dialogue-landing.dialogue-landing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::dialogue-landing.dialogue-landing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiEventEvent extends Schema.CollectionType {
  collectionName: 'events';
  info: {
    singularName: 'event';
    pluralName: 'events';
    displayName: 'Event';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    image: Attribute.Media;
    Date: Attribute.DateTime;
    title: Attribute.String;
    location: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    slug: Attribute.UID<'api::event.event', 'title'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::event.event',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::event.event',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiGameGame extends Schema.SingleType {
  collectionName: 'games';
  info: {
    singularName: 'game';
    pluralName: 'games';
    displayName: 'Game';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    banner_section: Attribute.Component<'game.banner'>;
    play_section: Attribute.Component<'game.play-category', true>;
    what_faciliators_love_section: Attribute.Component<'game.facilitators-love-about-evivve'>;
    testimonial_section: Attribute.Component<'game.testimonial'>;
    brand_section: Attribute.Component<'game.brand-section'>;
    download_app_section: Attribute.Component<'common.app-download'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::game.game', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::game.game', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiGameDownloadGameDownload extends Schema.SingleType {
  collectionName: 'game_downloads';
  info: {
    singularName: 'game-download';
    pluralName: 'game-downloads';
    displayName: 'Game Download';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    minimalDashboard: Attribute.Component<'game-download.minimal-dashboard'>;
    features: Attribute.Component<'game-download.features'>;
    appDownload: Attribute.Component<'game-download.app-download'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::game-download.game-download',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::game-download.game-download',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiGlossaryGlossary extends Schema.CollectionType {
  collectionName: 'glossaries';
  info: {
    singularName: 'glossary';
    pluralName: 'glossaries';
    displayName: 'Glossary';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    slug: Attribute.UID<'api::glossary.glossary', 'title'>;
    excerpt: Attribute.Text;
    editors: Attribute.DynamicZone<
      ['glossary.dark-editor', 'glossary.light-editor']
    >;
    reference: Attribute.Component<'glossary.reference', true>;
    author: Attribute.Relation<
      'api::glossary.glossary',
      'manyToOne',
      'api::author.author'
    >;
    tags: Attribute.Relation<
      'api::glossary.glossary',
      'manyToMany',
      'api::tag.tag'
    >;
    ctas: Attribute.Relation<
      'api::glossary.glossary',
      'manyToMany',
      'api::cta.cta'
    >;
    glossary_comments: Attribute.Relation<
      'api::glossary.glossary',
      'oneToMany',
      'api::glossary-comment.glossary-comment'
    >;
    seo: Attribute.Component<'shared.seo'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::glossary.glossary',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::glossary.glossary',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiGlossaryCommentGlossaryComment
  extends Schema.CollectionType {
  collectionName: 'glossary_comments';
  info: {
    singularName: 'glossary-comment';
    pluralName: 'glossary-comments';
    displayName: 'Glossary Comment';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    glossary: Attribute.Relation<
      'api::glossary-comment.glossary-comment',
      'manyToOne',
      'api::glossary.glossary'
    >;
    name: Attribute.String;
    email: Attribute.String;
    website: Attribute.String;
    comment: Attribute.Text;
    approve_by_admin: Attribute.Boolean & Attribute.DefaultTo<false>;
    parent_comment: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::glossary-comment.glossary-comment',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::glossary-comment.glossary-comment',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiGlossaryPageGlossaryPage extends Schema.SingleType {
  collectionName: 'glossary_pages';
  info: {
    singularName: 'glossary-page';
    pluralName: 'glossary-pages';
    displayName: 'Glossary Page';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    icon: Attribute.Media;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    ctas: Attribute.Relation<
      'api::glossary-page.glossary-page',
      'oneToMany',
      'api::cta.cta'
    >;
    seo: Attribute.Component<'shared.seo'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::glossary-page.glossary-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::glossary-page.glossary-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiHomeHome extends Schema.SingleType {
  collectionName: 'homes';
  info: {
    singularName: 'home';
    pluralName: 'homes';
    displayName: 'Home';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    top_section: Attribute.Component<'home.top-section'>;
    brand_section: Attribute.Component<'home.brand'>;
    how_it_works_title: Attribute.Component<'home.how-it-works'>;
    how_it_works_steps: Attribute.Component<'home.how-it-works-step', true>;
    testimonial_section: Attribute.Component<'home.testimonial'>;
    earning: Attribute.Component<'home.earning'>;
    community: Attribute.Component<'home.community'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    get_started: Attribute.Component<'home.get-started'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::home.home', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::home.home', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiJournalJournal extends Schema.CollectionType {
  collectionName: 'journals';
  info: {
    singularName: 'journal';
    pluralName: 'journals';
    displayName: 'Journal';
    description: 'Individual journal series entries';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    slug: Attribute.UID<'api::journal.journal', 'title'>;
    templates: Attribute.DynamicZone<['case-study.journal-series-template']>;
    seo: Attribute.Component<'shared.seo'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::journal.journal',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::journal.journal',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiJournalLandingJournalLanding extends Schema.SingleType {
  collectionName: 'journal_landing';
  info: {
    singularName: 'journal-landing';
    pluralName: 'journal-landings';
    displayName: 'Journal Landing';
    description: 'Landing page for journals';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    seo: Attribute.Component<'shared.seo'>;
    hero_section: Attribute.Component<'case-study.hero-section'>;
    brands_section: Attribute.Component<'case-study.brands'>;
    details_section: Attribute.Component<'case-study.aferr-details-section'>;
    details_section_2: Attribute.Component<'case-study.aferr-details-section-2'>;
    case_studies_section: Attribute.Component<'case-study.aferr-case-studies-section'>;
    video_carousel_section: Attribute.Component<'case-study.aferr-video-carousel'>;
    stats_section: Attribute.Component<'case-study.aferr-stats-section'>;
    final_cta_section: Attribute.Component<'case-study.aferr-final-cta'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::journal-landing.journal-landing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::journal-landing.journal-landing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiKnowledgeBaseKnowledgeBase extends Schema.CollectionType {
  collectionName: 'knowledge_bases';
  info: {
    singularName: 'knowledge-base';
    pluralName: 'knowledge-bases';
    displayName: 'Knowledge Base';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    slug: Attribute.UID<'api::knowledge-base.knowledge-base', 'title'>;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    version: Attribute.String;
    sub_versions: Attribute.Relation<
      'api::knowledge-base.knowledge-base',
      'oneToMany',
      'api::knowledge-base.knowledge-base'
    >;
    base_version: Attribute.Relation<
      'api::knowledge-base.knowledge-base',
      'manyToOne',
      'api::knowledge-base.knowledge-base'
    >;
    ctas: Attribute.Relation<
      'api::knowledge-base.knowledge-base',
      'manyToMany',
      'api::cta.cta'
    >;
    seo: Attribute.Component<'shared.seo'>;
    featured_faq: Attribute.Component<'knowledge-base.featured-faq'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::knowledge-base.knowledge-base',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::knowledge-base.knowledge-base',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiKnowledgeBasePageKnowledgeBasePage
  extends Schema.SingleType {
  collectionName: 'knowledge_base_pages';
  info: {
    singularName: 'knowledge-base-page';
    pluralName: 'knowledge-base-pages';
    displayName: 'Knowledge Base Page';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    seo: Attribute.Component<'shared.seo'>;
    ctas: Attribute.Relation<
      'api::knowledge-base-page.knowledge-base-page',
      'oneToMany',
      'api::cta.cta'
    >;
    sub_title: Attribute.String;
    featured_faq: Attribute.Component<'knowledge-base.featured-faq'>;
    knowledge_base_topic_title: Attribute.String;
    knowledge_bases: Attribute.Relation<
      'api::knowledge-base-page.knowledge-base-page',
      'oneToMany',
      'api::knowledge-base.knowledge-base'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::knowledge-base-page.knowledge-base-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::knowledge-base-page.knowledge-base-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiLandingPageLandingPage extends Schema.CollectionType {
  collectionName: 'landing_pages';
  info: {
    singularName: 'landing-page';
    pluralName: 'landing-pages';
    displayName: 'Landing Page';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    slug: Attribute.UID<'api::landing-page.landing-page', 'title'> &
      Attribute.Required;
    seo: Attribute.Component<'shared.seo'>;
    templates: Attribute.DynamicZone<
      [
        'landing-page.masterclass',
        'landing-page.template-2',
        'landing-page.template3',
        'landing-page.template-4',
        'landing-page.template-5',
        'landing-page.live-session',
        'landing-page.adventure'
      ]
    > &
      Attribute.SetMinMax<{
        max: 1;
      }>;
    category: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::landing-page.landing-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::landing-page.landing-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiLogoLogo extends Schema.CollectionType {
  collectionName: 'logos';
  info: {
    singularName: 'logo';
    pluralName: 'logos';
    displayName: 'Client Logos';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    image: Attribute.Media;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::logo.logo', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::logo.logo', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiNewPlayNowNewPlayNow extends Schema.SingleType {
  collectionName: 'new_play_nows';
  info: {
    singularName: 'new-play-now';
    pluralName: 'new-play-nows';
    displayName: 'New Play Now';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    Hero_Section: Attribute.Component<'new-play-now.hero-section'>;
    brands: Attribute.Component<'masterclass.template-4-brands'>;
    welcome: Attribute.Component<'new-play-now.welcome'>;
    game_list_section: Attribute.Component<'new-play-now.game-list-section'>;
    feature_section: Attribute.Component<'new-play-now.feature-section'>;
    steps_section: Attribute.Component<'new-play-now.steps-section'>;
    faq: Attribute.Component<'masterclass.faq'>;
    bottom_section: Attribute.Component<'new-play-now.bottom-section'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    form: Attribute.Component<'new-play-now.form'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::new-play-now.new-play-now',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::new-play-now.new-play-now',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiNewPricingNewPricing extends Schema.SingleType {
  collectionName: 'new_pricings';
  info: {
    singularName: 'new-pricing';
    pluralName: 'new-pricings';
    displayName: 'New Pricing';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    recommended: Attribute.Component<'new-pricing.new-pricing-card'>;
    reports_title: Attribute.String;
    pricing_cards: Attribute.Component<'new-pricing.new-pricing-card', true>;
    credits_title: Attribute.String;
    credits_description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    credits: Attribute.Component<'new-pricing.credits', true>;
    credits_button: Attribute.Component<'common.button'>;
    how_credits_work: Attribute.Component<'new-pricing.how-credits-work'>;
    faq_title: Attribute.String;
    faq: Attribute.Component<'new-pricing.faq', true>;
    get_in_touch: Attribute.Component<'new-pricing.get-in-touch'>;
    testimonial_section: Attribute.Component<'home.testimonial'>;
    brand_section: Attribute.Component<'home.brand'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    credits_header: Attribute.Component<'new-pricing.credits-header', true> &
      Attribute.SetMinMax<{
        max: 3;
      }>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::new-pricing.new-pricing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::new-pricing.new-pricing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiNewsroomNewsroom extends Schema.SingleType {
  collectionName: 'newsrooms';
  info: {
    singularName: 'newsroom';
    pluralName: 'newsrooms';
    displayName: 'Newsroom';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    section1: Attribute.Component<'newsroom.section1'>;
    section2: Attribute.Component<'newsroom.section2'>;
    section3: Attribute.Component<'newsroom.section3'>;
    videos: Attribute.Component<'newsroom.videos-section'>;
    section4: Attribute.Component<'newsroom.section4'>;
    brands: Attribute.Component<'newsroom.brands'>;
    seo: Attribute.Component<'shared.seo'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::newsroom.newsroom',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::newsroom.newsroom',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiOnboardingOnboarding extends Schema.SingleType {
  collectionName: 'onboardings';
  info: {
    singularName: 'onboarding';
    pluralName: 'onboardings';
    displayName: 'Onboarding';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    screen1: Attribute.Component<'onboarding.screen1'>;
    screen2: Attribute.Component<'onboarding.screen2'>;
    left_shade: Attribute.Media;
    top_shade: Attribute.Media;
    mobile_shade: Attribute.Media;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::onboarding.onboarding',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::onboarding.onboarding',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiPlayLivePlayLive extends Schema.SingleType {
  collectionName: 'play_lives';
  info: {
    singularName: 'play-live';
    pluralName: 'play-lives';
    displayName: 'Play Live';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    seo: Attribute.Component<'shared.seo'>;
    embed_code: Attribute.Text;
    schema: Attribute.JSON;
    play_live_button: Attribute.Component<'common.button'>;
    zoho_form_type: Attribute.Enumeration<['button', 'form']> &
      Attribute.DefaultTo<'button'>;
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::play-live.play-live',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::play-live.play-live',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiPlayNowPlayNow extends Schema.SingleType {
  collectionName: 'play_nows';
  info: {
    singularName: 'play-now';
    pluralName: 'play-nows';
    displayName: 'Play Now';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    seo: Attribute.Component<'shared.seo'>;
    embed_code: Attribute.Text;
    schema: Attribute.JSON;
    play_now_button: Attribute.Component<'common.button'>;
    zoho_form_type: Attribute.Enumeration<['button', 'form']> &
      Attribute.DefaultTo<'button'>;
    form: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    form_onload: Attribute.String;
    form_onsubmit: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::play-now.play-now',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::play-now.play-now',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiPopularBlogPopularBlog extends Schema.CollectionType {
  collectionName: 'popular_blogs';
  info: {
    singularName: 'popular-blog';
    pluralName: 'popular-blogs';
    displayName: 'Popular Blog';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    blogs: Attribute.Relation<
      'api::popular-blog.popular-blog',
      'oneToMany',
      'api::blog.blog'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::popular-blog.popular-blog',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::popular-blog.popular-blog',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiPressReleasePressRelease extends Schema.CollectionType {
  collectionName: 'press_releases';
  info: {
    singularName: 'press-release';
    pluralName: 'press-releases';
    displayName: 'Press Release';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    date: Attribute.Date;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    seo: Attribute.Component<'shared.seo'>;
    slug: Attribute.UID<'api::press-release.press-release', 'title'> &
      Attribute.Required;
    ctas: Attribute.Relation<
      'api::press-release.press-release',
      'manyToMany',
      'api::cta.cta'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::press-release.press-release',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::press-release.press-release',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiPricingPricing extends Schema.SingleType {
  collectionName: 'pricings';
  info: {
    singularName: 'pricing';
    pluralName: 'pricings';
    displayName: 'Pricing';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    plans: Attribute.Component<'pricing.plan', true>;
    faq_section: Attribute.Component<'pricing.faq-section'>;
    contact_section: Attribute.Component<'pricing.contact'>;
    brand_section: Attribute.Component<'pricing.brand-section'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    custom_plan: Attribute.Component<'pricing.custom-plan'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::pricing.pricing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::pricing.pricing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiPrivacyPolicyPrivacyPolicy extends Schema.SingleType {
  collectionName: 'privacy_policies';
  info: {
    singularName: 'privacy-policy';
    pluralName: 'privacy-policies';
    displayName: 'Privacy Policy';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::privacy-policy.privacy-policy',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::privacy-policy.privacy-policy',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiReleaseNoteReleaseNote extends Schema.CollectionType {
  collectionName: 'release_notes';
  info: {
    singularName: 'release-note';
    pluralName: 'release-notes';
    displayName: 'Release Note';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    slug: Attribute.UID<'api::release-note.release-note', 'title'>;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    version: Attribute.String;
    sub_versions: Attribute.Relation<
      'api::release-note.release-note',
      'oneToMany',
      'api::release-note.release-note'
    >;
    base_version: Attribute.Relation<
      'api::release-note.release-note',
      'manyToOne',
      'api::release-note.release-note'
    >;
    seo: Attribute.Component<'shared.seo'>;
    ctas: Attribute.Relation<
      'api::release-note.release-note',
      'manyToMany',
      'api::cta.cta'
    >;
    base_version_order_number: Attribute.Integer &
      Attribute.SetMinMax<{
        min: 0;
      }>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::release-note.release-note',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::release-note.release-note',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiReleaseNotePageReleaseNotePage extends Schema.SingleType {
  collectionName: 'release_note_pages';
  info: {
    singularName: 'release-note-page';
    pluralName: 'release-note-pages';
    displayName: 'Release Note Page';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    seo: Attribute.Component<'shared.seo'>;
    ctas: Attribute.Relation<
      'api::release-note-page.release-note-page',
      'oneToMany',
      'api::cta.cta'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::release-note-page.release-note-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::release-note-page.release-note-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiScienceLabScienceLab extends Schema.CollectionType {
  collectionName: 'science_labs';
  info: {
    singularName: 'science-lab';
    pluralName: 'science-labs';
    displayName: 'Science Lab';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    slug: Attribute.UID<'api::science-lab.science-lab', 'title'>;
    hero_section: Attribute.Component<'labs.hero-section'>;
    stats_section: Attribute.Component<'labs.stats-section'>;
    models_and_frameworks_section: Attribute.Component<'labs.models-and-frameworks-section'>;
    inside_labs_section: Attribute.Component<'labs.inside-labs-section'>;
    neuro_science: Attribute.Component<'labs.neuro-science'>;
    evidence_based_strategy: Attribute.Component<'labs.evidence-based-strategy'>;
    science_backed_approach: Attribute.Component<'labs.science-backed-approach'>;
    approach_section: Attribute.Component<'labs.approach-section'>;
    faq: Attribute.Component<'labs.faq'>;
    cta: Attribute.Component<'labs.cta'>;
    seo: Attribute.Component<'shared.seo'>;
    form: Attribute.Component<'new-play-now.form'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::science-lab.science-lab',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::science-lab.science-lab',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiTagTag extends Schema.CollectionType {
  collectionName: 'tags';
  info: {
    singularName: 'tag';
    pluralName: 'tags';
    displayName: 'tag';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    slug: Attribute.UID<'api::tag.tag', 'title'>;
    blogs: Attribute.Relation<'api::tag.tag', 'manyToMany', 'api::blog.blog'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    glossaries: Attribute.Relation<
      'api::tag.tag',
      'manyToMany',
      'api::glossary.glossary'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::tag.tag', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::tag.tag', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiTermsOfServiceTermsOfService extends Schema.SingleType {
  collectionName: 'terms_of_services';
  info: {
    singularName: 'terms-of-service';
    pluralName: 'terms-of-services';
    displayName: 'Terms of Service';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::terms-of-service.terms-of-service',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::terms-of-service.terms-of-service',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiTestimonialTestimonial extends Schema.CollectionType {
  collectionName: 'testimonials';
  info: {
    singularName: 'testimonial';
    pluralName: 'testimonials';
    displayName: 'Testimonial';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    name: Attribute.String;
    designation: Attribute.String;
    image: Attribute.Media;
    linkedin: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::testimonial.testimonial',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::testimonial.testimonial',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiTestimonialPageTestimonialPage extends Schema.SingleType {
  collectionName: 'testimonial_pages';
  info: {
    singularName: 'testimonial-page';
    pluralName: 'testimonial-pages';
    displayName: 'Testimonial Page';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String & Attribute.Required;
    testimonial_section: Attribute.Component<'testimonial.testimonials-section'>;
    brand_section: Attribute.Component<'testimonial.brands-section'>;
    bottom_section: Attribute.Component<'testimonial.bottom-section'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::testimonial-page.testimonial-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::testimonial-page.testimonial-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiThankYouPageThankYouPage extends Schema.CollectionType {
  collectionName: 'thank_you_pages';
  info: {
    singularName: 'thank-you-page';
    pluralName: 'thank-you-pages';
    displayName: 'thank-you-page';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    heading: Attribute.String;
    description: Attribute.Text;
    image: Attribute.Media;
    slug: Attribute.UID<'api::thank-you-page.thank-you-page', 'heading'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    thankyou_button: Attribute.Component<'common.button'>;
    ckeditor_description: Attribute.RichText &
      Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'toolbar';
        }
      >;
    button_type: Attribute.Enumeration<['link', 'download']> &
      Attribute.DefaultTo<'link'>;
    download_link: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::thank-you-page.thank-you-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::thank-you-page.thank-you-page',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiUseCaseUseCase extends Schema.CollectionType {
  collectionName: 'use_cases';
  info: {
    singularName: 'use-case';
    pluralName: 'use-cases';
    displayName: 'Use Case';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    banner: Attribute.Component<'use-case.banner'>;
    benefits: Attribute.Component<'use-case.benefits'>;
    features: Attribute.Component<'use-case.features'>;
    ready_section: Attribute.Component<'use-case.ready-section'>;
    explore: Attribute.Component<'use-case.explore'>;
    slug: Attribute.String;
    seo: Attribute.Component<'shared.seo'>;
    faq_section: Attribute.Component<'pricing.faq-section'>;
    description: Attribute.DynamicZone<
      ['use-case.ckeditor', 'use-case.swiper-description']
    >;
    description_type: Attribute.DynamicZone<
      [
        'button.button-image-text',
        'button.button-text',
        'button.newsletter',
        'common.button'
      ]
    >;
    ctas: Attribute.Relation<
      'api::use-case.use-case',
      'manyToMany',
      'api::cta.cta'
    >;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::use-case.use-case',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::use-case.use-case',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiWhyEvivveWhyEvivve extends Schema.SingleType {
  collectionName: 'why_evivves';
  info: {
    singularName: 'why-evivve';
    pluralName: 'why-evivves';
    displayName: 'Why Evivve';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    top_section: Attribute.Component<'home.top-section'>;
    brand_section: Attribute.Component<'home.brand'>;
    how_it_works_title: Attribute.Component<'home.how-it-works'>;
    how_it_works_steps: Attribute.Component<'home.how-it-works-step', true>;
    testimonial_section: Attribute.Component<'home.testimonial'>;
    earning: Attribute.Component<'home.earning'>;
    community: Attribute.Component<'home.community'>;
    seo: Attribute.Component<'shared.seo'>;
    schema: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::why-evivve.why-evivve',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::why-evivve.why-evivve',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

declare module '@strapi/types' {
  export module Shared {
    export interface ContentTypes {
      'admin::permission': AdminPermission;
      'admin::user': AdminUser;
      'admin::role': AdminRole;
      'admin::api-token': AdminApiToken;
      'admin::api-token-permission': AdminApiTokenPermission;
      'admin::transfer-token': AdminTransferToken;
      'admin::transfer-token-permission': AdminTransferTokenPermission;
      'plugin::upload.file': PluginUploadFile;
      'plugin::upload.folder': PluginUploadFolder;
      'plugin::i18n.locale': PluginI18NLocale;
      'plugin::users-permissions.permission': PluginUsersPermissionsPermission;
      'plugin::users-permissions.role': PluginUsersPermissionsRole;
      'plugin::users-permissions.user': PluginUsersPermissionsUser;
      'plugin::menus.menu': PluginMenusMenu;
      'plugin::menus.menu-item': PluginMenusMenuItem;
      'plugin::publisher.action': PluginPublisherAction;
      'api::about.about': ApiAboutAbout;
      'api::audio-book.audio-book': ApiAudioBookAudioBook;
      'api::audio-book-landing.audio-book-landing': ApiAudioBookLandingAudioBookLanding;
      'api::author.author': ApiAuthorAuthor;
      'api::blog.blog': ApiBlogBlog;
      'api::blog-comment.blog-comment': ApiBlogCommentBlogComment;
      'api::blog-page.blog-page': ApiBlogPageBlogPage;
      'api::book-a-demo.book-a-demo': ApiBookADemoBookADemo;
      'api::career.career': ApiCareerCareer;
      'api::case-study.case-study': ApiCaseStudyCaseStudy;
      'api::case-study-landing.case-study-landing': ApiCaseStudyLandingCaseStudyLanding;
      'api::category.category': ApiCategoryCategory;
      'api::common.common': ApiCommonCommon;
      'api::contact.contact': ApiContactContact;
      'api::contact-page.contact-page': ApiContactPageContactPage;
      'api::cookie-policy.cookie-policy': ApiCookiePolicyCookiePolicy;
      'api::cta.cta': ApiCtaCta;
      'api::dialogue.dialogue': ApiDialogueDialogue;
      'api::dialogue-landing.dialogue-landing': ApiDialogueLandingDialogueLanding;
      'api::event.event': ApiEventEvent;
      'api::game.game': ApiGameGame;
      'api::game-download.game-download': ApiGameDownloadGameDownload;
      'api::glossary.glossary': ApiGlossaryGlossary;
      'api::glossary-comment.glossary-comment': ApiGlossaryCommentGlossaryComment;
      'api::glossary-page.glossary-page': ApiGlossaryPageGlossaryPage;
      'api::home.home': ApiHomeHome;
      'api::journal.journal': ApiJournalJournal;
      'api::journal-landing.journal-landing': ApiJournalLandingJournalLanding;
      'api::knowledge-base.knowledge-base': ApiKnowledgeBaseKnowledgeBase;
      'api::knowledge-base-page.knowledge-base-page': ApiKnowledgeBasePageKnowledgeBasePage;
      'api::landing-page.landing-page': ApiLandingPageLandingPage;
      'api::logo.logo': ApiLogoLogo;
      'api::new-play-now.new-play-now': ApiNewPlayNowNewPlayNow;
      'api::new-pricing.new-pricing': ApiNewPricingNewPricing;
      'api::newsroom.newsroom': ApiNewsroomNewsroom;
      'api::onboarding.onboarding': ApiOnboardingOnboarding;
      'api::play-live.play-live': ApiPlayLivePlayLive;
      'api::play-now.play-now': ApiPlayNowPlayNow;
      'api::popular-blog.popular-blog': ApiPopularBlogPopularBlog;
      'api::press-release.press-release': ApiPressReleasePressRelease;
      'api::pricing.pricing': ApiPricingPricing;
      'api::privacy-policy.privacy-policy': ApiPrivacyPolicyPrivacyPolicy;
      'api::release-note.release-note': ApiReleaseNoteReleaseNote;
      'api::release-note-page.release-note-page': ApiReleaseNotePageReleaseNotePage;
      'api::science-lab.science-lab': ApiScienceLabScienceLab;
      'api::tag.tag': ApiTagTag;
      'api::terms-of-service.terms-of-service': ApiTermsOfServiceTermsOfService;
      'api::testimonial.testimonial': ApiTestimonialTestimonial;
      'api::testimonial-page.testimonial-page': ApiTestimonialPageTestimonialPage;
      'api::thank-you-page.thank-you-page': ApiThankYouPageThankYouPage;
      'api::use-case.use-case': ApiUseCaseUseCase;
      'api::why-evivve.why-evivve': ApiWhyEvivveWhyEvivve;
    }
  }
}

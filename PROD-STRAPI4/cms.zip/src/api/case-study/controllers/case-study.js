'use strict';

/**
 * case-study controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::case-study.case-study');
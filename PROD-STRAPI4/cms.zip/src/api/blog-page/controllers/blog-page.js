'use strict';

/**
 * blog-page controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::blog-page.blog-page');

"use strict";

/**
 * use-case controller
 */

const { createCoreController } = require("@strapi/strapi").factories;
const axios = require("axios");

module.exports = createCoreController(
  "api::use-case.use-case",
  ({ strapi }) => ({
    async duplicateEntry(ctx) {
      const paramId = ctx.params.id;

      const fetchUseCase = (id) => {
        return `
            query getUseCases {
              useCases( filters: { id: { eq: "${id}" } } ) {
                data {
                  attributes {
                    slug
                    banner {
                        title
                        image {
                        data {
                            id
                            attributes {
                            url
                            }
                        }
                        }
                        description
                    }
                    benefits {
                        title
                        benefits_detials {
                        image {
                            data {
                            id
                            attributes {
                                url
                            }
                            }
                        }
                        title
                        description
                        }
                    }
                    description{
                        ... on ComponentUseCaseCkeditor{
                        __typename
                        description
                        }
                        ... on ComponentUseCaseSwiperDescription{
                        __typename
                        swiper{
                            title
                            description
                        }
                        }
                    }
                    features {
                        title
                        subTitle
                        subTitle_highlight
                        description
                        image {
                        data {
                            id
                            attributes {
                            url
                            }
                        }
                        }
                    }
                    ready_section {
                        title
                        description
                        ready_section_button {
                            button_text
                            button_icon
                            button_link
                            button_target
                        }
                    }
                    explore {
                        image {
                        data {
                            id
                            attributes {
                            url
                            }
                        }
                        }
                        title
                        description
                    }
                    faq_section {
                        title
                        faq {
                        question
                        answer
                        }
                        heading_text
                        link_text
                        link_url
                        link_target
                    }
                    description_type {
                        ... on ComponentButtonButtonImageText {
                            __typename
                            image {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                            title
                            description
                            button_image_text_button {
                            button_text
                            button_icon
                            button_link
                            button_target
                            }
                        }
                        ... on ComponentButtonButtonText {
                            __typename
                            description
                            button_text_button {
                            button_text
                            button_icon
                            button_link
                            button_target
                            }
                        }
                        ... on ComponentCommonButton {
                            __typename
                            button_text
                            button_icon
                            button_link
                            button_target
                        }
                        ... on ComponentButtonNewsletter {
                            __typename
                            description
                            form_onload
                            form_onsubmit
                        }
                        }
                        ctas{
                        data{
                            id
                        }
                        }
                    schema
                    seo {
                        metaTitle
                        metaDescription
                        metaImage{
                            data{
                                id
                                attributes{
                                    url
                                }
                            }
                        }
                        metaSocial{
                            socialNetwork
                            title
                            description
                            image{
                                data{
                                id
                                    attributes{
                                        url
                                    }
                                }
                            }
                        }
                        keywords
                        metaRobots
                        structuredData
                        metaViewport
                        canonicalURL
                    }
                    }
                }
              }
            }
          `;
      };

      const url = process.env.STRAPI_URL;

      try {
        const originalEntry = await axios.post(`${url}graphql`, {
          query: fetchUseCase(paramId),
        });

        const resData =
          originalEntry?.data?.data?.useCases?.data[0]?.attributes;

        if (!resData) {
          return ctx.notFound("Entry not found");
        }

        // Universal processor that handles everything automatically
        const processData = (obj) => {
          if (!obj || typeof obj !== "object") return obj;

          // Handle GraphQL media relations (convert { data: {...} } to ID)
          if (obj.data !== undefined) {
            if (Array.isArray(obj.data)) {
              return obj.data.map((item) => item.id);
            } else if (obj.data && obj.data.id) {
              return obj.data.id;
            } else if (obj.data === null) {
              return null;
            }
          }

          // Handle arrays
          if (Array.isArray(obj)) {
            return obj.map((item) => processData(item));
          }

          // Handle dynamic zone components (has __typename)
          if (obj.__typename) {
            const { __typename, ...rest } = obj;

            // Map component typename to Strapi format
            const componentMap = {
              ComponentUseCaseCkeditor: "use-case.ckeditor",
              ComponentUseCaseSwiperDescription: "use-case.swiper-description",
              ComponentButtonButtonImageText: "button.button-image-text",
              ComponentButtonButtonText: "button.button-text",
              ComponentCommonButton: "common.button",
              ComponentButtonNewsletter: "button.newsletter",
              ComponentPopupPopup: "popup.popup",
              ComponentCommonAppDownload: "common.app-download",
            };

            const __component =
              componentMap[__typename] ||
              __typename
                ?.replace("Component", "")
                ?.replace(/([A-Z])/g, (match) => `-${match.toLowerCase()}`)
                ?.replace(/^-/, "");

            const processedRest = processData(rest);

            // Normalize button targets
            normalizeButtonTargets(processedRest);

            return {
              ...processedRest,
              __component,
            };
          }

          // Handle regular objects
          const result = {};
          for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
              result[key] = processData(obj[key]);
            }
          }
          return result;
        };

        // Normalize button targets throughout the data
        const normalizeButtonTargets = (obj) => {
          if (!obj || typeof obj !== "object") return;

          if (Array.isArray(obj)) {
            obj.forEach((item) => normalizeButtonTargets(item));
            return;
          }

          for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (key === "button_target" || key === "link_target") {
                obj[key] =
                  obj[key] === "_blank" || obj[key] === "blank"
                    ? "_blank"
                    : "_self";
              } else {
                normalizeButtonTargets(obj[key]);
              }
            }
          }
        };

        // Process all data automatically
        const processedData = processData(resData);

        // Normalize all button targets
        normalizeButtonTargets(processedData);

        // Create new entry data with modified slug
        const newEntryData = {
          ...processedData,
          slug: `${resData.slug}-copy`,
        };

        // Remove undefined values
        const cleanData = JSON.parse(
          JSON.stringify(newEntryData, (key, value) => {
            return value === undefined ? null : value;
          })
        );

        const duplicatedEntry = await strapi.entityService.create(
          "api::use-case.use-case",
          {
            data: cleanData,
          }
        );

        ctx.send(duplicatedEntry);
      } catch (error) {
        console.error("Error duplicating entry:", error);
        console.error("Error details:", error.response?.data || error.message);

        return ctx.badRequest("Failed to duplicate entry", {
          error: error.message,
          details: error.response?.data,
        });
      }
    },
  })
);

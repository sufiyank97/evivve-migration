'use strict';

/**
 * contact-page service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::contact-page.contact-page');

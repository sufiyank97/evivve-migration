'use strict';

/**
 * thank-you-page router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::thank-you-page.thank-you-page');

'use strict';

/**
 * dialogue-landing controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::dialogue-landing.dialogue-landing');


'use strict';

/**
 * dialogue-landing router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::dialogue-landing.dialogue-landing');


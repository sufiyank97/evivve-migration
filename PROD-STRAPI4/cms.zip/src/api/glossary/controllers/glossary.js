"use strict";

/**
 * glossary controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController(
  "api::glossary.glossary",
  ({ strapi }) => ({
    async search(ctx) {
      const { searchingText } = ctx.query;

      // Sanitize the search input to prevent SQL injection
      const sanitizedSearchText = searchingText.replace(/'/g, "''");

      const query = `
      SELECT DISTINCT
       glossary.id,
       glossary.title,
       glossary.slug,
       glossary.published_at,
       dark_editors.dark_editor,
       light_editors.light_editor
       FROM
       glossaries AS glossary
       LEFT JOIN
    glossaries_components AS gc_dark
    ON glossary.id = gc_dark.entity_id
    AND gc_dark.component_type = 'glossary.dark-editor'
    AND gc_dark.field = 'editors'
  LEFT JOIN
    components_glossary_dark_editors AS dark_editors
    ON gc_dark.component_id = dark_editors.id
  LEFT JOIN
    glossaries_components AS gc_light
    ON glossary.id = gc_light.entity_id
    AND gc_light.component_type = 'glossary.light-editor'
    AND gc_light.field = 'editors'
  LEFT JOIN
    components_glossary_light_editors AS light_editors
    ON gc_light.component_id = light_editors.id
       WHERE
       (
      glossary.title LIKE '%${sanitizedSearchText}%' 
      OR dark_editors.dark_editor LIKE '%${sanitizedSearchText}%' 
      OR light_editors.light_editor LIKE '%${sanitizedSearchText}%'
    )
    AND glossary.published_at IS NOT NULL;
    `;
      try {
        // Execute the query
        const results = await strapi.db.connection.raw(query);

        // Extract just the rows from the results (first element of the array)
        const rows = results[0];

        // Format the response according to Strapi's structure
        const formattedResponse = {
          data: rows.map((row) => ({
            id: row.id,
            attributes: {
              title: row.title,
              slug: row.slug,
            },
          })),
          meta: {
            pagination: {
              total: rows.length,
            },
          },
        };

        // Return the formatted response
        return formattedResponse;
      } catch (error) {
        console.error("Error executing query:", error);
        ctx.throw(500, {
          error: {
            status: 500,
            name: "Internal Server Error",
            message: "An error occurred while searching glossarys",
            details: error.message,
          },
        });
      }
    },
  })
);

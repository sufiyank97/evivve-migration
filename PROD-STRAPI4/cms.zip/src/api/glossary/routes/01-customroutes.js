module.exports = {
  routes: [
    {
      method: "GET",
      path: "/glossary/search",
      handler: "glossary.search",
      config: {
        policies: [],
      },
    },
  ],
};

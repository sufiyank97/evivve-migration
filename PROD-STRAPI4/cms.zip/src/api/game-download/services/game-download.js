'use strict';

/**
 * game-download service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::game-download.game-download');

'use strict';

/**
 * terms-of-service controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::terms-of-service.terms-of-service');

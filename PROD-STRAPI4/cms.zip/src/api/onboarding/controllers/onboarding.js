'use strict';

/**
 * onboarding controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::onboarding.onboarding');

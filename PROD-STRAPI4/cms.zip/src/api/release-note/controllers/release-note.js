"use strict";

/**
 * release-note controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController(
  "api::release-note.release-note",
  ({ strapi }) => ({
    async getReleaseNotesData(ctx) {
      try {
        const baseReleaseNotes = await strapi.db.connection.raw(`
            SELECT rn.*
            FROM release_notes rn
            LEFT JOIN release_notes_base_version_links rnbvl
            ON rn.id = rnbvl.release_note_id
            WHERE rnbvl.id IS NULL
            ORDER BY rn.base_version_order_number DESC
          `);

        const subVersions = await strapi.db.connection.raw(`
            SELECT rnbvl.inv_release_note_id AS base_id, rn.*
            FROM release_notes rn
            JOIN release_notes_base_version_links rnbvl
            ON rn.id = rnbvl.release_note_id
          `);

        const subVersionsByBase = subVersions[0].reduce((acc, item) => {
          if (!acc[item.base_id]) {
            acc[item.base_id] = [];
          }
          acc[item.base_id].push({
            id: item.id,
            title: item.title,
            slug: item.slug,
            version: item.version,
            created_at: item.created_at,
            updated_at: item.updated_at,
            published_at: item.published_at,
          });
          return acc;
        }, {});

        // Combine base release notes with their subversions
        const result = baseReleaseNotes[0].map((baseNote) => ({
          ...baseNote,
          sub_versions: subVersionsByBase[baseNote.id] || [],
        }));

        // Send the combined response
        ctx.send({
          data: result,
        });
      } catch (error) {
        console.error("Error fetching newsroom data:", error);
        ctx.throw(500, "Failed to fetch newsroom data");
      }
    },

    async search(ctx) {
      const { searchingText } = ctx.query;

      // Sanitize the search input to prevent SQL injection
      const sanitizedSearchText = searchingText.replace(/'/g, "''");

      const query = `
      SELECT DISTINCT
       release_note.id,
       release_note.title,
       release_note.slug,
       release_note.description,
       release_note.version,
       release_note.published_at
       FROM
       release_notes AS release_note
       WHERE
       (
      release_note.title LIKE '%${sanitizedSearchText}%' 
      OR release_note.description LIKE '%${sanitizedSearchText}%'
      OR release_note.version LIKE '%${sanitizedSearchText}%'
    )
    AND release_note.published_at IS NOT NULL;
    `;
      try {
        // Execute the query
        const results = await strapi.db.connection.raw(query);

        // Extract just the rows from the results (first element of the array)
        const rows = results[0];

        // Format the response according to Strapi's structure
        const formattedResponse = {
          data: rows.map((row) => ({
            id: row.id,
            attributes: {
              title: row.title,
              slug: row.slug,
            },
          })),
          meta: {
            pagination: {
              total: rows.length,
            },
          },
        };

        // Return the formatted response
        return formattedResponse;
      } catch (error) {
        console.error("Error executing query:", error);
        ctx.throw(500, {
          error: {
            status: 500,
            name: "Internal Server Error",
            message: "An error occurred while searching release notes",
            details: error.message,
          },
        });
      }
    },
  })
);

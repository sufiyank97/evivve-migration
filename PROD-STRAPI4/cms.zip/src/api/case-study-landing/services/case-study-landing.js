'use strict';

/**
 * case-study-landing service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::case-study-landing.case-study-landing');
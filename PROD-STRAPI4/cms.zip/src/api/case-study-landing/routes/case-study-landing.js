'use strict';

/**
 * case-study-landing router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::case-study-landing.case-study-landing');

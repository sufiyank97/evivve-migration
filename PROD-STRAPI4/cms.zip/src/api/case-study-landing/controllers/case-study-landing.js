'use strict';

/**
 * case-study-landing controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::case-study-landing.case-study-landing');
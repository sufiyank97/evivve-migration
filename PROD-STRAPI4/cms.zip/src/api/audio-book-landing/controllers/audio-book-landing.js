'use strict';

/**
 * audio-book-landing controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::audio-book-landing.audio-book-landing');

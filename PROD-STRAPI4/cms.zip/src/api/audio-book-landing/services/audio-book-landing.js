'use strict';

/**
 * audio-book-landing service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::audio-book-landing.audio-book-landing');

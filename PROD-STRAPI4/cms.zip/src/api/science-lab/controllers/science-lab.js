"use strict";

/**
 * science-lab controller
 */

const { createCoreController } = require("@strapi/strapi").factories;
const axios = require("axios");

module.exports = createCoreController(
  "api::science-lab.science-lab",
  ({ strapi }) => ({
    async duplicateEntry(ctx) {
      const paramId = ctx.params.id;

      const fetchScienceLab = (id) => {
        return `
            query getScienceLab {
              scienceLabs( filters: { id: { eq: "${id}" } } ) {
                data {
                  attributes {
                    title
                    slug
                    hero_section {
                        sub_title
                        title
                        description
                        labs_hero_section_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                        }
                        background_video {
                            data {
                            id
                            attributes {
                                url
                            }
                            }
                        }
                        button_type
                        }
                        stats_section {
                        sub_title
                        title
                        description
                        }
                        models_and_frameworks_section {
                        title
                        description
                        list {
                            title
                            description
                            icon {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                            image {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                        }
                        }
                        inside_labs_section {
                        title
                        description
                        features {
                            title
                            description
                            icon {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                        }
                        }
                        neuro_science {
                        title
                        description
                        bg_design_image{
                            data{
                                id
                                attributes{
                                    url
                                }
                            }
                        }
                        features {
                            title
                            description
                        }
                        }
                        evidence_based_strategy {
                        title
                        description
                        features {
                            icon {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                            title
                            pill
                            image {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                            description
                        }
                        }
                        science_backed_approach {
                        title
                        description
                        cards {
                            show_content_or_image
                            title
                            description
                            color
                            image {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                        }
                        }
                        approach_section {
                        title
                        description
                        cards {
                            background_video {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                            background_color
                            icon {
                            data {
                                id
                                attributes {
                                url
                                }
                            }
                            }
                            title
                            description
                            button_link
                        }
                        }
                        faq {
                        title
                        faq_list {
                            question
                            answer
                        }
                        }
                        cta {
                        title
                        description
                        labs_CTA_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                        }
                        background_video {
                            data {
                            id
                            attributes {
                                url
                            }
                            }
                        }
                        button_type
                    }
                    form {
                        form
                        form_onload
                        form_onsubmit
                    }
                    seo {
                        metaTitle
                        metaDescription
                        metaImage{
                            data{
                                id
                                attributes{
                                    url
                                }
                            }
                        }
                        metaSocial{
                            socialNetwork
                            title
                            description
                            image{
                                data{
                                id
                                    attributes{
                                        url
                                    }
                                }
                            }
                        }
                        keywords
                        metaRobots
                        structuredData
                        metaViewport
                        canonicalURL
                    }
                    }
                }
              }
            }
          `;
      };

      const url = process.env.STRAPI_URL;

      try {
        const originalEntry = await axios.post(`${url}graphql`, {
          query: fetchScienceLab(paramId),
        });

        const resData =
          originalEntry?.data?.data?.scienceLabs?.data[0]?.attributes;

        if (!resData) {
          return ctx.notFound("Entry not found");
        }

        // Universal processor that handles everything automatically
        const processData = (obj) => {
          if (!obj || typeof obj !== "object") return obj;

          // Handle GraphQL media relations (convert { data: {...} } to ID)
          if (obj.data !== undefined) {
            if (Array.isArray(obj.data)) {
              return obj.data.map((item) => item.id);
            } else if (obj.data && obj.data.id) {
              return obj.data.id;
            } else if (obj.data === null) {
              return null;
            }
          }

          // Handle arrays
          if (Array.isArray(obj)) {
            return obj.map((item) => processData(item));
          }

          // Handle dynamic zone components (has __typename)
          if (obj.__typename) {
            const { __typename, ...rest } = obj;

            // Map component typename to Strapi format
            const componentMap = {
              ComponentButtonButtonImageText: "button.button-image-text",
              ComponentButtonButtonText: "button.button-text",
              ComponentCommonButton: "common.button",
              ComponentButtonNewsletter: "button.newsletter",
              ComponentPopupPopup: "popup.popup",
              ComponentCommonAppDownload: "common.app-download",
            };

            const __component =
              componentMap[__typename] ||
              __typename
                ?.replace("Component", "")
                ?.replace(/([A-Z])/g, (match) => `-${match.toLowerCase()}`)
                ?.replace(/^-/, "");

            const processedRest = processData(rest);

            // Normalize button targets
            normalizeButtonTargets(processedRest);

            return {
              ...processedRest,
              __component,
            };
          }

          // Handle regular objects
          const result = {};
          for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
              result[key] = processData(obj[key]);
            }
          }
          return result;
        };

        // Normalize button targets throughout the data
        const normalizeButtonTargets = (obj) => {
          if (!obj || typeof obj !== "object") return;

          if (Array.isArray(obj)) {
            obj.forEach((item) => normalizeButtonTargets(item));
            return;
          }

          for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (key === "button_target" || key === "link_target") {
                obj[key] =
                  obj[key] === "_blank" || obj[key] === "blank"
                    ? "_blank"
                    : "_self";
              } else {
                normalizeButtonTargets(obj[key]);
              }
            }
          }
        };

        // Process all data automatically
        const processedData = processData(resData);

        // Normalize all button targets
        normalizeButtonTargets(processedData);

        // Create new entry data with modified slug
        const newEntryData = {
          ...processedData,
          slug: `${resData.slug}-copy`,
        };

        // Remove undefined values
        const cleanData = JSON.parse(
          JSON.stringify(newEntryData, (key, value) => {
            return value === undefined ? null : value;
          })
        );

        const duplicatedEntry = await strapi.entityService.create(
          "api::science-lab.science-lab",
          {
            data: cleanData,
          }
        );

        ctx.send(duplicatedEntry);
      } catch (error) {
        console.error("Error duplicating entry:", error);
        console.error("Error details:", error.response?.data || error.message);

        return ctx.badRequest("Failed to duplicate entry", {
          error: error.message,
          details: error.response?.data,
        });
      }
    },
  })
);

module.exports = {
  routes: [
    {
      method: "GET",
      path: "/science-lab/duplicate/:id", // Customize the route path as needed
      handler: "science-lab.duplicateEntry", // Matches the controller's duplicate method
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};

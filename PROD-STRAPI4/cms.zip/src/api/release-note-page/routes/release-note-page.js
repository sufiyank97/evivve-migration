'use strict';

/**
 * release-note-page router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::release-note-page.release-note-page');

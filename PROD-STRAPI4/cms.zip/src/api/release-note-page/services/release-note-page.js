'use strict';

/**
 * release-note-page service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::release-note-page.release-note-page');

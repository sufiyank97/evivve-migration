'use strict';

/**
 * journal-landing service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::journal-landing.journal-landing');

'use strict';

/**
 * why-evivve controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::why-evivve.why-evivve');

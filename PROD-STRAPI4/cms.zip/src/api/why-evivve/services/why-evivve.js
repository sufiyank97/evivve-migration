'use strict';

/**
 * why-evivve service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::why-evivve.why-evivve');

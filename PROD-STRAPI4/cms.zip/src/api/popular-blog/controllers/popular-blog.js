'use strict';

/**
 * popular-blog controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::popular-blog.popular-blog');

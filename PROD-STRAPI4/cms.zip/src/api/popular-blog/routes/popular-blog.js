'use strict';

/**
 * popular-blog router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::popular-blog.popular-blog');

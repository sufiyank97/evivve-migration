'use strict';

/**
 * logo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::logo.logo');

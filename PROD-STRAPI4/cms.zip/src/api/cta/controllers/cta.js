"use strict";

/**
 * cta controller
 */

const { createCoreController } = require("@strapi/strapi").factories;
const axios = require("axios");

module.exports = createCoreController("api::cta.cta", ({ strapi }) => ({
  async duplicateEntry(ctx) {
    const paramId = ctx.params.id;

    const fetchCtas = (id) => {
      return `
            query ctas {
              ctas( filters: { id: { eq: "${id}" } } ) {
                data {
                  id
                    attributes {
                        title
                        description_type {
                        __typename
                        ... on ComponentKnowledgeBase3CardsCtas {
                            card {
                            title
                            description
                            image {
                                data {
                                id
                                attributes {
                                    url
                                }
                                }
                            }
                            link_title
                            link_href
                            link_target
                            }
                        }
                        }
                        use_cases {
                        data {
                            id
                        }
                        }
                        blogs {
                        data {
                            id
                        }
                        }
                        glossaries {
                        data {
                            id
                        }
                        }
                        press_releases {
                        data {
                            id
                        }
                        }
                        release_notes {
                        data {
                            id
                        }
                        }
                        knowledge_bases {
                        data {
                            id
                        }
                        }
                    }
                }
              }
            }
          `;
    };

    const url = process.env.STRAPI_URL;

    const originalEntry = await axios.post(`${url}graphql`, {
      query: fetchCtas(paramId),
    });
    const resData = originalEntry?.data?.data?.ctas?.data[0]?.attributes;

    if (!originalEntry) {
      return ctx.notFound("Entry not found");
    }

    const transformTemplates = (description_type) => {
      // Helper function to extract image IDs (only if it has 'attributes' and 'url')
      const extractImageIds = (obj) => {
        if (!obj || typeof obj !== "object") return obj;

        // Check if object is an image with 'attributes' and 'url' before returning ID
        if (obj.data && obj.data.attributes && obj.data.attributes.url) {
          return obj.data.id; // Extract the ID only if the image has 'attributes' and 'url'
        }

        // Recursively traverse nested objects to find image IDs
        for (const key in obj) {
          obj[key] = extractImageIds(obj[key]);
        }
        return obj;
      };

      const normalizeButtonTarget = (target) => {
        if (target === "self" || target === "_self") return "_self";
        if (target === "blank" || target === "_blank") return "_blank";
        return "_self"; // default fallback
      };

      const mapTypenameToComponent = (typename) => {
        switch (typename) {
          case "ComponentKnowledgeBase3CardsCtas":
            return "knowledge-base.3-cards-ctas";
          default:
            return null;
        }
      };

      return description_type
        .map((cta) => {
          const { __typename, ...item } = cta;

          const __component = mapTypenameToComponent(__typename);

          if (!__component) return null; // skip unknown types

          // Normalize all button_target fields
          const normalizeTargetsDeep = (obj) => {
            if (!obj || typeof obj !== "object") return;

            for (const key in obj) {
              if (
                (key === "button_target" || key === "link_target") &&
                (typeof obj[key] === "string" || obj[key] == null)
              ) {
                obj[key] = normalizeButtonTarget(obj[key]);
              } else {
                normalizeTargetsDeep(obj[key]);
              }
            }
          };
          normalizeTargetsDeep(item);

          const modifiedTemplate = extractImageIds(item);

          return {
            ...modifiedTemplate,
            __component,
          };
        })
        .filter(Boolean);
    };

    const extractRelationIds = (relation) => {
      return relation?.data?.map((item) => Number(item.id)) || [];
    };

    const newEntryData = {
      ...resData,
      title: `${resData.title}-copy`,
      description_type: transformTemplates(resData.description_type),
      use_cases: extractRelationIds(resData.use_cases),
      blogs: extractRelationIds(resData.blogs),
      glossaries: extractRelationIds(resData.glossaries),
      press_releases: extractRelationIds(resData.press_releases),
      release_notes: extractRelationIds(resData.release_notes),
      knowledge_bases: extractRelationIds(resData.knowledge_bases),
    };

    const duplicatedEntry = await strapi.entityService.create("api::cta.cta", {
      data: newEntryData,
    });

    ctx.send(duplicatedEntry);
  },
}));

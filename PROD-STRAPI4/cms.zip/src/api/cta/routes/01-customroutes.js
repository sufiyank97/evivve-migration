module.exports = {
  routes: [
    {
      method: "GET",
      path: "/cta/duplicate/:id", // Customize the route path as needed
      handler: "cta.duplicateEntry", // Matches the controller's duplicate method
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};

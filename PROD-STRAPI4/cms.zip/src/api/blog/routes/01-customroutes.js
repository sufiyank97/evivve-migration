module.exports = {
  routes: [
    {
      method: "GET",
      path: "/blog/search",
      handler: "blog.search",
      config: {
        policies: [],
      },
    },
  ],
};

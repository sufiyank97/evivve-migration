'use strict';

/**
 * glossary-page controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::glossary-page.glossary-page');

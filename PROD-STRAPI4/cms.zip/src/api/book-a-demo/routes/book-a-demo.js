'use strict';

/**
 * book-a-demo router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::book-a-demo.book-a-demo');

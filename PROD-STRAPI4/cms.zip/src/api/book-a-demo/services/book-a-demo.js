'use strict';

/**
 * book-a-demo service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::book-a-demo.book-a-demo');

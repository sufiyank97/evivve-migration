'use strict';

/**
 * testimonial service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::testimonial.testimonial');

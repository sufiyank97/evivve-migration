'use strict';

/**
 * newsroom router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::newsroom.newsroom');

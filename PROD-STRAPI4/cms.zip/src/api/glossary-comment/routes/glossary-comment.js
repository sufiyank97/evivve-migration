'use strict';

/**
 * glossary-comment router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::glossary-comment.glossary-comment');

'use strict';

/**
 * glossary-comment controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::glossary-comment.glossary-comment');

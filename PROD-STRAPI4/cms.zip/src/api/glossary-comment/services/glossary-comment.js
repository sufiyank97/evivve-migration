'use strict';

/**
 * glossary-comment service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::glossary-comment.glossary-comment');

"use strict";

/**
 * landing-page controller
 */

const { createCoreController } = require("@strapi/strapi").factories;
const axios = require("axios");

module.exports = createCoreController(
  "api::landing-page.landing-page",
  ({ strapi }) => ({
    async duplicateEntry(ctx) {
      const paramId = ctx.params.id;

      const fetchLandingPages = (id) => {
        return `
            query getLandingPages {
              landingPages( filters: { id: { eq: "${id}" } } ) {
                data {
                  attributes {
                    title
                    slug
                    category
                    seo {
                        metaTitle
                        metaDescription
                        metaImage{
                            data{
                                id
                                attributes{
                                    url
                                }
                            }
                        }
                        metaSocial{
                            socialNetwork
                            title
                            description
                            image{
                                data{
                                id
                                    attributes{
                                        url
                                    }
                                }
                            }
                        }
                        keywords
                        metaRobots
                        structuredData
                        metaViewport
                        canonicalURL
                    }
                    templates {
                      ... on ComponentLandingPageMasterclass {
                        __typename
                        show_intro_animation
                        animations {
                          bg_img_1 {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          bg_img_2 {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          evivve_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          fav_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          e_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          masterclass_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          mobile_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          screen1 {
                            title
                            description
                            button_text
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                          screen2 {
                            title
                            description
                            button_text
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                          screen3 {
                            title
                            date
                            time
                            button_text
                            video {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                            video_thumbnail {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                          screen4_button_text
                        }
                        show_custom_navbar
                        custom_navbar {
                          links
                        }
                        agenda {
                          title
                          image {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          what_you_can_expect_title
                          what_you_can_expect_list {
                            list
                          }
                          time_and_date {
                            title
                            date
                            time
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        industry_experts {
                          title
                          experts_list {
                            name
                            designation
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        count {
                          count_number
                          count_text
                        }
                        brands {
                          title1
                          title2
                          title_icon
                          brands1 {
                            data {
                            id
                              attributes {
                                image {
                                  data {
                                  id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                          brands2 {
                            data {
                            id
                              attributes {
                                image {
                                  data {
                                  id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                          brands3 {
                            data {
                            id
                              attributes {
                                image {
                                  data {
                                  id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                        certifications {
                          title
                          cards {
                            name
                            description
                            bg_color
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        register {
                          title
                          register_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                          }
                          zoho_form_type
                        }
                        faq {
                          title
                          faq_list {
                            question
                            answer
                          }
                        }
                      }
                      ... on ComponentLandingPageTemplate2 {
                        __typename
                        show_intro_animation
                        animations {
                          bg_img_1 {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          bg_img_2 {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          evivve_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          fav_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          e_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          masterclass_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          mobile_logo {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          screen1 {
                            title
                            description
                            button_text
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                          screen2 {
                            title
                            description
                            button_text
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                          screen3 {
                            title
                            description
                            button_text
                            video {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                            video_thumbnail {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                          screen4_button_text
                        }
                        show_custom_navbar
                        custom_navbar {
                          links
                        }
                        agenda {
                          title
                          image {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                          what_you_can_expect_title
                          what_you_can_expect_list {
                            list
                          }
                          time_and_date {
                            title
                            date
                            time
                            template2_date
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        content {
                          title
                          weeks_session_card {
                            title
                            list
                          }
                        }
                        hosts {
                          title
                          experts_list {
                            name
                            designation
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        count {
                          count_number
                          count_text
                        }
                        brands {
                          title1
                          title2
                          title_icon
                          brands1 {
                            data {
                            id
                              attributes {
                                image {
                                  data {
                                  id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                          brands2 {
                            data {
                            id
                              attributes {
                                image {
                                  data {
                                  id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                          brands3 {
                            data {
                            id
                              attributes {
                                image {
                                  data {
                                  id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                        testimonials {
                          title
                          cards {
                            name
                            description
                            bg_color
                            image {
                              data {
                              id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        get_certified_now {
                          title
                          list
                          image {
                            data {
                            id
                              attributes {
                                url
                              }
                            }
                          }
                        }
                        register {
                          title
                          register_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                          }
                          zoho_form_type
                        }
                        new_register {
                          form
                          form_onload
                          form_onsubmit
                          title
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                          quote
                          company_image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                          name
                          designation
                          brands_title
                          brands {
                            data {
                              attributes {
                                image {
                                  data {
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                        faq {
                          title
                          faq_list {
                            question
                            answer
                          }
                        }
                      }
                      ... on ComponentLandingPageTemplate3 {
                        __typename
                        aferr_model {
                          title
                          description
                          aferr_model_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                          }
                          image {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                        }
                        advantages {
                          title
                          advantages_list {
                            title
                            description
                            image {
                              data {
                                id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        preview {
                          title
                          preview_list
                          button_text
                          image {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                        }
                        dive_deep {
                          title
                          dive_deep_list {
                            title
                            description
                          }
                        }
                        why_download {
                          title
                          why_dowload_list {
                            title
                            description
                          }
                          description
                        }
                        brands {
                          title1
                          title2
                          title_icon
                          brands1 {
                            data {
                              id
                              attributes {
                                image {
                                  data {
                                    id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                          brands2 {
                            data {
                              id
                              attributes {
                                image {
                                  data {
                                    id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                          brands3 {
                            data {
                              id
                              attributes {
                                image {
                                  data {
                                    id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                        faq {
                          title
                          faq_list {
                            question
                            answer
                          }
                        }
                      }
                      ... on ComponentLandingPageTemplate4 {
                        __typename
                        form {
                          form
                          form_onload
                          form_onsubmit
                        }
                        first_section {
                          title
                          description
                          first_section_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                          }
                          button_type
                          image {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                        }
                        why_choose {
                          title
                          description
                          first_section_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                          }
                          button_type
                          image {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                        }
                        agenda {
                          title
                          description
                          image {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                          upcoming_programs_title
                          upcoming_programs {
                            month
                            dates
                            location
                            time
                            show_tagline
                            tagline
                            level
                            button_type
                            upcoming_program_button {
                              button_text
                              button_link
                              button_target
                              button_icon
                            }
                            overwrite_bgcolor
                            bgcolor
                            divider_color
                          }
                        }
                        hosts {
                          title
                          experts_list {
                            name
                            designation
                            description
                            linkedin_url
                            image {
                              data {
                                id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        count {
                          count_number
                          count_text
                        }
                        brands {
                          title
                          brands {
                            data {
                              id
                              attributes {
                                image {
                                  data {
                                    id
                                    attributes {
                                      url
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                        what_you_get {
                          title
                          what_you_get_list {
                            icon {
                              data {
                                id
                                attributes {
                                  url
                                }
                              }
                            }
                            title
                            description
                            button {
                              button_text
                              button_link
                              button_target
                              button_icon
                            }
                          }
                        }
                        content {
                          title
                          weeks_session_card {
                            title
                            list
                          }
                          display
                        }
                        testimonials {
                          title
                          display
                          cards {
                            name
                            description
                            bg_color
                            image {
                              data {
                                id
                                attributes {
                                  url
                                }
                              }
                            }
                          }
                        }
                        get_certified_now {
                          title
                          list
                          display
                          image {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                          get_certified_now_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                          }
                          button_type
                        }
                        faq {
                          title
                          faq_list {
                            question
                            answer
                          }
                          display
                        }
                        consult_section {
                          title
                          display
                          default_images {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                          active_images {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                          cards {
                            card_title
                            image {
                              data {
                                id
                                attributes {
                                  url
                                }
                              }
                            }
                            description
                            sub_title
                            list {
                              data
                            }
                          }
                        }
                        case_stalwart {
                          title
                          display
                          case_study {
                            study_title
                            category
                            image {
                              data {
                                id
                                attributes {
                                  url
                                }
                              }
                            }
                            description
                            read_more {
                              button_text
                              button_link
                              button_target
                              button_icon
                            }
                          }
                        }
                        core {
                          title
                          display
                          image {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                          list {
                            description
                          }
                          core_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                          }
                        }
                      }
                      ... on ComponentLandingPageTemplate5 {
                        __typename
                        content {
                          title
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                          description
                          form
                          form_onsubmit
                          form_onload
                          video
                          video_description
                        }
                        pay_offs_section {
                          title
                          list {
                            title
                            description
                          }
                        }
                        get_started {
                          title
                          case_study_get_started_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          `;
      };

      const url = process.env.STRAPI_URL;

      const originalEntry = await axios.post(`${url}graphql`, {
        query: fetchLandingPages(paramId),
      });
      const resData =
        originalEntry?.data?.data?.landingPages?.data[0]?.attributes;

      if (!originalEntry) {
        return ctx.notFound("Entry not found");
      }

      const transformTemplates = (templates) => {
        // Helper function to extract image IDs (only if it has 'attributes' and 'url')
        const extractImageIds = (obj) => {
          if (!obj || typeof obj !== "object") return obj;

          // Check if object is an image with 'attributes' and 'url' before returning ID
          if (obj.data && obj.data.attributes && obj.data.attributes.url) {
            return obj.data.id; // Extract the ID only if the image has 'attributes' and 'url'
          }

          // Recursively traverse nested objects to find image IDs
          for (const key in obj) {
            obj[key] = extractImageIds(obj[key]);
          }
          return obj;
        };

        const normalizeButtonTarget = (target) => {
          if (target === "self" || target === "_self") return "_self";
          if (target === "blank" || target === "_blank") return "_blank";
          return "_self"; // default fallback
        };

        return templates
          .map((template) => {
            const { __typename, ...restTemplate } = template;
            if (!__typename?.startsWith("ComponentLandingPage")) return null;

            let __component = __typename
              .replace("ComponentLandingPage", "landing-page")
              .replace(/([A-Z])/g, (match) => `.${match.toLowerCase()}`)
              .replace(/([a-z])(\d+)/g, (match, p1, p2) => `${p1}-${p2}`);

            if (__component === "landing-page.template-3") {
              __component = "landing-page.template3";
            }

            // Normalize all button_target fields
            const normalizeTargetsDeep = (obj) => {
              if (!obj || typeof obj !== "object") return;

              for (const key in obj) {
                if (
                  key === "button_target" &&
                  (typeof obj[key] === "string" || obj[key] == null)
                ) {
                  obj[key] = normalizeButtonTarget(obj[key]);
                } else {
                  normalizeTargetsDeep(obj[key]);
                }
              }
            };
            normalizeTargetsDeep(restTemplate);

            // Normalize brands relations
            if (restTemplate.brands) {
              const transformBrandImages = (brandArray) => {
                return brandArray?.data?.map((item) => item.id) || [];
              };
              restTemplate.brands.brands1 = transformBrandImages(
                restTemplate.brands.brands1
              );
              restTemplate.brands.brands2 = transformBrandImages(
                restTemplate.brands.brands2
              );
              restTemplate.brands.brands3 = transformBrandImages(
                restTemplate.brands.brands3
              );
            }

            const modifiedTemplate = extractImageIds(restTemplate);

            return {
              ...modifiedTemplate,
              __component,
            };
          })
          .filter(Boolean);
      };

      const newEntryData = {
        ...resData,
        slug: `${resData.slug}-copy`, // Modify slug to be unique
        templates: transformTemplates(resData.templates),
      };

      const duplicatedEntry = await strapi.entityService.create(
        "api::landing-page.landing-page",
        {
          data: newEntryData,
        }
      );

      ctx.send(duplicatedEntry);
    },
  })
);

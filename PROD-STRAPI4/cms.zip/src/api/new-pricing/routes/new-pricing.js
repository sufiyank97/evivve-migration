'use strict';

/**
 * new-pricing router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::new-pricing.new-pricing');

'use strict';

/**
 * play-now router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::play-now.play-now');

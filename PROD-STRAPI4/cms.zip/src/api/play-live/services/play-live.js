'use strict';

/**
 * play-live service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::play-live.play-live');

'use strict';

/**
 * cookie-policy controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::cookie-policy.cookie-policy');

'use strict';

/**
 * cookie-policy router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::cookie-policy.cookie-policy');

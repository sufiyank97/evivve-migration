'use strict';

/**
 * knowledge-base-page router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::knowledge-base-page.knowledge-base-page');

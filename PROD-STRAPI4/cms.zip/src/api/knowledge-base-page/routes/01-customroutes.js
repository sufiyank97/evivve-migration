module.exports = {
  routes: [
    {
      method: "GET",
      path: "/knowledge-base-page/topics",
      handler: "knowledge-base-page.getKnowledgeBaseTopicsData",
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};

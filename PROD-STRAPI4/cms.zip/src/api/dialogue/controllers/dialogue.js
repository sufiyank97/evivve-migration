'use strict';

/**
 * dialogue controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::dialogue.dialogue');


'use strict';

/**
 * new-play-now controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::new-play-now.new-play-now');

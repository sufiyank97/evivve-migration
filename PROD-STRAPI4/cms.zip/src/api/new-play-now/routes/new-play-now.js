'use strict';

/**
 * new-play-now router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::new-play-now.new-play-now');

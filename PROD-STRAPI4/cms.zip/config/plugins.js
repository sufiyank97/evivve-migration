module.exports = ({ env }) => ({
  graphql: {
    config: {
      endpoint: "/graphql",
      playgroundAlways: true,
      defaultLimit: 100,
      maxLimit: 100,
      amountLimit: 100,
    },
  },
  upload: {
    config: {
      sizeLimit: 900 * 1024 * 1024, // 256mb in bytes
      provider: "aws-s3",
      providerOptions: {
        generateThumbnails: true,
        accessKeyId: "AKIAYE3AU5TQV2WECBPI",
        secretAccessKey: "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",
        region: "ap-south-1",
        params: {
          Bucket: "evivve-strapi-admin",
        },
      },
      actionOptions: {
        upload: {},
        uploadStream: {},
        delete: {},
      },
    },
  },
  seo: {
    enabled: true,
  },
  // "generate-schema": {
  //   enabled: true,
  // },
  "preview-button": {
    config: {
      contentTypes: [
        // homepage
        // {
        //   uid: "api::home.home",
        //   draft: {
        //     url: `${env("FRONTEND_URL")}api/preview`,
        //     query: {
        //       slug: "/home",
        //       secret: env("STRAPI_PREVIEW_SECRET"),
        //     },
        //   },
        //   published: {
        //     url: `${env("FRONTEND_URL")}`,
        //   },
        // },
        {
          uid: "api::about.about",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/about-us",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}about-us`,
          },
        },
        {
          uid: "api::privacy-policy.privacy-policy",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/privacy-policy",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}privacy-policy`,
          },
        },
        {
          uid: "api::cookie-policy.cookie-policy",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/cookie-policy",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}cookie-policy`,
          },
        },
        {
          uid: "api::terms-of-service.terms-of-service",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/terms-of-service",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}terms-of-service`,
          },
        },
        {
          uid: "api::testimonial-page.testimonial-page",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/testimonials",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}testimonials`,
          },
        },
        {
          uid: "api::case-study.case-study",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/case-study/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}/case-study/{slug}`,
          },
        },
        {
          uid: "api::dialogue.dialogue",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/dialogues/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}dialogues/{slug}`,
          },
        },
        {
          uid: "api::journal.journal",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/journal/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}journal/{slug}`,
          },
        },
        {
          uid: "api::case-study-landing.case-study-landing",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/case-study",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}case-study`,
          },
        },
        {
          uid: "api::dialogue-landing.dialogue-landing",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/dialogues",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}dialogues`,
          },
        },
        {
          uid: "api::journal-landing.journal-landing",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/journal",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}journal`,
          },
        },
        {
          uid: "api::pricing.pricing",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/pricing",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}pricing`,
          },
        },
        {
          uid: "api::new-pricing.new-pricing",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/pricing",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}pricing`,
          },
        },
        {
          uid: "api::book-a-demo.book-a-demo",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/schedule-a-call",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}schedule-a-call`,
          },
        },
        // {
        //   uid: "api::play-now.play-now",
        //   draft: {
        //     url: `${env("FRONTEND_URL")}api/preview`,
        //     query: {
        //       slug: "/play-now",
        //       secret: env("STRAPI_PREVIEW_SECRET"),
        //     },
        //   },
        //   published: {
        //     url: `${env("FRONTEND_URL")}play-now`,
        //   },
        // },
        {
          uid: "api::new-play-now.new-play-now",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/play-now",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}play-now`,
          },
        },
        {
          uid: "api::play-live.play-live",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/play-live",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}play-live`,
          },
        },
        {
          uid: "api::game-download.game-download",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/game-download",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}game-download`,
          },
        },
        {
          uid: "api::contact-page.contact-page",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/contact",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}contact`,
          },
        },
        {
          uid: "api::blog-page.blog-page",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/evivvo-pedia",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}evivvo-pedia`,
          },
        },
        {
          uid: "api::glossary-page.glossary-page",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/glossary",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}glossary`,
          },
        },
        {
          uid: "api::game.game",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/game",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}game`,
          },
        },
        {
          uid: "api::career.career",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/careers",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}careers`,
          },
        },
        {
          uid: "api::newsroom.newsroom",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/newsroom",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}newsroom`,
          },
        },
        {
          uid: "api::release-note-page.release-note-page",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/release-notes",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}release-notes`,
          },
        },
        {
          uid: "api::knowledge-base-page.knowledge-base-page",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/knowledge-base",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}knowledge-base`,
          },
        },
        {
          uid: "api::why-evivve.why-evivve",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/why-evivve",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}why-evivve`,
          },
        },
        // collection type
        {
          uid: "api::blog.blog",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              blogDetail: "/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}{slug}`,
          },
        },
        {
          uid: "api::science-lab.science-lab",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              blogDetail: "/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}{slug}`,
          },
        },
        {
          uid: "api::landing-page.landing-page",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              landingPage: "/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}{slug}`,
          },
        },
        {
          uid: "api::glossary.glossary",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/glossary/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}glossary/{slug}`,
          },
        },
        {
          uid: "api::use-case.use-case",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              blogDetail: "/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}{slug}`,
          },
        },
        {
          uid: "api::thank-you-page.thank-you-page",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              blogDetail: "/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}{slug}`,
          },
        },
        {
          uid: "api::author.author",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/author/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}author/{slug}`,
          },
        },
        {
          uid: "api::category.category",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/categories/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}categories/{slug}`,
          },
        },
        {
          uid: "api::tag.tag",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/tags/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}tags/{slug}`,
          },
        },
        {
          uid: "api::press-release.press-release",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/newsroom/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}newsroom/{slug}`,
          },
        },
        {
          uid: "api::knowledge-base.knowledge-base",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/knowledge-base/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}knowledge-base/{slug}`,
          },
        },
        {
          uid: "api::release-note.release-note",
          draft: {
            url: `${env("FRONTEND_URL")}api/preview`,
            query: {
              slug: "/release-notes/{slug}",
              secret: env("STRAPI_PREVIEW_SECRET"),
            },
          },
          published: {
            url: `${env("FRONTEND_URL")}release-notes/{slug}`,
          },
        },
      ],
    },
  },
});

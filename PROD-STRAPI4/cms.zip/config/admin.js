module.exports = ({ env }) => ({
  auth: {
    secret: env('ADMIN_JWT_SECRET','iBeyicSppjIW6q/tGx0giQ=='),
  },
  apiToken: {
    salt: env('API_TOKEN_SALT','DZRlgW/g7CXdFR44GtQwjw=='),
  },
  transfer: {
    token: {
      salt: env('TRANSFER_TOKEN_SALT','O4y8MuP9anmrLWzS/8/4SA=='),
    },
  },
  flags: {
    nps: env.bool('FLAG_NPS', true),
    promoteEE: env.bool('FLAG_PROMOTE_EE', true),
  },
});
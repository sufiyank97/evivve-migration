module.exports = ({ env }) => ({
  host: env('HOST', '0.0.0.0'),
  port: env.int('PORT', 1337),
  app: {
    keys: ['op+Bgf6Q+nXEDCF7hnxFMA==','juxfyJ94W+Gm81gWSkJkRw==','BZK4IN7Hq8eYFUauL3xDzg==','ZQ7iAJ51J6+TmqzfCVg2VA=='],
  },
  webhooks: {
    populateRelations: env.bool('WEBHOOKS_POPULATE_RELATIONS', false),
  },
});

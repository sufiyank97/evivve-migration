import Seo from "@/components/Common/seo";
import Brands from "@/components/LandingPages/common/Brands";
import Header from "@/components/Newsroom/Header";
import Section1 from "@/components/Newsroom/Section1";
import Section2 from "@/components/Newsroom/Section2";
import Section3 from "@/components/Newsroom/Section3";
import Section4 from "@/components/Newsroom/Section4";
import Videos from "@/components/Newsroom/Videos";
import { gql } from "@apollo/client";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import React from "react";

export default function Newsroom({ newsroomData }) {
  const titles = [
    newsroomData?.section1?.title,
    newsroomData?.section2?.title,
    newsroomData?.section3?.title,
    newsroomData?.section4?.title,
  ].filter(Boolean);

  return (
    <>
      <Seo data={newsroomData?.seo} />
      <main className="newsroom">
        <Header titles={titles} />
        {newsroomData?.section1 && <Section1 data={newsroomData?.section1} />}
        {newsroomData?.section2 && <Section2 data={newsroomData?.section2} />}
        {newsroomData?.section3 && <Section3 data={newsroomData?.section3} />}
        {newsroomData?.videos && <Videos data={newsroomData?.videos} />}
        {newsroomData?.brands && (
          <Brands
            data={newsroomData?.brands}
            button={newsroomData?.brands?.brands_button}
          />
        )}
        {newsroomData?.section4 && <Section4 data={newsroomData?.section4} />}
      </main>
    </>
  );
}

export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
        query newsroomData {
          newsroom ${preview ? "(publicationState:PREVIEW)" : ""} {
            data {
                attributes {
                    section1 {
                        title
                        feature_data {
                            title
                            description
                            publisher_name
                            date
                            feature_button {
                                button_text
                                button_link
                                button_target
                                button_icon
                            }
                            image {
                              data {
                                  attributes {
                                    url
                                  }
                              }
                            }
                        }
                    }
                    section2 {
                        title
                        award {
                            title
                            name
                            description
                            award_button {
                                button_text
                                button_link
                                button_target
                                button_icon
                            }
                            image {
                            data {
                                attributes {
                                url
                                }
                            }
                            }
                        }
                    }
                    section3 {
                        title
                    }
                    videos {
                        title
                        video_card {
                            video_embed_src_link
                            title
                        }
                    }
                    brands {
                        title1
                        title2
                        title_icon
                        brands1 {
                            data {
                            attributes {
                                image {
                                data {
                                    attributes {
                                    url
                                    }
                                }
                                }
                            }
                            }
                        }
                        brands2 {
                            data {
                            attributes {
                                image {
                                data {
                                    attributes {
                                    url
                                    }
                                }
                                }
                            }
                            }
                        }
                        brands3 {
                            data {
                            attributes {
                                image {
                                data {
                                    attributes {
                                    url
                                    }
                                }
                                }
                            }
                            }
                        }
                        brands_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                        }
                    }
                    section4 {
                        title
                        description
                        section4_button {
                            button_text
                            button_link
                            button_target
                            button_icon
                        }
                    }
                    ${getSeoData}
                }
            }
          }
        }
      `,
  });
  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/newsroom/`,
        permanent: true,
      },
    };
  }
  return {
    props: {
      newsroomData: data?.newsroom?.data?.attributes || null,
    },
  };
}

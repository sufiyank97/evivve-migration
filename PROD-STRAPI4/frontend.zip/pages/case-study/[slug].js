import React, { useContext, useEffect } from "react";
import dynamic from "next/dynamic";
import { fetchCaseStudyData } from "graphql/getCaseStudy";
import { convertToBase64 } from "@/utils/helper";
const Seo = dynamic(() => import("@/components/Common/seo"));
import { AppContext } from "context/AppContextProvider";
import { useRouter } from "next/router";
import Schema from "@/components/Common/Schema";
import CaseStudyDetail from "@/components/LandingPages/aferrMaster/CaseStudyDetail";

const CaseStudyPage = ({ caseStudyData, seoData }) => {
  const { setLoading } = useContext(AppContext);
  const router = useRouter();

  useEffect(() => {
    if (setLoading) {
      setLoading(false);
    }
  }, [setLoading]);

  if (!caseStudyData) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <h1>Case Study Not Found</h1>
        <p>The case study "{router.query.slug}" could not be found.</p>
        <a href="/case-study">← Back to Case Studies</a>
      </div>
    );
  }

  const { attributes } = caseStudyData;
  const { templates } = attributes;

  console.log("Case study attributes:", attributes);
  console.log("Templates:", templates);

  // Get the first template (since we only expect one per case study)
  const template = templates?.[0];

  console.log("Selected template:", template);

  if (!template) {
    console.log("No template found for this case study");
    return <div>No template found for this case study</div>;
  }

  return (
    <>
      <Seo seoData={seoData} />
      <Schema schemaData={seoData} />
      <CaseStudyDetail data={template} />
    </>
  );
};

export async function getServerSideProps(context) {
  const { params } = context;
  const { preview } = context.query;
  const { slug } = params;

  try {
    console.log(`Fetching case study data for slug: ${slug}`);
    const { data, error } = await fetchCaseStudyData(slug, preview);
    
    console.log("Case study query result:", { data, error });
    console.log("Case studies data length:", data?.caseStudies?.data?.length);
    console.log("First case study attributes:", data?.caseStudies?.data?.[0]?.attributes);
    console.log("Templates length:", data?.caseStudies?.data?.[0]?.attributes?.templates?.length);
    
    if (error) {
      console.error("GraphQL error:", error);
      return {
        redirect: {
          destination: `/500?url=${encodeURIComponent(`/case-study/${slug}`)}`,
          permanent: false,
        },
      };
    }
    
    if (!data?.caseStudies?.data?.length) {
      console.log("No case study found for slug:", slug);
      return {
        redirect: {
          destination: `/404?url=${encodeURIComponent(`/case-study/${slug}`)}`,
          permanent: false,
        },
      };
    }

    const caseStudyData = data.caseStudies.data[0];
    const seoData = caseStudyData.attributes.seo || null;

    return {
      props: {
        caseStudyData,
        seoData,
      },
    };
  } catch (error) {
    console.error("Error fetching case study data:", error);
    return {
      redirect: {
        destination: `/500?url=${encodeURIComponent(`/case-study/${slug}`)}`,
        permanent: false,
      },
    };
  }
}

export default CaseStudyPage;

import { gql } from "@apollo/client";
import client from "lib/apollo-client/ApolloClient";

const generateRobotTxt = (thankyouPagesData) => {
  const environment = process.env.NEXT_PUBLIC_ENVIRONMENT;
  let siteUrl = "https://evivve.com";
  let xml = "";
  xml += `User-agent: *
`;
  //   xml += `Disallow: /free-resources
  //       `;
  if (environment === "staging") {
    // Disallow all indexing for staging
    xml += `Disallow: /\n`;
  } else {
    thankyouPagesData.forEach((page) => {
      const slug = page?.attributes?.slug;
      if (slug) {
        xml += `Disallow: /${slug}/\n`;
      }
    });
    xml += `Disallow: ${siteUrl}/llms.txt/\n`;
    xml += `Allow: /
Sitemap: ${siteUrl}/sitemap.xml
          `;
         
  }

  return xml;
};

const getThankyouPages = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getThankyouPagesData {
        thankYouPages {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.thankYouPages?.data) {
    return data?.thankYouPages?.data || [];
  }
};

export async function getServerSideProps({ res }) {
  const thankyouPagesData = await getThankyouPages();

  res.setHeader("Content-Type", "text/plain");

  res.write(generateRobotTxt(thankyouPagesData));
  res.end();

  return {
    props: {},
  };
}

const RobotsTxT = () => null;
export default RobotsTxT;

import BreadCrumbs from "@/components/Common/BreadCrumbs/BreadCrumbs";
import { gql } from "@apollo/client";
import client from "lib/apollo-client/ApolloClient";
import React, { useContext, useEffect, useState } from "react";
import AppDownload from "@/components/Courses/AppDownload";
import Button from "@/components/Common/Button";
import ButtonText from "@/components/Common/ButtonText";
import JoinOurCommunity from "@/components/AboutUs/JoinOurCommunity";
import Zoho from "@/components/Blog/BlogDetails/Zoho";
import Editors from "@/components/Glossary/Editors";
import References from "@/components/Glossary/References";
import Author from "@/components/Glossary/Author";
import Share from "@/components/Glossary/Share";
import RelatedBlogs from "@/components/Glossary/RelatedBlogs";
import Comments from "@/components/Glossary/Comments";
import { getSeoData } from "graphql/getSeoData";
import Seo from "@/components/Common/seo";
import { useRouter } from "next/router";
import ExitIntentPopup from "@/components/Common/ExitIntentPopup";
import { AppContext } from "context/AppContextProvider";

export default function GlossaryDetails({ glossaryData, glossaryId }) {
  console.log("glossaryId:", glossaryId);
  console.log("glossaryData:", glossaryData);
  const authorData = glossaryData?.author?.data?.attributes || null;
  const relatedBlogs =
    glossaryData?.tags?.data.flatMap(
      (tag) => tag?.attributes?.blogs?.data || []
    ) || [];

  const { showStripe } = useContext(AppContext);

  const [popup, setPopup] = useState({});
  const [showPopup, setShowPopup] = useState(false);
  const [exitIntentCloseCookies, setExitIntentCloseCookies] = useState(false);
  const router = useRouter();
  const currentSlug = router.asPath;

  const getPopupData = () => {
    let filteredPopupData = [];
    if (glossaryData) {
      filteredPopupData = glossaryData?.ctas?.data?.filter((item) =>
        item?.attributes?.description_type?.find(
          (subItem) => subItem?.__typename === "ComponentPopupPopup"
        )
      );
    }

    const popupData =
      filteredPopupData &&
      filteredPopupData[0]?.attributes?.description_type[0];
    setPopup(popupData);
  };

  useEffect(() => {
    getPopupData();
  }, [glossaryData]);

  useEffect(() => {
    const exitIntentClosed = sessionStorage.getItem(
      `exit-intent-close-${currentSlug}`
    );
    exitIntentClosed
      ? setExitIntentCloseCookies(true)
      : setExitIntentCloseCookies(false);
  }, [router.asPath]);

  useEffect(() => {
    const handleMouseLeave = (event) => {
      if (event.clientY < (showStripe ? 150 : 100) && !exitIntentCloseCookies) {
        // console.log("event", event.clientY);
        setShowPopup(true);
      }
    };

    const handleMouseMove = () => {
      setExitIntentCloseCookies(
        sessionStorage.getItem(`exit-intent-close-${currentSlug}`) === "true"
      );
    };

    !exitIntentCloseCookies &&
      popup &&
      document.addEventListener("mousemove", handleMouseLeave);

    !exitIntentCloseCookies && popup
      ? document.addEventListener("mousemove", handleMouseMove)
      : document.removeEventListener("mousemove", handleMouseMove);

    return () => {
      document.removeEventListener("mousemove", handleMouseLeave);
      document.removeEventListener("mousemove", handleMouseMove);
    };
  }, [exitIntentCloseCookies]);

  const handleCloseExitIntentPopup = () => {
    setShowPopup(false);
    sessionStorage.setItem(`exit-intent-close-${currentSlug}`, true);
    setExitIntentCloseCookies(true);
  };

  return (
    <>
      <Seo data={glossaryData?.seo} />
      <BreadCrumbs
        crumbs={[{ name: "Glossary", link: "/glossary" }]}
        currentPage={glossaryData?.title}
      />
      <div className="page-title-area">
        <div className="container">
          <h1 className="glossary-details-page-title">{glossaryData?.title}</h1>
        </div>
      </div>
      {glossaryData?.editors?.length > 0 && (
        <Editors data={glossaryData?.editors} />
      )}
      {glossaryData?.reference?.length > 0 && (
        <References data={glossaryData?.reference} />
      )}
      <div className="container">
        <div className="section-9-5 blog-details-desc glossary-details-desc">
          <Share slug={glossaryData?.slug} />
          {authorData && <Author authorData={authorData} />}
        </div>

        {relatedBlogs?.length > 0 && <RelatedBlogs data={relatedBlogs} />}
      </div>
      {glossaryData?.ctas?.data?.map((item, i) => {
        return item?.attributes?.description_type?.map((subItem, index) => {
          if (subItem?.__typename === "ComponentButtonButtonImageText") {
            return (
              <JoinOurCommunity
                key={index}
                image={subItem?.image}
                title={subItem?.title}
                button={subItem?.button_image_text_button}
                description={subItem?.description}
              />
            );
          } else if (subItem?.__typename === "ComponentButtonButtonText") {
            return <ButtonText key={index} data={subItem} />;
          } else if (subItem?.__typename === "ComponentCommonButton") {
            return (
              <div style={{ width: "max-content", margin: "1rem auto" }}>
                <Button key={index} data={subItem} />
              </div>
            );
          } else if (subItem?.__typename === "ComponentCommonAppDownload") {
            return <AppDownload download_app_section={subItem} key={index} />;
          } else if (subItem?.__typename === "ComponentButtonNewsletter") {
            return (
              <Zoho
                key={index}
                embedCode={subItem?.description}
                form_onsubmit={subItem?.form_onsubmit}
                form_onload={subItem?.form_onload}
              />
            );
          }
        });
      })}
      <Comments glossaryData={glossaryData} glossaryId={glossaryId} />
      {showPopup && popup && (
        <ExitIntentPopup
          data={popup}
          handleCloseExitIntentPopup={handleCloseExitIntentPopup}
        />
      )}
    </>
  );
}

export async function getServerSideProps(context) {
  const slug = context.params.slug;
  const { data, errors } = await client.query({
    query: gql`
      query getGlossaryData {
        glossaries(filters: { slug: { eq: "${slug}" } }) {
            data {
                id
                attributes {
                    title
                    slug
                    excerpt
                    editors {
                    ... on ComponentGlossaryDarkEditor {
                        dark_editor
                    }
                    ... on ComponentGlossaryLightEditor {
                        light_editor
                    }
                    }
                    reference {
                    reference_editor
                    }
                    tags {
                    data {
                        attributes {
                          title
                          slug
                          blogs (sort: "createdAt:desc",pagination: { limit: 3 }) {
                            data {
                              id
                              attributes {
                                slug
                                title
                                createdAt
                                publish_date
                                image {
                                  data {
                                    attributes {
                                      url
                                    }
                                  }
                                }
                                categories {
                                  data {
                                    attributes {
                                      title
                                      slug
                                    }
                                  }
                                }
                                tags {
                                  data {
                                    attributes {
                                      title
                                      slug
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                    }
                    }
                    author {
                    data {
                        attributes {
                        name
                        image {
                            data {
                            attributes {
                                url
                            }
                            }
                        }
                        skill
                        slug
                        bio
                        location
                        social_links {
                          name
                          link
                        }
                        }
                    }
                    }
                    ctas {
                    data {
                        attributes {
                        description_type {
                            ... on ComponentCommonButton {
                            button_text
                            button_icon
                            button_link
                            button_target
                            }
                            ... on ComponentButtonButtonImageText {
                            image {
                                data {
                                attributes {
                                    url
                                }
                                }
                            }
                            title
                            description
                            button_image_text_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                            }
                            }
                            ... on ComponentButtonButtonText {
                            description
                            button_text_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                            }
                            }
                            ... on ComponentButtonNewsletter {
                              description
                              form_onload
                              form_onsubmit
                            }
                            ... on ComponentCommonAppDownload {
                            sectionTitle
                            title
                            image {
                                data {
                                attributes {
                                    url
                                }
                                }
                            }
                            playstoreButtonText
                            playstoreButtonLink
                            applestoreButtonText
                            applestoreButtonLink
                            }
                            ... on ComponentPopupPopup {
                            title
                            description
                            popup_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                            }
                            image {
                                data {
                                attributes {
                                    url
                                }
                                }
                            }
                            }
                        }
                        }
                    }
                    }
                    ${getSeoData}
                }
            }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/glossary/${slug}`,
        permanent: true,
      },
    };
  }

  if (!data?.glossaries?.data[0]?.attributes) {
    return {
      redirect: {
        destination: `/404?url=/glossary/${slug}`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      glossaryData: data?.glossaries?.data[0]?.attributes || null,
      glossaryId: data?.glossaries?.data[0]?.id || null,
    },
  };
}

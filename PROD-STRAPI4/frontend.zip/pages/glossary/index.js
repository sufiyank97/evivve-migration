import Zoho from "@/components/Blog/BlogDetails/Zoho";
import Seo from "@/components/Common/seo";
import CKEditor from "@/utils/CkEditor";
import { gql } from "@apollo/client";
import axios from "axios";
import { AppContext } from "context/AppContextProvider";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import Image from "next/image";
import Link from "next/link";
import React, { useContext, useEffect, useRef, useState } from "react";

export default function index({ glossaryPageData, glossariesData }) {
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [alphabet, setAlphabet] = useState([]);
  const [activeLetter, setActiveLetter] = useState(null);
  const { showStripe, navbarHeight } = useContext(AppContext);
  const [isSticky, setIsSticky] = useState(false);

  const sectionRefs = useRef({});
  const stickyRef = useRef(null);

  // const glossariesData = [
  //   { attributes: { title: "Apple", excerpt: "Content about Apple" } },
  //   { attributes: { title: "Apple", excerpt: "Content about Apple" } },
  //   { attributes: { title: "Apple", excerpt: "Content about Apple" } },
  //   { attributes: { title: "Apple", excerpt: "Content about Apple" } },
  //   { attributes: { title: "Banana", excerpt: "Content about Banana" } },
  //   { attributes: { title: "Banana", excerpt: "Content about Banana" } },
  //   { attributes: { title: "Banana", excerpt: "Content about Banana" } },
  //   { attributes: { title: "Banana", excerpt: "Content about Banana" } },
  //   { attributes: { title: "2st Apple", excerpt: "Content about 2st Apple" } },
  //   { attributes: { title: "Avocado", excerpt: "Content about Avocado" } },
  //   { attributes: { title: "Avocado", excerpt: "Content about Avocado" } },
  //   { attributes: { title: "Avocado", excerpt: "Content about Avocado" } },
  //   { attributes: { title: "Avocado", excerpt: "Content about Avocado" } },
  //   { attributes: { title: "Avocado", excerpt: "Content about Avocado" } },
  //   { attributes: { title: "Avocado", excerpt: "Content about Avocado" } },
  //   { attributes: { title: "Avocado", excerpt: "Content about Avocado" } },
  //   { attributes: { title: "Cherry", excerpt: "Content about Cherry" } },
  //   { attributes: { title: "Cherry", excerpt: "Content about Cherry" } },
  //   { attributes: { title: "Cherry", excerpt: "Content about Cherry" } },
  //   { attributes: { title: "Cherry", excerpt: "Content about Cherry" } },
  //   { attributes: { title: "Cherry", excerpt: "Content about Cherry" } },
  //   { attributes: { title: "1st Apple", excerpt: "Content about 1st Apple" } },
  // ];

  // Scroll listener for sticky behavior
  useEffect(() => {
    const handleScroll = () => {
      if (stickyRef.current) {
        const rect = stickyRef.current.getBoundingClientRect();
        const screenWidth = document?.documentElement?.clientWidth;
        const stickyThreshold = showStripe
          ? screenWidth > 1024
            ? 150
            : 180
          : 80;

        if (rect.top <= stickyThreshold + 10 && !isSticky) {
          setIsSticky(true);
        } else if (rect.top > stickyThreshold + 10 && isSticky) {
          setIsSticky(false);
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  // Dynamically set the alphabet based on glossary data
  useEffect(() => {
    const uniqueLetters = new Set(
      glossariesData?.map((item) => {
        const firstChar = item?.attributes?.title.charAt(0).toUpperCase();
        // Check if the first character is a letter (A-Z), else categorize under '#'
        return /[A-Z]/.test(firstChar) ? firstChar : "#";
      })
    );
    setAlphabet([...uniqueLetters]);
  }, []);

  // Set up IntersectionObserver to track visibility of sections
  useEffect(() => {
    const handleScroll = () => {
      let activeSection = null;
      let currentScrollY = window.scrollY;
      let screenTop = showStripe ? 230 : 160; // Adjust based on your sticky header

      alphabet.forEach((letter) => {
        const section = sectionRefs.current[letter];
        if (section) {
          const rect = section.getBoundingClientRect();

          // Check if the section top is near the top of the viewport, considering the header height
          if (rect.top <= screenTop && rect.bottom > screenTop) {
            activeSection = letter;
          }
        }
      });

      if (
        !activeSection &&
        currentScrollY < sectionRefs?.current[alphabet[0]]?.offsetTop
      ) {
        setActiveLetter(alphabet[0]); // Set the first letter when at the top of the page
      } else if (
        !activeSection &&
        currentScrollY >
          sectionRefs?.current[alphabet[alphabet.length - 1]]?.offsetTop
      ) {
        setActiveLetter(alphabet[alphabet.length - 1]); // Set the last letter when at the bottom
      } else if (activeSection && activeSection !== activeLetter) {
        setActiveLetter(activeSection); // Set the active section
      }
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll();
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [alphabet, activeLetter, showStripe]);

  // Function to handle smooth scroll when a letter is clicked
  const handleScroll = (letter) => {
    const section = sectionRefs.current[letter];

    if (section) {
      // Get the section's position relative to the top of the page
      const sectionPosition =
        section.getBoundingClientRect().top + window.pageYOffset;

      // Define your scroll offset (adjust based on condition)
      const scrollOffset = showStripe ? 220 : 150;

      // Scroll to the section position minus the desired offset
      window.scrollTo({
        top: sectionPosition - scrollOffset,
        behavior: "smooth",
      });
    }
  };

  const getGlossariessData = async (value) => {
    if (value.length > 0) {
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_STRAPI_URL}api/glossary/search?searchingText=${value}`
      );
      const data = res?.data?.data;
      if (data) {
        setSearchResults(data);
      }
    } else {
      setSearchResults([]);
    }
  };

  return (
    <>
      <Seo data={glossaryPageData?.seo} />
      <div className="page-title-area glossary-page-title-area">
        <div className="container">
          <div
            className="page-title-content page-title-content2 d-lg-flex align-items-lg-center justify-content-lg-between"
            style={{ textAlign: "left" }}
          >
            <div>
              <div className="glossary-page-content">
                <h1>{glossaryPageData?.title}</h1>
                {glossaryPageData?.icon?.data?.attributes?.url && (
                  <div className="glossary-page-icon">
                    <Image
                      src={glossaryPageData?.icon?.data?.attributes?.url}
                      alt="icon"
                      width={51}
                      height={53}
                    />
                  </div>
                )}
              </div>
              <CKEditor content={glossaryPageData?.description} />
            </div>
            <div
              className="form search-input bg-f2003c"
              style={{ position: "relative" }}
            >
              <div className="form-group d-flex">
                <input
                  type="text"
                  name="name"
                  className="form-control"
                  placeholder="Search..."
                  value={search}
                  onChange={(e) => {
                    getGlossariessData(e.target.value);
                    setSearch(e.target.value);
                  }}
                />
                <div className="px-3 bg-f2003c d-flex align-items-center icon-wrap">
                  <i className="bx bx-search" style={{ color: "#ffffff" }}></i>
                </div>
              </div>
              {searchResults?.length > 0 && (
                <div className="search-dropdown">
                  {searchResults?.map((item, i) => {
                    return (
                      <Link
                        href={`/glossary/${item?.attributes?.slug}`}
                        key={i}
                      >
                        <a
                          onClick={() => {
                            setSearch("");
                            setSearchResults([]);
                          }}
                        >
                          {item?.attributes?.title}
                        </a>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="position-relative">
        <div
          className={`glossary-links-list-wrap ${
            showStripe ? "glossary-links-list-wrap-with-top-stripe" : ""
          } ${isSticky ? "glossary-links-list-wrap-sticky" : ""}`}
          ref={stickyRef}
          style={{ top: `${navbarHeight}px` }}
        >
          <div className="container">
            <div className={`glossary-links-list`}>
              {"#ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").map((letter) => {
                if (alphabet?.includes(letter)) {
                  return (
                    <button
                      onClick={() => handleScroll(letter)}
                      key={letter}
                      className={letter === activeLetter ? "active" : ""}
                    >
                      {letter}
                    </button>
                  );
                }
              })}
            </div>
          </div>
        </div>
        <div className="glossary-data-list-wrap">
          <div className="container">
            {alphabet
              .sort((a, b) =>
                a === "#" ? -1 : b === "#" ? 1 : a.localeCompare(b)
              )
              .map((letter) => (
                <div
                  key={letter}
                  id={letter}
                  data-letter={letter}
                  ref={(el) => (sectionRefs.current[letter] = el)}
                  className="glossary-data-list-item-wrap"
                >
                  <h2 style={{ color: "white" }}>{letter}</h2>
                  <div className="glossary-data-list-item-content">
                    {glossariesData
                      .filter((item) => {
                        const firstChar = item?.attributes?.title
                          .charAt(0)
                          .toUpperCase();
                        return /[A-Z]/.test(firstChar)
                          ? firstChar === letter
                          : letter === "#";
                      })
                      .map((item, idx) => (
                        <div key={idx}>
                          <Link href={`/glossary/${item?.attributes?.slug}`}>
                            <a className="glossary-data-list-item-content-title">
                              {item?.attributes?.title}
                            </a>
                          </Link>
                          <p className="glossary-data-list-item-content-excerpt">
                            {item?.attributes?.excerpt}
                          </p>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      {glossaryPageData?.ctas?.data?.map((item, i) => {
        return item?.attributes?.description_type?.map((subItem, index) => {
          if (subItem?.__typename === "ComponentButtonNewsletter") {
            return (
              <Zoho
                key={index}
                embedCode={subItem?.description}
                form_onsubmit={subItem?.form_onsubmit}
                form_onload={subItem?.form_onload}
              />
            );
          }
        });
      })}
    </>
  );
}

export async function getServerSideProps(context) {
  const { data, errors } = await client.query({
    query: gql`
      query getGlossariesData {
        glossaryPage ${context?.preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              title
              icon {
                data {
                  attributes {
                    url
                  }
                }
              }
              description
              ctas{
                data{
                  attributes{
                    description_type {
                      ... on ComponentButtonNewsletter {
                        description
                        form_onload
                        form_onsubmit
                      }
                    }
                  }
                }
              }
              ${getSeoData}
            }
          }
        }
        glossaries {
          data {
            attributes {
              title
              slug
              excerpt
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/glossary/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      glossaryPageData: data?.glossaryPage?.data?.attributes || null,
      glossariesData: data?.glossaries?.data || null,
    },
  };
}

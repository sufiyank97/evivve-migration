import React from "react";
import AferrMaster from "@/components/LandingPages/aferrMaster/AferrMaster";
import dynamic from "next/dynamic";
import { fetchAudioBookLandingPage } from "graphql/getLandingPage";
const Seo = dynamic(() => import("@/components/Common/seo"));
import Schema from "@/components/Common/Schema";

export default function AudioBookLandingPage({ data, seoData }) {
  return (
    <>
      <Seo seoData={seoData} />
      <Schema schemaData={seoData} />
      <AferrMaster data={data} />
    </>
  );
}

export async function getServerSideProps() {
  try {
    console.log('Fetching audio book landing page data...');
    const { data } = await fetchAudioBookLandingPage();
    
    console.log('Audio book landing page data received:', data);
    
    const landingPageData = data?.audioBookLanding?.data?.attributes;
    const seoData = landingPageData?.seo || {
      metaTitle: "Audio Book Series - Evivve",
      metaDescription: "Discover our collection of audio books that bring insights and knowledge to life through engaging audio content.",
    };

    // If no data is available, return a fallback structure
    if (!landingPageData) {
      console.log('No audio book landing page data found, using fallback');
      return {
        props: {
          data: {
            title: "Audio Book Series",
            templates: [{
              hero_section: {
                enabled: true,
                title: "Audio Book Series",
                category: "Audio Content",
                description: "Discover our collection of audio books that bring insights and knowledge to life through engaging audio content."
              }
            }]
          },
          seoData,
        },
      };
    }

    // Transform the CMS data structure to match what AferrMaster expects
    const transformedData = {
      title: landingPageData.title || "Audio Book Series",
      seo: landingPageData.seo || null,
      templates: [{
        hero_section: landingPageData.hero_section || null,
        brands_section: landingPageData.brands_section || null,
        details_section: landingPageData.details_section || null,
        details_section_2: landingPageData.details_section_2 || null,
        case_studies_section: landingPageData.case_studies_section || null,
        video_carousel_section: landingPageData.video_carousel_section || null,
        stats_section: landingPageData.stats_section || null,
        final_cta_section: landingPageData.final_cta_section || null,
      }]
    };

    return {
      props: {
        data: transformedData,
        seoData,
      },
    };
  } catch (error) {
    console.error("Error fetching audio book landing page data:", error);
    return {
      props: {
        data: {
          title: "Audio Book Series",
          templates: [{
            hero_section: {
              enabled: true,
              title: "Audio Book Series",
              category: "Audio Content",
              description: "Discover our collection of audio books that bring insights and knowledge to life through engaging audio content."
            }
          }]
        },
        seoData: {
          metaTitle: "Audio Book Series - Evivve",
          metaDescription: "Discover our collection of audio books that bring insights and knowledge to life through engaging audio content.",
        },
      },
    };
  }
}

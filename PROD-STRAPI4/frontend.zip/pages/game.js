import React from "react";
import Image from "next/image";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import dynamic from "next/dynamic";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
const PageTopTitle = dynamic(() => import("@/components/Common/PageTopTitle"));
const AppDownload = dynamic(() => import("@/components/Courses/AppDownload"));
const GamePlay = dynamic(() => import("@/components/Play/GamePlay"));
const TestimonialOne = dynamic(() =>
  import("@/components/Testimonials/TestimonialOne")
);
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper";
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import BrandImagesSwiper from "@/components/Common/BrandImagesSwiper";
import Brands from "@/components/LandingPages/common/Brands";
const Seo = dynamic(() => import("@/components/Common/seo"));

const Game = ({ gamePage, commonData }) => {
  const banner_section = gamePage?.banner_section;
  const third_Section = gamePage?.what_faciliators_love_section;
  const brand_section = gamePage?.brand_section;
  const download_app_section = gamePage?.download_app_section;
  const testimonial_section = gamePage?.testimonial_section;
  const play_section = gamePage?.play_section;
  return (
    <>
      <Seo data={gamePage?.seo} />
      {gamePage?.schema && <Schema schema={gamePage?.schema} />}
      <BreadCrumbs currentPage={"Play Game"} />
      <PageTopTitle
        title={banner_section?.title}
        subHeading={banner_section?.subHeading}
        bgColor={"white"}
      />
      {play_section?.length > 0 && <GamePlay play_section={play_section} />}
      <div className="container mt-5">
        <h3>{third_Section?.title}</h3>
      </div>
      {testimonial_section?.testimonials?.data?.length > 0 && (
        <TestimonialOne
          testimonialSection={testimonial_section}
          testimonialData={testimonial_section?.testimonials?.data}
        />
      )}

      {/* 24.5 */}
      {/* <div className="container">
        <h3>{brand_section?.title}</h3>
        <div className="testimonial-companies">
          {brand_section?.brands?.data && (
            <BrandImagesSwiper data={brand_section?.brands?.data} />
          )}
        </div>
      </div> */}
      <Brands data={brand_section} />

      {/* 24.6 */}
      <AppDownload
        download_app_section={download_app_section}
        commonData={commonData}
      />
    </>
  );
};

export default Game;

export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query getGamePage {
        game ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              banner_section {
                title
                subHeading
              }
              play_section {
                heading
                title
                description
                game_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              what_faciliators_love_section {
                title
              }
              testimonial_section {
                title1
                title2
                title_icon
                testimonials {
                  data {
                    attributes {
                      title
                      description
                      designation
                      name
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      linkedin
                    }
                  }
                }
              }
              brand_section {
                title
                title2
                title_icon
                brands {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
                brands2 {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
                brands3 {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
              }
              download_app_section {
                sectionTitle
                title
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                playstoreButtonText
                playstoreButtonLink
                applestoreButtonText
                applestoreButtonLink
              }
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/game`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      gamePage: data?.game?.data?.attributes || null,
    },
  };
}

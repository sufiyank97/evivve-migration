import React from "react";

const Tag = () => {
  return <div>index</div>;
};

export default Tag;
export async function getServerSideProps() {
  return {
    redirect: {
      destination: `/evivvo-pedia/`,
      permanent: true,
    },
  };
}

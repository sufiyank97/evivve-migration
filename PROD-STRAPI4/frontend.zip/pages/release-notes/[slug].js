import BreadCrumbs from "@/components/Common/BreadCrumbs/BreadCrumbs";
import Seo from "@/components/Common/seo";
import Ctas from "@/components/Newsroom/Ctas";
import NotesMobile from "@/components/ReleaseNotes/NotesMobile";
import ReleaseNotesDescription from "@/components/ReleaseNotes/ReleaseNotesDescription";
import ReleaseNotesHero from "@/components/ReleaseNotes/ReleaseNotesHero";
import { gql } from "@apollo/client";
import axios from "axios";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import React, { useState } from "react";

function findPrevNext(slug, versions) {
  // Flatten the versions array: Include base and subversions in order
  const allVersions = versions.flatMap((version) => [
    {
      id: version.id,
      title: version.title,
      slug: version.slug,
      version: version.version,
    },
    ...version.sub_versions.map((sub) => ({
      id: sub.id,
      title: sub.title,
      slug: sub.slug,
      version: sub.version,
    })),
  ]);

  // Find the current index based on slug
  const currentIndex = allVersions.findIndex((v) => v.slug === slug);

  // Determine prev and next
  const prev =
    currentIndex > 0
      ? allVersions[currentIndex - 1]
      : allVersions[allVersions.length - 1]; // Loop to the last version if no prev
  const next =
    currentIndex < allVersions.length - 1
      ? allVersions[currentIndex + 1]
      : allVersions[0]; // Loop to the first version if no next

  return { prev, next };
}

export default function index({ releaseNoteData, versionsResponse }) {
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const base_version = releaseNoteData?.base_version?.data?.attributes;

  const handleSearchOnChange = async (e) => {
    const value = e.target.value;
    setSearch(value);
    if (value.length > 0) {
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_STRAPI_URL}api/release-note/search?searchingText=${value}`
      );
      const data = res?.data?.data;
      if (data) {
        setSearchResults(data);
      }
    } else {
      setSearchResults([]);
    }
  };

  const { prev, next } = findPrevNext(releaseNoteData?.slug, versionsResponse);

  return (
    <>
      <Seo data={releaseNoteData?.seo} />
      <div className="release-notes-breadcrumbs">
        <BreadCrumbs
          crumbs={[
            { link: "/release-notes", name: "Release Notes" },
            base_version
              ? {
                  link: `/release-notes/${base_version?.slug}`,
                  name: base_version?.title,
                }
              : null,
          ].filter(Boolean)}
          currentPage={releaseNoteData?.title}
        />
      </div>
      <ReleaseNotesHero
        title={releaseNoteData?.title}
        search={search}
        setSearch={setSearch}
        searchResults={searchResults}
        setSearchResults={setSearchResults}
        onChangeFun={handleSearchOnChange}
      />
      <ReleaseNotesDescription
        description={releaseNoteData?.description}
        versionsResponse={versionsResponse}
        prev={prev}
        next={next}
      />
      <NotesMobile versionsResponse={versionsResponse} />
      <Ctas ctasData={releaseNoteData?.ctas} />
    </>
  );
}

export async function getServerSideProps({ preview, params }) {
  const slug = params["slug"];
  const { data, errors } = await client.query({
    query: gql`
          query releaseNoteData {
            releaseNotes(${
              preview ? "publicationState:PREVIEW," : ""
            } filters: { slug: { eq: "${slug}" } }) {
              data {
                  attributes {
                    title
                    slug
                    description
                    version
                    base_version {
                        data {
                            attributes {
                                title
                                slug
                                version
                            }
                        }
                    }
                    sub_versions {
                        data {
                            attributes {
                                title
                                slug
                                version
                            }
                        }
                    }
                    ctas{
                      data{
                        attributes{
                          description_type {
                            ... on ComponentCommonButton {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            ... on ComponentButtonButtonImageText {
                              image {
                                data {
                                  attributes {
                                    url
                                  }
                                }
                              }
                              title
                              description
                              button_image_text_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                            }
                            ... on ComponentButtonButtonText {
                              description
                              button_text_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                            }
                            ... on ComponentButtonNewsletter {
                              description
                              form_onload
                              form_onsubmit
                            }
                            ... on ComponentCommonAppDownload {
                              sectionTitle
                              title
                              image {
                                data {
                                  attributes {
                                    url
                                  }
                                }
                              }
                              playstoreButtonText
                              playstoreButtonLink
                              applestoreButtonText
                              applestoreButtonLink
                            }
                            ... on ComponentPopupPopup{
                              title
                              description
                              popup_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                              image{
                                data{
                                  attributes{
                                    url
                                  }
                                }
                              }
                            }
                            ... on ComponentKnowledgeBase3CardsCtas {
                              card {
                                title
                                description
                                image {
                                  data {
                                    attributes {
                                      url
                                    }
                                  }
                                }
                                link_title
                                link_href
                                link_target
                              }
                            }
                          }
                        }
                      }
                    }
                    ${getSeoData}
                  }
              }
            }
          }
        `,
  });
  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/release-notes/${slug}`,
        permanent: true,
      },
    };
  }
  if (!data?.releaseNotes?.data[0]?.attributes) {
    return {
      redirect: {
        destination: `/404?url=/release-notes/${slug}`,
        permanent: true,
      },
    };
  }

  let versionsResult = await axios.get(
    `${process.env.NEXT_PUBLIC_STRAPI_URL}api/release-note/base-versions`
  );
  const versionsResponse = versionsResult?.data?.data;

  return {
    props: {
      releaseNoteData: data?.releaseNotes?.data[0]?.attributes || null,
      versionsResponse: versionsResponse || [],
    },
  };
}

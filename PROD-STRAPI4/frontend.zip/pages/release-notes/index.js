import BreadCrumbs from "@/components/Common/BreadCrumbs/BreadCrumbs";
import Seo from "@/components/Common/seo";
import Ctas from "@/components/Newsroom/Ctas";
import NotesMobile from "@/components/ReleaseNotes/NotesMobile";
import ReleaseNotesDescription from "@/components/ReleaseNotes/ReleaseNotesDescription";
import ReleaseNotesHero from "@/components/ReleaseNotes/ReleaseNotesHero";
import { gql } from "@apollo/client";
import axios from "axios";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import React, { useState } from "react";

export default function index({ releaseNotePageData, versionsResponse }) {
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);

  const handleSearchOnChange = async (e) => {
    const value = e.target.value;
    setSearch(value);
    if (value.length > 0) {
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_STRAPI_URL}api/release-note/search?searchingText=${value}`
      );
      const data = res?.data?.data;
      if (data) {
        setSearchResults(data);
      }
    } else {
      setSearchResults([]);
    }
  };

  return (
    <>
      <Seo data={releaseNotePageData?.seo} />
      <div className="release-notes-breadcrumbs">
        <BreadCrumbs currentPage={"Release Notes"} />
      </div>
      <ReleaseNotesHero
        title={releaseNotePageData?.title}
        search={search}
        setSearch={setSearch}
        searchResults={searchResults}
        setSearchResults={setSearchResults}
        onChangeFun={handleSearchOnChange}
      />
      <ReleaseNotesDescription
        description={releaseNotePageData?.description}
        versionsResponse={versionsResponse}
      />
      <NotesMobile versionsResponse={versionsResponse} />
      <Ctas ctasData={releaseNotePageData?.ctas} />
    </>
  );
}

export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
          query releaseNotePageData {
            releaseNotePage ${preview ? "(publicationState:PREVIEW)" : ""} {
              data {
                  attributes {
                    title
                    description
                    ctas{
                      data{
                        attributes{
                          description_type {
                            ... on ComponentCommonButton {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            ... on ComponentButtonButtonImageText {
                              image {
                                data {
                                  attributes {
                                    url
                                  }
                                }
                              }
                              title
                              description
                              button_image_text_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                            }
                            ... on ComponentButtonButtonText {
                              description
                              button_text_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                            }
                            ... on ComponentButtonNewsletter {
                              description
                              form_onload
                              form_onsubmit
                            }
                            ... on ComponentCommonAppDownload {
                              sectionTitle
                              title
                              image {
                                data {
                                  attributes {
                                    url
                                  }
                                }
                              }
                              playstoreButtonText
                              playstoreButtonLink
                              applestoreButtonText
                              applestoreButtonLink
                            }
                            ... on ComponentPopupPopup{
                              title
                              description
                              popup_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                              image{
                                data{
                                  attributes{
                                    url
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    ${getSeoData}
                  }
              }
            }
          }
        `,
  });
  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/release-notes/`,
        permanent: true,
      },
    };
  }

  let versionsResult = await axios.get(
    `${process.env.NEXT_PUBLIC_STRAPI_URL}api/release-note/base-versions`
  );
  const versionsResponse = versionsResult?.data?.data;

  return {
    props: {
      releaseNotePageData: data?.releaseNotePage?.data?.attributes || null,
      versionsResponse: versionsResponse || [],
    },
  };
}

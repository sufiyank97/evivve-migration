import React from "react";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import dynamic from "next/dynamic";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
const TermsConditionsContent = dynamic(() =>
  import("@/components/TermsConditions/TermsConditionsContent")
);
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
const Seo = dynamic(() => import("@/components/Common/seo"));

const CookiePolicy = ({ cookiePolicy }) => {
  return (
    <>
      <Seo data={cookiePolicy?.seo} />
      {cookiePolicy?.schema && <Schema schema={cookiePolicy?.schema} />}
      <BreadCrumbs currentPage={cookiePolicy?.title} />
      <div className="page-title-area">
        <div className="container">
          <div className="page-title-content">
            <h1>{cookiePolicy?.title}</h1>
          </div>
        </div>
      </div>
      <TermsConditionsContent termsOfService={cookiePolicy} />
    </>
  );
};

export default CookiePolicy;
export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query getTermsOfServicePage {
        cookiePolicy ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              title
              description
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/cookie-policy`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      cookiePolicy: data?.cookiePolicy?.data?.attributes || null,
    },
  };
}

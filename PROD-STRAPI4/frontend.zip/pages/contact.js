import React, { useState } from "react";
import { gql } from "@apollo/client";
import client from "../lib/apollo-client/ApolloClient";
import dynamic from "next/dynamic";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
const ContactForm = dynamic(() => import("@/components/Contact/ContactForm"));
const ThankYou = dynamic(() =>
  import("@/components/ThankYou/ThankYou").then((mod) => mod.ThankYou)
);
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
const Seo = dynamic(() => import("@/components/Common/seo"));

const Contact = ({ contactData }) => {
  const [isVisible, setIsVisible] = useState(false);
  return (
    <>
      <Seo data={contactData?.seo} />
      {contactData?.schema && <Schema schema={contactData?.schema} />}
      {isVisible ? (
        <ThankYou />
      ) : (
        <>
          <BreadCrumbs currentPage={contactData?.banner?.title} />
          <ContactForm contactData={contactData} setIsVisible={setIsVisible} />
        </>
      )}
    </>
  );
};

export default Contact;

export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query getContactPageData {
        contactPage ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              banner {
                title
              }
              second_section {
                heading
                title
                description
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              thankYou {
                heading
                description
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              zoho_form_type
              zoho_form_button {
                button_text
                button_link
                button_target
                button_icon
              }
              form
              form_onload
              form_onsubmit
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/contact/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      contactData: data?.contactPage?.data?.attributes || null,
    },
  };
}

import { gql } from "@apollo/client";
import client from "../../lib/apollo-client/ApolloClient";
import axios from "axios";

export default async function handler(req, res) {
  if (req.query.secret !== process.env.NEXT_PUBLIC_STRAPI_PREVIEW_SECRET) {
    return res.status(401).json({ message: "Invalid token" });
  }

  const redirect = (result, path) => {
    if (result?.errors?.length > 0) {
      return res.status(400).json({ message: "Something went wrong" });
    }
    res.setPreviewData(path, {
      maxAge: 20 * 60, // The preview mode cookies expire in 20mins
      path: path, // The preview mode cookies apply to paths
    });
    res.redirect(path);
  };

  let result;
  if (req?.query?.blogDetail) {
    result = await client.query({
      query: gql`
          query getBlogDetailsData {
            blogs(
              publicationState: PREVIEW
              filters: {
                slug: { eq: "${req?.query?.blogDetail?.split("/")[1]}" }
                publishedAt: { eq: null }
              }
            ) {
              data {
                id
                attributes {
                  title
                  slug
                }
              }
            }
          }
        `,
    });

    if (!result?.data?.blogs?.data?.length > 0) {
      return res.status(400).json({ message: "There is no Draft Data" });
    }

    redirect(result, req?.query?.blogDetail);
  } else {
    switch (true) {
      // homepage
      case req.query.slug.includes("/home"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/home?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/");

        break;

      case req.query.slug.includes("/about-us"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/about?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/about-us");

        break;

      case req.query.slug.includes("/privacy-policy"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/privacy-policy?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/privacy-policy");

        break;

      case req.query.slug.includes("/cookie-ploicy"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/cookie-ploicy?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/cookie-ploicy");

        break;

      case req.query.slug.includes("/terms-of-service"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/terms-of-service?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/terms-of-service");

        break;

      case req.query.slug.includes("/testimonials"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/case-study?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/testimonials");

        break;

      case req.query.slug.includes("/pricing"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/new-pricing?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/pricing");

        break;

      case req.query.slug.includes("/schedule-a-call"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/book-a-demo?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/schedule-a-call");

        break;

      case req.query.slug.includes("/play-live"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/play-live?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/play-live");

        break;

      // case req.query.slug.includes("/play-now"):
      //   result = await axios.get(
      //     `${process.env.NEXT_PUBLIC_STRAPI_URL}api/play-now?publicationState=preview&filters[publishedAt][$null]=true`
      //   );

      //   if (!result?.data?.data) {
      //     return res.status(400).json({ message: "There is no Draft Data" });
      //   }

      //   redirect(result, "/play-now");

      //   break;

      case req.query.slug.includes("/play-now"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/new-play-now?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/play-now");

        break;

      case req.query.slug.includes("/game-download"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/game-download?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/game-download");

        break;

      case req.query.slug.includes("/contact"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/contact-page?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/contact");

        break;

      case req.query.slug.includes("/game"):
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/game?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/game");

        break;

      case req.query.slug === "/evivvo-pedia":
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/blog-page?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/evivvo-pedia");

        break;

      case req.query.slug === "/glossary":
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/glossary-page?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/glossary");

        break;

      case req.query.slug === "/why-evivve":
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/why-evivve?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/why-evivve");

        break;

      // collection type
      
      case req.query.slug === "/science-lab":
        result = await axios.get(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/lab?publicationState=preview&filters[publishedAt][$null]=true`
        );

        if (!result?.data?.data) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, "/science-lab");

        break;

      case req.query.slug.includes("/author"):
        result = await client.query({
          query: gql`
          query getAuthor {
            authors(
            publicationState: PREVIEW
            filters: { slug: { eq: "${
              req.query.slug.split("/author/")[1]
            }" }, publishedAt: { eq: null } }
          ) {
              data {
                attributes {
                  name
                }
              }
            }
          }
        `,
        });

        if (!result?.data?.authors?.data?.length > 0) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, req.query.slug);
        break;

      case req.query.slug.includes("/categories"):
        result = await client.query({
          query: gql`
          query getcategory {
            categories(
              publicationState: PREVIEW
              filters: { slug: { eq: "${
                req.query.slug.split("/categories/")[1]
              }" }, publishedAt: { eq: null } }
            ) {
              data {
                attributes {
                  title
                  slug
                }
              }
            }
          }
        `,
        });

        if (!result?.data?.categories?.data?.length > 0) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, req.query.slug);
        break;

      case req.query.slug.includes("/tags"):
        result = await client.query({
          query: gql`
          query getTag {
            tags(
              publicationState: PREVIEW
              filters: { slug: { eq: "${
                req.query.slug.split("/tags/")[1]
              }" }, publishedAt: { eq: null } }
            ) {
              data {
                attributes {
                  title
                  slug
                }
              }
            }
          }
        `,
        });

        if (!result?.data?.tags?.data?.length > 0) {
          return res.status(400).json({ message: "There is no Draft Data" });
        }

        redirect(result, req.query.slug);
        break;

      default:
        break;
    }
  }
}

import React from "react";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import dynamic from "next/dynamic";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
const PrivacyPolicyContent = dynamic(() =>
  import("@/components/privacyPolicy/PrivacyPolicyContent")
);
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
const Seo = dynamic(() => import("@/components/Common/seo"));

const PrivacyPolicy = ({ privacyPage }) => {
  return (
    <>
      <Seo data={privacyPage?.seo} />
      {privacyPage?.schema && <Schema schema={privacyPage?.schema} />}
      <BreadCrumbs currentPage={privacyPage?.title} />
      <div className="page-title-area">
        <div className="container">
          <div className="page-title-content">
            <h1>{privacyPage?.title}</h1>
            {/* <ul>
              <li>
                <Link href="/">
                  <a>Home</a>
                </Link>
              </li>
              <li>Privacy Policy</li>
            </ul> */}
          </div>
        </div>
      </div>
      <PrivacyPolicyContent privacyPage={privacyPage} />
    </>
  );
};

export default PrivacyPolicy;
export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query getPrivacyPage {
        privacyPolicy ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              title
              description
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/privacy-policy`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      privacyPage: data?.privacyPolicy?.data?.attributes || null,
    },
  };
}

import React, { useContext, useEffect } from "react";
import dynamic from "next/dynamic";
import { fetchDialogueData } from "graphql/getAudioBook";
import { convertToBase64 } from "@/utils/helper";
const Seo = dynamic(() => import("@/components/Common/seo"));
import { AppContext } from "context/AppContextProvider";
import { useRouter } from "next/router";
import Schema from "@/components/Common/Schema";
import CaseStudyDetail from "@/components/LandingPages/aferrMaster/CaseStudyDetail";

const DialoguesPage = ({ dialogueData, seoData }) => {
  const { setLoading } = useContext(AppContext);
  const router = useRouter();

  useEffect(() => {
    if (setLoading) {
      setLoading(false);
    }
  }, [setLoading]);

  if (!dialogueData) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <h1>Dialogue Not Found</h1>
        <p>The dialogue "{router.query.slug}" could not be found.</p>
        <a href="/dialogues">← Back to Dialogues</a>
      </div>
    );
  }

  const { attributes } = dialogueData;
  const { templates } = attributes;

  // Get the first template (since we only expect one per dialogue)
  const template = templates?.[0];

  if (!template) {
    return <div>No template found for this dialogue</div>;
  }

  return (
    <>
      <Seo seoData={seoData} />
      <Schema schemaData={seoData} />
      <CaseStudyDetail data={template} />
    </>
  );
};

export async function getServerSideProps(context) {
  const { params } = context;
  const { preview } = context.query;
  const { slug } = params;

  try {
    console.log(`Fetching dialogue data for slug: ${slug}`);
    const { data, error } = await fetchDialogueData(slug, preview);
    
    console.log("Dialogue query result:", { data, error });
    
    if (error) {
      console.error("GraphQL error:", error);
      return {
        redirect: {
          destination: `/500?url=${encodeURIComponent(`/dialogues/${slug}`)}`,
          permanent: false,
        },
      };
    }
    
    if (!data?.dialogues?.data?.length) {
      console.log("No dialogue found for slug:", slug);
      return {
        redirect: {
          destination: `/404?url=${encodeURIComponent(`/dialogues/${slug}`)}`,
          permanent: false,
        },
      };
    }

    const dialogueData = data.dialogues.data[0];
    const seoData = dialogueData.attributes.seo || null;

    return {
      props: {
        dialogueData,
        seoData,
      },
    };
  } catch (error) {
    console.error("Error fetching dialogue data:", error);
    return {
      redirect: {
        destination: `/500?url=${encodeURIComponent(`/dialogues/${slug}`)}`,
        permanent: false,
      },
    };
  }
}

export default DialoguesPage;

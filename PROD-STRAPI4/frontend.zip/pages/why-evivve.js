import { gql } from "@apollo/client";
import client from "../lib/apollo-client/ApolloClient";
import { getSeoData } from "graphql/getSeoData";
import dynamic from "next/dynamic";
import Seo from "@/components/Common/seo";
import Schema from "@/components/Common/Schema";
import TopSection from "@/components/WhyEvivve/TopSection";
const Brands = dynamic(() => import("@/components/LandingPages/common/Brands"));
const CommunitySection = dynamic(() =>
  import("@/components/Home/CommunitySection")
);
const EarningsSection = dynamic(() =>
  import("@/components/Home/EarningsSection")
);
const HowItWorks = dynamic(() => import("@/components/Home/HowItWorks"));
const TestimonialOne = dynamic(() =>
  import("@/components/Testimonials/TestimonialOne")
);

export default function whyEvivve({ homeData }) {
  return (
    <div className={`why-evivve-main-wrap`}>
      <Seo data={homeData?.seo} />
      {homeData?.schema && <Schema schema={homeData?.schema} />}
      <TopSection top_section_data={homeData?.top_section} />
      <div>
        <>
          <Brands data={homeData?.brand_section} />
          <HowItWorks
            title={homeData?.how_it_works_title?.title}
            steps={homeData?.how_it_works_steps}
          />
          <TestimonialOne
            testimonialSection={homeData?.testimonial_section}
            testimonialData={homeData?.testimonial_section?.testimonials?.data}
          />
          <CommunitySection data={homeData?.community} />
          <EarningsSection data={homeData?.earning} />
        </>
      </div>
    </div>
  );
}

export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query getWhyEvivveData {
        whyEvivve ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              top_section {
                title
                description
                videoUrl
                button1_text
                button1_link
                button2_text
                background_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                mobile_background_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              brand_section {
                title1
                title2
                title_icon
                client_logos {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
                client_logos2 {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
                client_logos3 {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
              }
              how_it_works_title {
                title
              }
              how_it_works_steps {
                step_info
                title
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                description1
                description2
                textanimate {
                  text
                }
                points {
                  icon
                  title
                }
                how_it_work_buttons{
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                tooltip_text
              }
              testimonial_section {
                title
                testimonials {
                  data {
                    attributes {
                      title
                      description
                      designation
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      linkedin
                    }
                  }
                }
              }
              earning {
                title
                description
                earning_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              community {
                heading
                title
                description
                points {
                  title
                  icon
                }
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                community_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/why-evivve`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      homeData: data?.whyEvivve?.data?.attributes || null,
    },
  };
}

import React from "react";

const Categories = () => {
  return <div>index</div>;
};

export default Categories;
export async function getServerSideProps() {
  return {
    redirect: {
      destination: `/evivvo-pedia/`,
      permanent: true,
    },
  };
}

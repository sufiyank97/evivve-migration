// import React, { useEffect, useState } from "react";
// import Link from "next/link";
// import Image from "next/image";
// import client from "lib/apollo-client/ApolloClient";
// import { gql } from "@apollo/client";
// import dynamic from "next/dynamic";
// const BreadCrumbs = dynamic(() =>
//   import("@/components/Common/BreadCrumbs/BreadCrumbs")
// );
// const PricingContent = dynamic(() =>
//   import("@/components/Pricing/PricingContent")
// );
// const CustomPlan = dynamic(() => import("@/components/Pricing/CustomPlan"));
// const Faq = dynamic(() => import("@/components/Pricing/Faq"));
// import { getSeoData } from "graphql/getSeoData";
// import Schema from "@/components/Common/Schema";
// import { replaceImageUrl } from "@/utils/replaceImageUrl";
// import Brands from "@/components/LandingPages/common/Brands";
// const Seo = dynamic(() => import("@/components/Common/seo"));

// const Pricing = ({ pricingPageData }) => {
//   const [toggle, setToggle] = useState("monthly");
//   const [plans, setPlans] = useState([]);

//   useEffect(() => {
//     const plansData = pricingPageData?.plans?.filter((plan) =>
//       toggle === "annual" ? plan?.isYearly === true : plan?.isYearly === false
//     );
//     setPlans(plansData);
//   }, [toggle, pricingPageData]);

//   return (
//     <>
//       <Seo data={pricingPageData?.seo} />
//       {pricingPageData?.schema && <Schema schema={pricingPageData?.schema} />}
//       <BreadCrumbs currentPage={pricingPageData?.title} />
//       {pricingPageData?.title && (
//         <div className="page-title-area">
//           <div className="container">
//             <div className="page-title-content">
//               {/* <span className="sub-title light-green-color">Pricing Table</span> */}
//               <h1>{pricingPageData?.title}</h1>
//             </div>
//           </div>
//         </div>
//       )}
//       <div style={{ backgroundColor: "#f8fbff", paddingBottom: "30px" }}>
//         <div className="container">
//           <div className="pricing-plan-toggle">
//             <button
//               onClick={() => setToggle("annual")}
//               className={`${toggle === "annual" ? "active" : ""}`}
//             >
//               Annual
//             </button>
//             <button
//               onClick={() => setToggle("monthly")}
//               className={`${toggle === "monthly" ? "active" : ""}`}
//             >
//               Monthly
//             </button>
//           </div>
//         </div>
//       </div>
//       {plans?.length > 0 ? (
//         <PricingContent plansData={plans} />
//       ) : (
//         <div style={{ height: "75px" }}></div>
//       )}
//       {pricingPageData?.custom_plan && (
//         <CustomPlan data={pricingPageData?.custom_plan} />
//       )}
//       {pricingPageData?.faq_section && (
//         <Faq faqData={pricingPageData?.faq_section} />
//       )}

//       {/* section 13.5 */}
//       {pricingPageData?.contact_section && (
//         <div className="section-13-5">
//           <div
//             className={`${
//               pricingPageData?.contact_section?.image?.data ? "" : "m-pb"
//             } container`}
//           >
//             <div>
//               <div>
//                 <div
//                   data-aos="fade-up"
//                   data-aos-duration="1200"
//                   className="section-13-5-content-wrapper-div"
//                 >
//                   <h3>{pricingPageData?.contact_section?.title}</h3>
//                   <p>{pricingPageData?.contact_section?.description}</p>
//                   <a
//                     href={
//                       pricingPageData?.contact_section?.contact_section_button
//                         ?.button_link || "/contact"
//                     }
//                     passHref
//                     target={
//                       pricingPageData?.contact_section?.contact_section_button
//                         ?.button_target === "blank"
//                         ? "_blank"
//                         : "_self"
//                     }
//                     className="btn1 pricing_contact_section_btn"
//                   >
//                     {
//                       pricingPageData?.contact_section?.contact_section_button
//                         ?.button_text
//                     }
//                   </a>
//                 </div>
//               </div>
//               {pricingPageData?.contact_section?.image?.data && (
//                 <div>
//                   <div
//                     data-aos="fade-up"
//                     data-aos-duration="1200"
//                     data-aos-delay="500"
//                     className="section-13-5-img-wrapper"
//                   >
//                     <Image
//                       src={replaceImageUrl(
//                         pricingPageData?.contact_section?.image?.data
//                           ?.attributes?.url
//                       )}
//                       alt="contact"
//                       width={500}
//                       height={350}
//                       loading="lazy"
//                     />
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       )}

//       {/* section-13.6 */}
//       {/* {pricingPageData?.brand_section && (
//         <div className="section-13-6">
//           <div className="container">
//             <h3>{pricingPageData?.brand_section?.title}</h3>
//             <p>{pricingPageData?.brand_section?.description}</p>
//             <div className="companies-wrapper-div">
//               {pricingPageData?.brand_section?.brands?.map((item, i) => {
//                 if (item?.image?.data) {
//                   return (
//                     <div key={i} className="brand-img-wrap">
//                       <Image
//                         src={replaceImageUrl(
//                           item?.image?.data?.attributes?.url
//                         )}
//                         alt=""
//                         width={154}
//                         height={42}
//                         style={{ borderRadius: "0" }}
//                         loading="lazy"
//                       />
//                     </div>
//                   );
//                 }
//               })}
//             </div>
//             <Link href={"/testimonials"} passHref>
//               <div className="link btn1">
//                 success stories <i className="bx bx-right-arrow-alt"></i>
//               </div>
//             </Link>
//           </div>
//         </div>
//       )} */}
//       {pricingPageData?.brand_section && (
//         <div className="pricing-brands-wrap">
//           <Brands
//             data={pricingPageData?.brand_section}
//             button={pricingPageData?.brand_section?.pricing_brands_button}
//           />
//         </div>
//       )}
//     </>
//   );
// };

// export default Pricing;
// export async function getServerSideProps({ preview }) {
//   const { data, errors } = await client.query({
//     query: gql`
//       query getPricingPageData {
//         pricing ${preview ? "(publicationState:PREVIEW)" : ""} {
//           data {
//             attributes {
//               title
//               plans {
//                 plan_name
//                 description
//                 isYearly
//                 price{
//                   price
//                   plan_type
//                 }
//                 price_text
//                 most_popular
//                 plan_features {
//                   name
//                   applicable
//                   show_tooltip
//                   tooltip_text
//                 }
//                 pricing_button {
//                   button_text
//                   button_link
//                   button_target
//                   button_icon
//                 }
//               }
//               custom_plan {
//                 title
//                 description
//                 custom_plan_button {
//                   button_text
//                   button_link
//                   button_target
//                   button_icon
//                 }
//               }
//               faq_section {
//                 title
//                 faq {
//                   question
//                   answer
//                 }
//                 heading_text
//                 link_text
//                 link_url
//                 link_target
//               }
//               contact_section {
//                 title
//                 description
//                 image {
//                   data {
//                     attributes {
//                       url
//                     }
//                   }
//                 }
//                 contact_section_button {
//                   button_text
//                   button_link
//                   button_target
//                   button_icon
//                 }
//               }
//               brand_section {
//                 title
//                 title2
//                 title_icon
//                 description
//                 brands {
//                   data {
//                     attributes {
//                       image {
//                         data {
//                           attributes {
//                             url
//                           }
//                         }
//                       }
//                     }
//                   }
//                 }
//                 brands2 {
//                   data {
//                     attributes {
//                       image {
//                         data {
//                           attributes {
//                             url
//                           }
//                         }
//                       }
//                     }
//                   }
//                 }
//                 brands3 {
//                   data {
//                     attributes {
//                       image {
//                         data {
//                           attributes {
//                             url
//                           }
//                         }
//                       }
//                     }
//                   }
//                 }
//                 pricing_brands_button {
//                   button_text
//                   button_link
//                   button_target
//                   button_icon
//                 }
//               }
//               schema
//               ${getSeoData}
//             }
//           }
//         }
//       }
//     `,
//   });

//   if (errors?.length > 0) {
//     return {
//       redirect: {
//         destination: `/500?url=/pricing/`,
//         permanent: true,
//       },
//     };
//   }

//   return {
//     props: {
//       pricingPageData: data?.pricing?.data?.attributes || null,
//     },
//   };
// }

import React from "react";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import dynamic from "next/dynamic";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
import PricingCards from "@/components/NewPricing/PricingCards";
import Credits from "@/components/NewPricing/Credits";
import HowCreditsWork from "@/components/NewPricing/HowCreditsWork";
import Faq from "@/components/NewPricing/Faq";
import GetInTouch from "@/components/NewPricing/GetInTouch";
const Seo = dynamic(() => import("@/components/Common/seo"));
const TestimonialOne = dynamic(() =>
  import("@/components/Testimonials/TestimonialOne")
);
const Brands = dynamic(() => import("@/components/LandingPages/common/Brands"));

const Pricing = ({ pricingPageData }) => {
  return (
    <>
      <Seo data={pricingPageData?.seo} />
      {pricingPageData?.schema && <Schema schema={pricingPageData?.schema} />}
      <BreadCrumbs currentPage={"Pricing"} />
      <div className="new-pricing-content-wrap">
        <PricingCards data={pricingPageData} />
        <Credits data={pricingPageData} />
        {pricingPageData?.how_credits_work && (
          <HowCreditsWork data={pricingPageData?.how_credits_work} />
        )}
        {pricingPageData?.testimonial_section && (
          <TestimonialOne
            testimonialSection={pricingPageData?.testimonial_section}
            testimonialData={
              pricingPageData?.testimonial_section?.testimonials?.data
            }
          />
        )}
        {pricingPageData?.brand_section && (
          <Brands data={pricingPageData?.brand_section} />
        )}
        {(pricingPageData?.faq_title || pricingPageData?.faq) && (
          <Faq title={pricingPageData?.faq_title} faq={pricingPageData?.faq} />
        )}
        {pricingPageData?.get_in_touch && (
          <GetInTouch data={pricingPageData?.get_in_touch} />
        )}
      </div>
    </>
  );
};

export default Pricing;
export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query getNewPricingPageData {
        newPricing ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
                title
                recommended {
                title
                price_and_credits
                list {
                    text
                }
                new_pricing_card_button {
                    button_text
                    button_link
                    button_target
                    button_icon
                }
                }
                reports_title
                pricing_cards {
                title
                price_and_credits
                list {
                    text
                }
                new_pricing_card_button {
                    button_text
                    button_link
                    button_target
                    button_icon
                }
                most_popular
                tag_line
                }
                credits_title
                credits_description
                credits_header {
                  icon {
                    data {
                      attributes {
                          url
                      }
                    }
                  }
                  title
                }
                credits {
                segment
                price
                discount
                discount_green_color_text
                }
                credits_button {
                button_text
                button_link
                button_target
                button_icon
                }
                how_credits_work {
                title
                description
                how_credits_work_button {
                    button_text
                    button_link
                    button_target
                    button_icon
                }
                desktop_image {
                    data {
                    attributes {
                        url
                    }
                    }
                }
                mobile_image {
                    data {
                    attributes {
                        url
                    }
                    }
                }
                }
                faq_title
                faq {
                question
                answer
                }
                get_in_touch {
                title
                description
                get_in_touch_button {
                    button_text
                    button_link
                    button_target
                    button_icon
                }
                image {
                    data {
                    attributes {
                        url
                    }
                    }
                }
                }
                testimonial_section {
                title
                testimonials {
                    data {
                    attributes {
                        title
                        description
                        name
                        designation
                        image {
                        data {
                            attributes {
                            url
                            }
                        }
                        }
                        linkedin
                    }
                    }
                }
                }
                brand_section {
                title1
                title2
                title_icon
                client_logos {
                    data {
                    attributes {
                        image {
                        data {
                            attributes {
                            url
                            }
                        }
                        }
                    }
                    }
                }
                client_logos2 {
                    data {
                    attributes {
                        image {
                        data {
                            attributes {
                            url
                            }
                        }
                        }
                    }
                    }
                }
                client_logos3 {
                    data {
                    attributes {
                        image {
                        data {
                            attributes {
                            url
                            }
                        }
                        }
                    }
                    }
                }
                }
                schema
                ${getSeoData}
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/pricing/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      pricingPageData: data?.newPricing?.data?.attributes || null,
    },
  };
}

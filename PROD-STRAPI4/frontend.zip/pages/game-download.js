import React from "react";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import dynamic from "next/dynamic";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
const BannerComponent = dynamic(() =>
  import("@/components/Common/Banner/BannerComponent")
);
const MinimalDashboard = dynamic(() =>
  import("@/components/GameDownload/MinimalDashboar")
);
const Features = dynamic(() => import("@/components/HomePages/App/Features"));
const AppDownload = dynamic(() =>
  import("@/components/HomePages/App/AppDownload")
);
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
const Seo = dynamic(() => import("@/components/Common/seo"));

export default function GameDownload({ gameDownloadData, commonData }) {
  return (
    <>
      <Seo data={gameDownloadData?.seo} />
      {gameDownloadData?.schema && <Schema schema={gameDownloadData?.schema} />}
      <BreadCrumbs currentPage={gameDownloadData?.title || "Game Download"} />
      <BannerComponent title={gameDownloadData?.title} />
      <MinimalDashboard
        data={gameDownloadData?.minimalDashboard}
        commonData={commonData}
      />
      <Features data={gameDownloadData?.features} />
      <AppDownload data={gameDownloadData?.appDownload} />
    </>
  );
}

export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query gameDownloadData {
        gameDownload ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              title
              minimalDashboard {
                sectionTitle
                title
                overviewList {
                  overviewPoint
                }
                appDownloadButtons {
                  buttonText
                  buttonLink
                }
                image1 {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                image2 {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              features {
                title
                featureList {
                  title
                  description
                  icon
                }
              }
              appDownload {
                sectionTitle
                title
                playstoreButtonText
                playstoreButtonLink
                applestoreButtonText
                applestoreButtonLink
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });
  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/game-download/`,
        permanent: true,
      },
    };
  }
  return {
    props: {
      gameDownloadData: data?.gameDownload?.data?.attributes || null,
    },
  };
}

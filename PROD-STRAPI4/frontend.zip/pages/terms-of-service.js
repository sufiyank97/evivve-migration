import React from "react";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import dynamic from "next/dynamic";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
const TermsConditionsContent = dynamic(() =>
  import("@/components/TermsConditions/TermsConditionsContent")
);
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
const Seo = dynamic(() => import("@/components/Common/seo"));

const TermsConditions = ({ termsOfService }) => {
  return (
    <>
      <Seo data={termsOfService?.seo} />
      {termsOfService?.schema && <Schema schema={termsOfService?.schema} />}
      <BreadCrumbs currentPage={termsOfService?.title} />
      <div className="page-title-area">
        <div className="container">
          <div className="page-title-content">
            <h1>{termsOfService?.title}</h1>
            {/* <ul>
							<li>
								<Link href="/">
									<a>Home</a>
								</Link>
							</li>
							<li>Terms & Conditions</li>
						</ul> */}
          </div>
        </div>
      </div>
      <TermsConditionsContent termsOfService={termsOfService} />
    </>
  );
};

export default TermsConditions;
export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query getTermsOfServicePage {
        termsOfService ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              title
              description
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/terms-of-service`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      termsOfService: data?.termsOfService?.data?.attributes || null,
    },
  };
}

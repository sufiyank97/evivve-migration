import React, { useContext, useEffect } from "react";
import dynamic from "next/dynamic";
import { fetchJournalData } from "graphql/getJournal";
import { convertToBase64 } from "@/utils/helper";
const Seo = dynamic(() => import("@/components/Common/seo"));
import { AppContext } from "context/AppContextProvider";
import { useRouter } from "next/router";
import Schema from "@/components/Common/Schema";
import CaseStudyDetail from "@/components/LandingPages/aferrMaster/CaseStudyDetail";

const JournalPage = ({ journalData, seoData }) => {
  const { setLoading } = useContext(AppContext);
  const router = useRouter();

  useEffect(() => {
    if (setLoading) {
      setLoading(false);
    }
  }, [setLoading]);

  if (!journalData) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <h1>Journal Not Found</h1>
        <p>The journal "{router.query.slug}" could not be found.</p>
        <a href="/journal">← Back to Journals</a>
      </div>
    );
  }

  const { attributes } = journalData;
  const { templates } = attributes;

  // Get the first template (since we only expect one per journal)
  const template = templates?.[0];

  if (!template) {
    return <div>No template found for this journal</div>;
  }

  return (
    <>
      <Seo seoData={seoData} />
      <Schema schemaData={seoData} />
      <CaseStudyDetail data={template} />
    </>
  );
};

export async function getServerSideProps(context) {
  const { params } = context;
  const { preview } = context.query;
  const { slug } = params;

  try {
    console.log(`Fetching journal data for slug: ${slug}`);
    const { data, error } = await fetchJournalData(slug, preview);
    
    console.log("Journal query result:", { data, error });
    
    if (error) {
      console.error("GraphQL error:", error);
      return {
        redirect: {
          destination: `/500?url=${encodeURIComponent(`/journal/${slug}`)}`,
          permanent: false,
        },
      };
    }
    
    if (!data?.journals?.data?.length) {
      console.log("No journal found for slug:", slug);
      return {
        redirect: {
          destination: `/404?url=${encodeURIComponent(`/journal/${slug}`)}`,
          permanent: false,
        },
      };
    }

    const journalData = data.journals.data[0];
    const seoData = journalData.attributes.seo || null;

    return {
      props: {
        journalData,
        seoData,
      },
    };
  } catch (error) {
    console.error("Error fetching journal data:", error);
    return {
      redirect: {
        destination: `/500?url=${encodeURIComponent(`/journal/${slug}`)}`,
        permanent: false,
      },
    };
  }
}

export default JournalPage;


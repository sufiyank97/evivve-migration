import { gql } from "@apollo/client";
import client from "../lib/apollo-client/ApolloClient";
import { getSeoData } from "graphql/getSeoData";
import dynamic from "next/dynamic";
import { useState } from "react";
import Seo from "@/components/Common/seo";
import Schema from "@/components/Common/Schema";
import GetStarted from "@/components/Home/GetStarted";
const Onboarding = dynamic(() => import("@/components/Home/Onboarding"));
// const Brands = dynamic(() => import("@/components/Home/Brands"));
const Brands = dynamic(() => import("@/components/LandingPages/common/Brands"));
const CommunitySection = dynamic(() =>
  import("@/components/Home/CommunitySection")
);
const EarningsSection = dynamic(() =>
  import("@/components/Home/EarningsSection")
);
const FirstSection = dynamic(() => import("@/components/Home/FirstSection"));
const HowItWorks = dynamic(() => import("@/components/Home/HowItWorks"));
const TestimonialOne = dynamic(() =>
  import("@/components/Testimonials/TestimonialOne")
);
const Navbar = dynamic(() => import("@/components/Layout/Navigations/Navbar1"));
const FooterTwo = dynamic(() => import("@/components/Layout/Footer/FooterTwo"));

export default function home({
  showOnboarding,
  setShowOnboarding,
  homeData,
  onboardingData,
  headerData,
  logo,
  top_sticky_stripe,
  host,
  footerData,
  commonData,
}) {
  const [onboardingCompleted, setOnBoardingCompleted] = useState(false);

  return (
    <div className={`${showOnboarding ? "showing-onboarding" : ""}`}>
      <Seo data={homeData?.seo} />
      {homeData?.schema && <Schema schema={homeData?.schema} />}
      <Onboarding
        showOnboarding={showOnboarding}
        setShowOnboarding={setShowOnboarding}
        onboardingData={onboardingData}
        setOnBoardingCompleted={setOnBoardingCompleted}
        top_section_data={homeData?.top_section}
      />
      <div>
        {headerData && footerData && homeData && (
          <>
            {!showOnboarding && (
              <Navbar
                header={headerData}
                logo={logo}
                top_sticky_stripe={top_sticky_stripe}
                host={host}
              />
            )}
            {/* <FirstSection data={homeData?.top_section} /> */}
            <Brands
              data={homeData?.brand_section}
              showOnboarding={showOnboarding}
            />
            <HowItWorks
              title={homeData?.how_it_works_title?.title}
              steps={homeData?.how_it_works_steps}
            />
            <TestimonialOne
              testimonialSection={homeData?.testimonial_section}
              testimonialData={
                homeData?.testimonial_section?.testimonials?.data
              }
            />
            <CommunitySection data={homeData?.community} />
            {homeData?.earning && (
              <EarningsSection data={homeData?.earning} />
            )}
            {homeData?.get_started && (
              <GetStarted data={homeData?.get_started} />
            )}
            <FooterTwo
              footerData={footerData}
              commonData={commonData}
              showOnboarding={showOnboarding}
            />
          </>
        )}
      </div>
    </div>
  );
}

export async function getServerSideProps({ req }) {
  const onboarding = req?.cookies["evivve-onboarding-completed"] || null;

  const { data, errors } = await client.query({
    query: gql`
      query getHomeData {
        home {
          data {
            attributes {
              top_section {
                title
                description
                videoUrl
                button1_text
                button1_link
                button2_text
                background_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                mobile_background_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                bg_video {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                show_video_or_image
              }
              brand_section {
                title1
                title2
                title_icon
                client_logos {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
                client_logos2 {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
                client_logos3 {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
              }
              how_it_works_title {
                title
              }
              how_it_works_steps {
                step_info
                title
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                description1
                description2
                textanimate {
                  text
                }
                points {
                  icon
                  title
                }
                how_it_work_buttons{
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                tooltip_text
              }
              testimonial_section {
                title
                testimonials {
                  data {
                    attributes {
                      title
                      description
                      designation
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      linkedin
                    }
                  }
                }
              }
              earning {
                title
                description
                earning_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              community {
                heading
                title
                description
                points {
                  title
                  icon
                }
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                community_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              get_started{
                title
                description
                get_started_button{
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              schema
              ${getSeoData}
            }
          }
        }
        onboarding {
          data {
            attributes {
              screen1 {
                title
                button_text
                background_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                persons_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                mobile_background_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                mobile_persons_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              screen2 {
                title
                button_text
                background_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                persons_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                mobile_background_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                mobile_persons_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              left_shade {
                data {
                  attributes {
                    url
                  }
                }
              }
              top_shade {
                data {
                  attributes {
                    url
                  }
                }
              }
              mobile_shade {
                data {
                  attributes {
                    url
                  }
                }
              }
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      homeData: data?.home?.data?.attributes || null,
      onboardingData: data?.onboarding?.data?.attributes || null,
    },
  };
}

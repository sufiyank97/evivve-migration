import React from "react";
import AferrMaster from "@/components/LandingPages/aferrMaster/AferrMaster";
import dynamic from "next/dynamic";
import { fetchDialoguesLandingPage } from "graphql/getLandingPage";
const Seo = dynamic(() => import("@/components/Common/seo"));
import Schema from "@/components/Common/Schema";

export default function DialoguesLandingPage({ data, seoData }) {
  return (
    <>
      <Seo seoData={seoData} />
      <Schema schemaData={seoData} />
      <AferrMaster data={data} pageType="dialogues" />
    </>
  );
}


export async function getServerSideProps() {
  try {
    console.log('Fetching dialogues landing page data...');
    const { data } = await fetchDialoguesLandingPage();
    
    console.log('Dialogues landing page data received:', data);
    
    const landingPageData = data?.dialogueLanding?.data?.attributes;
    const seoData = landingPageData?.seo || {
      metaTitle: "Dialogues - Evivve",
      metaDescription: "Discover our collection of dialogues that bring insights and knowledge to life through engaging audio content.",
    };

    // If no data is available, return a fallback structure
    if (!landingPageData) {
      console.log('No dialogues landing page data found, using fallback');
      return {
        props: {
          data: {
            title: "Dialogues",
            templates: [{
              hero_section: {
                enabled: true,
                title: "Dialogues",
                category: "Audio Content",
                description: "Discover our collection of dialogues that bring insights and knowledge to life through engaging audio content."
              }
            }]
          },
          seoData,
        },
      };
    }

    // Transform the CMS data structure to match what AferrMaster expects
    const transformedData = {
      title: landingPageData.title || "Dialogues",
      seo: landingPageData.seo || null,
      templates: [{
        hero_section: landingPageData.hero_section || null,
        brands_section: landingPageData.brands_section || null,
        details_section: landingPageData.details_section || null,
        details_section_2: landingPageData.details_section_2 || null,
        case_studies_section: landingPageData.case_studies_section || null,
        video_carousel_section: landingPageData.video_carousel_section || null,
        stats_section: landingPageData.stats_section || null,
        final_cta_section: landingPageData.final_cta_section || null,
      }]
    };

    return {
      props: {
        data: transformedData,
        seoData,
      },
    };
  } catch (error) {
    console.error("Error fetching dialogues landing page data:", error);
    return {
      props: {
        data: {
          title: "Dialogues",
          templates: [{
            hero_section: {
              enabled: true,
              title: "Dialogues",
              category: "Audio Content",
              description: "Discover our collection of dialogues that bring insights and knowledge to life through engaging audio content."
            }
          }]
        },
        seoData: {
          metaTitle: "Dialogues - Evivve",
          metaDescription: "Discover our collection of dialogues that bring insights and knowledge to life through engaging audio content.",
        },
      },
    };
  }
}

import React from "react";

const Author = () => {
  return <div>index</div>;
};

export default Author;
export async function getServerSideProps() {
  return {
    redirect: {
      destination: `/blogs/`,
      permanent: true,
    },
  };
}

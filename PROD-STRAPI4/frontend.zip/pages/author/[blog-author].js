import React from "react";
import dynamic from "next/dynamic";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
import Author from "@/components/Glossary/Author";
const Seo = dynamic(() => import("@/components/Common/seo"));
const Zoho = dynamic(() => import("@/components/Blog/BlogDetails/Zoho"));
const GridContent = dynamic(() => import("@/components/Blog/GridContent"));

const BlogAuthor = ({ blogsData, totalPages, authoBlogsCount }) => {
  const authorData = blogsData[0]?.attributes?.author?.data?.attributes;
  // console.log("blogsData", blogsData);
  console.log(authorData?.newsletter_section);
  return (
    <>
      <Seo data={authorData?.seo} />
      {authorData?.schema && <Schema schema={authorData?.schema} />}
      {/* <div className="page-title-area">
        <div className="container">
          <div className="page-title-content">
            <h1>Author: Anna Smith</h1>
            <ul>
              <li>
                <Link href="/">
                  <a>Home</a>
                </Link>
              </li>
              <li>
                <Link href="/blogs/blog-grid">
                  <a>Blog</a>
                </Link>
              </li>
              <li>Author</li>
            </ul>
          </div>
        </div>
      </div> */}
      <div className="container author-main-wrap">
        <Author authorData={authorData} authoBlogsCount={authoBlogsCount} />
      </div>
      <GridContent blogsData={blogsData} totalPages={totalPages} />

      {authorData?.newsletter_section?.description && (
        <div className="mb-5">
          <Zoho
            embedCode={authorData?.newsletter_section?.description}
            form_onsubmit={authorData?.newsletter_section?.form_onsubmit}
            form_onload={authorData?.newsletter_section?.form_onload}
          />
        </div>
      )}
    </>
  );
};

export default BlogAuthor;

export async function getServerSideProps({ preview, params, query }) {
  const authorSlug = params["blog-author"];
  let pageNumber = query.page || 1;
  // console.log("pageNumber:", pageNumber);
  // for page number
  const { data, errors } = await client.query({
    query: gql`
      query getAuthor {
        blogs(
           ${preview ? "publicationState:PREVIEW," : ""}
          filters: { author: { slug: { eq: "${authorSlug}" } } },
          pagination: { page: ${pageNumber}, pageSize: 6 }, sort: "createdAt:desc") {
          data {
            id
            attributes {
              slug
              title
              createdAt
              publish_date
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              categories {
                data {
                  attributes {
                    title
                    slug
                  }
                }
              }
              tags {
                data {
                  attributes {
                    title
                    slug
                  }
                }
              }
              author {
                data {
                  attributes {
                    name
                    location
                    slug
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    bio
                    skill
                    newsletter_section {
                      description
                    }
                    social_links {
                      name
                      link
                    }
                    schema
                    ${getSeoData}
                  }
                }
              }
            }
          }
          meta {
            pagination {
              page
              pageSize
              total
              pageCount
            }
          }
        }
      }
    `,
  });

  // const { data, errors } = await client.query({
  //   query: gql`
  //     query getAuthor {
  //       authors(
  //         ${preview ? "publicationState:PREVIEW," : ""}
  //         filters: { slug: { eq: "${authorSlug}" } }) {
  //         data {
  //           attributes {
  //             name
  //             location
  //             slug
  //             image {
  //               data {
  //                 attributes {
  //                   url
  //                 }
  //               }
  //             }
  //             newsletter_section {
  //               icon {
  //                 data {
  //                   attributes {
  //                     url
  //                   }
  //                 }
  //               }
  //               heading
  //               description
  //             }
  //             bio
  //             social_links {
  //               name
  //               link
  //             }
  //             blogs {
  //               data {
  //                 attributes {
  //                   slug
  //                   title
  //                   createdAt
  //                   image {
  //                     data {
  //                       attributes {
  //                         url
  //                       }
  //                     }
  //                   }
  //                   categories {
  //                     data {
  //                       attributes {
  //                         title
  //                         slug
  //                       }
  //                     }
  //                   }
  //                   tags {
  //                     data {
  //                       attributes {
  //                         title
  //                       }
  //                     }
  //                    }
  //                 }
  //               }
  //             }
  //           }
  //         }
  //       }
  //     }
  //   `,
  // });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/${blogData?.slug}`,
        permanent: true,
      },
    };
  } else if (
    data?.blogs?.data?.length === 0 ||
    data?.authors?.data?.length === 0
  ) {
    //blogs condition for page number
    return {
      redirect: {
        destination: `/evivvo-pedia/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      // authorData: data?.authors?.data?.[0]?.attributes || [],
      blogsData: data?.blogs?.data || [], //these when pagenumber is there
      totalPages: data?.blogs?.meta?.pagination?.pageCount || null,
      authoBlogsCount: data?.blogs?.meta?.pagination?.total || null,
    },
  };
}

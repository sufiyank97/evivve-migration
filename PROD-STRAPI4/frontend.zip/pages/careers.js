import React from "react";
import { gql } from "@apollo/client";
import client from "../lib/apollo-client/ApolloClient";
import dynamic from "next/dynamic";
import { getSeoData } from "graphql/getSeoData";
import Seo from "@/components/Common/seo";
import Schema from "@/components/Common/Schema";
const HeroSection = dynamic(() => import("@/components/Careers/HeroSection"));
// const Brands = dynamic(() => import("@/components/Home/Brands"));
const Brands = dynamic(() => import("@/components/LandingPages/common/Brands"));
const TestimonialOne = dynamic(() =>
  import("@/components/Testimonials/TestimonialOne")
);
const ZohoCareers = dynamic(() => import("@/components/Careers/ZohoCareers"));
const JoinOurCommunity = dynamic(() =>
  import("@/components/AboutUs/JoinOurCommunity")
);

export default function careers({ careersData }) {
  return (
    <>
      <Seo data={careersData?.seo} />
      {careersData?.schema && <Schema schema={careersData?.schema} />}
      <HeroSection data={careersData?.hero_section} />
      <Brands data={careersData?.brand_section} />
      <TestimonialOne
        testimonialSection={careersData?.testimonial_section}
        testimonialData={careersData?.testimonial_section?.testimonials?.data}
      />
      {careersData?.show_zoho_careers && <ZohoCareers />}
      <JoinOurCommunity
        image={careersData?.bottom_section?.image}
        title={careersData?.bottom_section?.title}
        button={careersData?.bottom_section?.career_bottom_button}
        description={careersData?.bottom_section?.description}
      />
    </>
  );
}

export async function getServerSideProps(context) {
  const { data, errors } = await client.query({
    query: gql`
    query getCareersDate {
        career ${context?.preview ? "(publicationState:PREVIEW)" : ""} {
            data {
              attributes {
                hero_section {
                  title
                  description
                  career_button {
                    button_text
                    button_icon
                    button_link
                    button_target
                  }
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                }
                brand_section {
                  title1
                  title2
                  title_icon
                  client_logos {
                    data {
                      attributes {
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                      }
                    }
                  }
                  client_logos2 {
                    data {
                      attributes {
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                      }
                    }
                  }
                  client_logos3 {
                    data {
                      attributes {
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                      }
                    }
                  }
                }
                testimonial_section {
                  title
                  testimonials {
                    data {
                      attributes {
                        title
                        description
                        designation
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                        linkedin
                      }
                    }
                  }
                }
                show_zoho_careers
                bottom_section {
                    title
                    description
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    career_bottom_button {
                      button_text
                      button_icon
                      button_link
                      button_target
                    }
                  }
                  schema
                  ${getSeoData}
              }
            }
          }
    }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/careers/`,
        permanent: true,
      },
    };
  }

  return {
    props: { careersData: data?.career?.data?.attributes || null },
  };
}

export const formattedDate = (date) => {
  const dateObject = new Date(date);
  const options = {
    year: "numeric",
    month: "short",
    day: "2-digit",
  };
  const formattedDate = dateObject.toLocaleDateString("en-US", options);
  return formattedDate;
};

export const formattedDate2 = (date) => {
  const dateObject = new Date(date);
  const options = {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  };
  const formattedDate = new Intl.DateTimeFormat("en-US", options).format(
    dateObject
  );
  return formattedDate;
};

export const formattedDate3 = (date) => {
  if (date) {
    const dateObject = new Date(date);
    const options = {
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    const formattedDate = new Intl.DateTimeFormat("en-GB", options)?.format(
      dateObject
    );
    return formattedDate;
  }
};

export const convertToBase64 = async (url) => {
  const data = await fetch(url);
  const blob = await data.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
};

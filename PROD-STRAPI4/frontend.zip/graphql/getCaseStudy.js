import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";

export const fetchCaseStudyData = async (slug, preview) => {
  const queryString = preview 
    ? `query getCaseStudyData {
        caseStudies(publicationState: PREVIEW, filters: { slug: { eq: "${slug}" } }) {
          data {
            id
            attributes {
              title
              slug
              seo {
                metaTitle
                metaDescription
                keywords
                canonicalURL
                metaImage {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              templates {
                ... on ComponentCaseStudyCaseStudySeriesTemplate {
                  hero_section {
                    enabled
                    title
                    category
                    description
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    background_color
                    gradient_overlay
                  }
                  company_overview_section {
                    enabled
                    title
                    company_card_enabled
                    company_card_label
                    company_card_icon {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    industry_card_enabled
                    industry_card_label
                    industry_card_icon {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    location_card_enabled
                    location_card_label
                    location_card_icon {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    company_name
                    industry
                    location
                    description
                  }
                  key_challenges_section {
                    enabled
                    title
                    content
                    image_square {
                      data {
                        attributes {
                          url
                          
                        }
                      }
                    }
                    image_wide {
                      data {
                        attributes {
                          url
                          
                        }
                      }
                    }
                  }
                  solutions_section {
                    enabled
                    title
                    content
                    testimonial {
                      enabled
                      quote
                      author_name
                      author_designation
                      author_image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    additional_content
                    additional_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  solutions_banner {
                    enabled
                    title
                    description
                    button {
                      button_text
                      button_icon
                      button_link
                      button_target
                    }
                    button_type
                    form
                    form_onload
                    form_onsubmit
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    gradient_overlay
                  }
                  impact_section {
                    enabled
                    title
                    description
                    stats {
                      number
                      title
                      description
                      detailed_description
                    }
                  }
                  testimonial_section {
                    enabled
                    quote
                    author_name
                    author_designation
                    author_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  cta_header_section {
                    enabled
                    title
                    description
                    spacing {
                      top
                      bottom
                    }
                  }
                  cta_section {
                    data {
                      attributes {
                        title
                        description_type {
                          __typename
                          ... on ComponentCaseStudyCaseStudyCta {
                            caseStudyCtaTitle: title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            caseStudyBackgroundType: background_type
                            
                            background_image {
                              data {
                                attributes {
                                  url
                                  
                                }
                              }
                            }
                            gradient_overlay
                            background_color
                            caseStudyTextColor: text_color
                            custom_text_color
                            enabled
                          }
                          ... on ComponentCaseStudyAferrCta {
                            aferrCtaTitle: title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            aferrBackgroundType: background_type
                            
                            background_image {
                              data {
                                attributes {
                                  url
                                  
                                }
                              }
                            }
                            gradient_overlay
                            background_color
                            aferrTextColor: text_color
                            custom_text_color
                            enabled
                          }
                          ... on ComponentButtonNewsletter {
                            description
                            form_onload
                            form_onsubmit
                          }
                          ... on ComponentButtonButtonImageText {
                            image {
                              data {
                                attributes {
                                  url
                                  
                                }
                              }
                            }
                            buttonImageTextTitle: title
                            description
                            button_image_text_button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                          }
                          ... on ComponentButtonButtonText {
                            description
                            button_text_button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                          }
                          ... on ComponentCommonButton {
                            button_text
                            button_icon
                            button_link
                            button_target
                          }
                          ... on ComponentCommonAppDownload {
                            sectionTitle
                            appDownloadTitle: title
                            image {
                              data {
                                attributes {
                                  url
                                  
                                }
                              }
                            }
                            playstoreButtonText
                            applestoreButtonText
                            playstoreButtonLink
                            applestoreButtonLink
                          }
                          ... on ComponentKnowledgeBase3CardsCtas {
                            card {
                              title
                              description
                              image {
                                data {
                                  attributes {
                                    url
                                    
                                  }
                                }
                              }
                              link_title
                              link_href
                              link_target
                            }
                          }
                          
                        }
                      }
                    }
                  }
                  references_section {
                    enabled
                    title
                    references {
                      reference_editor
                    }
                  }
                }
              }
            }
          }
        }
      }`
    : `query getCaseStudyData {
        caseStudies(filters: { slug: { eq: "${slug}" } }) {
          data {
            id
            attributes {
              title
              slug
              seo {
                metaTitle
                metaDescription
                keywords
                canonicalURL
                metaImage {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              templates {
                ... on ComponentCaseStudyCaseStudySeriesTemplate {
                  hero_section {
                    enabled
                    title
                    category
                    description
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    background_color
                    gradient_overlay
                  }
                  company_overview_section {
                    enabled
                    title
                    company_card_enabled
                    company_card_label
                    company_card_icon {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    industry_card_enabled
                    industry_card_label
                    industry_card_icon {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    location_card_enabled
                    location_card_label
                    location_card_icon {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    company_name
                    industry
                    location
                    description
                  }
                  key_challenges_section {
                    enabled
                    title
                    content
                    image_square {
                      data {
                        attributes {
                          url
                          
                        }
                      }
                    }
                    image_wide {
                      data {
                        attributes {
                          url
                          
                        }
                      }
                    }
                  }
                  solutions_section {
                    enabled
                    title
                    content
                    testimonial {
                      enabled
                      quote
                      author_name
                      author_designation
                      author_image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    additional_content
                    additional_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  solutions_banner {
                    enabled
                    title
                    description
                    button {
                      button_text
                      button_icon
                      button_link
                      button_target
                    }
                    button_type
                    form
                    form_onload
                    form_onsubmit
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    gradient_overlay
                  }
                  impact_section {
                    enabled
                    title
                    description
                    stats {
                      number
                      title
                      description
                      detailed_description
                    }
                  }
                  testimonial_section {
                    enabled
                    quote
                    author_name
                    author_designation
                    author_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  cta_header_section {
                    enabled
                    title
                    description
                    spacing {
                      top
                      bottom
                    }
                  }
                  cta_section {
                    data {
                      attributes {
                        title
                        description_type {
                          __typename
                          ... on ComponentCaseStudyCaseStudyCta {
                            caseStudyCtaTitle: title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            caseStudyBackgroundType: background_type
                            
                            background_image {
                              data {
                                attributes {
                                  url
                                  
                                }
                              }
                            }
                            gradient_overlay
                            background_color
                            caseStudyTextColor: text_color
                            custom_text_color
                            enabled
                          }
                          ... on ComponentCaseStudyAferrCta {
                            aferrCtaTitle: title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            aferrBackgroundType: background_type
                            
                            background_image {
                              data {
                                attributes {
                                  url
                                  
                                }
                              }
                            }
                            gradient_overlay
                            background_color
                            aferrTextColor: text_color
                            custom_text_color
                            enabled
                          }
                          ... on ComponentButtonNewsletter {
                            description
                            form_onload
                            form_onsubmit
                          }
                          ... on ComponentButtonButtonImageText {
                            image {
                              data {
                                attributes {
                                  url
                                  
                                }
                              }
                            }
                            buttonImageTextTitle: title
                            description
                            button_image_text_button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                          }
                          ... on ComponentButtonButtonText {
                            description
                            button_text_button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                          }
                          ... on ComponentCommonButton {
                            button_text
                            button_icon
                            button_link
                            button_target
                          }
                          ... on ComponentCommonAppDownload {
                            sectionTitle
                            appDownloadTitle: title
                            image {
                              data {
                                attributes {
                                  url
                                  
                                }
                              }
                            }
                            playstoreButtonText
                            applestoreButtonText
                            playstoreButtonLink
                            applestoreButtonLink
                          }
                          ... on ComponentKnowledgeBase3CardsCtas {
                            card {
                              title
                              description
                              image {
                                data {
                                  attributes {
                                    url
                                    
                                  }
                                }
                              }
                              link_title
                              link_href
                              link_target
                            }
                          }
                          
                        }
                      }
                    }
                  }
                  references_section {
                    enabled
                    title
                    references {
                      reference_editor
                    }
                  }
                }
              }
            }
          }
        }
      }`;

  try {
    return await client.query({
      query: gql(queryString),
      errorPolicy: 'all'
    });
  } catch (err) {
    console.error("Full case study query failed; falling back to minimal CTA query", err?.networkError?.result?.errors || err);
    const fallbackQuery = `query getCaseStudyCtaOnly {
        caseStudies(filters: { slug: { eq: "${slug}" } }) {
          data {
            id
            attributes {
              title
              slug
              templates {
                ... on ComponentCaseStudyCaseStudySeriesTemplate {
                  cta_section {
                    data {
                      attributes {
                        title
                        description_type {
                          __typename
                          ... on ComponentCaseStudyCaseStudyCta {
                            title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            background_type
                            background_image { data { attributes { url } } }
                            gradient_overlay
                            background_color
                            text_color
                            custom_text_color
                            enabled
                          }
                          ... on ComponentCaseStudyAferrCta {
                            title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            background_type
                            background_image { data { attributes { url } } }
                            gradient_overlay
                            background_color
                            text_color
                            custom_text_color
                            enabled
                          }
                          ... on ComponentButtonNewsletter {
                            description
                            form_onload
                            form_onsubmit
                          }
                          ... on ComponentButtonButtonImageText {
                            image { data { attributes { url } } }
                            buttonImageTextTitle: title
                            description
                            button_image_text_button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                          }
                          ... on ComponentButtonButtonText {
                            description
                            button_text_button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                          }
                          ... on ComponentCommonButton {
                            button_text
                            button_icon
                            button_link
                            button_target
                          }
                          ... on ComponentCommonAppDownload {
                            sectionTitle
                            appDownloadTitle: title
                            image { data { attributes { url } } }
                            playstoreButtonText
                            applestoreButtonText
                            playstoreButtonLink
                            applestoreButtonLink
                          }
                          ... on ComponentKnowledgeBase3CardsCtas {
                            card {
                              title
                              description
                              image { data { attributes { url } } }
                              link_title
                              link_href
                              link_target
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }`;
    return await client.query({
      query: gql(fallbackQuery),
      errorPolicy: 'all'
    });
  }
};

export const fetchCaseStudies = async () => {
  return await client.query({
    query: gql`
      query getCaseStudies {
        caseStudies {
          data {
            id
            attributes {
              title
              slug
              seo {
                metaTitle
                metaDescription
                keywords
                canonicalURL
                metaImage {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
            }
          }
        }
      }
    `,
    errorPolicy: 'all'
  });
};
  
   
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import { getSeoData } from "./getSeoData";

export const fetchCaseStudyLandingPage = async () => {
  try {
    console.log('Attempting to fetch case study landing page...');
    
    // Use the simplest possible query first
    const simpleQuery = await client.query({
      query: gql`
        query getCaseStudyLanding {
          caseStudyLanding {
            data {
              id
              attributes {
                title
              }
            }
          }
        }
      `,
      errorPolicy: 'all'
    });
    
    console.log('Case study simple query result:', simpleQuery.data);
    
    // If no data, return null
    if (!simpleQuery.data?.caseStudyLanding?.data) {
      console.log('No case study landing data found');
      return { data: { caseStudyLanding: { data: null } } };
    }
    
    // If we have data, try to get more fields progressively
    try {
      const fullQuery = await client.query({
        query: gql`
          query getCaseStudyLandingFull {
            caseStudyLanding {
              data {
                attributes {
                  title
                  seo {
                    metaTitle
                    metaDescription
                    metaImage {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    keywords
                    canonicalURL
                  }
                  hero_section {
                    enabled
                    title
                    category
                    description
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  brands_section {
                    title
                    brands {
                      data {
                        id
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  details_section {
                    enabled
                    title
                    description
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    stats_quadrants {
                      stat_value
                      stat_description
                      position
                    }
                  }
                  details_section_2 {
                    enabled
                    title
                    description
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                  case_studies_section {
                    enabled
                    title
                    description
                    case_study_categories {
                      title
                      case_studies {
                        title
                        description
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                        button {
                          button_text
                          button_link
                          button_target
                          button_icon
                        }
                      }
                    }
                  }
                  video_carousel_section {
                    enabled
                    title
                    video_cards {
                      title
                      video_embed_src_link
                    }
                  }
                  stats_section {
                    enabled
                    title
                    description
                    stats_cards {
                      stat_value
                      stat_description
                    }
                  }
                  final_cta_section {
                    enabled
                    title
                    description
                    background_image_desktop {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    background_image_mobile {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    background_image {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    gradient_overlay
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                }
              }
            }
          }
        `,
        errorPolicy: 'all'
      });
      
      console.log('Case study full query successful:', fullQuery.data);
      return fullQuery;
      
    } catch (fullQueryError) {
      console.log('Case study full query failed, using simple query result');
      console.error('Case study full query error details:', {
        message: fullQueryError.message,
        graphQLErrors: fullQueryError.graphQLErrors,
        networkError: fullQueryError.networkError
      });
      return simpleQuery;
    }
    
  } catch (error) {
    console.error('Case study landing page fetch failed:', error.message);
    return { 
      data: { 
        caseStudyLanding: { 
          data: null 
        } 
      } 
    };
  }
};

export const fetchDialoguesLandingPage = async () => {
  try {
    console.log('Attempting to fetch dialogues landing page...');
    
    // Use the simplest possible query first
    const simpleQuery = await client.query({
      query: gql`
        query getDialogueLanding {
          dialogueLanding {
            data {
              id
              attributes {
                title
              }
            }
          }
        }
      `,
      errorPolicy: 'all'
    });
    
    console.log('Dialogues simple query result:', simpleQuery.data);
    
    // If no data, return null
    if (!simpleQuery.data?.dialogueLanding?.data) {
      console.log('No dialogues landing data found');
      return { data: { dialogueLanding: { data: null } } };
    }
    
    // If we have data, try to get more fields progressively
    try {
      const fullQuery = await client.query({
        query: gql`
          query getDialogueLandingFull {
            dialogueLanding {
              data {
                attributes {
                  title
                  seo {
                    metaTitle
                    metaDescription
                    metaImage {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    keywords
                    canonicalURL
                  }
                  hero_section {
                    enabled
                    title
                    category
                    description
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  brands_section {
                    title
                    brands {
                      data {
                        id
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  details_section {
                    enabled
                    title
                    description
                    media_type
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    video {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    video_thumbnail {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    stats_quadrants {
                      stat_value
                      stat_description
                      position
                    }
                  }
                  details_section_2 {
                    enabled
                    title
                    description
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                  case_studies_section {
                    enabled
                    title
                    description
                    case_study_categories {
                      title
                      case_studies {
                        title
                        description
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                        button {
                          button_text
                          button_link
                          button_target
                          button_icon
                        }
                      }
                    }
                  }
                  video_carousel_section {
                    enabled
                    title
                    video_cards {
                      title
                      video_embed_src_link
                    }
                  }
                  stats_section {
                    enabled
                    title
                    description
                    stats_cards {
                      stat_value
                      stat_description
                    }
                  }
                  final_cta_section {
                    enabled
                    title
                    description
                    background_image_desktop {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    background_image_mobile {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    background_image {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    gradient_overlay
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                }
              }
            }
          }
        `,
        errorPolicy: 'all'
      });
      
      console.log('Dialogues full query successful:', fullQuery.data);
      return fullQuery;
      
    } catch (fullQueryError) {
      console.log('Dialogues full query failed, using simple query result');
      console.error('Dialogues full query error details:', {
        message: fullQueryError.message,
        graphQLErrors: fullQueryError.graphQLErrors,
        networkError: fullQueryError.networkError
      });
      return simpleQuery;
    }
    
  } catch (error) {
    console.error('Dialogues landing page fetch failed:', error.message);
    return { 
      data: { 
        dialogueLanding: { 
          data: null 
        } 
      } 
    };
  }
};

export const fetchJournalLandingPage = async () => {
  try {
    console.log('Attempting to fetch journal landing page...');
    
    // Use the simplest possible query first
    const simpleQuery = await client.query({
      query: gql`
        query getJournalLanding {
          journalLanding {
            data {
              id
              attributes {
                title
              }
            }
          }
        }
      `,
      errorPolicy: 'all'
    });
    
    console.log('Simple query result:', simpleQuery.data);
    
    // If no data, return null
    if (!simpleQuery.data?.journalLanding?.data) {
      console.log('No journal landing data found');
      return { data: { journalLanding: { data: null } } };
    }
    
    // If we have data, try to get more fields progressively
    try {
      const fullQuery = await client.query({
        query: gql`
          query getJournalLandingFull {
            journalLanding {
              data {
                attributes {
                  title
                  seo {
                    metaTitle
                    metaDescription
                    metaImage {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    keywords
                    canonicalURL
                  }
                  hero_section {
                    enabled
                    title
                    category
                    description
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  brands_section {
                    title
                    brands {
                      data {
                        id
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  details_section {
                    enabled
                    title
                    description
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    stats_quadrants {
                      stat_value
                      stat_description
                      position
                    }
                  }
                  details_section_2 {
                    enabled
                    title
                    description
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                  case_studies_section {
                    enabled
                    title
                    description
                    case_study_categories {
                      title
                      case_studies {
                        title
                        description
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                        button {
                          button_text
                          button_link
                          button_target
                          button_icon
                        }
                      }
                    }
                  }
                  video_carousel_section {
                    enabled
                    title
                    video_cards {
                      title
                      video_embed_src_link
                    }
                  }
                  stats_section {
                    enabled
                    title
                    description
                    stats_cards {
                      stat_value
                      stat_description
                    }
                  }
                  final_cta_section {
                    enabled
                    title
                    description
                    background_image_desktop {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    background_image_mobile {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    background_image {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    gradient_overlay
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                }
              }
            }
          }
        `,
        errorPolicy: 'all'
      });
      
      console.log('Full query successful:', fullQuery.data);
      return fullQuery;
      
    } catch (fullQueryError) {
      console.log('Full query failed, using simple query result');
      console.error('Full query error details:', {
        message: fullQueryError.message,
        graphQLErrors: fullQueryError.graphQLErrors,
        networkError: fullQueryError.networkError
      });
      return simpleQuery;
    }
    
  } catch (error) {
    console.error('Journal landing page fetch failed:', error.message);
    return { 
      data: { 
        journalLanding: { 
          data: null 
        } 
      } 
    };
  }
};
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import { getSeoData } from "./getSeoData";

export const fetchBlogData = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getBlogData {
        blogs(${
          preview ? "publicationState:PREVIEW," : ""
        } filters: { slug: { eq: "${slug}" } }) {
          data {
            id
            attributes {
              title
              slug
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              description_type {
                ... on ComponentCommonEditor {
                  description
                }
                ... on ComponentButtonButtonImageText {
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  title
                  description
                  button_image_text_button {
                    button_text
                    button_icon
                    button_link
                    button_target
                  }
                }
                ... on ComponentButtonButtonText {
                  description
                  button_text_button {
                    button_text
                    button_icon
                    button_link
                    button_target
                  }
                }
                ... on ComponentButtonNewsletter {
                  description
                  form_onload
                  form_onsubmit
                }
                ... on ComponentCommonButton {
                  button_text
                  button_icon
                  button_link
                  button_target
                }
                ... on ComponentBlogKeyTakeaways {
                  title
                  description
                }
              }
              ctas{
                data{
                  attributes{
                    description_type {
                      ... on ComponentCommonButton {
                        button_text
                        button_icon
                        button_link
                        button_target
                      }
                      ... on ComponentButtonButtonImageText {
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                        title
                        description
                        button_image_text_button {
                          button_text
                          button_icon
                          button_link
                          button_target
                        }
                      }
                      ... on ComponentButtonButtonText {
                        description
                        button_text_button {
                          button_text
                          button_icon
                          button_link
                          button_target
                        }
                      }
                      ... on ComponentButtonNewsletter {
                        description
                        form_onload
                        form_onsubmit
                      }
                      ... on ComponentCommonAppDownload {
                        sectionTitle
                        title
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                        playstoreButtonText
                        playstoreButtonLink
                        applestoreButtonText
                        applestoreButtonLink
                      }
                      ... on ComponentPopupPopup{
                        title
                        description
                        popup_button {
                          button_text
                          button_icon
                          button_link
                          button_target
                        }
                        image{
                          data{
                            attributes{
                              url
                            }
                          }
                        }
                      }
                      ... on ComponentKnowledgeBase3CardsCtas {
                        card {
                          title
                          description
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                          link_title
                          link_href
                          link_target
                        }
                      }
                    }
                  }
                }
              }
              createdAt
              publish_date
              categories {
                data {
                  attributes {
                    title
                    slug
                  }
                }
              }
              tags {
                data {
                  attributes {
                    title
                    slug
                  }
                }
              }
              author {
                data {
                  attributes {
                    name
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    skill
                    location
                    slug
                    bio
                    social_links {
                      name
                      link
                    }
                  }
                }
              }
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });
};

export const fetchPopularBlogs = async () => {
  return await client.query({
    query: gql`
      query getPopularBlogs {
        popularBlogs {
          data {
            attributes {
              blogs {
                data {
                  attributes {
                    title
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    slug
                    createdAt
                    publish_date
                  }
                }
              }
            }
          }
        }
      }
    `,
  });
};

export const fetchUseCases = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getUseCases {
        useCases(${
          preview ? "publicationState:PREVIEW," : ""
        } filters: { slug: { eq: "${slug}" } }) {
          data {
            id
            attributes {
              slug
               banner {
                 title
                 image {
                   data {
                     attributes {
                       url
                     }
                   }
                 }
                 mobile_image {
                   data {
                     attributes {
                       url
                     }
                   }
                 }
                 description
               }
               benefits {
                 title
                 benefits_detials {
                   image {
                     data {
                       attributes {
                         url
                       }
                     }
                   }
                   title
                   description
                 }
               }
               description{
                ... on ComponentUseCaseCkeditor{
                  description
                }
                ... on ComponentUseCaseSwiperDescription{
                  swiper{
                    title
                    description
                  }
                }
              }
               features {
                 title
                 subTitle
                 subTitle_highlight
                 description
                 image {
                   data {
                     attributes {
                       url
                     }
                   }
                 }
               }
               ready_section {
                 title
                 description
                  ready_section_button {
                    button_text
                    button_icon
                    button_link
                    button_target
                  }
               }
               explore {
                 image {
                   data {
                     attributes {
                       url
                     }
                   }
                 }
                 title
                 description
               }
               faq_section {
                title
                faq {
                  question
                  answer
                }
                heading_text
                link_text
                link_url
                link_target
              }
              description_type {
                  ... on ComponentButtonButtonImageText {
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    title
                    description
                    button_image_text_button {
                      button_text
                      button_icon
                      button_link
                      button_target
                    }
                  }
                  ... on ComponentButtonButtonText {
                    description
                    button_text_button {
                      button_text
                      button_icon
                      button_link
                      button_target
                    }
                  }
                  ... on ComponentCommonButton {
                    button_text
                    button_icon
                    button_link
                    button_target
                  }
                  ... on ComponentButtonNewsletter {
                    description
                    form_onload
                    form_onsubmit
                  }
                }
                ctas{
                  data{
                    attributes{
                      description_type {
                        ... on ComponentButtonButtonImageText {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                          title
                          description
                          button_image_text_button {
                            button_text
                            button_icon
                            button_link
                            button_target
                          }
                        }
                        ... on ComponentButtonButtonText {
                          description
                          button_text_button {
                            button_text
                            button_icon
                            button_link
                            button_target
                          }
                        }
                        ... on ComponentButtonNewsletter {
                          description
                          form_onload
                          form_onsubmit
                        }
                        ... on ComponentCommonAppDownload {
                          sectionTitle
                          title
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                          playstoreButtonText
                          playstoreButtonLink
                          applestoreButtonText
                          applestoreButtonLink
                        }
                        ... on ComponentPopupPopup{
                          title
                          description
                          popup_button {
                            button_text
                            button_icon
                            button_link
                            button_target
                          }
                          image{
                            data{
                              attributes{
                                url
                              }
                            }
                          }
                        }
                        ... on ComponentCommonButton {
                          button_text
                          button_icon
                          button_link
                          button_target
                        }
                      }
                    }
                  }
                }
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });
};

export const fetchThankYouPages = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getThankYouPages {
        thankYouPages(${
          preview ? "publicationState:PREVIEW," : ""
        } filters: { slug: { eq: "${slug}" } }) {
          data {
            attributes {
              heading
              slug
              description
              ckeditor_description
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              thankyou_button {
                button_text
                button_icon
                button_link
                button_target
              }
              button_type
              download_link
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });
};

export const fetchLandingPages = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getLandingPages {
        landingPages(${
          preview ? "publicationState:PREVIEW," : ""
        } filters: { slug: { eq: "${slug}" } }) {
          data {
            attributes {
              title
              slug
              ${getSeoData}
              templates {
                ... on ComponentLandingPageMasterclass {
                  show_intro_animation
                  animations {
                    bg_img_1 {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    bg_img_2 {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    evivve_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    fav_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    e_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    masterclass_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    mobile_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    screen1 {
                      title
                      description
                      button_text
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    screen2 {
                      title
                      description
                      button_text
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    screen3 {
                      title
                      date
                      time
                      button_text
                      video {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      video_thumbnail {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    screen4_button_text
                  }
                  show_custom_navbar
                  custom_navbar {
                    links
                  }
                  agenda {
                    title
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    what_you_can_expect_title
                    what_you_can_expect_list {
                      list
                    }
                    time_and_date {
                      title
                      date
                      time
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  industry_experts {
                    title
                    experts_list {
                      name
                      designation
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      description
                      linkedin_url
                    }
                  }
                  count {
                    count_number
                    count_text
                  }
                  brands {
                    title1
                    title2
                    title_icon
                    brands1 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                    brands2 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                    brands3 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  certifications {
                    title
                    cards {
                      name
                      description
                      bg_color
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  register {
                    title
                    register_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    zoho_form_type
                    register_form
                    form_onload
                    form_onsubmit
                  }
                  faq {
                    title
                    faq_list {
                      question
                      answer
                    }
                  }
                }
                ... on ComponentLandingPageTemplate2 {
                  show_intro_animation
                  animations {
                    bg_img_1 {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    bg_img_2 {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    evivve_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    fav_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    e_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    masterclass_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    mobile_logo {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    screen1 {
                      title
                      description
                      button_text
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    screen2 {
                      title
                      description
                      button_text
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    screen3 {
                      title
                      description
                      button_text
                      video {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      video_thumbnail {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    screen4_button_text
                  }
                  show_custom_navbar
                  custom_navbar {
                    links
                  }
                  agenda {
                    title
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    what_you_can_expect_title
                    what_you_can_expect_list {
                      list
                    }
                    time_and_date {
                      title
                      date
                      time
                      template2_date
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  content {
                    title
                    weeks_session_card {
                      title
                      list
                    }
                  }
                  hosts {
                    title
                    experts_list {
                      name
                      designation
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  count {
                    count_number
                    count_text
                  }
                  brands {
                    title1
                    title2
                    title_icon
                    brands1 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                    brands2 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                    brands3 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  testimonials {
                    title
                    cards {
                      name
                      description
                      bg_color
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  get_certified_now {
                    title
                    list
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  register {
                    title
                    register_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    zoho_form_type
                    register_form
                    form_onload
                    form_onsubmit
                  }
                  new_register {
                    form
                    form_onload
                    form_onsubmit
                    title
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    quote
                    company_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    name
                    designation
                    brands_title
                    brands {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  faq {
                    title
                    faq_list {
                      question
                      answer
                    }
                  }
                }
                ... on ComponentLandingPageTemplate3 {
                  aferr_model {
                    title
                    description
                    aferr_model_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  advantages {
                    title
                    advantages_list {
                      title
                      description
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  preview {
                    title
                    preview_list
                    preview_form
                    form_onload
                    form_onsubmit
                    button_text
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  dive_deep {
                    title
                    dive_deep_list {
                      title
                      description
                    }
                  }
                  why_download {
                    title
                    why_dowload_list {
                      title
                      description
                    }
                    description
                  }
                  brands {
                    title1
                    title2
                    title_icon
                    brands1 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                    brands2 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                    brands3 {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  faq {
                    title
                    faq_list {
                      question
                      answer
                    }
                  }
                }
                ... on ComponentLandingPageTemplate4 {
                  form {
                    form
                    form_onload
                    form_onsubmit
                  }
                  first_section {
                    title
                    description
                    first_section_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    button_type
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  why_choose {
                    title
                    description
                    first_section_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    button_type
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  agenda {
                    title
                    description
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    upcoming_programs_title
                    upcoming_programs {
                      month
                      dates
                      location
                      time
                      show_tagline
                      tagline
                      level
                      button_type
                      upcoming_program_button {
                        button_text
                        button_link
                        button_target
                        button_icon
                      }
                      overwrite_bgcolor
                      bgcolor
                      divider_color
                    }
                  }
                  hosts {
                    title
                    experts_list {
                      name
                      designation
                      image {
                        data {
                          id
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  count {
                    count_number
                    count_text
                  }
                  brands {
                    title
                    brands {
                      data {
                        id
                        attributes {
                          image {
                            data {
                              id
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  what_you_get {
                    title
                    what_you_get_list {
                      icon {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      title
                      description
                      button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    }
                  }
                  content {
                    title
                    weeks_session_card {
                      title
                      list
                    }
                      display
                  }
                  testimonials {
                    title
                    cards {
                      name
                      description
                      bg_color
                      image {
                        data {
                          id
                          attributes {
                            url
                          }
                        }
                      }
                    }
                      display
                  }
                  get_certified_now {
                    title
                    list
                    image {
                      data {
                        id
                        attributes {
                          url
                        }
                      }
                    }
                    get_certified_now_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    button_type
                    display
                  }
                  faq{
                    title
                    faq_list{
                      question
                      answer
                    }
                      
                    display
                  }
                    case_stalwart {
              title
              display
              case_study {
                category
                study_title
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                description
                read_more {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
            }
            core {
              title
              display
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              list {
                description
              }
              core_button {
                button_text
                button_link
                button_target
                button_icon
              }
            }
            consult_section {
              title
              display
               default_images{
                data {
                  attributes {
                    url
                  }
                }
              }
               active_images{
                data {
                  attributes {
                    url
                  }
                }
              }
              cards {
                card_title
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                description
                sub_title
                list {
                  data
                }
              }
            }
            
                }
                ... on ComponentLandingPageTemplate5 {
                  content {
                    title
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    description
                    form
                    form_onsubmit
                    form_onload
                    video
                    video_description
                  }
                  pay_offs_section {
                    title
                    list {
                      title
                      description
                    }
                  }
                  get_started {
                    title
                    case_study_get_started_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                }
                ... on ComponentLandingPageLiveSession {
                  form {
                    title
                    form
                    form_onload
                    form_onsubmit
                  }
                  Banner {
                    title
                    description
                    images {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    banner_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    highlighted_title
                  }
                  brands {
                    title
                    brands {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  experience {
                    title
                    experience_cards {
                      title
                      description
                      icon {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  join {
                    title
                    join_cards {
                      title
                      description
                      icon {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  stripe_image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  adventure {
                    title
                    description
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    adventure_cards {
                      title
                      description
                      icon {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  join_stripe {
                    title
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                  testimonial_section {
                    title
                    testimonials {
                      data {
                        attributes {
                          title
                          description
                          name
                          designation
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                          linkedin
                        }
                      }
                    }
                  }
                  faq {
                    title
                    faq_list {
                      question
                      answer
                    }
                  }
                }
                ... on ComponentLandingPageAdventure {
                  hero_section {
                    title
                    description
                    adventure_hero_section_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    mobile_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  brands {
                    title
                    brands {
                      data {
                        attributes {
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  experience {
                    title
                    experience_cards {
                      title
                      description
                      icon {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  certified {
                    title
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    cards {
                      title
                      description
                      icon {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                  pay_offs_section {
                    title
                    list {
                      title
                      description
                    }
                  }
                  stripe {
                    title
                    stripe_button {
                      button_text
                      button_link
                      button_target
                      button_icon
                    }
                  }
                  testimonial_section {
                    title
                    testimonials {
                      data {
                        attributes {
                          title
                          description
                          name
                          designation
                          image {
                            data {
                              attributes {
                                url
                              }
                            }
                          }
                          linkedin
                        }
                      }
                    }
                  }
                  faq {
                    title
                    faq_list {
                      question
                      answer
                    }
                  }
                  form {
                    form
                    form_onload
                    form_onsubmit
                  }
                }
              }
            }
          }
        }
      }
    `,
  });
};

export const fetchScienceLabPages = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getScienceLabsPages {
        scienceLabs(${
          preview ? "publicationState:PREVIEW," : ""
        } filters: { slug: { eq: "${slug}" } }) {
          data {
            attributes {
              title
              slug
              ${getSeoData}
              hero_section {
                sub_title
                title
                description
                labs_hero_section_button {
                    button_text
                    button_link
                    button_target
                    button_icon
                }
                button_type
                background_video {
                    data {
                    attributes {
                        url
                    }
                    }
                }
                }
                stats_section {
                sub_title
                title
                description
                }
                models_and_frameworks_section {
                title
                description
                list {
                    title
                    description
                    icon {
                    data {
                        attributes {
                        url
                        }
                    }
                    }
                    image {
                    data {
                        attributes {
                        url
                        }
                    }
                    }
                }
                }
                inside_labs_section {
                title
                description
                features {
                    title
                    description
                    icon {
                    data {
                        attributes {
                        url
                        }
                    }
                    }
                }
                }
                neuro_science {
                title
                description
                bg_design_image {
                    data {
                    attributes {
                        url
                    }
                    }
                }
                features {
                    title
                    description
                }
                }
                evidence_based_strategy {
                title
                description
                features {
                    icon {
                    data {
                        attributes {
                        url
                        }
                    }
                    }
                    title
                    pill
                    image {
                    data {
                        attributes {
                        url
                        }
                    }
                    }
                    description
                }
                }
                science_backed_approach {
                title
                description
                cards {
                    show_content_or_image
                    title
                    description
                    color
                    image {
                    data {
                        attributes {
                        url
                        }
                    }
                    }
                }
                }
                approach_section {
                title
                description
                cards {
                    background_video {
                    data {
                        attributes {
                        url
                        }
                    }
                    }
                    background_color
                    icon {
                    data {
                        attributes {
                        url
                        }
                    }
                    }
                    title
                    description
                    button_link
                }
                }
                faq {
                title
                faq_list {
                    question
                    answer
                }
                }
                cta {
                title
                description
                labs_CTA_button {
                    button_text
                    button_link
                    button_target
                    button_icon
                }
                button_type
                background_video {
                    data {
                    attributes {
                        url
                    }
                    }
                }
                }
                form {
                form
                form_onload
                form_onsubmit
                }
            }
          }
        }
      }
    `,
  });
};

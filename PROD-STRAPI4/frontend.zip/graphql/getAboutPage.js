import { getSeoData } from "./getSeoData";

export const getAboutPage = (preview) => {
  return `
        query getAboutPageData {
        about ${preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              banner {
                title
              }
              second_section {
                heading
                title
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                description
                description1
                points {
                  title
                  description
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                }
              }
              vision_and_mission{
                title
                vision_and_mission_list{
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  title
                  description
                }
              }
              about_description
              third_section {
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                isImageLeft
                title
                description
              }
              history_section {
                heading
                title
                points {
                  title
                  description
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  date
                  show_date
                }
              }
              member_section {
                heading
                title
                show_section
                description
                members {
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  name
                  role
                  facebook_link
                  instagram_link
                  twiter_link
                  linkedIn_link
                }
              }
              bottom_section {
                title
                description
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                bottom_button {
                  button_text
                  button_icon
                  button_link
                  button_target
                }
              }
              schema
              ${getSeoData}
            }
          }
        }
      }
    `;
};

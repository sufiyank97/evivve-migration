import React from "react";

export default function BottomSection({ data }) {
  return (
    <div className="bottom-section-wrap">
      <div className="container">
        <h3 className="bottom-section-title">{data?.title}</h3>
        <a
          href={data?.case_study_get_started_button?.button_link || ""}
          target={
            data?.case_study_get_started_button?.button_target === "blank"
              ? "_blank"
              : "_self"
          }
          className="bottom-section-btn"
        >
          {data?.case_study_get_started_button?.button_text}
        </a>
      </div>
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";
import React, { useState } from "react";

export default function Faq({ data }) {
  const [activeIndex, setActiveIndex] = useState(0);
  return (
    <div className="knowledge-base-page-faq-area">
      <h1 className="release-notes-page-title">{data?.title}</h1>
      {data?.faq?.length > 0 && (
        <div className="knowledge-base-page-faq-list-wrap">
          {data?.faq?.map((item, index) => {
            return (
              <div key={index}>
                <button
                  className={`knowledge-base-page-faq-question ${
                    activeIndex === index ? "active" : ""
                  }`}
                  onClick={() => setActiveIndex(index)}
                >
                  {item?.question}{" "}
                  <span>
                    <i class="bx bx-chevron-down"></i>
                  </span>
                </button>
                {activeIndex === index && (
                  <div className="knowledge-base-page-faq-answer">
                    <CKEditor content={item?.answer} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";
import Link from "next/link";
import React from "react";

export default function CtasCard({ data }) {
  return (
    <div className="ctas-cards container">
      {data?.card?.map((item, index) => {
        return (
          <div key={index}>
            <img src={item?.image?.data?.attributes?.url || ""} alt="image" />
            <h4 className="ctas-card-title">{item?.title}</h4>
            <div className="ctas-card-description">
              <CKEditor content={item?.description} />
            </div>
            {item?.link_title && (
              <Link href={item?.link_href || ""}>
                <a
                  target={item?.link_target === "blank" ? "_blank" : "_self"}
                  className="ctas-card-link"
                >
                  {item?.link_title}
                  <img src="/images/link-arrow-top-right.svg" alt="icon" />
                </a>
              </Link>
            )}
          </div>
        );
      })}
    </div>
  );
}

"use client";
import React, { useEffect, useState } from "react";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function EvidenceBasedStrategy({ data }) {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth <= 1024);
    };
    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  const staticImage = data?.features?.[0]?.image?.data?.attributes?.url;

  return (
    <div style={{ position: "relative" }}>
      <section className="labs-evidence-based-strategy-container">
        <div className="labs-evidence-based-strategy-wrapper">
          {/* LEFT SIDE (text and features) */}
          <div className="labs-evidence-based-left-side">
            <div className="labs-evidence-based-heading-section">
              <h2>{data?.title}</h2>
              <CKEditor content={data?.description} />
            </div>

            {isMobile && staticImage && (
              <div className="labs-evidence-based-image-mobile-container">
                <img
                  src={replaceImageUrl(staticImage)}
                  alt="Evidence-based strategy"
                  className="labs-evidence-based-image-mobile"
                />
              </div>
            )}

            <div className="labs-evidence-based-features-section">
              {data?.features?.map((feature, index) => (
                <div key={index} className="labs-evidence-based-feature">
                  {feature?.icon?.data?.attributes?.url && (
                    <img
                      src={replaceImageUrl(
                        feature?.icon?.data?.attributes?.url
                      )}
                      alt={feature?.title}
                      className="labs-evidence-based-feature-icon"
                    />
                  )}
                  <div className="labs-evidence-based-feature-heading">
                    <h4>{feature?.title}</h4>
                    {feature?.pill && (
                      <span className="labs-evidence-based-feature-pill">
                        {feature?.pill}
                      </span>
                    )}
                  </div>
                  <CKEditor content={feature?.description} />
                </div>
              ))}
            </div>
          </div>

          {!isMobile && (
            <div
              className="labs-evidence-based-right-side"
              style={{ marginTop: "40px" }}
            >
              <div className="labs-evidence-based-image-container">
                {staticImage && (
                  <img
                    src={replaceImageUrl(staticImage)}
                    alt="Evidence-based strategy visual"
                    className="labs-evidence-based-static-image"
                  />
                )}
              </div>
            </div>
          )}
        </div>
      </section>
      <div className="labs-whisper-image"></div>
    </div>
  );
}

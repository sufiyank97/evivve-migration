import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function InsideLabs({ data }) {
  return (
    <div style={{ position: "relative", overflow: "hidden" }}>
      <div className="inside-labs-wrap-snow-1"></div>
      <div className="inside-labs-wrap-snow-2"></div>
      <section className="inside-labs-wrap">
        <div className="container">
          <div className="inside-labs-text-container">
            <h1>{data?.title}</h1>
            <CKEditor content={data?.description} />
          </div>
          <div className="inside-labs-features-container">
            {data?.features?.map((feature, index) => (
              <div key={index} className="inside-labs-features-card">
                <img
                  src={replaceImageUrl(feature?.icon?.data?.attributes?.url)}
                  alt={feature?.title}
                />
                <h3>{feature?.title}</h3>
                <CKEditor content={feature?.description} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

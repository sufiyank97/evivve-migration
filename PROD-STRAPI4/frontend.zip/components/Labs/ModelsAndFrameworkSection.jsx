import React, { useState, useEffect, useRef } from "react";
import { gsap } from "gsap";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function ModelsAndFrameworkSection({ data }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMobile, setIsMobile] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const imageContainerRef = useRef(null);
  const sectionRef = useRef(null);
  const tabsRef = useRef([]);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth <= 1024);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);

    return () => {
      window.removeEventListener("resize", checkScreenSize);
    };
  }, []);

  // Intersection Observer to trigger animations when 80% is visible
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  // Animate active card title and description fade in/out
  useEffect(() => {
    if (isMobile || !isInView || !tabsRef.current[activeIndex]) return;

    const activeTab = tabsRef.current[activeIndex];
    const title = activeTab.querySelector("h3");
    const description = activeTab.querySelector(".tab-description");

    if (!title || !description) return;

    const tl = gsap.timeline();

    // Set initial state to 0 for smooth start
    gsap.set([title, description], { opacity: 0, y: 10 });

    // Fade in with slide
    tl.to([title, description], {
      opacity: 1,
      y: 0,
      duration: 0.6,
      ease: "power2.out",
      stagger: 0.1,
    });
  }, [activeIndex, isMobile, isInView]);

  // Animate image with stacking effect - bottom to top
  useEffect(() => {
    if (isMobile || !isInView || !imageContainerRef.current) return;

    const images = imageContainerRef.current.querySelectorAll("img");
    const container = imageContainerRef.current;
    const containerHeight = container.offsetHeight;

    images.forEach((img, index) => {
      if (index === activeIndex) {
        // Set initial position at the very bottom (outside container)
        gsap.set(img, {
          y: containerHeight,
          opacity: 1,
          zIndex: 10,
        });

        // Animate new active image - slide up from very bottom
        gsap.to(img, {
          y: 0,
          duration: 1,
          ease: "power2.out",
        });
      } else if (index < activeIndex) {
        // Keep previous images visible in the back with lower z-index
        gsap.set(img, {
          opacity: 1,
          y: 0,
          zIndex: index,
        });
      } else {
        // Hide future images
        gsap.set(img, {
          opacity: 0,
          zIndex: 1,
        });
      }
    });
  }, [activeIndex, isMobile, isInView]);

  useEffect(() => {
    if (isMobile || !isInView) return; // Don't auto-rotate on mobile or if not in view

    const timer = setTimeout(() => {
      setActiveIndex((prevIndex) => (prevIndex + 1) % data?.list?.length);
    }, 10000);

    return () => clearTimeout(timer);
  }, [activeIndex, data?.list?.length, isMobile, isInView]);

  return (
    <section ref={sectionRef} className="labs-models-and-frameworks-container">
      <div className="labs-models-frameworks-wrapper">
        <div className="labs-models-frameworks-heading-content">
          <h2>{data?.title}</h2>
          <CKEditor content={data?.description} />
        </div>
        <div>
          <div className="labs-models-frameworks-left-side">
            <div className="labs-models-frameworks-tabs-container">
              {data?.list?.map((tab, index) => (
                <div
                  key={index}
                  ref={(el) => (tabsRef.current[index] = el)}
                  className={`labs-models-frameworks-tab-content ${
                    !isMobile && activeIndex === index ? "active" : ""
                  }`}
                  onClick={() => !isMobile && setActiveIndex(index)}
                >
                  {isMobile && tab?.image?.data?.attributes?.url && (
                    <div className="labs-models-frameworks-image-container">
                      <img
                        src={replaceImageUrl(tab?.image?.data?.attributes?.url)}
                        alt={tab.title}
                      />
                    </div>
                  )}
                  <div className="labs-models-frameworks-tab">
                    {tab?.icon?.data?.attributes?.url && (
                      <div className="labs-models-frameworks-tab-img">
                        <img
                          src={replaceImageUrl(
                            tab?.icon?.data?.attributes?.url
                          )}
                          alt={tab.title}
                          style={{
                            opacity:
                              isMobile || activeIndex === index ? 1 : 0.2,
                          }}
                        />
                      </div>
                    )}
                    <div className="labs-models-frameworks-tab-text-content">
                      <h3
                        style={{
                          color:
                            isMobile || activeIndex === index
                              ? "#261B07"
                              : "#8C8C8C",
                        }}
                      >
                        {tab.title}
                      </h3>
                      {(isMobile || activeIndex === index) && (
                        <div className="tab-description">
                          <CKEditor content={tab.description} />
                        </div>
                      )}
                    </div>
                  </div>
                  {isMobile && index !== data?.list?.length - 1 && (
                    <div className="labs-models-frameworks-static-border"></div>
                  )}
                  {!isMobile && (
                    <div className="labs-models-frameworks-progress-bar">
                      <div
                        className={`labs-models-frameworks-progress-fill ${
                          activeIndex === index ? "animating" : ""
                        }`}
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {!isMobile && (
            <div className="labs-models-frameworks-right-side">
              <div
                ref={imageContainerRef}
                className="labs-models-frameworks-image-container"
                style={{ position: "relative", overflow: "hidden" }}
              >
                {data?.list?.map(
                  (item, index) =>
                    item?.image?.data?.attributes?.url && (
                      <img
                        key={index}
                        src={replaceImageUrl(item.image.data.attributes.url)}
                        alt={item.title}
                        style={{
                          position: index === 0 ? "relative" : "absolute",
                          top: 0,
                          left: 0,
                          width: "513px",
                          height: "613px",
                          // objectFit: 'cover',
                          display: "block",
                          willChange: "transform, opacity",
                        }}
                      />
                    )
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

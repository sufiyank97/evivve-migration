import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function Neuroscience({ data }) {
  return (
    <section className="labs-neuroscience-wrapper">
      <div className="container">
        <div className="labs-neuroscience-container">
          <div
            className="labs-neuroscience-image"
            style={{
              backgroundImage: `url(${
                replaceImageUrl(data?.bg_design_image?.data?.attributes?.url) ||
                "/images/labs/neuroscience/neurosciene.png"
              })`,
            }}
          ></div>
          <div className="labs-neuroscience-heading">
            <h2>{data?.title}</h2>
            <CKEditor content={data?.description} />
          </div>
          <div className="labs-neuroscience-feature-container">
            {data?.features.map((feature, index) => (
              <div key={index} className="labs-neuroscience-feature-card">
                <h4>{index + 1}.</h4>
                <h3>{feature?.title}</h3>
                <CKEditor content={feature?.description} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

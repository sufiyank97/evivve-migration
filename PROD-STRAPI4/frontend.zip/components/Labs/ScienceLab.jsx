import React, { useEffect, useState } from "react";
import Seo from "../Common/seo";
import HeroSection from "./HeroSection";
import StatsSection from "./StatsSection";
import ModelsAndFrameworkSection from "./ModelsAndFrameworkSection";
import InsideLabs from "./InsideLabs";
import Neuroscience from "./Neuroscience";
import EvidenceBasedStrategy from "./EvidenceBasedStrategy";
import ScienceBackedApproachSection from "./ScienceBackedApproachSection";
import CardsSection from "./CardsSection";
import Faq from "../NewPricing/Faq";
import CTASection from "./CTASection";
import Form from "@/components/LandingPages/template3/Form";

export default function ScienceLab({ labData }) {
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    document.body.style.overflow = showModal ? "hidden" : "unset";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [showModal]);

  return (
    <>
      <Seo data={labData?.seo} />
      <main className="labs-content-wrap">
        <div style={{ backgroundColor: "#F0EBEF" }}>
          {labData?.hero_section && (
            <HeroSection
              data={labData?.hero_section}
              setShowModal={setShowModal}
            />
          )}
          {labData?.stats_section && (
            <StatsSection data={labData?.stats_section} />
          )}
          {labData?.models_and_frameworks_section && (
            <ModelsAndFrameworkSection
              data={labData?.models_and_frameworks_section}
            />
          )}
          {labData?.inside_labs_section && (
            <InsideLabs data={labData?.inside_labs_section} />
          )}
        </div>
        {labData?.neuro_science && (
          <Neuroscience data={labData?.neuro_science} />
        )}
        {labData?.evidence_based_strategy && (
          <EvidenceBasedStrategy data={labData?.evidence_based_strategy} />
        )}

        {labData?.science_backed_approach && (
          <ScienceBackedApproachSection
            data={labData?.science_backed_approach}
          />
        )}
        {labData?.approach_section && (
          <CardsSection data={labData?.approach_section} />
        )}
        {labData?.faq && (
          <Faq title={labData?.faq?.title} faq={labData?.faq?.faq_list} />
        )}
        {labData?.cta && (
          <CTASection data={labData?.cta} setShowModal={setShowModal} />
        )}
        {showModal && labData?.form && (
          <div className="template2-popup-form-overlay">
            <div className="template2-popup-form-wrap preview-modal-form">
              <Form
                data={{
                  form_onload: labData?.form?.form_onload,
                  form_onsubmit: labData?.form?.form_onsubmit,
                  preview_form: labData?.form?.form,
                }}
              />
              <button
                onClick={() => setShowModal(false)}
                className="template2-popup-close-btn"
              >
                <i class="bx bx-x"></i>
              </button>
            </div>
          </div>
        )}
      </main>
    </>
  );
}

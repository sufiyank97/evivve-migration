import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function StatsSection({ data }) {
  return (
    <section className="labs-stats-section-wrapper">
      <div className="container">
        <div className="labs-stats-section-wrap">
          <h5 className="labs-stats-section-eyebrow">{data?.sub_title}</h5>
          <div className="labs-stats-section-text-container">
            <div className="labs-stats-section-title">
              <CKEditor content={data?.title} />
            </div>
            <div>
              <CKEditor content={data?.description} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function CTASection({ data, setShowModal }) {
  return (
    <section className="labs-cta-section-wrap">
      <div className="container">
        <div className="cta-section-left"></div>
        <div className="cta-section-right"></div>
        <div className="labs-cta-section-wrapper">
          <h1 className="labs-cta-section-title">{data?.title}</h1>
          <div className="labs-cta-section-subtitle">
            <CKEditor content={data?.description} />
          </div>
          {data?.labs_CTA_button?.button_text &&
            (data?.button_type === "form" ? (
              <button
                className="labs-cta-section-btn"
                onClick={() => setShowModal(true)}
              >
                <p></p>
                {data?.labs_CTA_button?.button_text}
              </button>
            ) : (
              <a
                href={data?.labs_CTA_button?.button_link || ""}
                target={
                  data?.labs_CTA_button?.button_target === "blank"
                    ? "_blank"
                    : "_self"
                }
                className="labs-cta-section-btn"
              >
                <p></p>
                {data?.labs_CTA_button?.button_text}
              </a>
            ))}
        </div>
        {data?.background_video?.data?.attributes?.url && (
          <video
            src={replaceImageUrl(data?.background_video?.data?.attributes?.url)}
            autoPlay
            muted
            loop
            playsInline
            className="labs-cta-section-video"
          ></video>
        )}
      </div>
    </section>
  );
}

import CKEditor from "@/utils/CkEditor";
import React, { useEffect, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

export default function WhyDownload({ data }) {
  const textRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    // Function to wrap text nodes with spans
    const wrapTextInSpans = (node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const textContent = node.textContent.trim();
        if (textContent) {
          // Wrap each character in a span, but make sure no nested spans exist
          const wrappedContent = Array.from(textContent)
            .map((char) => `<span class="revealing-letter">${char}</span>`)
            .join("");

          const wrapper = document.createElement("span");
          wrapper.innerHTML = wrappedContent;

          node.replaceWith(wrapper);
        }
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        // Recursively wrap text nodes but avoid wrapping the text inside <span> tags
        Array.from(node.childNodes).forEach(wrapTextInSpans);
      }
    };

    const handleScroll = () => {
      const container = containerRef.current;
      if (!container) return;

      const containerRect = container.getBoundingClientRect();
      const viewportHeight = window.innerHeight;

      // Check if the container is within the viewport
      if (containerRect.bottom < 0 || containerRect.top > viewportHeight) {
        return; // Exit if container is not in the viewport
      }

      const spans = textRef.current.querySelectorAll(".revealing-letter");
      const containerTop = containerRect.top;
      const containerHeight = containerRect.height;

      spans.forEach((span, index) => {
        // Calculate the letter's position relative to the container's top
        const letterTop =
          containerTop + containerHeight * (index / spans.length);
        const progress = Math.min(
          Math.max(0, (viewportHeight - letterTop) / viewportHeight),
          1
        );

        // Set opacity and transition based on progress
        span.style.opacity = progress > 0 ? 1 : 0.3;
        span.style.transition = `opacity 0.3s ease-out`;
      });
    };

    // Wrap all the text content inside the ref div in spans
    const textContainer = textRef.current;
    if (textContainer) {
      Array.from(textContainer.childNodes).forEach(wrapTextInSpans);
    }

    // Listen to the scroll event
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section className="why-download-wrap container">
      <h1 className="landing-page-template3-h1 why-download-title">
        {data?.title}
      </h1>
      <div className="why-download-list">
        <Swiper
          spaceBetween={50}
          direction={"vertical"}
          centeredSlides={true}
          slidesPerView={"auto"}
          slideToClickedSlide={true}
          className="mySwiper why-download-list-swiper"
        >
          {data?.why_dowload_list?.map((item, index) => {
            return (
              <SwiperSlide key={index}>
                <div className="why-download-list-item">
                  <p className="why-download-list-title">{item?.title}</p>
                  <div className="why-download-list-desc">
                    <CKEditor content={item?.description} />
                  </div>
                </div>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
      <div className="why-download-animated-description" ref={containerRef}>
        <div ref={textRef} className="animatedText">
          <CKEditor content={data?.description} />
        </div>
      </div>
    </section>
  );
}

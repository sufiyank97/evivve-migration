import React, { useEffect, useState } from "react";
import Brands from "../common/Brands";
import Faq from "../common/Faq";
import Seo from "../../Common/seo";
import AferrModel from "./AferrModel";
import Advantages from "./Advantages";
import Preview from "./Preview";
import DiveDeep from "./DiveDeep";
import WhyDownload from "./WhyDownload";
import Image from "next/image";
import Form from "./Form";

export default function Template3({ data }) {
  const [showModal, setShowModal] = useState(false);

  const previewData = data?.templates[0]?.preview;
  const previewImageUrl = previewData?.image?.data?.attributes?.url;

  useEffect(() => {
    document.body.style.overflow = showModal ? "hidden" : "unset";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [showModal]);

  return (
    <>
      <Seo data={data?.seo} />
      <main className={`landing-page-template3`}>
        <AferrModel
          data={data?.templates[0]?.aferr_model}
          setShowModal={setShowModal}
        />
        <Advantages data={data?.templates[0]?.advantages} />
        <Preview data={previewData} setShowModal={setShowModal} />
        <DiveDeep data={data?.templates[0]?.dive_deep} />
        <WhyDownload data={data?.templates[0]?.why_download} />
        {data?.templates[0]?.brands && (
          <Brands data={data?.templates[0]?.brands} />
        )}
        {data?.templates[0]?.faq && <Faq data={data?.templates[0]?.faq} />}
        {showModal && (
          <div className="preview-modal-overly">
            <div className="preview-modal-wrap">
              <div className="preview-modal-form">
                <Form data={previewData} />
              </div>
              {previewImageUrl && (
                <div className="preview-modal-img">
                  <Image
                    src={previewImageUrl}
                    alt="Image"
                    width={475}
                    height={615}
                  />
                </div>
              )}
              <button
                onClick={() => setShowModal(false)}
                className="close-preview-btn"
              >
                <i class="bx bx-x"></i>
              </button>
            </div>
          </div>
        )}
      </main>
    </>
  );
}

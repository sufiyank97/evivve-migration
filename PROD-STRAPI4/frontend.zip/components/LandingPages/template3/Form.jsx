import React, { useEffect } from "react";
import { Helmet } from "react-helmet";
import parse from "html-react-parser";
import { useRouter } from "next/router";

export default function Form({ data, template5, setChangeComponent }) {
  const router = useRouter();

  useEffect(() => {
    const handleOnLoad = () => {
      eval(data?.form_onload);
    };

    // Add event listener
    window.addEventListener("load", handleOnLoad);

    // Cleanup function to remove the event listener
    return () => {
      window.removeEventListener("load", handleOnLoad);
    };
  }, []);

  useEffect(() => {
    if (router.asPath === "/stalwart/") {
      // Function to handle form submission
      const handleButtonClick = (event) => {
        const button = event.target;
        if (
          button.name === "SIGNUP_SUBMIT_BUTTON" ||
          button.id === "zcWebOptin"
        ) {
          const form = button.closest("form") || document;
          const emailInput = form.querySelector(
            'input[name="CONTACT_EMAIL"][type="email"]'
          );
          const firstNameInput = form.querySelector(
            'input[name="FIRSTNAME"][type="text"]'
          );
          const lastNameInput = form.querySelector(
            'input[name="LASTNAME"][type="text"]'
          );

          if (emailInput?.value) {
            const formData = {
              email: emailInput.value || "",
              firstname: firstNameInput?.value || "",
              lastname: lastNameInput?.value || "",
            };

            localStorage.setItem(
              "submitted_user_data",
              JSON.stringify(formData)
            );

            // console.log("Stored Data:", formData);
          }
        }
      };

      // Add event listeners
      document.addEventListener("click", handleButtonClick, true);

      // Cleanup function
      return () => {
        document.removeEventListener("click", handleButtonClick, true);
      };
    }
  }, [router.asPath]);

  useEffect(() => {
    if (template5) {
      const overrideSaveOptin = () => {
        const originalSaveOptin = window.saveOptin;

        if (typeof originalSaveOptin === "function") {
          window.saveOptin = function (el, flag, callback, ...rest) {
            const customCallback = function () {
              setChangeComponent(true); // ✅ Your logic here
              if (typeof callback === "function") callback(); // Keep original callback
            };

            // Call the original saveOptin with the new callback
            return originalSaveOptin.call(
              this,
              el,
              flag,
              customCallback,
              ...rest
            );
          };
        }
      };

      // Retry logic in case script hasn't loaded yet
      const interval = setInterval(() => {
        if (window.saveOptin) {
          overrideSaveOptin();
          clearInterval(interval);
        }
      }, 100);

      // Cleanup
      return () => {
        clearInterval(interval);
      };
    }
  }, [template5, setChangeComponent]);

  return (
    <>
      <Helmet>
        <script
          type="text/javascript"
          src="https://fsut-zc1.maillist-manage.in/js/optin.min.js"
          onload={data?.form_onload}
        ></script>

        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{
            __html: `
				function runOnFormSubmit_${data?.form_onsubmit}(th) {}
			`,
          }}
        />
      </Helmet>
      <div className="">{parse(`${data?.preview_form}`)}</div>
    </>
  );
}

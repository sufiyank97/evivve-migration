import React, { useContext } from "react";
import Form from "../template3/Form";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";
import { AppContext } from "context/AppContextProvider";

export default function Content({ data, setChangeComponent }) {
  const { navbarHeight } = useContext(AppContext);
  return (
    <div className="landing-page-template5-content-wrap">
      <div>
        <div className="landing-page-template5-image-wrap">
          <Image
            src={replaceImageUrl(data?.image?.data?.attributes?.url)}
            alt="Image"
            layout="fill"
          />
        </div>
        <CKEditor
          content={data?.description}
          customStyle={"landing-page-template5-content-description"}
        />
      </div>
      <div
        className="landing-page-template5-form-sticky-wrap"
        style={{ top: `${navbarHeight + 20}px` }}
      >
        <div className="landing-page-template5-form-wrap">
          <div className="template5-form-wrap">
            <Form
              data={{
                form_onload: data?.form_onload,
                form_onsubmit: data?.form_onsubmit,
                preview_form: data?.form,
              }}
              template5
              setChangeComponent={setChangeComponent}
            />
          </div>
          <img
            src="/images/template5-form-bg-blob.svg"
            alt="bg-blob"
            className="template5-form-bg-blob"
          />
        </div>
      </div>
    </div>
  );
}

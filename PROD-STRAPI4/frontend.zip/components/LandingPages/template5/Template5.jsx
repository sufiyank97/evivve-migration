import Seo from "@/components/Common/seo";
import React, { useState } from "react";
import Content from "./Content";
import ReactPlayer from "react-player";
import PaysOffSection from "@/components/CaseStudy/PaysOffSection";
import BottomSection from "@/components/CaseStudy/BottomSection";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function Template5({ data }) {
  const contentData = data?.templates[0]?.content;
  const [changeComponent, setChangeComponent] = useState(false);
  return (
    <>
      <Seo data={data?.seo} />
      <main className={`landing-page-template5`}>
        <div className={`landing-page-template5-wrap`}>
          <div className="container">
            <h1>{contentData?.title}</h1>
            {changeComponent ? (
              <>
                <div className="template5-video-wrap">
                  <ReactPlayer
                    // playing
                    controls
                    url={replaceImageUrl(contentData?.video)}
                  />
                </div>
                <div className="template5-video-description">
                  <CKEditor content={contentData?.video_description} />
                </div>
              </>
            ) : (
              <Content
                data={contentData}
                setChangeComponent={setChangeComponent}
              />
            )}
          </div>
        </div>
        {changeComponent && (
          <>
            {data?.templates[0]?.pay_offs_section && (
              <PaysOffSection data={data?.templates[0]?.pay_offs_section} />
            )}
            {data?.templates[0]?.get_started && (
              <BottomSection data={data?.templates[0]?.get_started} />
            )}
          </>
        )}
      </main>
    </>
  );
}

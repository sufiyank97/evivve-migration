import React from "react";

export default function Stripe({ data, setShowModal }) {
  return (
    <div className="adventure-stripe-wrap">
      <div className="container">
        <h2>{data?.title}</h2>
        {data?.stripe_button?.button_text && (
          <button
            className="adventure-stripe-btn"
            onClick={() => setShowModal(true)}
          >
            {data?.stripe_button?.button_text}
          </button>
        )}
      </div>
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";
import { AppContext } from "context/AppContextProvider";
import Image from "next/image";
import React, { useContext } from "react";

export default function HeroSection({ data, setShowModal }) {
  const { navbarHeight, showStripe } = useContext(AppContext);
  return (
    <div
      className="adventure-hero-section"
      style={{
        "--marginTop": `${showStripe ? navbarHeight - 60 : navbarHeight}px`,
      }}
    >
      {data?.image?.data?.attributes?.url && (
        <img
          src={data?.image?.data?.attributes?.url}
          alt="bg-image"
          className="desktop-image"
        />
      )}
      {data?.mobile_image?.data?.attributes?.url && (
        <img
          src={data?.mobile_image?.data?.attributes?.url}
          alt="bg-image"
          className="mobile-image"
        />
      )}
      <div className="container">
        <div>
          <h1>{data?.title}</h1>
          <div className="adventure-hero-desc">
            <CKEditor content={data?.description} />
          </div>
          {data?.adventure_hero_section_button?.button_text && (
            <button
              className="top-sticky-stripe-button"
              onClick={() => setShowModal(true)}
            >
              {data?.adventure_hero_section_button?.button_text}
            </button>
          )}
        </div>
        <div></div>
      </div>
    </div>
  );
}

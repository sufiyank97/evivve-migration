import React from "react";
import Seo from "../../Common/seo";

export default function LiveSession({
  data,
  headerData,
  footerData,
  commonData,
  logo,
  top_sticky_stripe,
}) {
  return (
    <main className="live-session-page-wrap">
      <Seo data={data?.seo} />
      
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="live-session-content">
              <h1>Live Session Template</h1>
              <p>This is a placeholder for the Live Session template.</p>
              <p>Content: {data?.title || 'No title available'}</p>
              
              {data?.templates?.[0] && (
                <div className="template-data">
                  <h2>Template Data:</h2>
                  <pre>{JSON.stringify(data.templates[0], null, 2)}</pre>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

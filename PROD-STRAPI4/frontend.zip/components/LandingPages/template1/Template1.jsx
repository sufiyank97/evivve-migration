import React, { useEffect, useRef, useState } from "react";
import Join from "../common/Join";
import Count from "../common/Count";
import Brands from "../common/Brands";
import IndustryExperts from "../common/IndustryExperts";
import Faq from "../common/Faq";
import Certifications from "../common/Certifications";
import Register from "../common/Register";
import dynamic from "next/dynamic";
import Seo from "../../Common/seo";
import HeroScreens from "./HeroScreens";
import Hero from "../common/Hero";
import CustomNavbar from "../common/Navbar";
const Navbar = dynamic(() => import("@/components/Layout/Navigations/Navbar1"));
const FooterTwo = dynamic(() => import("@/components/Layout/Footer/FooterTwo"));

export default function Template1({
  data,
  top_sticky_stripe,
  logo,
  headerData,
  footerData,
  commonData,
  host,
}) {
  const [screen, setScreen] = useState(1);
  const [reverseScreen, setReverseScreen] = useState(null);
  const [animationsComplete, setAnimationsComplete] = useState(false);
  const [showNavbar, setShowNavbar] = useState(false);
  const [wheelEventCount, setWheelEventCount] = useState(0);
  const agendaSectionRef = useRef();
  const RegisterSectionRef = useRef();

  // active section state for custom navbar
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    // Create an Intersection Observer instance
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setAnimationsComplete(true); // Update state when the section comes into view
          }
        });
      },
      {
        root: null, // Use the viewport as the root
        threshold: 0.5, // Trigger when 50% of the section is visible
      }
    );

    // Observe the section
    if (agendaSectionRef.current) {
      observer.observe(agendaSectionRef.current);
    }

    // Cleanup the observer on unmount
    return () => {
      if (agendaSectionRef.current) {
        observer.unobserve(agendaSectionRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (animationsComplete) {
      // Show the navbar after a delay of 500ms when animations are complete
      const timeoutId = setTimeout(() => {
        setShowNavbar(true);
      }, 500);

      // Clean up the timeout when animationsComplete changes
      return () => clearTimeout(timeoutId);
    } else {
      // Hide the navbar immediately when animations are not complete
      setShowNavbar(false);
    }
  }, [animationsComplete]);

  const show_custom_navbar = data?.templates[0]?.show_custom_navbar;
  const show_initial_animation = data?.templates[0]?.show_intro_animation;

  return (
    <main
      className={`${showNavbar ? "" : "webinar-animations"} webinar-page-wrap`} //shownavbar representing animation complete but after little delay
    >
      <Seo data={data?.seo} />
      <Hero
        animationsComplete={animationsComplete}
        setAnimationsComplete={setAnimationsComplete}
        agendaSectionRef={agendaSectionRef}
        screen={screen}
        setScreen={setScreen}
        wheelEventCount={wheelEventCount}
        setWheelEventCount={setWheelEventCount}
        data={data?.templates[0]?.animations}
        RegisterSectionRef={RegisterSectionRef}
        reverseScreen={reverseScreen}
        setReverseScreen={setReverseScreen}
        show_custom_navbar={show_custom_navbar}
        setActiveSection={setActiveSection}
        show_initial_animation={show_initial_animation}
      >
        <HeroScreens />
      </Hero>
      <div
        style={{
          backgroundColor: "white",
          position: "relative",
          zIndex: "1",
        }}
        className="webinar-page-components-wrap"
      >
        {show_custom_navbar ? (
          <CustomNavbar
            fav_logo={
              data?.templates[0]?.animations?.fav_logo?.data?.attributes?.url
            }
            evivve_logo={
              data?.templates[0]?.animations?.evivve_logo?.data?.attributes?.url
            }
            masterclass_logo={
              data?.templates[0]?.animations?.masterclass_logo?.data?.attributes
                ?.url
            }
            mobile_logo={
              data?.templates[0]?.animations?.mobile_logo?.data?.attributes?.url
            }
            animationsComplete={animationsComplete}
            setAnimationsComplete={setAnimationsComplete}
            setReverseScreen={setReverseScreen}
            setScreen={setScreen}
            setWheelEventCount={setWheelEventCount}
            links={data?.templates[0]?.custom_navbar?.links}
            activeSection={activeSection}
            setActiveSection={setActiveSection}
            show_initial_animation={show_initial_animation}
          />
        ) : (
          showNavbar && (
            <Navbar
              header={headerData}
              logo={logo}
              top_sticky_stripe={top_sticky_stripe}
              host={host}
              hide //to hide stripe showing above nav
            />
          )
        )}
        {data?.templates[0]?.agenda && (
          <Join
            setAnimationsComplete={setAnimationsComplete}
            agendaSectionRef={agendaSectionRef}
            setScreen={setScreen}
            wheelEventCount={wheelEventCount}
            setWheelEventCount={setWheelEventCount}
            data={data?.templates[0]?.agenda}
            screen2Present={data?.templates[0]?.animations?.screen2}
            screen3Present={data?.templates[0]?.animations?.screen3}
            setReverseScreen={setReverseScreen}
            show_custom_navbar={show_custom_navbar}
            setActiveSection={setActiveSection}
          />
        )}
        {data?.templates[0]?.industry_experts && (
          <IndustryExperts data={data?.templates[0]?.industry_experts} />
        )}
        {data?.templates[0]?.count?.length > 0 && (
          <Count data={data?.templates[0]?.count} />
        )}
        {data?.templates[0]?.brands && (
          <Brands data={data?.templates[0]?.brands} />
        )}
        {data?.templates[0]?.certifications && (
          <Certifications data={data?.templates[0]?.certifications} />
        )}
        {data?.templates[0]?.register && (
          <Register
            RegisterSectionRef={RegisterSectionRef}
            data={data?.templates[0]?.register}
          />
        )}
        {data?.templates[0]?.faq && <Faq data={data?.templates[0]?.faq} />}
        <FooterTwo footerData={footerData} commonData={commonData} />
      </div>
    </main>
  );
}

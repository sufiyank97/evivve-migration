import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React, { useEffect } from "react";

export default function TransformSection({
  show_custom_navbar,
  // setAnimationsComplete,
  // setScreen,
  // setWheelEventCount,
  // screen2Present,
  // screen3Present,
  // setReverseScreen,
  // setActiveSection,
  brandsSectionRef,
  setShowModal,
  data,
}) {
  //   useEffect(() => {
  //     if (document.documentElement.clientWidth >= 1024) {
  //       const handleWheel = (e) => {
  //         const section = brandsSectionRef?.current;
  //         // Check if the section is at the top of the viewport and the user is scrolling up
  //         if (section) {
  //           const sectionTop = section.getBoundingClientRect().top;
  //           if (sectionTop >= 0 && e.deltaY < -25) {
  //             setAnimationsComplete(false);
  //             if (screen3Present) {
  //               setScreen(3);
  //               setWheelEventCount(2);
  //               setReverseScreen(3);
  //             } else if (screen2Present && !screen3Present) {
  //               setScreen(2);
  //               setWheelEventCount(1);
  //               setReverseScreen(2);
  //             } else if (!screen2Present && !screen3Present) {
  //               setScreen(1);
  //               setWheelEventCount(0);
  //               setReverseScreen(1);
  //             }
  //             setActiveSection("home"); //setting active section state to home in navbar
  //           }
  //         }
  //       };

  //       // Add the wheel event listener
  //       brandsSectionRef?.current?.addEventListener("wheel", handleWheel);

  //       // Cleanup the event listener on component unmount
  //       return () => {
  //         brandsSectionRef?.current?.removeEventListener("wheel", handleWheel);
  //       };
  //     }
  //   }, []);
  return (
    <div
      ref={brandsSectionRef}
      id="template4-brands"
      className={`transform-section-main-wrap ${
        show_custom_navbar
          ? "show_custom_navbar-transform-section-main-wrap"
          : ""
      }`}
    >
      <div className="transform-section-wrap">
        <div className="container">
          <div className="transform-section-content-wrap">
            <CKEditor
              content={data?.title}
              customStyle={"transform-section-title"}
            />
            <div className="transform-section-description">
              <CKEditor content={data?.description} />
            </div>
            {data?.first_section_button?.button_text &&
            data?.button_type === "popup" ? (
              <button
                className="btn1 transform-section-button"
                onClick={() => setShowModal(true)}
              >
                {data?.first_section_button?.button_text}
              </button>
            ) : (
              <a
                href={data?.first_section_button?.button_link || ""}
                target={
                  data?.first_section_button?.button_target === "blank"
                    ? "_blank"
                    : "_self"
                }
                className="btn1 transform-section-button"
              >
                {data?.first_section_button?.button_text}
              </a>
            )}
          </div>
          {data?.image?.data?.attributes?.url && (
            <div className="transform-section-img-wrap">
              <img
                src={replaceImageUrl(data?.image?.data?.attributes?.url)}
                alt="Image"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

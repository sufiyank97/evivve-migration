import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function WhyChoose({ setShowModal, data, brands }) {
  return (
    <div className={`why-choose-wrap container ${brands ? "" : "without-brands"}`}>
      {data?.image?.data?.attributes?.url && (
        <div className="why-choose-img-wrap">
          <img
            src={replaceImageUrl(data?.image?.data?.attributes?.url)}
            alt="Image"
          />
        </div>
      )}
      <div className="why-choose-content-wrap">
        <CKEditor content={data?.title} customStyle={"why-choose-title"} />
        <div className="why-choose-description">
          <CKEditor content={data?.description} />
        </div>
        {data?.first_section_button?.button_text &&
        data?.button_type === "popup" ? (
          <button
            className="btn1 why-choose-button"
            onClick={() => setShowModal(true)}
          >
            {data?.first_section_button?.button_text}
          </button>
        ) : (
          <a
            href={data?.first_section_button?.button_link || ""}
            target={
              data?.first_section_button?.button_target === "blank"
                ? "_blank"
                : "_self"
            }
            className="btn1 why-choose-button"
          >
            {data?.first_section_button?.button_text}
          </a>
        )}
      </div>
    </div>
  );
}

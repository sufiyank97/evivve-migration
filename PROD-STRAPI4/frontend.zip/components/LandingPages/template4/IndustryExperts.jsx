import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React from "react";

export default function IndustryExperts({ data }) {
  return (
    <section id="hosts">
      <div className="container ptb-70">
        <CKEditor
          content={data?.title}
          customStyle={"template4-industry-expert-title"}
        />
        {data?.experts_list?.length > 0 && (
          <div
            className={`experts-wrap ${
              data?.experts_list?.length === 4 ||
              data?.experts_list?.length === 2
                ? "show-experts-2-per-row"
                : data?.experts_list?.length === 1
                ? "show-experts-1-per-row"
                : ""
            }`}
          >
            {data?.experts_list?.map((item, index) => {
              return (
                <div key={index} className="industry-expert-main-wrapper">
                  {item?.image?.data?.attributes?.url && (
                    // <div className="expert-img">
                    <div className="template4-industry-expert-img-container">
                      <img
                        src={replaceImageUrl(
                          item?.image?.data?.attributes?.url
                        )}
                        alt="expert"
                      />
                    </div>
                  )}
                  <div className="industy-expert-text-wrapper">
                    <div className="industy-expert-main-title">
                      <h2 className="industy-expert-name">{item?.name}</h2>
                      <a
                        href={item?.linkedin_url}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <span className="industry-export-rel-icon"></span>
                      </a>
                    </div>
                    <p className="industry-expert-designation">
                      {item?.designation}
                    </p>
                    <p className="industry-expert-description">
                      {item?.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}

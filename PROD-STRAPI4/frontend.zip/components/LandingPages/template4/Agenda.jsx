import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { AppContext } from "context/AppContextProvider";
import Image from "next/image";
import React, { useContext, useEffect } from "react";
import { Navigation } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";

export default function Agenda({
  setAnimationsComplete,
  agendaSectionRef,
  setScreen,
  setWheelEventCount,
  data,
  screen2Present,
  screen3Present,
  setReverseScreen,
  show_custom_navbar,
  setActiveSection,
  setShowModal,
  template,
}) {
  const { showStripe } = useContext(AppContext);

  useEffect(() => {
    if (document.documentElement.clientWidth >= 1024 && template !== 4) {
      const handleWheel = (e) => {
        const section = agendaSectionRef?.current;
        // Check if the section is at the top of the viewport and the user is scrolling up
        if (section) {
          const sectionTop = section.getBoundingClientRect().top;
          if (sectionTop >= 0 && e.deltaY < -25) {
            setAnimationsComplete(false);
            if (screen3Present) {
              setScreen(3);
              setWheelEventCount(2);
              setReverseScreen(3);
            } else if (screen2Present && !screen3Present) {
              setScreen(2);
              setWheelEventCount(1);
              setReverseScreen(2);
            } else if (!screen2Present && !screen3Present) {
              setScreen(1);
              setWheelEventCount(0);
              setReverseScreen(1);
            }
            setActiveSection("home"); //setting active section state to home in navbar
          }
        }
      };

      // Add the wheel event listener
      agendaSectionRef?.current?.addEventListener("wheel", handleWheel);

      // Cleanup the event listener on component unmount
      return () => {
        agendaSectionRef?.current?.removeEventListener("wheel", handleWheel);
      };
    }
  }, []);

  return (
    <section
      ref={agendaSectionRef}
      id="time-date"
      className={`container ${
        showStripe ? "join-main-wrap-topstripe" : "join-main-wrap"
      } ${show_custom_navbar ? "show_custom_navbar-join-main-wrap" : ""}`}
    >
      <div className="template4-agenda-wrap">
        <div className="template4-agenda-content-wrap">
          <h1 className="template4-h1">{data?.title}</h1>
          <div className="template4-agenda-description-wrap">
            <CKEditor content={data?.description} />
          </div>
        </div>
        {data?.image?.data?.attributes?.url && (
          <div className="template4-agenda-img-wrap">
            <Image
              src={replaceImageUrl(data?.image?.data?.attributes?.url)}
              alt="Image"
              width={475}
              height={424}
            />
          </div>
        )}
      </div>
      {/* <div className="upcoming-programs-wrap">
        <div>
          <h1 className="template4-h1">{data?.upcoming_programs_title}</h1>
          <div className="template-4btn-desktop">
              {data?.upcoming_programs_button?.button_text &&
              data?.button_type === "popup" ? (
                <button
                  className="template4-btn1"
                  onClick={() => setShowModal(true)}
                >
                  {data?.upcoming_programs_button?.button_text}
                </button>
              ) : (
                <a
                  href={data?.upcoming_programs_button?.button_link || ""}
                  target={
                    data?.upcoming_programs_button?.button_target === "blank"
                      ? "_blank"
                      : "_self"
                  }
                  className="template4-btn1"
                >
                  {data?.upcoming_programs_button?.button_text}
                </a>
              )}
          </div>
        </div>
        <div className="upcoming-programs-list-wrap">
          {data?.upcoming_programs?.map((item, index) => {
            return (
              <div key={index} className="upcoming-programs-list-item">
                <div>
                  <p className="upcoming-programs-month">{item?.month}</p>
                  <p className="upcoming-programs-dates">{item?.dates}</p>
                </div>
                <div className="border"></div>
                <div className="upcoming-programs-time-and-location-wrap">
                  <div>
                    <img src="/images/location-icon.svg" alt="icon" />
                    <p>{item?.location}</p>
                  </div>
                  <div>
                    <img src="/images/time-icon.svg" alt="icon" />
                    <p>{item?.time}</p>
                  </div>
                </div>
                {item?.show_tagline && (
                  <div className="tag-line">{item?.tagline}</div>
                )}
              </div>
            );
          })}
        </div>
        <div className="template-4btn-mobile">
          {data?.upcoming_programs_button?.button_text &&
            data?.button_type === "popup" ? (
              <button
                className="template4-btn1"
                onClick={() => setShowModal(true)}
              >
                {data?.upcoming_programs_button?.button_text}
              </button>
            ) : (
              <a
                href={data?.upcoming_programs_button?.button_link || ""}
                target={
                  data?.upcoming_programs_button?.button_target === "blank"
                    ? "_blank"
                    : "_self"
                }
                className="template4-btn1"
              >
                {data?.upcoming_programs_button?.button_text}
              </a>
            )}
        </div>
      </div> */}
      <div className="upcoming-programs-wrap">
        <h1 className="template4-h1">{data?.upcoming_programs_title}</h1>
        {data?.upcoming_programs?.length > 0 && (
          <div className="upcoming-programs-swiper-wrap">
            <Swiper
              breakpoints={{
                640: { spaceBetween: 40 },
              }}
              slidesPerView={"auto"}
              spaceBetween={25}
              navigation={true}
              modules={[Navigation]}
              className="mySwiper upcoming-programs-swiper"
            >
              {data?.upcoming_programs?.map((item, index) => {
                return (
                  <SwiperSlide key={index}>
                    <div
                      className={`upcoming-programs-list-item`}
                      style={{
                        backgroundColor:
                          item?.overwrite_bgcolor && item?.bgcolor
                            ? item?.bgcolor
                            : "",
                      }}
                    >
                      <div>
                        <p className="upcoming-programs-month">{item?.month}</p>
                        <p className="upcoming-programs-lvl">{item?.level}</p>
                      </div>
                      <div
                        className="border"
                        style={{
                          backgroundColor:
                            item?.overwrite_bgcolor && item?.divider_color
                              ? item?.divider_color
                              : "",
                        }}
                      ></div>
                      <div className="upcoming-programs-details">
                        <div>
                          <img src="/images/date-icon.svg" alt="icon" />
                          <p>{item?.dates}</p>
                        </div>
                        <div>
                          <img src="/images/location-icon.svg" alt="icon" />
                          <p>{item?.location}</p>
                        </div>
                        <div>
                          <img src="/images/time-icon.svg" alt="icon" />
                          <p>{item?.time}</p>
                        </div>
                      </div>
                      {item?.upcoming_program_button?.button_text &&
                      item?.button_type === "popup" ? (
                        <button
                          className="btn1 upcoming-programs-button"
                          onClick={() => setShowModal(true)}
                        >
                          {item?.upcoming_program_button?.button_text}
                        </button>
                      ) : (
                        <a
                          href={
                            `${item?.upcoming_program_button?.button_link}` ||
                            ""
                          }
                          target={
                            item?.upcoming_program_button?.button_target ===
                            "blank"
                              ? "_blank"
                              : "_self"
                          }
                          className="btn1 upcoming-programs-button"
                        >
                          {item?.upcoming_program_button?.button_text}
                        </a>
                      )}
                      {item?.show_tagline && (
                        <div className="tag-line">{item?.tagline}</div>
                      )}
                    </div>
                  </SwiperSlide>
                );
              })}
            </Swiper>
          </div>
        )}
      </div>
    </section>
  );
}

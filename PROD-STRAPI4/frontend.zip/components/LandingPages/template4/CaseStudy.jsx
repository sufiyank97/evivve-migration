import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React, { useState, useRef, useEffect } from "react";

export default function CaseStudySection({ data }) {
  

  const [activeIndex, setActiveIndex] = useState(0);
  const [animatedIndices, setAnimatedIndices] = useState([0]);
  const scrollerRef = useRef(null);
  const contentWrapRef = useRef(null);
  const [isSmallScreen, setIsSmallScreen] = useState(false);

  const updateTransform = () => {
    if (scrollerRef.current) {
      const isTabletOrSmaller = window.matchMedia(
        "(max-width: 1024px)"
      ).matches;
      scrollerRef.current.style.flexDirection = isTabletOrSmaller
        ? "row"
        : "column";

      if (isTabletOrSmaller) {
        const containerWidth =
          scrollerRef.current.parentElement?.offsetWidth || 0;
        const cardWidth = containerWidth;
        scrollerRef.current.style.transform = `translateX(-${
          activeIndex * cardWidth
        }px)`;
      } else {
        const cardHeight = scrollerRef.current.children[0]?.offsetHeight || 0;
        scrollerRef.current.style.transform = `translateY(-${
          activeIndex * cardHeight
        }px)`;
      }
    }
  };

  useEffect(() => {
    const timeoutId =
      activeIndex === 0 ? setTimeout(updateTransform, 100) : null;
    if (activeIndex !== 0) updateTransform();

    const handleResize = () => {
      const isTabletOrSmaller = window.matchMedia(
        "(max-width: 1024px)"
      ).matches;
      setIsSmallScreen(isTabletOrSmaller);
      updateTransform();
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
      window.removeEventListener("resize", handleResize);
    };
  }, [activeIndex]);

  useEffect(() => {
    if (!isSmallScreen || !contentWrapRef.current) return;

    const contentWrap = contentWrapRef.current;
    let startX = 0;
    let startY = 0;
    let isDragging = false;

    const handleTouchStart = (e) => {
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      isDragging = true;
    };

    const handleTouchMove = (e) => {
      if (!isDragging) return;
      e.preventDefault();
    };

    const handleTouchEnd = (e) => {
      if (!isDragging) return;
      isDragging = false;

      const endX = e.changedTouches[0].clientX;
      const endY = e.changedTouches[0].clientY;
      const deltaX = endX - startX;
      const deltaY = endY - startY;

      if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 50) {
        if (deltaX > 0 && activeIndex > 0) {
          handleTabClick(activeIndex - 1);
        } else if (deltaX < 0 && activeIndex < data?.case_study?.length - 1) {
          handleTabClick(activeIndex + 1);
        }
      }
    };

    const handleWheel = (e) => {
      if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
        e.preventDefault();
        if (e.deltaX > 0 && activeIndex < data?.case_study?.length - 1) {
          handleTabClick(activeIndex + 1);
        } else if (e.deltaX < 0 && activeIndex > 0) {
          handleTabClick(activeIndex - 1);
        }
      }
    };

    contentWrap.addEventListener("touchstart", handleTouchStart, {
      passive: false,
    });
    contentWrap.addEventListener("touchmove", handleTouchMove, {
      passive: false,
    });
    contentWrap.addEventListener("touchend", handleTouchEnd, {
      passive: false,
    });
    contentWrap.addEventListener("wheel", handleWheel, { passive: false });

    return () => {
      contentWrap.removeEventListener("touchstart", handleTouchStart);
      contentWrap.removeEventListener("touchmove", handleTouchMove);
      contentWrap.removeEventListener("touchend", handleTouchEnd);
      contentWrap.removeEventListener("wheel", handleWheel);
    };
  }, [isSmallScreen, activeIndex, data?.case_study?.length]);

  const handleTabClick = (targetIndex) => {
    if (targetIndex === activeIndex) return;

    const animateTabs = async () => {
      const step = targetIndex > activeIndex ? 1 : -1;
      const indices = [];
      for (let i = activeIndex; i !== targetIndex; i += step) {
        indices.push(i);
      }
      indices.push(targetIndex);

      for (let k = 0; k < indices.length; k++) {
        const idx = indices[k];
        setAnimatedIndices([idx]);
        setActiveIndex(idx);
        if (k < indices.length - 1) {
          await new Promise((resolve) => setTimeout(resolve, 200));
        }
      }
    };
    animateTabs();
  };

  return (
    <section>
      <div className="template4-case-study-wrap">
        {data?.title && (
          <h1 className="template4-case-study-h1">{data?.title}</h1>
        )}
        <div className="container">
          <div className="template4-tabs-container">
            {data?.case_study && (
              <nav className="tempate4-tab-links">
                {data?.case_study?.map((item, index) => (
                  <div
                    key={index}
                    className={`tempate4-tab-link ${
                      animatedIndices.includes(index) ? "selected" : ""
                    }`}
                    onClick={() => handleTabClick(index)}
                  >
                    <h4>{item?.category}</h4>
                  </div>
                ))}
              </nav>
            )}

            <div className="template4-tab-content-wrap" ref={contentWrapRef}>
              <div
                className="tabs-scroller"
                ref={scrollerRef}
                style={{
                  display: "flex",
                  transition: "transform 0.3s ease-in-out",
                  overflow: "hidden",
                }}
              >
                {data?.case_study?.map((item, index) => (
                  <article key={index} className="template4-tab-content">
                    <img
                      src={replaceImageUrl(item?.image?.data?.attributes?.url)}
                      alt={item?.title}
                      loading="lazy"
                    />
                    <div className="template4-tab-text">
                      <h4>{item?.study_title}</h4>
                      <div>
                        <CKEditor content={item?.description} />
                        <a
                          href={item?.read_more?.button_link}
                          className="template4-case-study-button"
                          target={item?.read_more?.button_link}
                        >
                          {item?.read_more?.button_text}
                        </a>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function WhatYouGet({ data }) {
  return (
    <div className="container what-you-get-wrap">
      <h1 className="template4-h1">{data?.title}</h1>
      <div className="what-you-get-list">
        {data?.what_you_get_list?.map((item, index) => {
          return (
            <div key={index}>
              <img
                src={replaceImageUrl(item?.icon?.data?.attributes?.url)}
                alt="icon"
                className="what-you-get-list-item-icon"
              />
              <h3>{item?.title}</h3>
              <div className="what-you-get-list-item-description">
                <CKEditor content={item?.description} />
              </div>
              {item?.button && (
                <a
                  href={item?.button?.button_link}
                  className="what-you-get-list-item-button"
                  target={item?.button?.button_link}
                >
                  {item?.button?.button_text}
                </a>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

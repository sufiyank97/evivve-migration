import React from "react";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";

export default function DetailsSection({ data }) {
  const imageUrl = data?.image?.data?.attributes?.url
    ? replaceImageUrl(data.image.data.attributes.url)
    : null;
  return (
    <section className="aferr-details-section2">
      <div className="container">
        <div className="row align-items-center">
          {/* Image - First on mobile, Right on desktop */}
          <div className="col-lg-6 col-md-12 order-1 order-lg-2">
            <div className="details-image-wrapper">
              {imageUrl ? (
                <img
                  src={imageUrl}
                  alt={
                    data?.image?.data?.attributes?.alternativeText ||
                    "Details Image"
                  }
                  // width={600}
                  // height={550}
                  className="details-image"
                />
              ) : (
                <div className="details-image-placeholder">
                  <div className="placeholder-content">
                    <span>700 × 500</span>
                    <small>Desktop Image</small>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Text Content - Second on mobile, Left on desktop */}
          <div className="col-lg-6 col-md-12 order-2 order-lg-1">
            <div className="details-text-content">
              <h2 className="details-title font-inter-semibold">
                {data?.title || "Lorem Ipsum Is Simply"}
              </h2>
              <div
                className="details-description font-inter-light"
                style={{ fontSize: "15.37px" }}
              >
                {data?.description ? (
                  <CKEditor content={data.description} />
                ) : (
                  <p>
                    Many desktop publishing packages and web page editors now
                    use Lorem Ipsum as their default model text, and a search
                    for 'lorem ipsum' will uncover many web sites still in their
                    infancy.
                  </p>
                )}
              </div>
              {data?.button && (
                <div className="details-button">
                  <a
                    href={data.button.link || "#"}
                    className="btn-style-one blue-dark-color"
                    target={data.button.target === "blank" ? "_blank" : "_self"}
                  >
                    {data.button.text || "Learn More"}
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

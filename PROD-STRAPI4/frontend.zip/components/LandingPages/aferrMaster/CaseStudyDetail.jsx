import React, { useEffect, useState } from "react";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";
import { formatReferencesWithClickHere } from "@/utils/formatReferences";
import Zoho from "@/components/Blog/BlogDetails/Zoho";
import Form from "@/components/LandingPages/template3/Form";
import AppDownload from "@/components/Courses/AppDownload";
import CtasCard from "@/components/knowledgebase/CtasCard";

export default function CaseStudyDetail({ data }) {
  const [showModal, setShowModal] = useState(false);

  // Handle modal overflow
  useEffect(() => {
    document.body.style.overflow = showModal ? "hidden" : "unset";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [showModal]);
  // Helper function to get section spacing
  const getSectionSpacing = (section) => ({
    paddingTop: section?.spacing?.top || '30px',
    paddingBottom: section?.spacing?.bottom || '30px',
    background: section?.background || 'white',

  });

  // Share functionality
  useEffect(() => {
    const handleShareClick = (e) => {
      e.preventDefault();
      const platform = e.currentTarget.getAttribute('data-platform');
      const url = window.location.href;
      const title = data?.hero_section?.title || data?.title || "Case Study";

      let shareUrl = '';

      switch (platform) {
        case 'linkedin':
          shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
          break;
        case 'twitter':
          shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`;
          break;
        case 'whatsapp':
          shareUrl = `https://wa.me/?text=${encodeURIComponent(title + ' ' + url)}`;
          break;
        case 'telegram':
          shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`;
          break;
        case 'copy':
          navigator.clipboard.writeText(url).then(() => {
            const copyBtn = e.currentTarget;
            const originalTitle = copyBtn.getAttribute('title');
            copyBtn.setAttribute('title', 'Copied!');
            setTimeout(() => {
              copyBtn.setAttribute('title', originalTitle);
            }, 2000);
          });
          return;
        default:
          return;
      }

      if (shareUrl) {
        window.open(shareUrl, '_blank');
      }
    };

    // Hide share menu when clicking outside
    const handleClickOutside = (e) => {
      const container = document.querySelector('.share-container');

      if (container && !container.contains(e.target)) {
        container.classList.remove('expanded');
      }
    };

    // Hide share menu when scrolling
    const handleScroll = () => {
      const container = document.querySelector('.share-container');
      if (container) {
        container.classList.remove('expanded');
      }
    };

    // Add event listeners
    const shareIcons = document.querySelectorAll('.share-icon-item');

    shareIcons.forEach(icon => {
      icon.addEventListener('click', handleShareClick);
    });

    document.addEventListener('click', handleClickOutside);
    window.addEventListener('scroll', handleScroll);

    return () => {
      shareIcons.forEach(icon => {
        icon.removeEventListener('click', handleShareClick);
      });

      document.removeEventListener('click', handleClickOutside);
      window.removeEventListener('scroll', handleScroll);
    };
  }, [data]);

  return (
    <main className="case-study-detail-page">
      {/* Hero Banner Section */}
      {data?.hero_section?.enabled !== false && (
        <section
          className="case-study-hero-section"
          style={getSectionSpacing(data?.hero_section)}
        >
          <div
            className="case-study-hero-background"
            style={{
              backgroundImage: data?.hero_section?.background_image?.data?.attributes?.url
                ? `url(${replaceImageUrl(data.hero_section.background_image.data.attributes.url)})`
                : 'none',
              backgroundColor: data?.hero_section?.background_color || 'transparent',
              backgroundSize: 'cover',
              backgroundPosition: 'center center',
              backgroundRepeat: 'no-repeat'
            }}
          />
          <div
            className="case-study-hero-gradient-overlay"
            style={{
              background: data?.hero_section?.gradient_overlay || 'transparent'
            }}
          />

          <div className="case-study-hero-content">
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-lg-10 col-md-10 col-12 text-center">
                  <div className="case-study-hero-text">
                    {data?.hero_section?.category && (
                      <div className="success-story-tag">
                        <span>{data.hero_section.category}</span>
                      </div>
                    )}
                    <h1 className="case-study-hero-title font-inter-medium">
                      {data?.hero_section?.title || data?.title || "Lorem Ipsum is simply dummy text of the printing and typesetting industry."}
                    </h1>
                    {data?.hero_section?.description && (
                      <p className="case-study-hero-description">
                        {data.hero_section.description}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Share Button */}
            <div className="hero-share-button">
              <div className="share-container" id="shareContainer">
                <button className="share-toggle-btn" onClick={(e) => {
                  e.preventDefault();
                  const container = document.getElementById('shareContainer');
                  container.classList.toggle('expanded');
                }}>
                  <i className="bx bx-share-alt"></i>
                </button>
                <div className="share-icons-wrapper">
                  <a href="#" className="share-icon-item" data-platform="linkedin" title="Share on LinkedIn">
                    <i className="bx bxl-linkedin"></i>
                  </a>
                  <a href="#" className="share-icon-item" data-platform="twitter" title="Share on Twitter">
                    <i className="bx bxl-twitter"></i>
                  </a>
                  <a href="#" className="share-icon-item" data-platform="instagram" title="Share on Instagram">
                    <i className="bx bxl-instagram"></i>
                  </a>
                  <a href="#" className="share-icon-item" data-platform="whatsapp" title="Share on WhatsApp">
                    <i className="bx bxl-whatsapp"></i>
                  </a>
                  <a href="#" className="share-icon-item" data-platform="telegram" title="Share on Telegram">
                    <i className="bx bxl-telegram"></i>
                  </a>
                  <a href="#" className="share-icon-item" data-platform="copy" title="Copy Link">
                    <i className="bx bx-link"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Company Overview Section */}
      {data?.company_overview_section?.enabled !== false && (
        <section
          className="company-overview-section"
        >
          <div className="container">
            <div className="row">
              <div className="col-12">
                <h2 className="company-overview-title font-inter-semibold">
                  {data?.company_overview_section?.title || "COMPANY OVERVIEW"}
                </h2>

                <div
                  className="company-details-grid"
                >
                  {data?.company_overview_section?.company_card_enabled !== false && (
                    <div className="company-detail-item" >
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start' }}>

                        <div className="company-detail-icon">
                          {data?.company_overview_section?.company_card_icon?.data?.attributes?.url ? (
                            <Image
                              src={replaceImageUrl(data.company_overview_section.company_card_icon.data.attributes.url)}
                              alt="Company"
                              width={24}
                              height={24}
                              style={{ objectFit: 'contain' }}
                            />
                          ) : (
                            <i className="bx bx-building"></i>
                          )}
                        </div>
                        <div className="company-detail-content font-inter-semibold" style={{ paddingTop: '0.5rem' }}>
                          <h4>{data?.company_overview_section?.company_card_label || "Company"}</h4>
                        </div>
                      </div>
                      <div className="company-detail-content font-inter-regular" style={{ paddingLeft: '8px', width: '300px' }} >
                        <p>{data?.company_overview_section?.company_name || "Company Name"}</p>
                      </div>

                    </div>
                  )}

                  {data?.company_overview_section?.industry_card_enabled !== false && (
                    <div className="company-detail-item">
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start' }}>
                        <div className="company-detail-icon">
                          {data?.company_overview_section?.industry_card_icon?.data?.attributes?.url ? (
                            <Image
                              src={replaceImageUrl(data.company_overview_section.industry_card_icon.data.attributes.url)}
                              alt="Industry"
                              width={24}
                              height={24}
                              style={{ objectFit: 'contain' }}
                            />
                          ) : (
                            <i className="bx bx-cog"></i>
                          )}
                        </div>
                        <div className="company-detail-content font-inter-semibold" style={{ paddingTop: '0.5rem' }}>
                          <h4>{data?.company_overview_section?.industry_card_label || "Industry"}</h4>
                        </div>
                      </div>
                      <div className="company-detail-content font-inter-regular" style={{ paddingLeft: '8px', width: '400px' }}>
                        <p>{data?.company_overview_section?.industry || "Industry Name"}</p>
                      </div>
                    </div>
                  )}

                  {data?.company_overview_section?.location_card_enabled !== false && (
                    <div className="company-detail-item">
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start' }}>
                        <div className="company-detail-icon">
                          {data?.company_overview_section?.location_card_icon?.data?.attributes?.url ? (
                            <Image
                              src={replaceImageUrl(data.company_overview_section.location_card_icon.data.attributes.url)}
                              alt="Location"
                              width={24}
                              height={24}
                              style={{ objectFit: 'contain' }}
                            />
                          ) : (
                            <i className="bx bx-map"></i>
                          )}
                        </div>
                        <div className="company-detail-content font-inter-semibold" style={{ paddingTop: '0.5rem' }}>
                          <h4>{data?.company_overview_section?.location_card_label || "Location"}</h4>
                        </div>
                      </div>
                      <div className="company-detail-content font-inter-regular" style={{ paddingLeft: '8px', width: '400px' }}>
                        <p>{data?.company_overview_section?.location || "Location, Country"}</p>
                      </div>
                    </div>
                  )}
                </div>


              </div>
            </div>

          </div>
        </section>
      )}

      {/* Company Overview Description Section */}
      {data?.company_overview_section?.description && (
        <section className="company-overview-desc-section">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-lg-12 col-12">
                <div className="company-overview-description">
                  <CKEditor content={data.company_overview_section.description} />
                </div>
              </div>
            </div>
          </div>
        </section>
      )}


      {/* Key Challenges Section */}
      {data?.key_challenges_section?.enabled !== false && data?.key_challenges_section?.content && (
        <section
          className="key-challenges-section"
          style={getSectionSpacing(data?.key_challenges_section)}
        >
          <div className="container">
            <h2 className="key-challenges-title">
              {data?.key_challenges_section?.title || "KEY CHALLENGES"}
            </h2>
            <div className="row align-items-start">
              <div className={data?.key_challenges_section?.image_square?.data ? "col-lg-7 col-12" : "col-12"}>
                <div className="key-challenges-content">
                  <CKEditor content={data.key_challenges_section.content} />
                </div>
              </div>
              {data?.key_challenges_section?.image_square?.data && (
                <div className="col-lg-5 col-12">
                  <div className="challenges-image-wrapper-square">
                    <Image
                      src={replaceImageUrl(data.key_challenges_section.image_square.data.attributes.url)}
                      alt={data.key_challenges_section.image_square.data.attributes.alternativeText || "Key Challenges"}
                      width={800}
                      height={800}
                      style={{ objectFit: 'cover', width: '100%', height: '100%' }}
                      className="challenges-image-square"
                    />
                  </div>
                </div>
              )}
            </div>
            {data?.key_challenges_section?.image_wide?.data && (
              <div className="col-12">
                <div className="challenges-image-wrapper-wide">
                  <Image
                    src={replaceImageUrl(data.key_challenges_section.image_wide.data.attributes.url)}
                    alt={data.key_challenges_section.image_wide.data.attributes.alternativeText || "Key Challenges"}
                    width={1400}
                    height={400}
                    style={{ objectFit: 'cover', width: '100%', height: '100%' }}
                    className="challenges-image-wide"
                  />
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Our Solutions Section */}
      {data?.solutions_section?.enabled !== false && (
        <section
          className="solutions-section"
          style={getSectionSpacing(data?.solutions_section)}
        >
          <div className="container">
            <div className="row">
              <div className="col-12">
                <h2 className="solutions-title">
                  {data?.solutions_section?.title || "OUR SOLUTIONS"}
                </h2>

                {/* Solutions Content */}
                {data?.solutions_section?.content && (
                  <div className="solutions-content">
                    <CKEditor content={data.solutions_section.content} />
                  </div>
                )}

                {/* Integrated Testimonial */}
                {data?.solutions_section?.testimonial?.enabled !== false && data?.solutions_section?.testimonial?.quote && (
                  <div className="solutions-testimonial">
                    <div className="solutions-quote-container">

                      <div className="solutions-quote-text font-abhaya-medium">
                        {data.solutions_section.testimonial.quote}
                      </div>
                      <div className="solutions-quote-attribution">
                        {data.solutions_section.testimonial.author_image?.data && (
                          <div className="author-image">
                            <Image
                              src={replaceImageUrl(data.solutions_section.testimonial.author_image.data.attributes.url)}
                              alt={data.solutions_section.testimonial.author_name || "Author"}
                              width={60}
                              height={60}
                              style={{ borderRadius: '50%', objectFit: 'cover' }}
                            />
                          </div>
                        )}
                        <div className="author-details">
                          {data.solutions_section.testimonial.author_name && (
                            <div className="author-name">{data.solutions_section.testimonial.author_name}</div>
                          )}
                          {data.solutions_section.testimonial.author_designation && (
                            <div className="author-designation">{data.solutions_section.testimonial.author_designation}</div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Additional Solutions Content with Image */}
                {data?.solutions_section?.additional_content && (
                  <div className="solutions-additional-section">
                    <div className="row align-items-center">
                      <div className="col-lg-8 col-12">
                        <div className="solutions-additional-content">
                          <CKEditor content={data.solutions_section.additional_content} />
                        </div>
                      </div>
                      {data?.solutions_section?.additional_image?.data && (
                        <div className="col-lg-4 col-12">
                          <div className="solutions-additional-image-wrapper">
                            <Image
                              src={replaceImageUrl(data.solutions_section.additional_image.data.attributes.url)}
                              alt={data.solutions_section.additional_image.data.attributes.alternativeText || "Solutions Additional"}
                              width={500}
                              height={300}
                              style={{ objectFit: 'cover', width: '100%', height: '100%' }}
                              className="solutions-additional-image"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Solutions Banner Section */}
      {data?.solutions_banner?.enabled !== false && (
        <section
          className="solutions-banner-section"
          style={getSectionSpacing(data?.solutions_banner)}
        >
          <div
            className="solutions-banner-background"
            style={{
              backgroundImage: data?.solutions_banner?.background_image?.data?.attributes?.url
                ? `url(${replaceImageUrl(data.solutions_banner.background_image.data.attributes.url)})`
                : "",
              backgroundSize: 'cover',
              backgroundPosition: 'center center',
              backgroundRepeat: 'no-repeat'
            }}
          />
          <div
            className="solutions-banner-overlay"
            style={{
              background: data?.solutions_banner?.gradient_overlay
            }}
          />

          <div className="solutions-banner-content">
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-lg-8 col-12 text-center">
                  {data?.solutions_banner?.title && (
                    <h2 className="solutions-banner-title">
                      {data.solutions_banner.title}
                    </h2>
                  )}
                  {data?.solutions_banner?.description && (
                    <p className="solutions-banner-description">
                      {data.solutions_banner.description}
                    </p>
                  )}
                  {data?.solutions_banner?.button && (
                    <>
                      {data?.solutions_banner?.button_type === "popup" || data?.solutions_banner?.button_type === "form" ? (
                        <button
                          onClick={() => setShowModal(true)}
                          className="solutions-banner-btn"
                        >
                          {data.solutions_banner.button.button_text || "Learn More"}
                        </button>
                      ) : (
                        <a
                          href={data.solutions_banner.button.button_link || "#"}
                          className="solutions-banner-btn"
                          target={data.solutions_banner.button.button_target === "blank" || data.solutions_banner.button.button_target === "_blank" ? "_blank" : "_self"}
                        >
                          {data.solutions_banner.button.button_text || "Learn More"}
                        </a>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Impact Section */}
      {data?.impact_section?.enabled !== false && (
        <section
          className="impact-section"
          style={getSectionSpacing(data?.impact_section)}
        >
          <div className="container">
            <div className="row align-items-start">
              <h2 className="impact-title">
                {data?.impact_section?.title || "THE IMPACT"}
              </h2>

              {/* Check if stats are available to determine layout */}
              {data?.impact_section?.stats && data.impact_section.stats.length > 0 ? (
                // Stats available: Show stats with detailed descriptions and main description at bottom
                <div className="impact-section-with-stats">
                  {data.impact_section.stats.map((stat, index) => (
                    <div key={index} className="impact-stat-row">
                      <div className="impact-stat-content-wrapper">
                        {stat.detailed_description && (
                          <div className="impact-stat-detailed-description font-inter-regular">
                            <CKEditor content={stat.detailed_description} />
                          </div>
                        )}
                        <div className={`impact-stat-card${index + 1}`}>
                          <div className="impact-stat-number font-inter-semibold">{stat.number}</div>
                          <div className="impact-stat-title font-inter-semibold">{stat.title}</div>
                          <div className="impact-stat-description font-inter-regular">{stat.description}</div>
                        </div>
                      </div>
                    </div>
                  ))}

                  <div className="impact-main-description">
                    <div className="impact-description">
                      <div className="impact-description-text">
                        <CKEditor content={data.impact_section.description} />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                // Single column layout: description takes full width
                <div className="col-12">
                  <div className="impact-description">
                    <div className="impact-description-text">
                      <CKEditor content={data.impact_section.description} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* CTA Header Section */}
      {data?.cta_header_section?.enabled !== false && (
        <section
          className="cta-header-section"
          style={getSectionSpacing(data?.cta_header_section)}
        >
          <div className="container">
            <div className="row">
              <div className="col-12">
                {data?.cta_header_section?.title && (
                  <h2 className="cta-header-title font-inter-semibold">
                    {data.cta_header_section.title}
                  </h2>
                )}
                {data?.cta_header_section?.description && (
                  <div className="cta-header-description font-inter-regular">
                    <CKEditor content={data.cta_header_section.description} />
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}


      {/* Testimonial Section */}
      {data?.testimonial_section?.enabled !== false && (
        <section
          className="testimonial-section"
          style={getSectionSpacing(data?.testimonial_section)}
        >
          <div className="container" >
            <div className="row">
              <div className="col-12">
                <div className="testimonial-content">
                  <div className="quote-mark">
                    <i className="bx bxs-quote-left-alt"></i>
                  </div>
                  {data?.testimonial_section?.quote && (
                    <div className="testimonial-quote font-abhaya-medium">
                      {data.testimonial_section.quote}
                    </div>
                  )}
                  <div className="testimonial-attribution">
                    {data?.testimonial_section?.author_image?.data && (
                      <div className="author-image">
                        <Image
                          src={replaceImageUrl(data.testimonial_section.author_image.data.attributes.url)}
                          alt={data.testimonial_section.author_name || "Author"}
                          width={60}
                          height={60}
                          style={{ borderRadius: '50%', objectFit: 'cover' }}
                        />
                      </div>
                    )}
                    <div className="author-details">
                      {data?.testimonial_section?.author_name && (
                        <div className="author-name font-inter-semibold">{data.testimonial_section.author_name}</div>
                      )}
                      {data?.testimonial_section?.author_designation && (
                        <div className="author-designation font-inter-regular">{data.testimonial_section.author_designation}</div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}



      {/* CTA Section */}
      {data?.cta_section?.data?.length > 0 && data.cta_section.data.map((cta, ctaIndex) => {
        console.log(cta,"CTA")
        if (!cta?.attributes || !cta.attributes.description_type || cta.attributes.description_type.length === 0) {
          return null;
        }

        return (
          <React.Fragment key={ctaIndex}>
            {cta.attributes.description_type.map((ctaItem, itemIndex) => {
              console.log(ctaItem,'cta item')
              // Skip empty CTA items
              if (!ctaItem || Object.keys(ctaItem).length === 0) {
                console.log('true')
                return null;
              }
              console.log("false")
              if (ctaItem.__typename === "ComponentButtonNewsletter") {
                return (
                  <Zoho
                    key={itemIndex}
                    embedCode={ctaItem.description}
                    form_onsubmit={ctaItem.form_onsubmit}
                    form_onload={ctaItem.form_onload}
                  />
                );
              }

              if (ctaItem.__typename === "ComponentCaseStudyCaseStudyCta" || ctaItem.__typename === "ComponentCaseStudyAferrCta") {
                return (
                  <section key={itemIndex} className="case-study-cta-section">
                    <div className="container">
                      <div className="row align-items-center">
                        <div className="col-lg-8 col-md-7">
                          <div className="cta-content-left">
                            {cta.attributes.title && (
                              <h3 className="cta-title-bordered">{cta.attributes.title}</h3>
                            )}
                            {ctaItem.description && (
                              <div
                                className="cta-description"
                                dangerouslySetInnerHTML={{ __html: ctaItem.description }}
                              />
                            )}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-5">
                          <div className="cta-button-wrapper">
                            <img src={"https://evivve-strapi-admin.s3.ap-south-1.amazonaws.com/spark_icon.svg"} className="cta-star cta-star-1"></img>
                            <img src={"https://evivve-strapi-admin.s3.ap-south-1.amazonaws.com/spark_icon.svg"} className="cta-star cta-star-2"></img>
                            <img src={"https://evivve-strapi-admin.s3.ap-south-1.amazonaws.com/spark_icon.svg"} className="cta-star cta-star-3"></img>
                            {ctaItem.button && (
                              <a
                                href={ctaItem.button.button_link || "#"}
                                className="cta-btn font-inter-regular"
                                target={ctaItem.button.button_target === "blank" || ctaItem.button.button_target === "_blank" ? "_blank" : "_self"}
                              >
                                {ctaItem.button.button_text || "Click Here"} →
                              </a>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                );
              }

              if (ctaItem.__typename === "ComponentButtonButtonText") {
                return (
                  <section key={itemIndex} className="case-study-cta-section">
                    <div className="container">
                      <div className="row align-items-center">
                        <div className="col-lg-8 col-md-7">
                          {cta.attributes.title && (
                            <h3 className="cta-title-bordered">{cta.attributes.title}</h3>
                          )}
                          {ctaItem.description && (
                            <div
                              className="cta-description"
                              dangerouslySetInnerHTML={{ __html: ctaItem.description }}
                            />
                          )}
                        </div>
                        <div className="col-lg-4 col-md-5">
                          {ctaItem.button_text_button && (
                            <a
                              href={ctaItem.button_text_button.button_link || "#"}
                              className="cta-btn font-inter-regular"
                              target={ctaItem.button_text_button.button_target === "blank" || ctaItem.button_text_button.button_target === "_blank" ? "_blank" : "_self"}
                            >
                              {ctaItem.button_text_button.button_text || "Click Here"} →
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  </section>
                );
              }

              if (ctaItem.__typename === "ComponentCommonButton") {
                return (
                  <div key={itemIndex} className="case-study-cta-inline-btn" style={{ width: "max-content", margin: "1rem auto" }}>
                    <a
                      href={ctaItem.button_link || "#"}
                      className="cta-btn font-inter-regular"
                      target={ctaItem.button_target === "blank" || ctaItem.button_target === "_blank" ? "_blank" : "_self"}
                    >
                      {ctaItem.button_text || "Click Here"} →
                    </a>
                  </div>
                );
              }

              if (ctaItem.__typename === "ComponentButtonButtonImageText") {
                return (
                  <section key={itemIndex} className="case-study-cta-section">
                    <div className="container">
                      <div className="row align-items-center">
                        <div className="col-lg-8 col-md-7">
                          {ctaItem.buttonImageTextTitle && (
                            <h3 className="cta-title-bordered">{ctaItem.buttonImageTextTitle}</h3>
                          )}
                          {ctaItem.description && (
                            <div
                              className="cta-description"
                              dangerouslySetInnerHTML={{ __html: ctaItem.description }}
                            />
                          )}
                        </div>
                        <div className="col-lg-4 col-md-5">
                          {ctaItem.button_image_text_button && (
                            <a
                              href={ctaItem.button_image_text_button.button_link || "#"}
                              className="cta-btn font-inter-regular"
                              target={ctaItem.button_image_text_button.button_target === "blank" || ctaItem.button_image_text_button.button_target === "_blank" ? "_blank" : "_self"}
                            >
                              {ctaItem.button_image_text_button.button_text || "Click Here"} →
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  </section>
                );
              }

              if (ctaItem.__typename === "ComponentCommonAppDownload") {
                return <AppDownload key={itemIndex} download_app_section={ctaItem} />;
              }

              if (ctaItem.__typename === "ComponentKnowledgeBase3CardsCtas") {
                return <CtasCard key={itemIndex} data={ctaItem} />;
              }

              // Skip unknown CTA types
              return null;
            })}
          </React.Fragment>
        );
      })}

      {/* References Section */}
      {data?.references_section?.enabled !== false && (
        <section
          className="references-section"
          style={getSectionSpacing(data?.references_section)}
        >
          <div className="container" style={{ display: "flex", justifyContent: "flex-start" }}>
            <div className="row">
              <div className="col-12" >
                <h2 className="references-title">
                  {data?.references_section?.title || "References"}
                </h2>
                {data?.references_section?.references && data.references_section.references.length > 0 && (
                  <div className="case-study-references-wrap">
                    <ul className="case-study-references-list">
                      {formatReferencesWithClickHere(data.references_section.references).map((reference, index) => (
                        <li key={index}>
                          {reference.has_urls ? (
                            <div
                              className="reference-content"
                              dangerouslySetInnerHTML={{ __html: reference.formatted_text }}
                            />
                          ) : (
                            <CKEditor content={reference?.reference_editor} />
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Related Case Studies Section
      {data?.related_case_studies_section?.enabled !== false && data?.related_case_studies_section?.case_studies?.length > 0 && (
        <section className="related-case-studies-section">
          <div className="container">
            <div className="row">
              <div className="col-12">
                <h2 className="related-case-studies-title">
                  {data?.related_case_studies_section?.title || "Related Case Studies"}
                </h2>
                <div className="related-case-studies-grid">
                  {data.related_case_studies_section.case_studies.slice(0, 3).map((study, index) => {
                    const imageUrl = study?.image?.data?.attributes?.url 
                      ? replaceImageUrl(study.image.data.attributes.url)
                      : null;
                    return (
                      <div key={index} className="related-case-study-card">
                        <div className="related-case-study-image">
                          {imageUrl && (
                            <Image
                              src={imageUrl}
                              alt={study?.title || "Case Study"}
                              width={400}
                              height={240}
                              style={{ objectFit: 'cover', width: '100%', height: '100%' }}
                            />
                          )}
                          <div className="related-case-study-overlay"></div>
                        </div>
                        <div className="related-case-study-content">
                          <h3 className="related-case-study-title">
                            {study?.title || "Case Study Title"}
                          </h3>
                          {study?.description && (
                            <p className="related-case-study-description">
                              {study.description.slice(0, 100)}...
                            </p>
                          )}
                          {study?.button && (
                            <a 
                              href={study.button.button_link || "#"}
                              className="related-case-study-btn"
                              target={study.button.button_target === "_blank" ? "_blank" : "_self"}
                            >
                              Read More
                              <i className="bx bx-right-arrow-alt"></i>
                            </a>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </section>
      )} */}

      {/* Form Popup Modal */}
      {showModal && data?.solutions_banner?.form && (
        <div className="template2-popup-form-overlay">
          <div className="template2-popup-form-wrap preview-modal-form">
            <Form
              data={{
                form_onload: data.solutions_banner.form_onload,
                form_onsubmit: data.solutions_banner.form_onsubmit,
                preview_form: data.solutions_banner.form,
              }}
            />
            <button
              onClick={() => setShowModal(false)}
              className="template2-popup-close-btn"
            >
              <i className="bx bx-x"></i>
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

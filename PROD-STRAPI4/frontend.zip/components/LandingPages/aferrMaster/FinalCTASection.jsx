import React, { useState, useEffect } from "react";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";

export default function FinalCTASection({ data }) {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    // Initial check
    handleResize();

    // Add event listener
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Determine which background image to use
  const getBackgroundImageUrl = () => {
    if (isMobile && data?.background_image_mobile?.data?.attributes?.url) {
      return replaceImageUrl(data.background_image_mobile.data.attributes.url);
    } else if (!isMobile && data?.background_image_desktop?.data?.attributes?.url) {
      return replaceImageUrl(data.background_image_desktop.data.attributes.url);
    } else if (data?.background_image?.data?.attributes?.url) {
      // Fallback to legacy background_image
      return replaceImageUrl(data.background_image.data.attributes.url);
    }
    return null;
  };

  const backgroundImageUrl = getBackgroundImageUrl();

  return (
    <section className="aferr-final-cta-section">
      {/* Background Image Layer - Responsive */}
      {backgroundImageUrl && (
        <>
          <div className="cta-background-image cta-background-desktop">
            <img
              src={backgroundImageUrl}
              alt="CTA Background"
              width={1920}
              height={800}
              style={{ borderRadius: '0px', objectFit: 'cover', width: '100%', height: '100%' }}
            />
          </div>
          <div className="cta-background-image cta-background-mobile">
            <img
              src={backgroundImageUrl}
              alt="CTA Background"
              width={768}
              height={1024}
              style={{ borderRadius: '0px', objectFit: 'cover', width: '100%', height: '100%' }}
            />
          </div>
        </>
      )}

      {/* Gradient Overlay Layer */}
      <div
        className="cta-gradient-overlay"
        style={{
          background: data?.gradient_overlay
        }}
      />

      {/* Content */}
      <div className="cta-content">
        <div className="container">
          <div className="row">
            <div className="col-lg-8 col-md-10 col-12">
              <div className="cta-text-content">
                <h1 className="cta-title font-inter">
                  {data?.title || "Lorem Ipsum Is Simply Dummy Text"}
                </h1>
                <div className="cta-description font-inter-medium">
                  {data?.description ? (
                    <CKEditor content={data.description} />
                  ) : (
                    <p >
                      Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.
                    </p>
                  )}
                </div>
                {data?.button && (
                  <div className="cta-button">
                    <a
                      href={data.button.button_link || "#"}
                      className="btn-cta font-inter-bold"
                      target={data.button.button_target === "blank" ? "_blank" : "_self"}
                    >
                      {data.button.button_text || "Partner With Us"}
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

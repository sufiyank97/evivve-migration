import React, { useEffect, useState } from "react";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";
import ReactPlayer from "react-player";
import { BsPlayBtnFill } from "react-icons/bs";

export default function DetailsSection({ data }) {
  const [thumbnail, setThumbnail] = useState(null);
  const mediaType = data?.media_type || "image";
  const imageUrl = data?.image?.data?.attributes?.url 
    ? replaceImageUrl(data.image.data.attributes.url)
    : null;
  const videoUrl = data?.video?.data?.attributes?.url 
    ? replaceImageUrl(data.video.data.attributes.url)
    : null;
  const videoThumbnailUrl = data?.video_thumbnail?.data?.attributes?.url
    ? replaceImageUrl(data.video_thumbnail.data.attributes.url)
    : null;

  useEffect(() => {
    if (mediaType === "video" && videoUrl && !videoThumbnailUrl) {
      generateThumbnail(videoUrl);
    } else if (videoThumbnailUrl) {
      setThumbnail(videoThumbnailUrl);
    }
  }, [videoUrl, videoThumbnailUrl, mediaType]);

  const generateThumbnail = (videoUrl) => {
    const video = document.createElement("video");
    video.src = videoUrl;
    video.crossOrigin = "anonymous";
    video.addEventListener("loadeddata", () => {
      video.currentTime = 1;
    });

    video.addEventListener("seeked", () => {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      setThumbnail(canvas.toDataURL("image/png"));
    });
  };

  return (
    <section className="aferr-details-section">
      <div className="container">
        <div className="row align-items-center">
          {/* Left Side - Text Content */}
          <div className="col-lg-6 col-md-12">
            <div className="details-text-content">
              <h2 className="details-title1 font-inter-semibold" style={{fontSize:"46.5px"}}>
                {data?.title || "Lorem Ipsum Is Simply"}
              </h2>
              <div className="details-description1 font-inter-regular" style={{fontSize:"15.38px"}}>
                {data?.description ? (
                  <CKEditor content={data.description} />
                ) : (
                  <p>
                    Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.
                  </p>
                )}
              </div>
              {data?.button && (
                <div className="details-button">
                  <a 
                    href={data.button.button_link || "#"}
                    className="btn-style-one blue-dark-color"
                    target={data.button.button_target === "blank" || data.button.button_target === "_blank" ? "_blank" : "_self"}
                  >
                    {data.button.button_text || "Learn More"}
                  </a>
                </div>
              )}
            </div>
          </div>
          
          {/* Right Side - Image with Stats Overlay OR Video */}
          <div className="col-lg-6 col-md-12">
            <div className="details-image-wrapper">
              {mediaType === "video" && videoUrl ? (
                <div className="details-video-container" style={{ position: 'relative', width: '100%', paddingTop: '56.25%' }}>
                  <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}>
                    <ReactPlayer
                      light={thumbnail ? <img src={thumbnail} alt="Video Thumbnail" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : false}
                      playing
                      controls
                      playIcon={<BsPlayBtnFill className="s3VideoThumbnail_btn" style={{ fontSize: '3rem', color: '#5B105A' }} />}
                      url={videoUrl}
                      width="100%"
                      height="100%"
                      style={{ borderRadius: '8px', overflow: 'hidden' }}
                    />
                  </div>
                </div>
              ) : (
                <div className="details-image-container">
                  {/* {imageUrl && (
                    <Image
                      src={imageUrl}
                      alt={data?.title || "Details Image"}
                      width={500}
                      height={500}
                      style={{ width: '100%', height: 'auto', borderRadius: '8px' }}
                    />
                  )}
                   */}
                  {/* Stats Quadrants Overlay */}
                  {data?.stats_quadrants && data.stats_quadrants.length > 0 && (
                    <div className="stats-quadrants-overlay">
                      {data.stats_quadrants.map((quadrant, index) => (
                        <div 
                          key={index}
                          className={`stats-quadrant stats-quadrant-${quadrant.position}`}
                        >
                          <div className="stats-quadrant-content">
                            <div className="stats-value font-inter-semibold">
                              {quadrant.stat_value}
                            </div>
                            
                            <div className="stats-description font-inter-regular">
                              {quadrant.stat_description}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

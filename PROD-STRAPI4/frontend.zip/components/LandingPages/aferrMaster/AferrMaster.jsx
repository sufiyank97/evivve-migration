import React, { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import Seo from "../../Common/seo";
import HeroSection from "./HeroSection";
import Template4Brands from "../template4/Template4Brands";
import DetailsSection from "./DetailsSection";
import DetailsSection2 from "./DetailsSection2";
import CaseStudiesSection from "./CaseStudiesSection";
import Videos from "../../Newsroom/Videos";
import StatsSection from "./StatsSection";
import FinalCTASection from "./FinalCTASection";

const Navbar = dynamic(() => import("@/components/Layout/Navigations/Navbar1"));
const FooterTwo = dynamic(() => import("@/components/Layout/Footer/FooterTwo"));

export default function AferrMaster({
  data,
  top_sticky_stripe,
  logo,
  headerData,
  footerData,
  commonData,
  host,
}) {
  const [show_initial_animation, setShow_initial_animation] = useState(true);
  const [animationsComplete, setAnimationsComplete] = useState(false);
  const [showNavbar, setShowNavbar] = useState(false);
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    if (show_initial_animation) {
      const timer = setTimeout(() => {
        setShow_initial_animation(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [show_initial_animation]);

  return (
    <main className="aferr-master-page-wrap">
      <Seo data={data?.seo} />
      
      {/* Hero Section with Background Image and Gradient Overlay */}
      {data?.templates[0]?.hero_section && (
        <HeroSection
          data={data?.templates[0]?.hero_section}
          show_initial_animation={show_initial_animation}
          setAnimationsComplete={setAnimationsComplete}
        />
      )}

      {/* Brands Section */}
      {data?.templates[0]?.brands_section && (
        <Template4Brands data={data?.templates[0]?.brands_section} />
      )}

      {/* Details Section 1 - Left Text, Right Image */}
      {data?.templates[0]?.details_section && (
        <DetailsSection data={data?.templates[0]?.details_section} />
      )}

      {/* Details Section 2 - Right Image, Left Text */}
      {data?.templates[0]?.details_section_2 && (
        <DetailsSection2 data={data?.templates[0]?.details_section_2} />
      )}

      {/* Case Studies Section with Tabs */}
      {data?.templates[0]?.case_studies_section && (
        <CaseStudiesSection data={data?.templates[0]?.case_studies_section} />
      )}

      {/* Videos Section */}
      {data?.templates[0]?.video_carousel_section && (
        <Videos data={data?.templates[0]?.video_carousel_section} />
      )}

      {/* Statistics Section
      {data?.templates[0]?.stats_section && (
        <StatsSection data={data?.templates[0]?.stats_section} />
      )} */}

      {/* Final CTA Banner */}
      {data?.templates[0]?.final_cta_section && (
        <FinalCTASection data={data?.templates[0]?.final_cta_section} />
      )}
    </main>
  );
}
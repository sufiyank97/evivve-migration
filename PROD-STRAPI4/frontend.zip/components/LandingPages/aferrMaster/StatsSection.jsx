import React from "react";
import CKEditor from "@/utils/CkEditor";
import StatCard from "./StatCard";

export default function StatsSection({ data }) {
  const stats = data?.stats_cards || [
    {
      stat_value: "50%",
      stat_description: "Reduction in training costs compared to traditional methods"
    },
    {
      stat_value: "40%",
      stat_description: "Increase in repeat business from organizations using gamified learning"
    },
    {
      stat_value: "50%",
      stat_description: "Reduction in training costs compared to traditional methods"
    },
    {
      stat_value: "3x",
      stat_description: "Higher client retention for facilitators using Evivve in workshops"
    }
  ];

  return (
    <section className="aferr-stats-section">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="stats-content">
              {/* Left Side - Text */}
              <div className="stats-text">
                <h2 className="stats-title">
                  {data?.title || "Lorem Ipsum Is Simply"}
                </h2>
                <div className="stats-description">
                  {data?.description ? (
                    <CKEditor content={data.description} />
                  ) : (
                    <p>
                      Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.
                    </p>
                  )}
                </div>
              </div>

              {/* Right Side - Stats Grid */}
              <div className="stats-grid">
                {stats.map((stat, index) => (
                  <StatCard key={index} data={stat} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

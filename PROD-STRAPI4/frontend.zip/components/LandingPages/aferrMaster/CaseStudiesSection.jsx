import React, { useRef, useState, useEffect } from "react";
import CKEditor from "@/utils/CkEditor";
import CaseStudyCard from "./CaseStudyCard";

export default function CaseStudiesSection({ data }) {
  const [activeTab, setActiveTab] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [slideDirection, setSlideDirection] = useState(null); // (mobile only)
  const [tabWindowStart, setTabWindowStart] = useState(0);
  const [windowWidth, setWindowWidth] = useState(0);
  const itemsPerPage = 6;
  const categories = data?.case_study_categories || [
    { 
      title: "Category 1", 
      case_studies: [
        {
          title: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
          description: "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.",
          image: { data: { attributes: { url: "/images/placeholder.jpg" } } },
          button: { button_text: "Read More", button_link: "#", button_target: "_self" }
        },
        {
          title: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
          description: "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.",
          image: { data: { attributes: { url: "/images/placeholder.jpg" } } },
          button: { button_text: "Read More", button_link: "#", button_target: "_self" }
        },
        {
          title: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
          description: "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.",
          image: { data: { attributes: { url: "/images/placeholder.jpg" } } },
          button: { button_text: "Read More", button_link: "#", button_target: "_self" }
        },
        {
          title: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
          description: "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.",
          image: { data: { attributes: { url: "/images/placeholder.jpg" } } },
          button: { button_text: "Read More", button_link: "#", button_target: "_self" }
        },
        {
          title: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
          description: "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.",
          image: { data: { attributes: { url: "/images/placeholder.jpg" } } },
          button: { button_text: "Read More", button_link: "#", button_target: "_self" }
        },
        {
          title: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
          description: "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.",
          image: { data: { attributes: { url: "/images/placeholder.jpg" } } },
          button: { button_text: "Read More", button_link: "#", button_target: "_self" }
        }
      ]
    },
    { title: "Category 2", case_studies: [] },
    { title: "Category 3", case_studies: [] }
  ];

  useEffect(() => {
    setWindowWidth(typeof window === 'object' ? window.innerWidth : 0);
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  // Which logic to use
  const isMobile = windowWidth < 768;
  const isDesktop = windowWidth >= 768;
  // Always visible tabs/chevrons!
  const total = categories.length;
  const activeCategory = categories[activeTab];
  // Desktop: windowed logic - limit to 5, then use chevrons
  let tabWindow = [];
  if (isDesktop && categories.length > 5) {
    let start = tabWindowStart;
    if (activeTab < start) start = activeTab;
    if (activeTab > start + 4) start = activeTab - 4;
    if (start < 0) start = 0;
    if (start > total - 5) start = total - 5;
    tabWindow = categories.slice(start, start + 5);
    if (tabWindow.length && !tabWindow.includes(categories[activeTab])) {
      setTabWindowStart(start);
      tabWindow = categories.slice(start, start + 5);
    }
  } else if (isDesktop) {
    tabWindow = categories;
  } else {
    tabWindow = [categories[activeTab]];
  }
  // Always looping chevrons. Mobile wraps, desktop wraps both for nav & window
  const tabsRef = useRef(null);
  const animateTabChange = (nextIdx, direction) => {
    setSlideDirection(direction);
    setTimeout(() => {
      setActiveTab((nextIdx + categories.length) % categories.length);
      setCurrentPage(1);
      setSlideDirection(null);
    }, 200);
  };
  // Desktop chevrons: move the window left/right, wrap around
  const moveWindow = (delta) => {
    let newStart = tabWindowStart + delta;
    const windowSize = total > 5 ? 5 : total;
    if (newStart < 0) newStart = total - windowSize;
    if (newStart > total - windowSize) newStart = 0;
    // Set window, also shift the active tab for next/prev
    setTabWindowStart(newStart);
    let nextTab = activeTab + delta;
    if (nextTab < 0) nextTab = total - 1;
    if (nextTab >= total) nextTab = 0;
    setActiveTab(nextTab);
    setCurrentPage(1);
  };
  const setTabDesktop = (idx) => {
    setActiveTab(idx);
    setCurrentPage(1);
  }
  const mobileGoPrev = () => animateTabChange(activeTab - 1, "left");
  const mobileGoNext = () => animateTabChange(activeTab + 1, "right");

  const totalPages = Math.ceil((activeCategory?.case_studies?.length || 0) / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentStudies = activeCategory?.case_studies?.slice(startIndex, endIndex) || [];

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <section className="aferr-case-studies-section">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="case-studies-header">
              <h2 className="case-studies-title" >
                {data?.title || "OUR CASE STUDIES"}
              </h2>
              {data?.description && (
                <div className="case-studies-description">
                  <CKEditor content={data.description} />
                </div>
              )}
            </div>
            {/* Tabs and Chevrons - visible based on conditions */}
            <div className="case-studies-tabs" ref={tabsRef}>
              {/* Show chevrons on mobile always, on desktop only when more than 5 categories */}
              {(isMobile || (isDesktop && categories.length > 5)) && (
                <button
                  type="button"
                  className="tabs-chevron tabs-chevron-left"
                  aria-label="Previous category"
                  onClick={isMobile ? mobileGoPrev : () => moveWindow(-1)}
                >
                  <i className="bx bx-chevron-left" />
                  <span className="visually-hidden">Previous category</span>
                </button>
              )}
              {isMobile ? (
                <div
                  className={
                    `tab-slide` +
                    (slideDirection ? ` slide-${slideDirection}` : '')
                  }
                  key={activeTab}
                  style={{display:'inline-block', width: "280px", textAlign: "center"}}
                >
                  <button
                    style={{textTransform:'none !important'}}
                    className={`tab-button active font-inter-regular`}
                    tabIndex={0}
                  >
                    {categories[activeTab]?.title}
                  </button>
                </div>
              ) : (
                tabWindow.map((cat, i) => {
                  const idx = categories.indexOf(cat);
                  const isActive = idx === activeTab;
                  return (
                    <button
                      key={cat.title+idx}
                      style={{textTransform:'none !important'}}
                      className={`tab-button ${isActive ? 'active' : ''}`}
                      tabIndex={0}
                      onClick={() => setTabDesktop(idx)}
                    >
                      {cat.title}
                    </button>
                  );
                })
              )}
              {/* Show chevrons on mobile always, on desktop only when more than 5 categories */}
              {(isMobile || (isDesktop && categories.length > 5)) && (
                <button
                  type="button"
                  className="tabs-chevron tabs-chevron-right"
                  aria-label="Next category"
                  onClick={isMobile ? mobileGoNext : () => moveWindow(1)}
                >
                  <i className="bx bx-chevron-right" />
                  <span className="visually-hidden">Next category</span>
                </button>
              )}
            </div>

            {/* Case Studies Grid - Fixed 2x3 layout */}
            <div className="case-studies-content">
              {currentStudies.length > 0 ? (
                <div className="case-studies-grid">
                  {currentStudies.map((study, index) => (
                    <CaseStudyCard key={index} data={study} />
                  ))}
                </div>
              ) : (
                <div className="case-studies-empty">
                  <p>No case studies available for {activeCategory?.title}.</p>
                </div>
              )}

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="case-studies-pagination">
                  <button 
                    className="pagination-btn prev-btn"
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <i className="bx bx-chevron-left"></i>
                  </button>
                  
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <button
                      key={page}
                      className={`pagination-btn page-btn ${currentPage === page ? 'active' : ''}`}
                      onClick={() => handlePageChange(page)}
                    >
                      {page}
                    </button>
                  ))}
                  
                  <button 
                    className="pagination-btn next-btn"
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <i className="bx bx-chevron-right"></i>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

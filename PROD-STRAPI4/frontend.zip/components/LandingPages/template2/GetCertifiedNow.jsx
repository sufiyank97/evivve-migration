import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React from "react";

export default function GetCertifiedNow({ data, setShowModal }) {
  return (
    <div className="get-certified-now-wrap">
      <div className="stripe-1"></div>
      <div className="stripe-2">
        <div className="container">
          <h1>{data?.title}</h1>
        </div>
      </div>
      <div className="stripe-3"></div>
      <div className="get-certified-now-desc-wrap container">
        <CKEditor
          content={data?.list}
          customStyle={"weeks-session-card-list"}
        />
        {data?.image?.data?.attributes?.url && (
          <div>
            <Image
              src={replaceImageUrl(data?.image?.data?.attributes?.url)}
              alt="image"
              width={650}
              height={500}
              style={{ maxWidth: "100%" }}
            />
          </div>
        )}
      </div>
      {data?.get_certified_now_button?.button_text &&
      data?.button_type === "popup" ? (
        <button className="template4-btn1" onClick={() => setShowModal(true)}>
          {data?.get_certified_now_button?.button_text}
        </button>
      ) : (
        // <></>
        <a
          href={data?.get_certified_now_button?.button_link || ""}
          target={
            data?.get_certified_now_button?.button_target === "blank"
              ? "_blank"
              : "_self"
          }
          className="template4-btn1"
        >
          {data?.get_certified_now_button?.button_text}
        </a>
      )}
    </div>
  );
}

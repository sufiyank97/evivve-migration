import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function WeeksSession({ data }) {
  return (
    <div className="weeks-sessions-wrap" id="content">
      <div className="design-1">
        <div className="stripe-1"></div>
        <div className="stripe-2"></div>
      </div>
      <div className="design-2">
        <div className="stripe-1"></div>
        <div className="stripe-2"></div>
      </div>
      <div className="container">
        <h1 className="weeks-sessions-title">{data?.title}</h1>
        <div className="weeks-session-cards-wrap">
          {data?.weeks_session_card.map((item, index) => {
            return (
              <div key={index} className="weeks-session-card">
                <h2>{item?.title}</h2>
                <CKEditor
                  content={item?.list}
                  customStyle={"weeks-session-card-list"}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import React, { useEffect } from "react";
import { Helmet } from "react-helmet";
import parse from "html-react-parser";

const ZohoScript = () => {
	 // Function to load Zoho script dynamically
	 const loadZohoScript = () => {
		// Remove the existing script if any
		const existingScript = document.getElementById("zohoScript");
		if (existingScript) {
		  existingScript.remove();
		}
	
		// Create a new script element
		const script = document.createElement("script");
		script.id = "zohoScript";
		script.type = "text/javascript";
		script.src = "https://fsut-zc1.maillist-manage.in/js/optin.min.js";
		
		// On script load, call the Zoho form setup function
		script.onload = () => {
		  window.setupSF(
			'sf3z5ff5eee8c619c894c1155d4045b3bb73e1b68bd9768e97afa98eebf47065f07a',
			'ZCFORMVIEW',
			false,
			'acc',
			false,
			'2'
		  );
		};
	
		// Append the script to the document head
		document.head.appendChild(script);
	  };
	
	  useEffect(() => {
		// Load Zoho script when the component mounts
		loadZohoScript();
	  }, []); // Empty dependency array ensures it runs only on mount
  return (
    <>
      {/* <Helmet>
        <script
          type="text/javascript"
          src="https://fsut-zc1.maillist-manage.in/js/optin.min.js"
          onload="setupSF('sf3z5ff5eee8c619c894c1155d4045b3bb73e1b68bd9768e97afa98eebf47065f07a','ZCFORMVIEW',false,'acc',false,'2')"
        ></script>
        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{
            __html:
              function runOnFormSubmit_sf3z5ff5eee8c619c894c1155d4045b3bb73e1b68bd9768e97afa98eebf47065f07a(
                th
              ) {},
          }}
        />
		<meta content="width=device-width,initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport"></meta>
      </Helmet> */}

      <div className="play-embed-code-wrap">
        {parse(`
<div id="sf3z5ff5eee8c619c894c1155d4045b3bb73e1b68bd9768e97afa98eebf47065f07a" data-type="signupform">
	<div id="customForm">
		<input type="hidden" id="recapTheme" value="2">
		<input type="hidden" id="isRecapIntegDone" value="false">
		<input type="hidden" id="recapMode" value="170054000000926019">
		<input type="hidden" id="signupFormType" value="LargeForm_Vertical">
		<div name="SIGNUP_PAGE" id="SIGNUP_PAGE" class="SIGNUP_PAGE large_form_10_css">
			<div>
				<div name="" changeid="" changename="">
					<div id="imgBlock" name="LOGO_DIV" logo="true"></div>
				</div>
				<br>
				<div id="signupMainDiv" name="SIGNUPFORM" changeid="SIGNUPFORM" changename="SIGNUPFORM">
					<div>
						<div style="position:relative;">
							<div id="Zc_SignupSuccess" style="display:none;position:absolute;margin-left:4%;width:90%;background-color: white; padding: 3px; border: 3px solid rgb(194, 225, 154);  margin-top: 10px;margin-bottom:10px;word-break:break-all ">
								<table width="100%" cellpadding="0" cellspacing="0" border="0">
									<tbody>
										<tr>
											<td width="10%">
												<img class="successicon" src="https://fsut-zc1.maillist-manage.in/images/challangeiconenable.jpg" align="absmiddle">
											</td>
											<td>
												<span id="signupSuccessMsg" style="color: rgb(73, 140, 132); font-family: sans-serif; font-size: 14px;word-break:break-word">&nbsp;&nbsp;Thank you for Signing Up</span>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<form method="POST" id="zcampaignOptinForm" action="https://fsut-zc1.maillist-manage.in/weboptin.zc" target="_zcSignup">
							<div id="SIGNUP_BODY_ALL" name="SIGNUP_BODY_ALL">
								<h1 id="SIGNUP_HEADING" name="SIGNUP_HEADING" changeid="SIGNUP_MSG" changetype="SIGNUP_HEADER">Join Evivve Masterclass Program</h1>
								<div id="SIGNUP_BODY" name="SIGNUP_BODY">
									<div>
										<div class="" changeid="SIGNUP_MSG" id="SIGNUP_DESCRIPTION" changetype="SIGNUP_DESCRIPTION"></div>
										<div>
											<div name="fieldsdivSf" class="zcsffieldsdiv">
												<div class="zcsffield " fieldid="170054000000000023">
													<div>
														<div name="SIGNUP_FORM_LABEL">Email&nbsp;
															
															
															
															
															
															
															
															
															<span name="SIGNUP_REQUIRED">*</span>
														
														
														
														
														
														
														
														
														</div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="CONTACT_EMAIL" changeitem="SIGNUP_FORM_FIELD" maxlength="100" type="email" required="true" value="">
															<span style="display:none" id="dt_CONTACT_EMAIL">1,true,6,Contact Email,2</span>
														</div>
													</div>
													
													
													
													
													
													
													
													
													
												
											<div></div>
											
												
												
												
												
												
												
												
												
												</div>
												<div class="zcsffield " fieldid="170054000000000029">
													<div>
														<div name="SIGNUP_FORM_LABEL">First Name&nbsp;<span name="SIGNUP_REQUIRED">*</span></div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="FIRSTNAME" changeitem="SIGNUP_FORM_FIELD" maxlength="100" type="text" required="true" value="">
															<span style="display:none" id="dt_FIRSTNAME">1,true,1,First Name,2</span>
														</div>
													</div><div></div></div>
												<div class="zcsffield " fieldid="170054000000000032">
													<div>
														<div name="SIGNUP_FORM_LABEL">Last Name&nbsp;<span name="SIGNUP_REQUIRED">*</span></div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="LASTNAME" changeitem="SIGNUP_FORM_FIELD" maxlength="50" type="text" required="true" value="">
															<span style="display:none" id="dt_LASTNAME">1,true,1,Last Name,2</span>
														</div>
													</div><div></div></div>
												<div class="zcsffield " fieldid="170054000000000035">
													<div>
														<div name="SIGNUP_FORM_LABEL">Job Title&nbsp;<span name="SIGNUP_REQUIRED">*</span></div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="JOB_TITLE" changeitem="SIGNUP_FORM_FIELD" maxlength="50" type="text" required="true" value="">
															<span style="display:none" id="dt_JOB_TITLE">1,true,1,Job Title,2</span>
														</div>
													</div><div></div></div>
												<div class="zcsffield " fieldid="170054000000000038">
													<div>
														<div name="SIGNUP_FORM_LABEL">Company Name&nbsp;<span name="SIGNUP_REQUIRED">*</span></div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="COMPANYNAME" changeitem="SIGNUP_FORM_FIELD" maxlength="100" type="text" required="true" value="">
															<span style="display:none" id="dt_COMPANYNAME">1,true,1,Company Name,2</span>
														</div>
													</div><div></div></div>
												<div class="zcsffield " fieldid="170054000000950001">
													<div>
														<div name="SIGNUP_FORM_LABEL">Industry&nbsp;<span name="SIGNUP_REQUIRED">*</span></div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="CONTACT_CF3" changeitem="SIGNUP_FORM_FIELD" maxlength="20" type="text" required="true" value="">
															<span style="display:none" id="dt_CONTACT_CF3">1,true,1,Your Industry,2</span>
														</div>
													</div><div></div></div>
												<div class="zcsffield " fieldid="170054000000000053">
													<div>
														<div name="SIGNUP_FORM_LABEL">City&nbsp;<span name="SIGNUP_REQUIRED">*</span></div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="CITY" changeitem="SIGNUP_FORM_FIELD" maxlength="100" type="text" required="true" value="">
															<span style="display:none" id="dt_CITY">1,true,1,City,2</span>
														</div>
													</div><div></div></div>
												<div class="zcsffield " fieldid="170054000000000062">
													<div>
														<div name="SIGNUP_FORM_LABEL">Country&nbsp;<span name="SIGNUP_REQUIRED">*</span></div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="COUNTRY" changeitem="SIGNUP_FORM_FIELD" maxlength="100" type="text" required="true" value="">
															<span style="display:none" id="dt_COUNTRY">1,true,1,Country,2</span>
														</div>
													</div><div></div></div>
												<div class="zcsffield " fieldid="170054000000000095">
													<div>
														<div name="SIGNUP_FORM_LABEL">LinkedIn Handle&nbsp;<span name="SIGNUP_REQUIRED">*</span></div>
														<div><!-- check to mark emailid field as type email, and other mandatory fields as type required -->
															<input name="LINKEDIN_HANDLE" changeitem="SIGNUP_FORM_FIELD" maxlength="200" type="text" required="true" value="">
															<span style="display:none" id="dt_LINKEDIN_HANDLE">1,true,1,LinkedIn Handle,2</span>
														</div>
													</div><div></div></div>
											</div><!-- Captcha for Signup -->
											<div class="recaptcha" style="padding: 10px 0px 10px 10px;display:none " id="captchaOld" name="captchaContainer">
												<div>
													<div id="captchaParent">
														<img src="//campaigns.zoho.in/images/refresh_icon.png" onclick="loadCaptcha('https://campaigns.zoho.in/campaigns/CaptchaVerify.zc?mode=generate',this,'#sf3z5ff5eee8c619c894c1155d4045b3bb73e1b68bd9768e97afa98eebf47065f07a');" id="relCaptcha">
														<div id="captchaDiv" captcha="true" name=""></div>
														<input placeholder="Captcha" id="captchaText" name="captchaText" changeitem="SIGNUP_FORM_FIELD" maxlength="100" type="text">
														<span name="SIGNUP_REQUIRED" id="capRequired">*</span>
													</div>
												</div><div></div></div>
											<input type="hidden" id="secretid" value="6LdNeDUUAAAAAG5l7cJfv1AA5OKLslkrOa_xXxLs"><!-- Captcha for Signup End--><!-- Other Lists Subscription Start-->
											<div style="margin-top:20px;" id="selectMailingLists" identity="mailingLists">
												<table width="96%" border="0" cellspacing="0" id="listRelTable" cellpadding="0" class="mt10">
													<tbody></tbody>
												</table>
											</div><!-- Other Lists Subscription End--><div></div>
											<div name="privacyPolicy">
												<input type="checkbox" name="PRIVACY_POLICY" value="PRIVACY_AGREED">
												<span style="vertical-align:middle;margin-left:5px">I agree to the&nbsp;
													<a href="https://evivve.com/privacy-policy/" target="_blank">Privacy Policy</a>&nbsp;and&nbsp;
													<a href="https://evivve.com/terms-of-service/" target="_blank">Terms of Service</a>&nbsp;</span>
											</div>
											<div>
												<input type="button" action="Save" id="zcWebOptin" name="SIGNUP_SUBMIT_BUTTON" changetype="SIGNUP_SUBMIT_BUTTON_TEXT" value="Register Now" onclick="saveOptin(this,false,function(){},'#sf3z5ff5eee8c619c894c1155d4045b3bb73e1b68bd9768e97afa98eebf47065f07a[data-type=&quot;signupform_0&quot;] ',event);">
											</div><!-- Do not edit the below Zoho Campaigns hidden tags -->
											<input type="hidden" id="fieldBorder" value="">
											<input type="hidden" name="zc_trackCode" id="zc_trackCode" value="ZCFORMVIEW" onload="">
											<input type="hidden" name="viewFrom" id="viewFrom" value="URL_ACTION">
											<input type="hidden" id="submitType" name="submitType" value="optinCustomView">
											<input type="hidden" id="lD" name="lD" value="125c273646b08131">
											<input type="hidden" name="emailReportId" id="emailReportId" value="">
											<input type="hidden" name="zx" id="cmpZuid" value="1df9d8b5a7">
											<input type="hidden" name="zcvers" value="2.0">
											<input type="hidden" name="oldListIds" id="allCheckedListIds" value="">
											<input type="hidden" id="mode" name="mode" value="OptinCreateView">
											<input type="hidden" id="zcld" name="zcld" value="125c273646b08131">
											<input type="hidden" id="zctd" name="zctd" value="">
											<input type="hidden" id="document_domain" value="">
											<input type="hidden" id="zc_Url" value="fsut-zc1.maillist-manage.in">
											<input type="hidden" id="new_optin_response_in" value="1">
											<input type="hidden" id="duplicate_optin_response_in" value="1">
											<input type="hidden" id="zc_formIx" name="zc_formIx" value="3z5ff5eee8c619c894c1155d4045b3bb73e1b68bd9768e97afa98eebf47065f07a"><!-- End of the campaigns hidden tags --></div>
									</div>
									<input type="hidden" id="isCaptchaNeeded" value="false">
									<input type="hidden" id="superAdminCap" value="0">
									<img src="https://fsut-zc1.maillist-manage.in/images/spacer.gif" onload="referenceSetter(this)" id="refImage">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="zcOptinOverLay" oncontextmenu="return false" style="display:none;text-align: center; background-color: rgb(0, 0, 0); opacity: 0.5; z-index: 100; position: fixed; width: 100%; top: 0px; left: 0px; height: 988px;"></div>
<div id="zcOptinSuccessPopup" style="display:none;z-index: 9999;width: 800px; height: 40%;top: 84px;position: fixed; left: 26%;background-color: #FFFFFF;border-color: #E6E6E6; border-style: solid; border-width: 1px;  box-shadow: 0 1px 10px #424242;padding: 35px;">
	<span style="position: absolute;top: -16px;right:-14px;z-index:99999;cursor: pointer;" id="closeSuccess">
		<img src="https://fsut-zc1.maillist-manage.in/images/videoclose.png">
	</span>
	<div id="zcOptinSuccessPanel"></div></div>`)}
      </div>
    </>
  );
};

export default ZohoScript;

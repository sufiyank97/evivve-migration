import CKEditor from "@/utils/CkEditor";
import { formattedDate3 } from "@/utils/helper";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { AppContext } from "context/AppContextProvider";
import Image from "next/image";
import React, { useContext, useEffect } from "react";

export default function Join({
  setAnimationsComplete,
  agendaSectionRef,
  setScreen,
  setWheelEventCount,
  data,
  screen2Present,
  screen3Present,
  setReverseScreen,
  show_custom_navbar,
  setActiveSection,
}) {
  const { showStripe } = useContext(AppContext);
  const when_and_where = data?.time_and_date || data?.when_and_where;

  useEffect(() => {
    if (document.documentElement.clientWidth >= 1024) {
      const handleWheel = (e) => {
        const section = agendaSectionRef?.current;
        // Check if the section is at the top of the viewport and the user is scrolling up
        if (section) {
          const sectionTop = section.getBoundingClientRect().top;
          if (sectionTop >= 0 && e.deltaY < -25) {
            setAnimationsComplete(false);
            if (screen3Present) {
              setScreen(4);
              setWheelEventCount(3);
            } else if (screen2Present && !screen3Present) {
              setScreen(2);
              setWheelEventCount(1);
              setReverseScreen(2);
            } else if (!screen2Present && !screen3Present) {
              setScreen(1);
              setWheelEventCount(0);
              setReverseScreen(1);
            }
            setActiveSection("home"); //setting active section state to home in navbar
          }
        }
      };

      // Add the wheel event listener
      agendaSectionRef?.current?.addEventListener("wheel", handleWheel);

      // Cleanup the event listener on component unmount
      return () => {
        agendaSectionRef?.current?.removeEventListener("wheel", handleWheel);
      };
    }
  }, []);

  return (
    <section
      ref={agendaSectionRef}
      id="time-date"
      className={`container ${
        showStripe ? "join-main-wrap-topstripe" : "join-main-wrap"
      } ${show_custom_navbar ? "show_custom_navbar-join-main-wrap" : ""}`}
      style={{
        paddingBottom: "60px",
      }}
    >
      <h1
        style={{ textAlign: "center", marginBottom: "80px", color: "#5B105A" }}
      >
        {data?.title}
      </h1>
      {when_and_where && (
        <div className="when-and-where-wrap">
          <div>
            <h2
              className="when-and-where-title"
              style={{ paddingLeft: "12px" }}
            >
              {when_and_where?.title}
            </h2>
            {(when_and_where?.date || when_and_where?.template2_date) && (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "20px",
                }}
              >
                <div
                  style={{
                    width: "75px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  className="calender-img-wrap"
                >
                  <Image
                    src={"/images/webinar/calender-purple.svg"}
                    alt="calender-icon"
                    width={50}
                    height={50}
                  />
                </div>
                <h2 className="when-and-where-date-time">
                  DATE:{" "}
                  {when_and_where?.template2_date ||
                    formattedDate3(when_and_where?.date)}
                </h2>
              </div>
            )}
            {when_and_where?.time && (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "20px",
                  marginTop: "18px",
                }}
              >
                <div className="time-img-wrap">
                  <Image
                    src={"/images/webinar/time-purple.svg"}
                    alt="time-icon"
                    width={75}
                    height={75}
                  />
                </div>
                <h2 className="when-and-where-date-time">
                  TIME: {when_and_where?.time}
                </h2>
              </div>
            )}
          </div>
          {when_and_where?.image?.data?.attributes?.url && (
            <div className="vanguard-img-wrap">
              <Image
                src={replaceImageUrl(
                  when_and_where?.image?.data?.attributes?.url
                )}
                alt="image"
                width={500}
                height={500}
                style={{ maxWidth: "100%" }}
              />
            </div>
          )}
        </div>
      )}
      <div className="join-desc-wrap" id="agenda">
        {data?.image?.data?.attributes?.url && (
          <div className="join-img-wrap">
            <Image
              src={replaceImageUrl(data?.image?.data?.attributes?.url)}
              alt="image"
              width={450}
              height={500}
              style={{ maxWidth: "100%" }}
            />
          </div>
        )}
        <div>
          <h2 style={{ marginBottom: "50px" }}>
            {data?.what_you_can_expect_title}
          </h2>
          <ul>
            {data?.what_you_can_expect_list?.map((item, i) => {
              return (
                <li key={i}>
                  <CKEditor content={item?.list} />
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </section>
  );
}

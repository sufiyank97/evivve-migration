import React from "react";
// import LandingZohoForm from "../../zoho_form/LandingZohoForm";

export default function Register({ RegisterSectionRef, data, setShowModal }) {
  return (
    <section className="container ptb-70 register-wrap">
      <div ref={RegisterSectionRef} id="register">
        <h1
          style={{
            color: "#5B105A",
            textAlign: "center",
            textShadow: "3px 3px 3px #00000040",
          }}
        >
          {data?.title}
        </h1>

        {/* <LandingZohoForm data={data} /> */}
        {data?.zoho_form_type === "button" ? (
          <Link
            href={data?.register_button?.button_link || ""}
            target={
              data?.register_button?.button_target === "blank"
                ? "_blank"
                : "_self"
            }
          >
            <a
              className="register-button"
              target={
                data?.register_button?.button_target === "blank"
                  ? "_blank"
                  : "_self"
              }
            >
              {data?.register_button?.button_text}
            </a>
          </Link>
        ) : (
          <button
            className="btn1"
            style={{ margin: "auto", marginTop: "50px" }}
            onClick={() => setShowModal(true)}
          >
            {data?.register_button?.button_text}
          </button>
        )}
      </div>
    </section>
  );
}

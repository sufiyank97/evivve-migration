import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import Image from "next/image";
import { Autoplay } from "swiper";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function BrandsSwiper({ data, speed }) {
  // Ensure there are at least a few slides for autoplay/loop to work
  const duplicateSlides = (arr) => {
    if (arr.length < 5) {
      return [...arr, ...arr, ...arr, ...arr]; // Increase the slides to ensure loop
    } else if (arr.length < 10) {
      return [...arr, ...arr]; // Increase the slides to ensure loop
    }
    return arr;
  };
  const slides = duplicateSlides(data);

  return (
    <Swiper
      autoplay={{
        delay: 0,
        disableOnInteraction: false,
        reverseDirection: true,
      }}
      speed={speed || 1000}
      slidesPerView={"auto"}
      spaceBetween={24}
      loop={true}
      modules={[Autoplay]}
      className={"mySwiper home-brands-swiper"}
      onSwiper={(swiper) => {
        swiper.$wrapperEl[0].style.transitionTimingFunction = "linear";
      }}
    >
      {slides?.map((brand, i) => {
        return (
          <SwiperSlide key={i}>
            <Image
              src={replaceImageUrl(
                brand?.attributes?.image?.data?.attributes?.url ||
                  brand?.image?.data?.attributes?.url
              )}
              alt=""
              width={140}
              height={34}
              style={{ borderRadius: "0" }}
              loading="lazy"
            />
          </SwiperSlide>
        );
      })}
    </Swiper>
  );
}

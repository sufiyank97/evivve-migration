import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function BehaviourSignature({ data }) {
  return (
    <div className="container">
      <div className="new-play-now-behaviourr-container">
        <div
          className="new-play-now-signature-text-wrapper"
          data-aos="fade-up"
          data-aos-duration="1200"
        >
          <h1 className="new-play-now-signature-h1">{data?.title}</h1>
          {data?.description && (
            <CKEditor
              content={data?.description}
              customStyle={"new-play-now-signature-p"}
            />
          )}
        </div>
        {data?.Cards?.length > 0 && (
          <div
            className="new-play-now-signature-image-wrapper"
            data-aos="fade-up"
            data-aos-duration="1200"
          >
            {data?.Cards?.map((item, index) => (
              <div
                key={index}
                className={`new-play-now-hexagon-container`}
                style={{
                  backgroundImage: `url(${replaceImageUrl(
                    item?.bg_design?.data?.attributes?.url
                  )})`,
                }}
              >
                <div
                  className="new-play-now-hexagon-container-overlay"
                  style={{
                    "--bg_linear_color": item.bg_linear_color,
                    "--text_shadow_color": item.text_shadow_color,
                  }}
                ></div>
                <div className="new-play-now-hexagon">
                  {item?.image?.data?.attributes?.url && (
                    <img
                      src={replaceImageUrl(item?.image?.data?.attributes?.url)}
                      alt={item?.title}
                      className="new-play-now-hexagon-icon"
                    />
                  )}
                  <div className="new-play-now-hexagon-content">
                    {/* <p
                      className="new-play-now-hexagon-title"
                      style={{
                        textShadow: `2px 2px 0px ${item.text_shadow_color}`,
                      }}
                    >
                      {item?.title}
                    </p> */}
                    <CKEditor
                      content={item?.title}
                      customStyle={"new-play-now-hexagon-title"}
                    />
                    <CKEditor
                      content={item?.description}
                      customStyle={"new-play-now-hexagon-description"}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";

export default function DynamicSection({ data, setShowModal }) {
  return (
    <div className="new-play-now-dyanamic-container">
      <div className="new-play-now-dynamic-img2" data-aos="fade-left"></div>
      <div className="new-play-now-dynamic-img1" data-aos="fade-right"></div>

      <div className="new-play-now-dynamic-section-container">
        <div className="container">
          <div className="new-play-now-dynamic-section-content-wrap">
            <h1
              className="new-play-now-dynamic-section-h1"
              data-aos="fade-up"
              data-aos-duration="1200"
            >
              {data?.title} <br />
              <span>{data?.title_highlight}</span>
            </h1>
            {data?.description && (
              <div data-aos="fade-up">
                <CKEditor
                  content={data?.description}
                  customStyle={"new-play-now-dynamic-section-p"}
                />
              </div>
            )}

            {data?.new_play_now_bottom_section_button?.button_text &&
              (data?.button_type === "form" ? (
                <button
                  className="new-play-now-dynamic-section-btn"
                  data-aos="fade-up"
                  onClick={() => setShowModal(true)}
                >
                  {data?.new_play_now_bottom_section_button?.button_text}
                </button>
              ) : (
                <a
                  href={
                    data?.new_play_now_bottom_section_button?.button_link || ""
                  }
                  target={
                    data?.new_play_now_bottom_section_button?.button_target ===
                    "blank"
                      ? "_blank"
                      : "_self"
                  }
                  className="new-play-now-dynamic-section-btn"
                  data-aos="fade-up"
                >
                  {data?.new_play_now_bottom_section_button?.button_text}
                </a>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

const WelcomeSection = ({ data }) => {
  return (
    <div className="new-play-now-welcome-container">
      {data?.video?.data?.attributes?.url && (
        <video
          className="new-play-now-bg-video"
          autoPlay
          loop
          muted
          playsInline
          preload={true}
        >
          <source
            src={replaceImageUrl(data?.video?.data?.attributes?.url)}
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      )}

      <div className="new-play-now-gradient-overlay"></div>
      <div className="new-play-now-dant-small"></div>
      <div className="new-play-now-dant-big"></div>

      <div className="container">
        <div
          className="new-play-now-welcome-wrapper"
          data-aos="fade-up"
          data-aos-duration="1200"
        >
          <h1 className="new-play-now-welcome-h1">{data?.title}</h1>
          {data?.description && (
            <CKEditor
              content={data?.description}
              customStyle={"new-play-now-welcome-p"}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default WelcomeSection;

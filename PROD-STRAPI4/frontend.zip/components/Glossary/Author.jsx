import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import React from "react";

export default function Author({ authorData, authoBlogsCount,hideAddress }) {
  const router = useRouter();
  return (
    <div
      style={{
        margin: router?.pathname.startsWith("/author") ? "0px" : "70px 0",
      }}
      className="glossary-author"
    >
      <div className="glossary-author-image">
        {authorData?.image?.data ? (
          <Image
            src={replaceImageUrl(authorData?.image?.data?.attributes?.url)}
            height={150}
            width={150}
            alt="user"
            loading="lazy"
            style={{ borderRadius: "50%" }}
          />
        ) : (
          <div className="default-image"></div>
        )}
      </div>
      <div className="glossary-author-content-wrap">
        <div className="glossary-author-name-social-wrap">
          {router?.pathname.startsWith("/author") ? (
            <h2 className="glossary-author-name">{authorData?.name}</h2>
          ) : (
            <h2 className="glossary-author-name">
              <Link href={`/author/${authorData?.slug}` || ""}>
                <a>{authorData?.name}</a>
              </Link>
            </h2>
          )}
          {authorData?.social_links?.length > 0 && (
            <div
              className="author-social"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              {authorData?.social_links?.map((item, index) => {
                return (
                  <div key={index}>
                    <a
                      href={item?.link || ""}
                      // className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className={item?.name} style={{ height: "16px" }}></i>
                    </a>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        <span className="glossary-author-skills">{authorData?.skill}</span>
        {(authoBlogsCount || authorData?.location) && (
          <div className="author-meta">
            {authorData?.location && !hideAddress && <span>{authorData?.location}</span>}
            {authoBlogsCount && authorData?.location && "  •  "}
            {authoBlogsCount && <span>{authoBlogsCount} posts</span>}
          </div>
        )}
        <CKEditor
          content={authorData?.bio}
          customStyle="my-3 glossary-author-bio"
        />
        {authorData?.social_links?.length > 0 && (
          <div
            className="author-social glossary-author-social"
            style={{ display: "flex", alignItems: "center", gap: "10px" }}
          >
            {authorData?.social_links?.map((item, index) => {
              return (
                <div key={index}>
                  <a
                    href={item?.link || ""}
                    // className="d-block"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <i className={item?.name} style={{ height: "16px" }}></i>
                  </a>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

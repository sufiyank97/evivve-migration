import CKEditor from "@/utils/CkEditor";
import { AppContext } from "context/AppContextProvider";
import React, { useContext } from "react";

export default function Editors({ data }) {
  const { showStripe } = useContext(AppContext);
  return data?.map((editor, index) => {
    if (editor?.__typename === "ComponentGlossaryDarkEditor") {
      return (
        <div key={index} className="container">
          <div className="glossary-details-dark-editor">
            <CKEditor content={editor?.dark_editor} />
          </div>
        </div>
      );
    } else if (editor?.__typename === "ComponentGlossaryLightEditor") {
      return (
        <div key={index} className="container">
          <div className="glossary-details-light-editor-wrap">
            <div
              className={`glossary-details-toc-wrap ${
                showStripe ? "glossary-details-toc-wrap-with-top-stipe" : ""
              }`}
            >
              <h3 style={{ color: "#341A5A", marginBottom: "20px" }}>
                Contents
              </h3>
              <div>
                <CKEditor
                  content={editor?.light_editor}
                  id
                  tableOfContent
                  customStyle={"glossary-details-toc"}
                />
              </div>
            </div>
            <div className="glossary-details-light-editor">
              <CKEditor content={editor?.light_editor} id />
            </div>
          </div>
        </div>
      );
    }
  });
}

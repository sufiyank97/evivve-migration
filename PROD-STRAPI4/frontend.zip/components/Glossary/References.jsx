import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function References({ data }) {
  return (
    <div className="container">
      <div className="glossary-details-references-wrap">
        <div className="glossary-details-references-title">
          <h3 style={{ color: "#341A5A", borderBottom: "1px solid #341a5a" }}>
            References
          </h3>
        </div>
        <ul className="glossary-details-references-list">
          {data?.map((item, index) => {
            return (
              <li key={index}>
                <CKEditor content={item?.reference_editor} />
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

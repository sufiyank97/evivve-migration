import React from "react";

const BannerComponent = ({ title }) => {
  return (
    <div className="contact-page-title-area">
      <div className="container">
        <div className="contact-page-title-content">
          <h2>{title}</h2>
        </div>
      </div>
    </div>
  );
};

export default BannerComponent;

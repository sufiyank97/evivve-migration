import { AppContext } from "context/AppContextProvider";
import React, { useContext, useEffect, useState } from "react";

export default function ScrollProgress(props) {
  const { containerRef } = props;

  const [scrollProgress, setScrollProgress] = useState(0);
  const { navbarHeight } = useContext(AppContext);

  useEffect(() => {
    const handleScroll = () => {
      const target = containerRef?.current || document.documentElement;

      // Calculate the scroll progress based on the target element's scroll position
      const { scrollTop, scrollHeight, clientHeight } = target;
      const totalHeight = scrollHeight - clientHeight;
      const progress = (scrollTop / totalHeight) * 100;

      // Update the scroll progress state
      setScrollProgress(progress);
    };

    const target = containerRef?.current || window;

    // Add a scroll event listener to the target element
    target.addEventListener("scroll", handleScroll);

    return () => {
      // Remove the scroll event listener when the component is unmounted
      target.removeEventListener("scroll", handleScroll);
    };
  }, [containerRef]);

  return (
    <div
      className={`scroll-progress`}
      style={{
        width: `${scrollProgress}%`,
        height: `7px`,
        zIndex: 9,
        top: `${navbarHeight}px`,
      }}
    />
  );
}

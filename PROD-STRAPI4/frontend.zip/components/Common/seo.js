import * as React from "react";
import Head from "next/head";
import { useRouter } from "next/router";

function Seo({ data }) {
  const router = useRouter();
  const url = `https://evivve.com${router.asPath}`;

  const socialData = (network) =>
    data?.metaSocial?.find((social) => social?.socialNetwork === network);

  const twitterData = socialData("Twitter");
  const facebookData = socialData("Facebook");
  const linkedinData = socialData("LinkedIn");

  const renderSocialMetaTags = (platform, data) => (
    <>
      <meta name={`${platform}:card`} content="summary" />
      <meta name={`${platform}:title`} content={data?.title} />
      <meta name={`${platform}:description`} content={data?.description} />
      {data?.image?.data?.attributes?.url && (
        <meta
          name={`${platform}:image`}
          content={data?.image?.data?.attributes?.url}
        />
      )}
    </>
  );

  return (
    <Head>
      <title>{data?.metaTitle}</title>
      <meta charSet="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="description" content={data?.metaDescription} />
      <meta property="og:title" content={data?.metaTitle} />
      <meta property="og:description" content={data?.metaDescription} />
      <meta property="og:type" content="website" />
      {data?.keywords && <meta name="keywords" content={data?.keywords} />}
      {data?.metaRobots ? (
        <meta name="robots" content={data?.metaRobots} />
      ) : (
        <meta name="robots" content="index, follow" />
      )}

      {twitterData && renderSocialMetaTags("twitter", twitterData)}
      {facebookData && renderSocialMetaTags("facebook", facebookData)}
      {linkedinData && renderSocialMetaTags("linkedin", linkedinData)}

      {data?.canonicalURL && <link rel="canonical" href={data?.canonicalURL} />}
      {data?.metaImage?.data?.attributes?.url && (
        <meta
          property="og:image"
          content={data?.metaImage?.data?.attributes?.url}
        />
      )}
      <meta property="og:url" content={url} />
      {data?.structuredData && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(data?.structuredData),
          }}
        />
      )}
    </Head>
  );
}

export default Seo;

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import React from "react";

export default function ExperienceEvivve({
  title,
  description,
  margin,
  button,
}) {
  const route = useRouter();
  return (
    <div className={`experience-evivve ${margin}`}>
      <div className="container">
        <div>
          <h3>{title || "EXPERIENCE THE POWER OF EVIVVE"}</h3>
          <p>
            {description ||
              "Join the thousands of People who have experienced Evivve"}
          </p>
        </div>
        {/* <button
          className="btn1"
          onClick={() => route.push("/services/services-3/")}
        >
          Try Now
          <i className="bx bx-right-arrow-alt"></i>
        </button> */}
        <a href={button?.link || "/game"} target={button?.target || "_self"}>
          <button className="btn1">
            {button?.text || "Try Now"}
            {button?.icon && <i className={button?.icon}></i>}
          </button>
        </a>
      </div>
    </div>
  );
}

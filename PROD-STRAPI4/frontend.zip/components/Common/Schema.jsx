import Script from "next/script";
import React from "react";
import { Helmet } from "react-helmet";

export default function Schema({ schema }) {
  return (
    <Helmet>
      <Script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: `${schema}` }}
      />
    </Helmet>
  );
}

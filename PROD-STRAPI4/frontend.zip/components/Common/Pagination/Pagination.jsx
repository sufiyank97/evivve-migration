import { useRouter } from "next/router";
import React from "react";
import ReactPaginate from "react-paginate";

export default function Pagination({ totalPages }) {
  const router = useRouter();
  const handlePageClick = (event) => {
    const pageNo = event.selected + 1;
    let query = `page=${pageNo}`;
    router.replace({
      pathname: router?.asPath?.split("?")[0],
      query: query,
    });
    // console.log("event", event.selected);
  };
  return (
    <div
      className="col-xl-12 col-lg-12 col-md-12"
      // data-aos="fade-up"
      // data-aos-duration="1200"
      // data-aos-delay="300"
    >
      <div className="pagination-area">
        <div className="nav-links">
          <ReactPaginate
            breakLabel="..."
            nextLabel={"next"}
            previousLabel={"prev"}
            onPageChange={handlePageClick}
            pageRangeDisplayed={2}
            marginPagesDisplayed={2}
            pageCount={totalPages || null}
            renderOnZeroPageCount={null}
            containerClassName="react-pagination"
            activeClassName="active"
          />
        </div>
      </div>
    </div>
  );
}

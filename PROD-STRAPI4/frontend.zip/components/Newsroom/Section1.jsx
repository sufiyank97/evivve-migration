import React, { useEffect, useState } from "react";
import TitleTag from "./common/TitleTag";
import Image from "next/image";
import Link from "next/link";
import LoadMoreButton from "./common/LoadMoreButton";
import CKEditor from "@/utils/CkEditor";
import { convertDate } from "./common/convertDate";
import { createTitleId } from "./common/createTitleId";
import axios from "axios";

export default function Section1({ data }) {
  const [mediaData, setMediaData] = useState([]);
  const [query, setQuery] = useState({ page: 1, pageSize: 6 });
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  // Function to determine the pageSize based on screen width
  const determinePageSize = () => {
    return window.innerWidth <= 767 ? 3 : 6; // Mobile: 3, Desktop: 6
  };

  const fetchMediaData = async (page = 1, pageSize = 6) => {
    try {
      setIsLoading(true);
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_STRAPI_URL}api/newsroom/media-data?page=${page}&pageSize=${pageSize}`
      );

      const { count, data } = res.data;
      setTotalCount(Number(count));

      // Append new data to the existing list
      setMediaData((prev) => (page === 1 ? data : [...prev, ...data]));
    } catch (error) {
      console.error("Error fetching press releases:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoadMore = () => {
    const nextPage = query.page + 1;
    setQuery((prev) => ({ ...prev, page: nextPage }));
    fetchMediaData(nextPage, query.pageSize);
  };

  useEffect(() => {
    // Set initial pageSize based on device type
    const initialPageSize = determinePageSize();
    setQuery((prev) => ({ ...prev, pageSize: initialPageSize }));

    // Fetch initial data
    fetchMediaData(1, initialPageSize);

    // Optional: Add a resize listener to adjust pageSize dynamically
    const handleResize = () => {
      const newPageSize = determinePageSize();
      setQuery((prev) => ({ ...prev, pageSize: newPageSize }));
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <section className="newsroom-section1" id={createTitleId(data?.title)}>
      <div className="container">
        <TitleTag title={data?.title} />
        {data?.feature_data && (
          <div className="newsroom-section1-feature">
            {data?.feature_data?.image?.data?.attributes?.url && (
              <div className="newsroom-section1-feature-image-wrap">
                <Image
                  src={data?.feature_data?.image?.data?.attributes?.url}
                  alt="Image"
                  layout="fill"
                  objectFit="cover"
                />
              </div>
            )}
            <div>
              <div className="newsroom-section1-feature-title-wrap">
                <h2>{data?.feature_data?.title}</h2>
                <div className="publisher-name-and-date">
                  <span>{data?.feature_data?.publisher_name}</span>
                  <i class="bx bx-calendar"></i>
                  <span>{convertDate(data?.feature_data?.date)}</span>
                </div>
              </div>
              {data?.feature_data?.description && (
                <div className="description">
                  <CKEditor content={data?.feature_data?.description} />
                </div>
              )}
              <div className="publisher-name-and-date">
                <span>{data?.feature_data?.publisher_name}</span>
                <i class="bx bx-calendar"></i>
                <span>{convertDate(data?.feature_data?.date)}</span>
              </div>
              {data?.feature_data?.feature_button?.button_text && (
                <Link
                  href={data?.feature_data?.feature_button?.button_link || ""}
                >
                  <a
                    className="newsroom-btn"
                    style={{ color: "white" }}
                    target={
                      data?.feature_data?.feature_button?.button_target
                        ? `_${data?.feature_data?.feature_button?.button_target}`
                        : "_blank"
                    }
                  >
                    {data?.feature_data?.feature_button?.button_text}
                  </a>
                </Link>
              )}
            </div>
          </div>
        )}
        <div className="newsroom-section1-media-data">
          {mediaData?.map((item, index) => {
            const image = item?.image?.data?.attributes?.url;
            return (
              <div key={index}>
                {image && (
                  <div className="newsroom-section1-media-image-wrap">
                    <Image
                      src={image}
                      alt="Image"
                      layout="fill"
                      objectFit="cover"
                    />
                  </div>
                )}
                <div style={{ marginBottom: "20px" }}>
                  <div className="media-publisher-name-and-date">
                    <span>{item?.publisher_name}</span>
                    <div>
                      <i class="bx bx-calendar"></i>
                      <span>{convertDate(item?.date)}</span>
                    </div>
                  </div>
                  {item?.description && (
                    <div className="description">
                      <CKEditor content={item?.description} />
                    </div>
                  )}
                </div>
                {item?.media_card_button?.button_text && (
                  <Link href={item?.media_card_button?.button_link || ""}>
                    <a
                      className="newsroom-btn"
                      style={{ color: "white" }}
                      target={
                        item?.media_card_button?.button_target
                          ? `_${item?.media_card_button?.button_target}`
                          : "_blank"
                      }
                    >
                      {item?.media_card_button?.button_text}
                    </a>
                  </Link>
                )}
              </div>
            );
          })}
        </div>
        {mediaData.length < totalCount && (
          <LoadMoreButton
            text={isLoading ? "Loading..." : "Load More"}
            onClickFun={handleLoadMore}
            disabled={isLoading}
          />
        )}
      </div>
    </section>
  );
}

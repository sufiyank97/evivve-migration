import React from "react";

export default function TitleTag({ title, bool = false }) {
  return (
    <div className="newsroom-title-wrap">
      <h1
        className="newsroom-title font-inter-bold"
        style={{
          fontSize: bool ? "40px" : "",
          textTransform: bool ? "uppercase" : "",
          lineHeight: bool ? "52px" : "",
        }}
      >
        {title}
      </h1>
      {!bool ? (
        <img src="/images/newsroom/title-design.svg" alt="title-design" />
      ) : (
        <></>
      )}
    </div>
  );
}

import React from "react";
import TitleTag from "./common/TitleTag";
import Image from "next/image";
import Link from "next/link";
import CKEditor from "@/utils/CkEditor";
import { createTitleId } from "./common/createTitleId";

export default function Section2({ data }) {
  return (
    <section className="newsroom-section2" id={createTitleId(data?.title)}>
      <div className="container">
        <TitleTag title={data?.title} />
        <div className="awards-wrap">
          {data?.award?.map((item, index) => {
            return (
              <div key={index}>
                {item?.image?.data?.attributes?.url && (
                  <div className="awards-img">
                    <img src={item?.image?.data?.attributes?.url} alt="Image" />
                  </div>
                )}
                <div>
                  <p className="awards-title">{item?.title}</p>
                  {item?.name && <p className="awards-name">{item?.name}</p>}
                  {item?.description && (
                    <div className="awards-description">
                      <CKEditor content={item?.description} />
                    </div>
                  )}
                  {item?.award_button?.button_text && (
                    <Link href={item?.award_button?.button_link || ""}>
                      <a
                        className="awards-learn-more-btn"
                        target={
                          item?.award_button?.button_target
                            ? `_${item?.award_button?.button_target}`
                            : "_blank"
                        }
                      >
                        <span>{item?.award_button?.button_text}</span>{" "}
                        <i class="bx bx-up-arrow-alt"></i>
                      </a>
                    </Link>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

import React from "react";
import TitleTag from "./common/TitleTag";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation } from "swiper";
import Link from "next/link";

export default function Videos({ data }) {
  const videoData = data?.video_card || data?.video_cards || [];
  
  return (
    <section className="newsroom-videos">
      <div className="container">
        <TitleTag  title={data?.title} bool={true} />
      </div>
      {videoData?.length > 0 && (
        <div className="newsroom-videos-swiper">
          <Swiper
            autoplay={{
              delay: 2500,
              disableOnInteraction: false,
            }}
            navigation={true}
            loop={true}
            modules={[Navigation, Autoplay]}
            className="mySwiper"
            centeredSlides={true}
            slidesPerView={2}
            spaceBetween={40}
            breakpoints={{
              0: {
                slidesPerView: 1.5,
              },
              500: {
                slidesPerView: 2,
              },
              1400: {
                slidesPerView: 3,
              },
              1700: {
                slidesPerView: 3.5,
              },
            }}
          >
            {videoData?.map((item, index) => {
              return (
                <SwiperSlide key={index}>
                  <div>
                    {item?.video_embed_src_link && (
                      <div className="position-relative">
                        <Link href={item?.video_embed_src_link}>
                          <a
                            target="_blank"
                            className="newsroom-video-card-link"
                          ></a>
                        </Link>
                        <iframe
                          width="560"
                          height="315"
                          src={item?.video_embed_src_link || ""}
                          title="YouTube video player"
                          frameborder="0"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                          referrerpolicy="strict-origin-when-cross-origin"
                          allowfullscreen
                        ></iframe>
                      </div>
                    )}
                    <div className="newsroom-videos-card-description">
                      {item?.title}
                    </div>
                  </div>
                </SwiperSlide>
              );
            })}
          </Swiper>
        </div>
      )}
    </section>
  );
}

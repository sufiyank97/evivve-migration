import React from "react";
import Link from "next/link";
import Image from "next/image";

const MinimalDashboard = ({ data, commonData }) => {
  return (
    <div className="overview-area ptb-100 with-top-border">
      <div className="container">
        <div className="overview-item">
          <div className="row align-items-center">
            <div className="col-lg-5 col-md-12 overview-content">
              <span className="sub-title">
                {data?.sectionTitle || "Minimal Dashboard"}
              </span>
              <h2>
                {data?.title || "The world’s most powerful & easy-to-use"}
              </h2>
              <ul className="overview-list">
                {data?.overviewList?.map((item, i) => {
                  return (
                    <li
                      data-aos="fade-up"
                      data-aos-duration="1200"
                      data-aos-delay={i * 100}
                      key={i}
                    >
                      {/* <i className="flaticon-draw-check-mark"></i> */}
                      <span className={"check-icon"}>
                        <i className="bx bx-check"></i>
                      </span>
                      {item?.overviewPoint}
                    </li>
                  );
                })}
              </ul>
              <div
                className="btn-box"
                data-aos="fade-up"
                data-aos-duration="1200"
                data-aos-delay="300"
              >
                {/* {data?.appDownloadButtons?.map((button, i) => {
                  return (
                    <Link href={button?.buttonLink}>
                      <a
                        className="btn-style-one light-green-color"
                        // style={{ marginRight: i == 0 ? "30px" : "0" }}
                      >
                        {button?.buttonText}
                      </a>
                    </Link>
                  );
                })} */}
                <Link href={commonData?.download_app?.android_link || ""}>
                  <a className="">
                    {commonData?.download_app?.android?.data ? (
                      <Image
                        src={
                          commonData?.download_app?.android?.data?.attributes
                            ?.url
                        }
                        alt=""
                        width={
                          commonData?.download_app?.android?.data?.attributes
                            ?.width
                        }
                        height={
                          commonData?.download_app?.android?.data?.attributes
                            ?.height
                        }
                        loading="lazy"
                      />
                    ) : (
                      <Image
                        src={"/images/play-store.png"}
                        alt=""
                        width={34}
                        height={35}
                        loading="lazy"
                      />
                    )}
                  </a>
                </Link>
                <Link href={commonData?.download_app?.ios_link || ""}>
                  <a className="">
                    {commonData?.download_app?.ios?.data ? (
                      <Image
                        src={
                          commonData?.download_app?.ios?.data?.attributes?.url
                        }
                        alt=""
                        width={
                          commonData?.download_app?.ios?.data?.attributes?.width
                        }
                        height={
                          commonData?.download_app?.ios?.data?.attributes
                            ?.height
                        }
                        loading="lazy"
                      />
                    ) : (
                      <Image
                        src={"/images/apple-store.png"}
                        alt=""
                        width={34}
                        height={35}
                        loading="lazy"
                      />
                    )}
                  </a>
                </Link>
              </div>
            </div>
            <div className="col-lg-7 col-md-12 overview-image style-two">
              {data?.image1?.data?.attributes?.url && (
                <div className="img">
                  <Image
                    src={data?.image1?.data?.attributes?.url}
                    data-aos="fade-up"
                    data-aos-duration="1200"
                    alt="overview-image"
                    width={350}
                    height={700}
                    loading="lazy"
                  />
                </div>
              )}

              {data?.image2?.data?.attributes?.url && (
                <div className="img">
                  <Image
                    src={data?.image2?.data?.attributes?.url}
                    alt="overview-image"
                    width={500}
                    height={287}
                    loading="lazy"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MinimalDashboard;

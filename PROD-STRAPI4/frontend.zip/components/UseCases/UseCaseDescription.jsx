import CKEditor from "@/utils/CkEditor";
import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper";

export default function UseCaseDescription({ data }) {
  return (
    <>
      {data?.map((item, i) => {
        if (item?.__typename === "ComponentUseCaseCkeditor") {
          return (
            <div className="container" key={i}>
              <div className="usecases-description">
                <CKEditor content={item?.description} />
              </div>
            </div>
          );
        } else {
          if (item?.swiper?.length > 0) {
            return (
              <div className="usecases-swiper-description-wrap" key={i}>
                <div className="container">
                  <Swiper
                    navigation={true}
                    pagination={{ clickable: true }}
                    loop={true}
                    modules={[Navigation, Pagination]}
                    className="mySwiper"
                  >
                    {item?.swiper?.map((swiperData, index) => {
                      return (
                        <SwiperSlide key={index}>
                          <div className="usecases-swiper-description-item">
                            <h3>{swiperData?.title}</h3>
                            <div className="usecases-description">
                              <CKEditor content={swiperData?.description} />
                            </div>
                          </div>
                        </SwiperSlide>
                      );
                    })}
                  </Swiper>
                </div>
              </div>
            );
          } else {
            return null;
          }
        }
      })}
    </>
  );
}

import Link from "next/link";
import React from "react";

export default function ReadySection({ data }) {
  return (
    <div className="container">
      <div className="usecases-ready">
        <h2>{data?.title}</h2>
        <p>{data?.description}</p>
        <a
          href={data?.ready_section_button?.button_link || ""}
          target={data?.ready_section_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
        >
          <button className="btn1">
            {data?.ready_section_button?.button_text}
          </button>
        </a>
      </div>
    </div>
  );
}

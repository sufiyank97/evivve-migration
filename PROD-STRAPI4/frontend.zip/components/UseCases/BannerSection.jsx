import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React from "react";

export default function BannerSection({ data }) {
  return (
    <div className="container">
      <div className="usecases-banner">
        <h1>{data?.title}</h1>
        {data?.image?.data?.attributes?.url && (
          <>
            <div className="banner-img hide-on-desktop">
              {/* <Image
                src={replaceImageUrl(data?.image?.data?.attributes?.url)}
                alt={data?.title}
                priority
                // loading="eager"
                layout="fill"
                quality={75}
                objectFit="cover"
                objectPosition={"center"}
              /> */}
              <picture>
                <source
                  media="(max-width:699px)"
                  srcSet={
                    replaceImageUrl(
                      data?.mobile_image?.data?.attributes?.url ||
                        data?.image?.data?.attributes?.url
                    ) || ""
                  }
                  type="image/webp"
                />
                <source
                  media="(max-width:640px)"
                  srcSet={
                    replaceImageUrl(
                      data?.mobile_image?.data?.attributes?.url ||
                        data?.image?.data?.attributes?.url
                    ) || ""
                  }
                  type="image/webp"
                />
                <Image
                  src={replaceImageUrl(
                    data?.mobile_image?.data?.attributes?.url ||
                      data?.image?.data?.attributes?.url
                  )}
                  alt={data?.title}
                  layout="fill"
                  objectFit="contain"
                  objectPosition={"center"}
                  priority
                  // loading="eager"
                  quality={75}
                />
              </picture>
            </div>
            <div className="banner-img hide-on-small-screen">
              {/* <Image
              src={replaceImageUrl(data?.image?.data?.attributes?.url)}
              alt={data?.title}
              // priority="low"
              loading="lazy"
              layout="fill"
              quality={75}
              objectFit="cover"
              objectPosition={"center"}
            /> */}
              <picture>
                <source
                  media="(max-width:699px)"
                  srcSet={
                    replaceImageUrl(data?.image?.data?.attributes?.url) || ""
                  }
                  type="image/webp"
                />
                <source
                  media="(max-width:640px)"
                  srcSet={
                    replaceImageUrl(data?.image?.data?.attributes?.url) || ""
                  }
                  type="image/webp"
                />
                <Image
                  src={replaceImageUrl(data?.image?.data?.attributes?.url)}
                  alt={data?.title}
                  layout="fill"
                  objectFit="contain"
                  objectPosition={"center"}
                  priority
                  // loading="eager"
                  quality={75}
                />
              </picture>
            </div>
          </>
        )}
        <div className="description">
          <CKEditor content={data?.description} />
        </div>
      </div>
    </div>
  );
}

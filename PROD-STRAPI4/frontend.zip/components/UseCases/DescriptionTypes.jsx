import React, { useEffect, useState } from "react";
import JoinOurCommunity from "../AboutUs/JoinOurCommunity";
import Button from "../Common/Button";
import dynamic from "next/dynamic";
const ButtonText = dynamic(() => import("../Common/ButtonText"));
const Zoho = dynamic(() => import("../Blog/BlogDetails/Zoho"));
import AppDownload from "../Courses/AppDownload";

export default function DescriptionTypes({ description_type, ctas }) {
  const [cta, setCta] = useState([]);
  useEffect(() => {
    const filteredCtasData = ctas?.data?.filter((item) =>
      item?.attributes?.description_type?.some(
        (subItem) => subItem?.__typename === "ComponentButtonNewsletter"
      )
    );
    setCta(filteredCtasData);
  }, [ctas]);
  return (
    <>
      {description_type?.map((item, index) => {
        if (item?.__typename === "ComponentButtonButtonImageText") {
          return (
            <JoinOurCommunity
              key={index}
              image={item?.image}
              title={item?.title}
              button={item?.button_image_text_button}
              description={item?.description}
            />
          );
        } else if (item?.__typename === "ComponentButtonButtonText") {
          return <ButtonText key={index} data={item} />;
        } else if (item?.__typename === "ComponentCommonButton") {
          return (
            <div style={{ width: "max-content", margin: "0 auto 1rem" }}>
              <Button key={index} data={item} />
            </div>
          );
        } else if (item?.__typename === "ComponentButtonNewsletter") {
          return (
            <Zoho
              key={index}
              embedCode={item?.description}
              form_onsubmit={item?.form_onsubmit}
              form_onload={item?.form_onload}
            />
          );
        }
      })}
      {cta?.map((item, i) => {
        return item?.attributes?.description_type?.map((subItem, index) => {
          if (subItem?.__typename === "ComponentButtonNewsletter") {
            return (
              <Zoho
                key={index}
                embedCode={subItem?.description}
                form_onsubmit={subItem?.form_onsubmit}
                form_onload={subItem?.form_onload}
              />
            );
          }
        });
      })}
      {ctas?.data?.map((item, i) => {
        return item?.attributes?.description_type?.map((subItem, index) => {
          if (subItem?.__typename === "ComponentCommonAppDownload") {
            return <AppDownload download_app_section={subItem} key={index} />;
          }
        });
      })}
    </>
  );
}

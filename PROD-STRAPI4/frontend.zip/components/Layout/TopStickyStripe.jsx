import CKEditor from "@/utils/CkEditor";
import { AppContext } from "context/AppContextProvider";
import React, { useContext } from "react";

export default function TopStickyStripe({ top_sticky_stripe }) {
  const { setShowStripe } = useContext(AppContext);
  return (
    <div
      className="top-sticky-stripe-wrap"
      style={{ backgroundColor: "#341a5a", padding: "8px 0" }}
    >
      <div className="container top-sticky-stripe">
        {top_sticky_stripe?.description && (
          <div className="top-sticky-stripe-description">
            <CKEditor content={top_sticky_stripe?.description} />
          </div>
        )}
        {top_sticky_stripe?.top_sticky_stripe_button?.button_text && (
          <a
            href={
              top_sticky_stripe?.top_sticky_stripe_button?.button_link || ""
            }
            target={
              top_sticky_stripe?.top_sticky_stripe_button?.button_target ||
              "_blank"
            }
            className="top-sticky-stripe-button"
            onClick={() => setShowStripe(false)}
          >
            {top_sticky_stripe?.top_sticky_stripe_button?.button_text}{" "}
            {/* {top_sticky_stripe?.top_sticky_stripe_button?.button_icon && (
           <i
             className={
               top_sticky_stripe?.top_sticky_stripe_button?.button_icon
             }
           ></i>
         )} */}
            <img
              src={"/images/top-bar-right-arrow.svg"}
              alt="icon"
              width={17}
              height={17}
              className="top-bar-right-arrow"
            />
          </a>
        )}
        <i
          className="bx bx-x top-sticky-stripe-close"
          onClick={() => setShowStripe(false)}
        ></i>
      </div>
    </div>
  );
}

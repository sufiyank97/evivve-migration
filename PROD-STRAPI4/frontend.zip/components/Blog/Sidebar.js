import React from "react";
import Link from "next/link";
import Image from "next/image";
import CKEditor from "@/utils/CkEditor";
import { formattedDate } from "@/utils/helper";

const Sidebar = ({ categories, tableOfContent, slug, popularBlogs }) => {
  const combinedDescription = tableOfContent
    ?.filter((item) => item?.__typename === "ComponentCommonEditor")
    .map((item) => item?.description)
    .join("\n\n");

  return (
    <>
      <aside className="widget-area" style={{ marginTop: "0" }}>
        {/* <div className="widget widget_search">
          <h3 className="widget-title">
            <span>Search</span>
          </h3>
          <form className="search-form">
            <input
              type="search"
              className="search-field"
              placeholder="Search..."
            />
            <button type="submit">
              <i className="bx bx-search"></i>
            </button>
          </form>
        </div> */}

        {/* <CKEditor
          content={tableOfContent}
          customStyle="widget-table-of-contents"
        /> */}
        <h3>Table of Contents</h3>
        {/* {tableOfContent?.map((item, index) => {
          if (item?.__typename === "ComponentCommonEditor") {
            return (
              <div className="blog-widget-table-of-contents-wrap" key={index}>
                <CKEditor
                  content={item?.description}
                  id
                  tableOfContent="blog-tableOfContent"
                  customStyle={"widget-table-of-contents"}
                />
              </div>
            );
          }
        })} */}

        <div className="blog-widget-table-of-contents-wrap">
          <CKEditor
            content={combinedDescription}
            id
            tableOfContent="blog-tableOfContent"
            customStyle={"widget-table-of-contents"}
          />
        </div>

        {categories?.length > 0 && (
          <div className="widget widget_categories sidebar">
            <h3 className="widget-title">
              <span>Categories</span>
            </h3>
            <ul>
              {categories?.map((category, index) => {
                const count = category?.attributes?.blogs?.data?.length;
                return (
                  <li key={index}>
                    <Link
                      href={
                        count > 0
                          ? `/categories/${category?.attributes?.slug}`
                          : `/${slug}`
                      }
                    >
                      <a>
                        {category?.attributes?.title}{" "}
                        <span className="count">({count})</span>
                      </a>
                    </Link>
                  </li>
                );
              })}
              {/* <li>
                <Link href="/blogs/blog-categories">
                  <a>
                    Business <span className="count">(6)</span>
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/blogs/blog-categories">
                  <a>
                    Privacy <span className="count">(4)</span>
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/blogs/blog-categories">
                  <a>
                    Technology <span className="count">(5)</span>
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/blogs/blog-categories">
                  <a>
                    Tips <span className="count">(3)</span>
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/blogs/blog-categories">
                  <a>
                    Log in <span className="count">(8)</span>
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/blogs/blog-categories">
                  <a>
                    Uncategorized <span className="count">(1)</span>
                  </a>
                </Link>
              </li> */}
            </ul>
          </div>
        )}

        {popularBlogs?.length > 0 && (
          <div className="widget widget_posts_thumb">
            <h3 className="widget-title">
              <span>Popular Posts</span>
            </h3>
            {popularBlogs?.map((item, index) => {
              const blog = item?.attributes;
              return (
                <article key={index} className="item">
                  <Link href={blog?.slug || ""}>
                    <a className="thumb">
                      {blog?.image?.data && (
                        <Image
                          src={blog?.image?.data?.attributes?.url}
                          alt="blog-image"
                          width={105}
                          height={67}
                          loading="lazy"
                        />
                      )}
                    </a>
                  </Link>
                  <div className="info">
                    <h4 className="title">
                      <Link href={blog?.slug || ""}>
                        <a>{blog?.title}</a>
                      </Link>
                    </h4>
                    <span className="date">
                      {formattedDate(blog?.publish_date || blog?.createdAt)}
                    </span>
                  </div>
                </article>
              );
            })}

            {/* <article className="item">
              <Link href="/blogs/blog-details">
                <a className="thumb">
                  <Image src={blogImg2} alt="blog-image" />
                </a>
              </Link>
              <div className="info">
                <h4 className="title">
                  <Link href="/blogs/blog-details">
                    <a>
                      Questions to ask vendors before choosing an LMS platform
                    </a>
                  </Link>
                </h4>
                <span className="date">19th Sep, 2021</span>
              </div>
            </article>

            <article className="item">
              <Link href="/blogs/blog-details">
                <a className="thumb">
                  <Image src={blogImg3} alt="blog-image" />
                </a>
              </Link>
              <div className="info">
                <h4 className="title">
                  <Link href="/blogs/blog-details">
                    <a>
                      In person, virtual or hybrid: helpful tools for back to
                      school
                    </a>
                  </Link>
                </h4>
                <span className="date">19th Sep, 2021</span>
              </div>
            </article>

            <article className="item">
              <Link href="/blogs/blog-details">
                <a className="thumb">
                  <Image src={blogImg4} alt="blog-image" />
                </a>
              </Link>
              <div className="info">
                <h4 className="title">
                  <Link href="/blogs/blog-details">
                    <a>
                      Corporate online learning trends you still need to
                      implement in 2021
                    </a>
                  </Link>
                </h4>
                <span className="date">19th Sep, 2021</span>
              </div>
            </article> */}
          </div>
        )}

        {/* {followData?.length > 0 && (
          <div className="widget widget_follow_us">
            <h3 className="widget-title">
              <span>Follow Us</span>
            </h3>
            <ul>
              {followData?.map((follow, index) => {
                return (
                  <li key={index}>
                    <a
                      href={follow?.link}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {follow?.name}
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        )} */}

        {/* {categories?.tags?.length > 0 && (
          <div className="widget widget_tag_cloud">
            <h3 className="widget-title">
              <span>Tags</span>
            </h3>
            <div className="tagcloud">
              {categories?.tags?.map((tag, index) => {
                return (
                  <Link key={index} href="/blogs/blog-tag">
                    <a>{tag?.attributes?.title}</a>
                  </Link>
                );
              })}
            </div>
          </div>
        )} */}
      </aside>
    </>
  );
};

export default Sidebar;

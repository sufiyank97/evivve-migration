import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function Credits({ data }) {
  return (
    <div className="container">
      <div className="credits-wrap">
        <div className="credits-content-wrap">
          <h2 className="credits-title">{data?.credits_title}</h2>
          <div className="credits-description">
            <CKEditor content={data?.credits_description} />
          </div>
        </div>
        {data?.credits?.length > 0 && (
          <div className="credits-table-wrap">
            <table>
              <thead>
                <tr>
                  {data?.credits_header?.map((item, index) => {
                    return (
                      <th key={index}>
                        <div>
                          {item?.icon?.data?.attributes?.url && (
                            <img
                              src={replaceImageUrl(
                                item?.icon?.data?.attributes?.url
                              )}
                              alt="icon"
                            />
                          )}
                          {item?.title}
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {data?.credits?.map((item, index) => {
                  return (
                    <tr key={index}>
                      <td>
                        <div>{item?.segment}</div>
                      </td>
                      <td>
                        <div>{item?.price}</div>
                      </td>
                      <td>
                        <div
                          className={`${
                            item?.discount_green_color_text
                              ? "discount_green_color_text"
                              : ""
                          }`}
                        >
                          {item?.discount}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {data?.credits_button?.button_text && (
          <a
            href={data?.credits_button?.button_link || ""}
            target={
              data?.credits_button?.button_target === "blank"
                ? "_blank"
                : "_self"
            }
            className="btn1 credits-btn"
          >
            {data?.credits_button?.button_text}
          </a>
        )}
      </div>
    </div>
  );
}

import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function HowCreditsWork({ data }) {
  return (
    <div className="how-credits-work-wrap">
      <img
        src="/images/how-credits-work-design1.png"
        alt="image"
        className="how-credits-work-design1-img"
      />
      <img
        src="/images/how-credits-work-design2.png"
        alt="image"
        className="how-credits-work-design2-img"
      />
      <div className="container">
        <div className="how-credits-work-content-wrap">
          <div>
            <p className="how-credits-work-title">{data?.title}</p>
            <p className="how-credits-work-description">{data?.description}</p>
            {data?.how_credits_work_button?.button_text && (
              <a
                href={data?.how_credits_work_button?.button_link || ""}
                target={
                  data?.how_credits_work_button?.button_target === "blank"
                    ? "_blank"
                    : "_self"
                }
                className="how-credits-work-btn"
              >
                {data?.how_credits_work_button?.button_text}
              </a>
            )}
          </div>
          <div className="how-credits-work-img-wrap">
            {data?.desktop_image?.data?.attributes?.url && (
              <img
                src={replaceImageUrl(data?.desktop_image?.data?.attributes?.url)}
                alt="image"
                className={
                  data?.mobile_image?.data?.attributes?.url ? "img-desktop" : ""
                }
              />
            )}
            {data?.mobile_image?.data?.attributes?.url && (
              <img
                src={replaceImageUrl(data?.mobile_image?.data?.attributes?.url)}
                alt="image"
                className="img-mobile"
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

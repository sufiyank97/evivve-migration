import CKEditor from "@/utils/CkEditor";
import React, { useState } from "react";

export default function Faq({ title, faq }) {
  const [showQuestions, setShowQuestions] = useState([]);

  const handleClick = (index) => {
    setShowQuestions((prevIndexes) => {
      if (prevIndexes.includes(index)) {
        return prevIndexes.filter((item) => item !== index);
      } else {
        return [...prevIndexes, index];
      }
    });
  };

  return (
    <div className="container">
      <div className="new-pricing-faq-wrap">
        <h2 className="new-pricing-faq-title" data-aos="fade-up">{title}</h2>
        <div className="new-pricing-faq-list">
          {faq?.map((item, index) => {
            return (
              <div key={index} data-aos="fade-up">
                <div
                  className="new-pricing-faq-question-wrap"
                  onClick={() => handleClick(index)}
                >
                  <div className="new-pricing-faq-question">
                    <img
                      src="/images/new-pricing-faq-question-icon.svg"
                      alt="icon"
                    />
                    {item?.question}
                  </div>
                  <div
                    className={`new-pricing-faq-question-icon ${
                      showQuestions?.includes(index) ? "active" : ""
                    }`}
                  >
                    <i class="bx bx-plus"></i>
                  </div>
                </div>
                <div
                  className={`new-pricing-faq-answer ${
                    showQuestions?.includes(index) ? "active" : ""
                  }`}
                >
                  <CKEditor content={item?.answer} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

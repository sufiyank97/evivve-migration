import Link from "next/link";
import React, { useEffect } from "react";
import { Helmet } from "react-helmet";
import parse from "html-react-parser";

export default function LandingZohoForm({ data }) {
  useEffect(() => {
    const handleOnLoad = () => {
      eval(data?.form_onload);
    };

    // Add event listener
    window.addEventListener("load", handleOnLoad);

    // Cleanup function to remove the event listener
    return () => {
      window.removeEventListener("load", handleOnLoad);
    };
  }, []);
  return (
    <>
      <Helmet>
        <script
          type="text/javascript"
          src="https://fsut-zc1.maillist-manage.in/js/optin.min.js"
          onload={data?.form_onload}
        ></script>

        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{
            __html: `function runOnFormSubmit_${data?.form_onsubmit}(
                th
              ) {}`,
          }}
        />
      </Helmet>

      {data?.zoho_form_type === "button" ? (
        data?.register_button?.button_text ? (
          <Link
            href={data?.register_button?.button_link || ""}
            target={
              data?.register_button?.button_target === "blank"
                ? "_blank"
                : "_self"
            }
          >
            <a
              className="register-button"
              target={
                data?.register_button?.button_target === "blank"
                  ? "_blank"
                  : "_self"
              }
            >
              {data?.register_button?.button_text}
            </a>
          </Link>
        ) : (
          ""
        )
      ) : (
        <>
          <div className="play-embed-code-wrap">
            {parse(`${data?.register_form}`)}
          </div>
        </>
      )}
    </>
  );
}

import React from "react";

export default function Join({ data, setShowModal }) {
  return (
    <div className="play-live-join-section">
      <div className="container">
        <div className="play-live-join-section-content-wrap">
          <h1>{data?.title}</h1>
          {data?.button?.button_text && (
            <button
              className="play-live-join-btn"
              onClick={() => setShowModal(true)}
            >
              {data?.button?.button_text}
            </button>
          )}
        </div>
        <div></div>
      </div>
      {data?.image?.data?.attributes?.url && (
        <img src={data?.image?.data?.attributes?.url} alt="Image" />
      )}
    </div>
  );
}

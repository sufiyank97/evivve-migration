import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function Adventure({ data }) {
  return (
    <section className="adventure-section-wrap">
      <div className="container">
        <div className="adventure-section-content-wrap">
          <div>
            <h1>{data?.title}</h1>
            <div className="adventure-section-desc-wrap">
              <CKEditor content={data?.description} />
            </div>
            <div className="adventure-list">
              {data?.adventure_cards?.map((item, index) => {
                return (
                  <div key={index}>
                    {item?.icon?.data?.attributes?.url && (
                      <div className="adventure-list-icon-bg">
                        <img
                          src={item?.icon?.data?.attributes?.url}
                          alt="icon"
                        />
                      </div>
                    )}
                    <p className="adventure-list-title">{item?.title}</p>
                    <div className="adventure-list-desc-list">
                      <CKEditor content={item?.description} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <div className="">
          {data?.image?.data?.attributes?.url && (
            <img src={data?.image?.data?.attributes?.url} alt="Image" />
          )}
        </div>
      </div>
    </section>
  );
}

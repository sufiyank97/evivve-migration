import CKEditor from "@/utils/CkEditor";
import Image from "next/image";
import React, { useContext } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, EffectFade } from "swiper";
import { AppContext } from "context/AppContextProvider";

export default function HeroSection({ setShowModal, data }) {
  const { navbarHeight, showStripe } = useContext(AppContext);
  return (
    <section
      className="play-live-hero-section"
      style={{
        "--marginTop": `${showStripe ? navbarHeight - 60 : navbarHeight}px`,
      }}
    >
      {data?.banner_image?.data?.attributes?.url && (
        <img
          src={data?.banner_image?.data?.attributes?.url}
          alt="bg-image"
          layout="fill"
          className="play-live-hero-bg"
        />
      )}
      <div className="container play-live-hero-section-wrap">
        <div className="play-live-hero-content-wrap">
          <h1>
            <span>{data?.highlighted_title}</span> {data?.title}
          </h1>
          <div className="play-live-hero-content-desc-wrap">
            <CKEditor content={data?.description} />
          </div>
          {data?.button?.button_text && (
            <button
              className="top-sticky-stripe-button"
              onClick={() => setShowModal(true)}
            >
              {data?.button?.button_text}
            </button>
          )}
        </div>
        <div className="play-live-hero-img-wrap">
          <div className="play-live-hero-img-bg-design"></div>
          <Swiper
            spaceBetween={30}
            effect={"fade"}
            autoplay={{
              delay: 4000,
              disableOnInteraction: false,
            }}
            speed={1500}
            modules={[EffectFade, Autoplay]}
            className="mySwiper play-live-hero-swiper"
          >
            {data?.images?.map((item, index) => {
              return (
                <SwiperSlide key={index}>
                  <Image
                    src={item?.image?.data?.attributes?.url}
                    alt="image"
                    layout="fill"
                  />
                </SwiperSlide>
              );
            })}
          </Swiper>
        </div>
      </div>
    </section>
  );
}

import React from "react";
import styles from "./home.module.css";
import BrandImagesSwiper from "../Common/BrandImagesSwiper";

export default function Brands({ data }) {
  return (
    <div className="container" id="brands">
      <div className={styles.brands}>
        <p>
          {data?.title1 || data?.title2 || data?.title_icon ? (
            <span>
              <span>{data?.title1}</span>
              {data?.title_icon && (
                <span>
                  {" "}
                  <i class={data?.title_icon || ""}></i>{" "}
                </span>
              )}
              <span>{data?.title2}</span>
            </span>
          ) : (
            <span>{data?.heading || ""}</span>
          )}
        </p>
        {data?.client_logos?.data && (
          <BrandImagesSwiper data={data?.client_logos?.data} />
        )}
      </div>
    </div>
  );
}

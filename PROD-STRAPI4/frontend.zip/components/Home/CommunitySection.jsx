import React from "react";
import styles from "./home.module.css";
import Image from "next/image";
import Link from "next/link";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function CommunitySection({ data }) {
  return (
    <div className="container">
      <div className={styles.community}>
        <div>
          <p className={styles.community_info}>{data?.heading}</p>
          <h1>{data?.title}</h1>
          <CKEditor
            content={data?.description}
            customStyle={styles.community_description}
          />
          <div className={styles.community_points}>
            {data?.points?.map((item, index) => {
              return (
                <div key={index} data-aos="fade-up" data-aos-duration="1200">
                  <div className={styles.community_icon}>
                    <i className={item?.icon}></i>
                  </div>
                  <p className={styles.community_point_title}>{item?.title}</p>
                </div>
              );
            })}
            {/* <div data-aos="fade-up" data-aos-duration="1200">
              <div className={styles.community_icon}>
                <i className="bx bx-check"></i>
              </div>
              <p className={styles.community_point_title}>
                Meet our community leaders
              </p>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="1200"
              data-aos-delay="100"
            >
              <div className={styles.community_icon}>
                <i className="bx bx-check"></i>
              </div>
              <p className={styles.community_point_title}>
                Meet like-minded people
              </p>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="1200"
              data-aos-delay="200"
            >
              <div className={styles.community_icon}>
                <i className="bx bx-check"></i>
              </div>
              <p className={styles.community_point_title}>Rising stars</p>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="1200"
              data-aos-delay="300"
            >
              <div className={styles.community_icon}>
                <i className="bx bx-check"></i>
              </div>
              <p className={styles.community_point_title}>Evivve Champions</p>
            </div> */}
          </div>
          <div
            className={styles.btns}
            data-aos="fade-up"
            data-aos-duration="1200"
            data-aos-delay="500"
          >
            <a
              href={data?.community_button?.button_link || ""}
              target={data?.community_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
            >
              <button className={styles.btn2}>
                {data?.community_button?.button_text}
              </button>
            </a>
          </div>
        </div>
        <div className={styles.community_img_wrap}>
          {data?.image?.data && (
            <Image
              src={replaceImageUrl(data?.image?.data?.attributes?.url)}
              alt="community-image"
              className={styles.community_image}
              width={616}
              height={640}
              data-aos="fade-up"
              data-aos-duration="1200"
              loading="lazy"
            />
          )}
        </div>
        <div
          className={styles.mobile_btns}
          data-aos="fade-up"
          data-aos-duration="1200"
          data-aos-delay="500"
        >
          <a
            href={data?.community_button?.button_link || ""}
            target={data?.community_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
          >
            <button className={styles.btn2}>
              {data?.community_button?.button_text}
            </button>
          </a>
        </div>
      </div>
    </div>
  );
}

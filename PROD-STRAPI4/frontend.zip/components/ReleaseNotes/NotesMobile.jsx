import React, { useState } from "react";
import Notes from "./Notes";
import { FaChevronRight } from "react-icons/fa";

export default function NotesMobile({ versionsResponse }) {
  const [showNotes, setShowNotes] = useState(false);
  return (
    <div
      className={`release-notes-mobile ${showNotes ? "active" : "inactive"}`}
    >
      <FaChevronRight
        className="release-notes-mobile-btn"
        style={{
          rotate: showNotes ? "180deg" : "0deg",
          transition: "all 0.3s ease",
        }}
        onClick={() => setShowNotes(!showNotes)}
      />
      <Notes versions={versionsResponse} setShowNotes={setShowNotes} />
    </div>
  );
}

import React from "react";
import Image from "next/image";

import appDownloadImg from "@/public/images/app-download.png";
import playStoreImg from "@/public/images/play-store.png";
import appleStoreImg from "@/public/images/apple-store.png";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

const AppDownload = ({ download_app_section, commonData }) => {
  return (
    <div className="app-download-area bg-yellow pt-100">
      <div className="container">
        <div className="row">
          <div className="col-lg-6 col-md-12">
            <div className="app-download-image">
              {download_app_section?.image?.data ? (
                <Image
                  src={replaceImageUrl(
                    download_app_section?.image?.data?.attributes?.url
                  )}
                  data-aos="fade-up"
                  data-aos-duration="1200"
                  alt="app-download"
                  width={636}
                  height={448}
                  loading="lazy"
                />
              ) : (
                <Image
                  src={appDownloadImg}
                  data-aos="fade-up"
                  data-aos-duration="1200"
                  alt="app-download"
                  loading="lazy"
                />
              )}
            </div>
          </div>

          <div className="col-lg-6 col-md-12">
            <div className="app-download-content">
              <span
                className="sub-title"
                data-aos="fade-up"
                data-aos-duration="1200"
              >
                {download_app_section?.sectionTitle || "Download App"}
              </span>
              <h2
                className="nunito-font"
                data-aos="fade-up"
                data-aos-duration="1200"
                data-aos-delay="100"
              >
                {/* Let&apos;s get your free copy from Apple and Play store */}
                {download_app_section?.title ||
                  "Experience Evivve on Google Play and Play Store"}
              </h2>
              <div
                className="btn-box"
                data-aos="fade-up"
                data-aos-duration="1200"
                data-aos-delay="200"
              >
                <>
                  <a
                    href={
                      download_app_section?.playstoreButtonLink ||
                      "https://play.google.com/store/apps/details?id=com.evivvemain.evivvemain&hl=en_IN&gl=US&pli=1"
                    }
                    className="playstore-btn"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <div className="img">
                      {/* {commonData?.download_app?.android?.data ? (
                        <Image
                          src={
                            commonData?.download_app?.android?.data?.attributes
                              ?.url
                          }
                          alt=""
                          width={
                            commonData?.download_app?.android?.data?.attributes
                              ?.width
                          }
                          height={
                            commonData?.download_app?.android?.data?.attributes
                              ?.height
                          }
                        />
                      ) : (
                        )} */}
                      <Image
                        src={playStoreImg}
                        alt="image"
                        loading="lazy"
                        style={{ borderRadius: "0" }}
                      />
                    </div>
                    <div>
                      Get Evivve on
                      <span>{download_app_section?.playstoreButtonText}</span>
                    </div>
                  </a>
                  <a
                    href={
                      download_app_section?.applestoreButtonLink ||
                      "https://apps.apple.com/us/app/evivve-the-leadership-game/id1495148773"
                    }
                    className="applestore-btn"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <div className="img">
                      {/* {commonData?.download_app?.ios?.data ? (
                        <Image
                          src={
                            commonData?.download_app?.ios?.data?.attributes?.url
                          }
                          alt=""
                          width={
                            commonData?.download_app?.ios?.data?.attributes
                              ?.width
                          }
                          height={
                            commonData?.download_app?.ios?.data?.attributes
                              ?.height
                          }
                        />
                      ) : (
                        )} */}
                      <Image
                        src={appleStoreImg}
                        alt="image"
                        loading="lazy"
                        style={{ borderRadius: "0" }}
                      />
                    </div>
                    <div>
                      Get Evivve on
                      <span>{download_app_section?.applestoreButtonText}</span>
                    </div>
                  </a>
                </>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="lines">
        <div className="line"></div>
        <div className="line"></div>
        <div className="line"></div>
      </div>
    </div>
  );
};

export default AppDownload;

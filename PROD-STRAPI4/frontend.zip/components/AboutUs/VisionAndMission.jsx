import CKEditor from "@/utils/CkEditor";
import { createId } from "@/utils/CreateId";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React from "react";

export default function VisionAndMission({ data }) {
  return (
    <div className="container">
      <div className="vision-and-mission">
        <h1 id={createId(data?.title)}>{data?.title}</h1>
        <div className="vision-and-mission-list">
          {data?.vision_and_mission_list?.map((item, i) => {
            return (
              <div key={i}>
                <div>
                  <Image
                    src={replaceImageUrl(item?.image?.data?.attributes?.url)}
                    alt=""
                    width={616}
                    height={640}
                    loading="lazy"
                  />
                </div>
                <div>
                  <h2 id={createId(item?.title)}>{item?.title}</h2>
                  <CKEditor content={item?.description} id />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";
import { createId } from "@/utils/CreateId";
import { convertToBase64 } from "@/utils/helper";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import NextImage from "next/future/image";
import React from "react";

const Designer = ({ data }) => {
  const [sectionData, setSectionData] = React.useState([]);
  const updateImageToBase64 = async (item) => {
    const base64Image = await convertToBase64(
      item?.image?.data?.attributes?.url
    );
    return {
      ...item,
      base64Image,
    };
  };

  const updateSectionData = async () => {
    let asyncCalls = [];
    data?.map((item) => {
      asyncCalls.push(updateImageToBase64(item));
    });
    const updatedData = await Promise.all(asyncCalls);
    setSectionData(updatedData);
  };
  React.useEffect(() => {
    updateSectionData();
  }, []);
  return (
    <div className="designer-section">
      <div className="container">
        {sectionData?.map((item, index) => {
          const image = replaceImageUrl(item?.image?.data?.attributes?.url);
          return (
            <div key={index} className="row align-items-center pb-100">
              <div
                className={`${
                  item?.isImageLeft ? "order-lg-1" : "order-lg-0"
                } col-lg-6 col-md-12`}
              >
                <div className="designer-content">
                  <h2 id={createId(item?.title)}>{item?.title}</h2>
                  {/* <p>
                    Cloud based storage for your data backup just log in with
                    your mail account from play store &amp; using whatever you
                    want for your business purpose orem ipsum dummy text. never
                    missyour chance its just began. backup just log in with your
                    mail account from.
                  </p>
                  <p>
                    Most provabily best for your data backup just log in with
                    your mail account from play store and using whatever you
                    want for your business purpose orem ipsum dummy.
                  </p> */}
                  <CKEditor content={item?.description} />
                </div>
              </div>
              <div
                className={`${
                  item?.isImageLeft ? "" : "d-flex justify-content-lg-end"
                } col-lg-6 col-md-12`}
              >
                {item?.image?.data && (
                  <NextImage
                    src={image}
                    alt=""
                    height={589}
                    width={412}
                    loading="lazy"
                  />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Designer;

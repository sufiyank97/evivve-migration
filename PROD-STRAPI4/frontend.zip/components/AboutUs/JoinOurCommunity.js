import React from "react";
import Image from "next/image";

import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { createId } from "@/utils/CreateId";

const JoinOurCommunity = ({ image, title, button, description }) => {
  return (
    <div
      className="join-our-community-area ptb-100"
      style={{ backgroundColor: "#f3feff" }}
    >
      <div className="container">
        <div className="row align-items-center">
          {image?.data && (
            <div
              className="col-lg-6 col-md-12"
              data-aos="fade-up"
              data-aos-duration="1200"
            >
              <div className="join-our-community-image">
                <img
                  src={replaceImageUrl(image?.data?.attributes?.url)}
                  width={446}
                  height={397}
                  alt="join-out-community"
                  loading="lazy"
                />
              </div>
            </div>
          )}
          <div className="col-lg-6 col-md-12">
            <div className="join-our-community-content">
              {/* <span
                className="sub-title"
                data-aos="fade-up"
                data-aos-duration="1200"
              >
                Join Our Community
              </span> */}
              <h2
                className="nunito-font"
                data-aos="fade-up"
                data-aos-duration="1200"
                data-aos-delay="100"
                id={createId(title)}
              >
                {/* Would you like to be a part of us? */}
                {title}
              </h2>
              {/* <p
                data-aos="fade-up"
                data-aos-duration="1200"
                data-aos-delay="200"
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Id
                proin <br />
                lectus in aliquam orci mollis ornare nec commodo.
              </p> */}
              <CKEditor content={description} id />
              <div
                className="btn-box"
                data-aos="fade-up"
                data-aos-duration="1200"
                data-aos-delay="300"
              >
                {/* <Link href="/careers">
                  <button className="btn1">
                    Get Started Now <i className="bx bx-chevron-right"></i>
                  </button>
                </Link> */}
                {button?.button_text && (
                  <a
                    href={button?.button_link || ""}
                    target={button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
                  >
                    <button className="btn1">
                      {button?.button_text}{" "}
                      {button?.button_icon && (
                        <i className={button?.button_icon}></i>
                      )}
                    </button>
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JoinOurCommunity;

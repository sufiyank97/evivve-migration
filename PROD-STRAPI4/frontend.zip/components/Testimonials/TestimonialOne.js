import React from "react";
import Image from "next/image";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper";

import userImg8 from "@/public/images/user/user8.jpg";
import userImg9 from "@/public/images/user/user9.jpg";
import userImg10 from "@/public/images/user/user10.jpg";
import CKEditor from "@/utils/CkEditor";
import { useRouter } from "next/router";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

const TestimonialOne = ({ testimonialSection, testimonialData }) => {
  const router = useRouter();
  return (
    <div
      className={`testimonials-area pt-100 pb-75 ${
        router.pathname === "/testimonials" && "testimonials-page-area"
      }`}
    >
      <div className="container">
        <div
          className="section-title"
          data-aos="fade-up"
          data-aos-duration="1200"
        >
          {/* <span className="sub-title light-green-color">
            {testimonialData?.heading}
          </span> */}
          <h2>
            {testimonialSection?.title1 ||
            testimonialSection?.title2 ||
            testimonialSection?.title_icon ? (
              <span>
                <span>{testimonialSection?.title1}</span>
                {testimonialSection?.title_icon && (
                  <span>
                    {" "}
                    <i class={testimonialSection?.title_icon || ""}></i>{" "}
                  </span>
                )}
                <span>{testimonialSection?.title2}</span>
              </span>
            ) : (
              <span>
                {testimonialSection?.title ||
                  "Here's what our amazing clients are saying"}
              </span>
            )}
          </h2>
        </div>

        {testimonialData?.length > 0 ? (
          <Swiper
            slidesPerView={1}
            spaceBetween={25}
            loop={true}
            pagination={{
              clickable: true,
            }}
            autoplay={{
              delay: 6000,
              disableOnInteraction: false,
            }}
            modules={[Pagination, Autoplay]}
            className="testimonials-slides-two"
          >
            {testimonialData?.map((testimonial, i) => {
              const item = testimonial?.attributes;
              return (
                <SwiperSlide key={i}>
                  <div className="single-testimonials-box">
                    <div className="row align-items-center">
                      <div className="col-lg-7 col-md-7">
                        <i className="flaticon-left-quote"></i>
                        <h5>{item?.title}</h5>
                        <div>
                          <CKEditor content={item?.description} />
                        </div>
                        <div className="info">
                          <h3>{item?.name}</h3>
                          <span>{item?.designation}</span>
                        </div>
                      </div>
                      <div className="col-lg-5 col-md-5 text-center">
                        <div className="img testimonial-img-wrap">
                          {item?.image?.data && (
                            <Image
                              src={replaceImageUrl(
                                item?.image?.data?.attributes?.url
                              )}
                              width={301}
                              height={290}
                              alt="user"
                              loading="lazy"
                            />
                          )}
                          {item?.linkedin && (
                            <a
                              href={item?.linkedin || ""}
                              target="_blank"
                              rel="noreferrer"
                              className="testimonial-linkedin-icon"
                            >
                              <i
                                className={"flaticon-linkedin"}
                                style={{ height: "16px" }}
                              ></i>
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              );
            })}
            {/* <SwiperSlide>
            <div className="single-testimonials-box">
              <div className="row align-items-center">
                <div className="col-lg-7 col-md-7">
                  <i className="flaticon-left-quote"></i>
                  <h5>“I never really lost it to begin with.”</h5>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Urna facilisi viverra felis eleifend ornare urna. Eu mauris,
                    velit volutpat massa volutpat. Risus pellentesque felis nisl
                    ut laoreet euismod vel, integer. Massa sodales lorem nisi,
                    sed massa volutpat.
                  </p>
                  <div className="info">
                    <h3>Lora Joly</h3>
                    <span>Founder at Envato</span>
                  </div>
                </div>
                <div className="col-lg-5 col-md-5 text-center">
                  <div className="img">
                    <Image src={userImg8} alt="user" />
                  </div>
                </div>
              </div>
            </div>
          </SwiperSlide>

          <SwiperSlide>
            <div className="single-testimonials-box">
              <div className="row align-items-center">
                <div className="col-lg-7 col-md-7">
                  <i className="flaticon-left-quote"></i>
                  <h5>“Every moment is a fresh beginning.”</h5>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Urna facilisi viverra felis eleifend ornare urna. Eu mauris,
                    velit volutpat massa volutpat. Risus pellentesque felis nisl
                    ut laoreet euismod vel, integer. Massa sodales lorem nisi,
                    sed massa volutpat.
                  </p>
                  <div className="info">
                    <h3>David Warner</h3>
                    <span>Founder at ThemeForest</span>
                  </div>
                </div>
                <div className="col-lg-5 col-md-5 text-center">
                  <div className="img">
                    <Image src={userImg9} alt="user" />
                  </div>
                </div>
              </div>
            </div>
          </SwiperSlide>

          <SwiperSlide>
            <div className="single-testimonials-box">
              <div className="row align-items-center">
                <div className="col-lg-7 col-md-7">
                  <i className="flaticon-left-quote"></i>
                  <h5>“Whatever you do, do it well.”</h5>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Urna facilisi viverra felis eleifend ornare urna. Eu mauris,
                    velit volutpat massa volutpat. Risus pellentesque felis nisl
                    ut laoreet euismod vel, integer. Massa sodales lorem nisi,
                    sed massa volutpat.
                  </p>
                  <div className="info">
                    <h3>James Anderson</h3>
                    <span>Founder at EnvyTheme</span>
                  </div>
                </div>
                <div className="col-lg-5 col-md-5 text-center">
                  <div className="img">
                    <Image src={userImg10} alt="user" />
                  </div>
                </div>
              </div>
            </div>
          </SwiperSlide> */}
          </Swiper>
        ) : (
          <Swiper
            slidesPerView={1}
            spaceBetween={25}
            pagination={{
              clickable: true,
            }}
            modules={[Pagination]}
            className="testimonials-slides-two"
          >
            <SwiperSlide>
              <div className="single-testimonials-box">
                <div className="row align-items-center">
                  <div className="col-lg-7 col-md-7">
                    <i className="flaticon-left-quote"></i>
                    <h5>“I never really lost it to begin with.”</h5>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Urna facilisi viverra felis eleifend ornare urna. Eu
                      mauris, velit volutpat massa volutpat. Risus pellentesque
                      felis nisl ut laoreet euismod vel, integer. Massa sodales
                      lorem nisi, sed massa volutpat.
                    </p>
                    <div className="info">
                      <h3>Lora Joly</h3>
                      <span>Founder at Envato</span>
                    </div>
                  </div>
                  <div className="col-lg-5 col-md-5 text-center">
                    <div className="img">
                      <Image src={userImg8} alt="user" loading="lazy" />
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>

            <SwiperSlide>
              <div className="single-testimonials-box">
                <div className="row align-items-center">
                  <div className="col-lg-7 col-md-7">
                    <i className="flaticon-left-quote"></i>
                    <h5>“Every moment is a fresh beginning.”</h5>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Urna facilisi viverra felis eleifend ornare urna. Eu
                      mauris, velit volutpat massa volutpat. Risus pellentesque
                      felis nisl ut laoreet euismod vel, integer. Massa sodales
                      lorem nisi, sed massa volutpat.
                    </p>
                    <div className="info">
                      <h3>David Warner</h3>
                      <span>Founder at ThemeForest</span>
                    </div>
                  </div>
                  <div className="col-lg-5 col-md-5 text-center">
                    <div className="img">
                      <Image src={userImg9} alt="user" loading="lazy" />
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>

            <SwiperSlide>
              <div className="single-testimonials-box">
                <div className="row align-items-center">
                  <div className="col-lg-7 col-md-7">
                    <i className="flaticon-left-quote"></i>
                    <h5>“Whatever you do, do it well.”</h5>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Urna facilisi viverra felis eleifend ornare urna. Eu
                      mauris, velit volutpat massa volutpat. Risus pellentesque
                      felis nisl ut laoreet euismod vel, integer. Massa sodales
                      lorem nisi, sed massa volutpat.
                    </p>
                    <div className="info">
                      <h3>James Anderson</h3>
                      <span>Founder at EnvyTheme</span>
                    </div>
                  </div>
                  <div className="col-lg-5 col-md-5 text-center">
                    <div className="img">
                      <Image src={userImg10} alt="user" loading="lazy" />
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        )}
      </div>
    </div>
  );
};

export default TestimonialOne;

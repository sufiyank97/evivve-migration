import CKEditor from "@/utils/CkEditor";
import Image from "next/image";
import Link from "next/link";
import React from "react";

export default function HeroSection({ data }) {
  return (
    <div className="container careers-hero-wrap">
      <div>
        <h1>{data?.title}</h1>
        <div className="careers-hero-description">
          <CKEditor content={data?.description} />
        </div>
        {data?.career_button?.button_text && (
          <div
            style={{ marginTop: "32px" }}
            data-aos="fade-up"
            data-aos-duration="1200"
            data-aos-delay="500"
          >
            <a
              href={data?.career_button?.button_link || ""}
              target={data?.career_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
            >
              <button className={"btn1"}>
                {data?.career_button?.button_text}
              </button>
            </a>
          </div>
        )}
      </div>
      <div
        className={"careers-hero-image-wrap"}
        data-aos="fade-up"
        data-aos-duration="1200"
        data-aos-delay="500"
      >
        {data?.image?.data && (
          <Image
            src={data?.image?.data?.attributes?.url}
            alt="image"
            width={616}
            height={640}
            loading="lazy"
          />
        )}
      </div>
    </div>
  );
}

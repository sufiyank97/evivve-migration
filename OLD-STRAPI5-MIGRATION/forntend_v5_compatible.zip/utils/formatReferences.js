// Utility function to format references and make URLs clickable
export const formatReferences = (references) => {
  if (!references || !Array.isArray(references)) {
    return [];
  }

  return references.map((reference, index) => {
    if (!reference?.reference_editor) {
      return null;
    }

    // Extract URLs from the reference text
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const text = reference.reference_editor;
    
    // Check if text contains URLs
    const urls = text.match(urlRegex);
    
    if (urls && urls.length > 0) {
      // Replace URLs with clickable links
      let formattedText = text;
      
      urls.forEach((url, urlIndex) => {
        const linkText = url.length > 50 ? `${url.substring(0, 47)}...` : url;
        const clickableLink = `<a href="${url}" target="_blank" rel="noopener noreferrer" class="reference-link">${linkText}</a>`;
        formattedText = formattedText.replace(url, clickableLink);
      });
      
      return {
        ...reference,
        formatted_text: formattedText,
        has_urls: true
      };
    }
    
    return {
      ...reference,
      formatted_text: text,
      has_urls: false
    };
  }).filter(Boolean);
};

// Alternative: Create a simple "Click here" link for long URLs
export const formatReferencesWithClickHere = (references) => {
  if (!references || !Array.isArray(references)) {
    return [];
  }

  return references.map((reference, index) => {
    if (!reference?.reference_editor) {
      return null;
    }

    const text = reference.reference_editor;
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const urls = text.match(urlRegex);
    
    if (urls && urls.length > 0) {
      let formattedText = text;
      
      urls.forEach((url) => {
        // Create a "Click here" link for long URLs
        const clickableLink = `<a href="${url}" target="_blank" rel="noopener noreferrer" class="reference-link">Click here</a>`;
        formattedText = formattedText.replace(url, clickableLink);
      });
      
      return {
        ...reference,
        formatted_text: formattedText,
        has_urls: true
      };
    }
    
    return {
      ...reference,
      formatted_text: text,
      has_urls: false
    };
  }).filter(Boolean);
};

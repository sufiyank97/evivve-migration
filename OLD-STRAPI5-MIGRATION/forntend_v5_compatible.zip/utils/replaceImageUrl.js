export const replaceImageUrl = (url) => {
  let newUrl = url?.replace(
    `https://evivve-strapi-admin.s3.ap-south-1.amazonaws.com`,
    `https://d2eebkdj3dhq4s.cloudfront.net`
  );
  return newUrl;
};

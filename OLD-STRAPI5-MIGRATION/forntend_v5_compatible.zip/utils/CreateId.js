export const createId = (text) => {
  return (
    text
      ?.trim()
      ?.replace(/[^a-zA-Z0-9\s]/g, "") // Remove all characters except letters, numbers, spaces, and hyphens
      ?.replace(/\s+/g, "-") || // Replace spaces with hyphens
    ""
  );
};

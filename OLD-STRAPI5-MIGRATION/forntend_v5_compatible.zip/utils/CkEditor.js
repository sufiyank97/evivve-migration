import React from "react";
import ReactMarkdown from "react-markdown";
import rehypeRaw from "rehype-raw";
import Image from "next/image";
import { replaceImageUrl } from "./replaceImageUrl";
import { createId } from "./CreateId";

const CKEditor = ({ content, customStyle, id, tableOfContent }) => {
  // to get string
  const getString = (children) => {
    if (typeof children === "string") {
      return createId(children.trim());
    } else if (Array.isArray(children)) {
      return children
        .map((child) => extractTextFromReactElement(child))
        .filter((text) => typeof text === "string" && text.length > 0)
        .map((text) => createId(text.trim()))
        .join("-"); // Concatenate all strings with hyphens
    } else if (React.isValidElement(children)) {
      const text = extractTextFromReactElement(children);
      return createId(text.trim());
    } else {
      return "";
    }
  };

  const extractTextFromReactElement = (element) => {
    if (typeof element === "string") {
      return element;
    }
    if (React.isValidElement(element)) {
      if (element.props && element.props.children) {
        return extractTextFromReactElement(element.props.children);
      }
    } else if (Array.isArray(element)) {
      return element
        .map((child) => extractTextFromReactElement(child))
        .join("");
    }
    return "";
  };

  const createHeadingComponent = (level) => {
    const HeadingComponent = ({ node, children }) => {
      // console.log("children", children);
      const headingId = getString(children);
      const cleanId = headingId.replace(/^-+|-+$/g, "");
      // console.log("headingId", headingId);
      if (tableOfContent) {
        if (tableOfContent === "blog-tableOfContent" && level !== 2) {
          return null;
        }
        if (!cleanId || cleanId.length === 0) {
          // console.log("Children is empty or whitespace only");
          return null;
        }
        return (
          <div style={{ marginBottom: "16px" }}>
            <a href={`#${cleanId}`} target="_self">
              {children}
            </a>
          </div>
        );
      }
      const HeadingTag = `h${level}`;
      return <HeadingTag id={cleanId}>{children}</HeadingTag>;
    };

    HeadingComponent.displayName = `Heading${level}`;

    return HeadingComponent;
  };

  const createImageComponent = () => {
    const ImageComponent = ({ node, children }) => {
      const src = replaceImageUrl(node?.properties?.src);
      return (
        // <div className="ck-editor-img">
        //   <Image src={src} loading="lazy" layout="fill" alt="Image" />
        // </div>
        <img src={src} loading="lazy" alt="Image" />
      );
    };

    ImageComponent.displayName = `Image`;

    return ImageComponent;
  };

  const createListItemComponent = () => {
    const ListItemComponent = ({ node, children }) => {
      // console.log("children", children);
      const listItemId =
        children?.length > 0 && Array.isArray(children)
          ? children?.map((child) =>
              typeof child === "string" ? child.trim().replace(/ /g, "-") : ""
            )?.[0]
          : typeof children === "string"
          ? children.trim().replace(/ /g, "-")
          : "";
      return <li id={listItemId}>{children}</li>;
    };
    ListItemComponent.displayName = "ListItem";
    return ListItemComponent;
  };

  const headingComponents = {
    h1: createHeadingComponent(1),
    h2: createHeadingComponent(2),
    h3: createHeadingComponent(3),
    h4: createHeadingComponent(4),
    h5: createHeadingComponent(5),
    h6: createHeadingComponent(6),
  };

  const listComponents = {
    li: createListItemComponent(),
  };

  const imageComponents = {
    img: createImageComponent(),
  };

  const aComponents = {
    a: ({ node, children }) => {
      // console.log("children:", children);
      // Helper function to recursively get color from children
      const getColorFromChildren = (children) => {
        if (typeof children === "string") {
          // No color to extract from a direct string
          return null;
        }

        if (React.isValidElement(children)) {
          // If valid React element, check its style prop
          const childColor = children.props?.style?.color;
          if (childColor) return childColor;

          // If the element has further children, recursively check them
          if (children.props?.children) {
            return getColorFromChildren(children.props.children);
          }
        }

        // If children is an array, iterate over the elements and find color
        if (Array.isArray(children)) {
          for (const child of children) {
            const color = getColorFromChildren(child);
            if (color) return color; // Return the first color found
          }
        }

        return null; // No color found
      };

      // Helper function to recursively check if "aferr" is in children
      const containsAferr = (children) => {
        if (typeof children === "string") {
          return children.toLocaleLowerCase().includes("aferr");
        }

        if (React.isValidElement(children)) {
          // If the element has further children, recursively check them
          if (children.props?.children) {
            return containsAferr(children.props.children);
          }
        }

        // If children is an array, iterate over the elements and find "aferr"
        if (Array.isArray(children)) {
          for (const child of children) {
            if (containsAferr(child)) return true;
          }
        }

        return false; // "aferr" not found
      };

      // Determine if "aferr" is present in children
      const isAferrPresent = containsAferr(children);

      // Get dynamic color or default to blue
      const color = getColorFromChildren(children) || "blue";

      return (
        <a
          href={node?.properties?.href || ""}
          target={
            customStyle === "widget-table-of-contents" ? "_self" : "_blank"
          }
          style={{ color }}
          className={isAferrPresent ? "affear-word" : ""}
        >
          {children}
        </a>
      );
    },
  };

  const enhanceImages = (source) => {
    return source?.replace(
      /<img/g,
      `<Image loading="lazy" width="800" height="600" alt="Image"`
    );
  };

  return (
    <div className={`ck-text-style ${customStyle ? customStyle : ""}`}>
      <ReactMarkdown
        rehypePlugins={[rehypeRaw]}
        components={
          tableOfContent
            ? {
                ...headingComponents,
                p: () => null,
                img: () => null,
                iframe: () => null,
                li: () => null,
                table: () => null,
                ul: () => null,
                ol: () => null,
                blockquote: () => null,
                figure: () => null,
                pre: () => null,
                hr: () => null,
                br: () => null,
                a: () => null,
                b: () => null,
                i: () => null,
                code: () => null,
                div: () => null,
              }
            : id
            ? {
                ...headingComponents,
                ...listComponents,
                ...imageComponents,
                ...aComponents,
              }
            : {
                ...imageComponents,
                ...aComponents,
              }
        }
      >
        {content}
        {/* {enhanceImages(content)} */}
      </ReactMarkdown>
    </div>
  );
};

export default CKEditor;

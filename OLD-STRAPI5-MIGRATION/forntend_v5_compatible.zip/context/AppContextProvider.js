import { createContext, useCallback, useEffect, useState } from "react";

export const AppContext = createContext();

export const AppContextProvider = ({ children, headerData }) => {
  const [showStripe, setShowStripe] = useState(true);
  const [navbarHeight, setNavbarHeight] = useState(0);

  const updateNavbarHeight = useCallback(() => {
    const navbarElement = document.getElementById("navbar");
    if (navbarElement) {
      setNavbarHeight(navbarElement.offsetHeight);
    }
  }, []);

  useEffect(() => {
    // Initial height calculation after DOM and headerData are ready
    const timeout = setTimeout(() => {
      updateNavbarHeight();
    }, 0);

    return () => clearTimeout(timeout);
  }, [updateNavbarHeight, headerData]);

  useEffect(() => {
    // Attach scroll and resize listeners for dynamic updates
    window.addEventListener("scroll", updateNavbarHeight);
    window.addEventListener("resize", updateNavbarHeight);

    return () => {
      window.removeEventListener("scroll", updateNavbarHeight);
      window.removeEventListener("resize", updateNavbarHeight);
    };
  }, [updateNavbarHeight]);

  useEffect(() => {
    if (showStripe) {
      document.documentElement.style.scrollPaddingTop = "175px";
      document.documentElement.style.scrollBehavior = "smooth";
    } else {
      document.documentElement.style.scrollPaddingTop = "100px";
      document.documentElement.style.scrollBehavior = "smooth";
    }
  }, [showStripe]);

  useEffect(() => {
    const navbarElement = document.getElementById("navbar");
    if (!navbarElement) return;

    // Update height on initial load
    updateNavbarHeight();

    // Use MutationObserver to detect class changes
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (
          mutation.type === "attributes" &&
          mutation.attributeName === "class"
        ) {
          // console.log("Class changed:", navbarElement.className);
          updateNavbarHeight();
        }
      });
    });

    observer.observe(navbarElement, {
      attributes: true,
    });

    // Invoke the function again after 0.5s
    const timeout = setTimeout(() => {
      // console.log("Rechecking height after delay...");
      updateNavbarHeight();
    }, 500);

    return () => {
      observer.disconnect();
      clearTimeout(timeout);
    };
  }, [updateNavbarHeight]);

  return (
    <AppContext.Provider value={{ showStripe, setShowStripe, navbarHeight }}>
      {children}
    </AppContext.Provider>
  );
};

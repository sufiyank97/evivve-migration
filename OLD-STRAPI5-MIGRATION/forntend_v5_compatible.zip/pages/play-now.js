// import React from "react";
// import client from "lib/apollo-client/ApolloClient";
// import { gql } from "@apollo/client";
// import { getSeoData } from "graphql/getSeoData";
// import dynamic from "next/dynamic";
// const Seo = dynamic(() => import("@/components/Common/seo"));
// import Schema from "@/components/Common/Schema";
// import PlayNowZohoForm from "@/components/zoho_form/PlayNowZohoForm";
// const BreadCrumbs = dynamic(() =>
//   import("@/components/Common/BreadCrumbs/BreadCrumbs")
// );
// const PageTopTitle = dynamic(() => import("@/components/Common/PageTopTitle"));
// // const EmbedCode = dynamic(() => import("@/components/Play/EmbedCode"));

// export default function PlayNow({ playNowData }) {
//   return (
//     <>
//       <Seo data={playNowData?.seo} />
//       {playNowData?.schema && <Schema schema={playNowData?.schema} />}
//       <BreadCrumbs
//         crumbs={[{ name: "Play Game", link: "/game" }]}
//         currentPage={"Play Now"}
//       />
//       <PageTopTitle
//         // subTitle={playNowData?.pageTitle}
//         title={playNowData?.title}
//         subHeading={playNowData?.description}
//         button={playNowData?.play_now_button}
//         zoho_form_type={playNowData?.zoho_form_type}
//       />
//       {/* <EmbedCode embed_code={playNowData?.embed_code} /> */}
//       <PlayNowZohoForm
//         zoho_form_type={playNowData?.zoho_form_type}
//         form={playNowData?.form}
//         form_onload={playNowData?.form_onload}
//         form_onsubmit={playNowData?.form_onsubmit}
//       />
//     </>
//   );
// }

// export async function getServerSideProps({ preview }) {
//   const { data, errors } = await client.query({
//     query: gql`
//       query playNowData {
//         playNow ${preview ? "(publicationState:PREVIEW)" : ""} {
//           data {
//             attributes {
//               title
//               description
//               embed_code
//               schema
//               play_now_button {
//                 button_text
//                 button_link
//                 button_target
//                 button_icon
//               }
//               zoho_form_type
//               form
//               form_onload
//               form_onsubmit
//               ${getSeoData}
//             }
//           }
//         }
//       }
//     `,
//   });
//   if (errors?.length > 0) {
//     return {
//       redirect: {
//         destination: `/500?url=/play-now/`,
//         permanent: true,
//       },
//     };
//   }
//   return {
//     props: {
//       playNowData: data?.playNow?.data?.attributes || null,
//     },
//   };
// }


import Template4Brands from "@/components/LandingPages/template4/Template4Brands";
import BehaviourSignature from "@/components/New-Play-Now/BehaviourSignature";
import DynamicSection from "@/components/New-Play-Now/DynamicsSection";
import HeroSection from "@/components/New-Play-Now/HeroSection";
import JourneySection from "@/components/New-Play-Now/JournySection";
import RealPlay from "@/components/New-Play-Now/RealPlay";
import PlayWelcomeSection from "@/components/New-Play-Now/WelcomeSection";
import Faq from "@/components/NewPricing/Faq";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import Seo from "@/components/Common/seo";
import { useEffect, useState } from "react";
import Form from "@/components/LandingPages/template3/Form";
import Head from "next/head";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";

export default function PlayNow({ playNowData }) {
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    document.body.style.overflow = showModal ? "hidden" : "unset";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [showModal]);

  const heroImage = playNowData?.Hero_Section?.image?.url;
  const welcomeVideo = playNowData?.welcome?.video?.url;

  return (
    <>
      <Head>
        {/* Static preload */}
        {/* <link
          rel="preload"
          href="/images/new-play-now/bgImage.svg"
          as="image"
        /> */}
        <link
          rel="preload"
          href="/images/new-play-now/bgImage.svg"
          as="image"
        />
        <link
          rel="preload"
          href="/images/new-play-now/HeroSection/bg-image.webp"
          as="image"
        />
        <link
          rel="preload"
          href="/images/new-play-now/Dynamic/dyanmic-bgimage.webp"
          as="image"
        />

        {/* Dynamic preloads */}
        {heroImage && (
          <link rel="preload" href={replaceImageUrl(heroImage)} as="image" />
        )}
        {welcomeVideo && (
          <link
            rel="preload"
            href={replaceImageUrl(welcomeVideo)}
            as="video"
            type="video"
          />
        )}
      </Head>
      <Seo data={playNowData?.seo} />
      {playNowData?.schema && <Schema schema={playNowData?.schema} />}
      <main className="new-play-now">
        {playNowData?.Hero_Section && (
          <HeroSection
            data={playNowData?.Hero_Section}
            setShowModal={setShowModal}
          />
        )}
        {playNowData?.brands && <Template4Brands data={playNowData?.brands} />}
        {playNowData?.welcome && (
          <PlayWelcomeSection data={playNowData?.welcome} />
        )}


        <div className="new-play-now-bg-image-wrapper">
          <Image
            src={"/images/new-play-now/bgImage.svg"}
            alt="bg-img"
            layout="fill"
            objectFit="cover"
            objectPosition={"center"}
          />
          {playNowData?.game_list_section && (
            <BehaviourSignature data={playNowData?.game_list_section} />
          )}
          {playNowData?.feature_section && (
            <RealPlay data={playNowData?.feature_section} />
          )}
          {playNowData?.steps_section && (
            <JourneySection data={playNowData?.steps_section} />
          )}
          {playNowData?.faq && (
            <Faq
              title={playNowData?.faq?.title}
              faq={playNowData?.faq?.faq_list}
            />
          )}
        </div>
        {playNowData?.bottom_section && (
          <DynamicSection
            data={playNowData?.bottom_section}
            setShowModal={setShowModal}
          />
        )}
        {showModal && playNowData?.form && (
          <div className="template2-popup-form-overlay">
            <div className="template2-popup-form-wrap preview-modal-form">
              <Form
                data={{
                  form_onload: playNowData?.form?.form_onload,
                  form_onsubmit: playNowData?.form?.form_onsubmit,
                  preview_form: playNowData?.form?.form,
                }}
              />
              <button
                onClick={() => setShowModal(false)}
                className="template2-popup-close-btn"
              >
                <i class="bx bx-x"></i>
              </button>
            </div>
          </div>
        )}
      </main>
    </>
  );
}

// export async function getServerSideProps({ preview }) {
//   const { data, errors } = await client.query({
//     query: gql`
//       query newPlayNowData {
//         newPlayNow ${preview ? "(publicationState:PREVIEW)" : ""} {
//           data {
//             attributes {
//         Hero_Section {
//           sub_title
//           title
//           new_play_now_hero_button {
//             button_text
//             button_link
//             button_target
//             button_icon
//           }
//           button_type
//           image {
//             data {
//               attributes {
//                 url
//               }
//             }
//           }
//         }
//         brands {
//           title
//           brands {
//             data {
//               attributes {
//                 image {
//                   data {
//                     attributes {
//                       url
//                     }
//                   }
//                 }
//               }
//             }
//           }
//         }
//         welcome {
//           title
//           description
//           video {
//             data {
//               attributes {
//                 url
//               }
//             }
//           }
//         }
//         game_list_section {
//           title
//           description
//           Cards {
//             title
//             description
//             bg_linear_color
//             text_shadow_color
//             image {
//               data {
//                 attributes {
//                   url
//                 }
//               }
//             }
//             bg_design {
//               data {
//                 attributes {
//                   url
//                 }
//               }
//             }
//           }
//         }
//         feature_section {
//           title
//           cards {
//             icon {
//               data {
//                 attributes {
//                   url
//                 }
//               }
//             }
//             title
//             description
//           }
//         }
//         steps_section {
//           title
//           cards {
//             title
//             description
//             image {
//               data {
//                 attributes {
//                   url
//                 }
//               }
//             }
//           }
//         }
//         faq {
//           title
//           faq_list {
//             question
//             answer
//           }
//         }
//         bottom_section {
//           title
//           title_highlight
//           description
//           new_play_now_bottom_section_button {
//             button_text
//             button_link
//             button_target
//             button_icon
//           }
//           button_type
//         }
//         form {
//           form
//           form_onload
//           form_onsubmit
//         }
//         schema  
//           ${getSeoData}
//             }
//           }
//         }
//       }
//     `,
//   });
//   if (errors?.length > 0) {
//     return {
//       redirect: {
//         destination: `/500?url=/play-now/`,
//         permanent: true,
//       },
//     };
//   }
//   return {
//     props: {
//       playNowData: data?.newPlayNow?.data?.attributes || null,
//     },
//   };
// }

export async function getServerSideProps() {
  const { data, errors } = await client.query({
    query: gql`
      query newPlayNowData {
        newPlayNow {
          Hero_Section {
            sub_title
            title
            new_play_now_hero_button {
              button_text
              button_link
              button_target
              button_icon
            }
            button_type
            image {
              url
            }
          }

          brands {
            title
            brands {
              image {
                url
              }
            }
          }

          welcome {
            title
            description
            video {
              url
            }
          }

          game_list_section {
            title
            description
            Cards {
              title
              description
              bg_linear_color
              text_shadow_color
              image {
                url
              }
              bg_design {
                url
              }
            }
          }

          feature_section {
            title
            cards {
              icon {
                url
              }
              title
              description
            }
          }

          steps_section {
            title
            cards {
              title
              description
              image {
                url
              }
            }
          }

          faq {
            title
            faq_list {
              question
              answer
            }
          }

          bottom_section {
            title
            title_highlight
            description
            new_play_now_bottom_section_button {
              button_text
              button_link
              button_target
              button_icon
            }
            button_type
          }

          form {
            form
            form_onload
            form_onsubmit
          }

          schema
          ${getSeoData}
        }
      }
    `,
  });

  if (errors?.length > 0) {
    console.error('GraphQL errors:', errors);
    return {
      redirect: {
        destination: `/500?url=/play-now/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      playNowData: data?.newPlayNow || null,
    },
  };
}

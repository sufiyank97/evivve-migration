import React from "react";
import AferrMaster from "@/components/LandingPages/aferrMaster/AferrMaster";
import dynamic from "next/dynamic";
import { fetchJournalLandingPage } from "graphql/getLandingPage";
const Seo = dynamic(() => import("@/components/Common/seo"));
import Schema from "@/components/Common/Schema";

export default function JournalLandingPage({ data, seoData }) {
  return (
    <>
      <Seo seoData={seoData} />
      <Schema schemaData={seoData} />
      <AferrMaster data={data} />
    </>
  );
}

export async function getServerSideProps() {
  try {
    console.log('Fetching journal landing page data...');
    const { data } = await fetchJournalLandingPage();
    
    console.log('Journal landing page data received:', data);
    
    const landingPageData = data?.journalLanding?.data?.attributes;
    const seoData = landingPageData?.seo || {
      metaTitle: "Journal Series - Evivve",
      metaDescription: "Explore our collection of journals featuring in-depth research, case studies, and industry insights.",
    };

    // If no data is available, return a fallback structure
    if (!landingPageData) {
      console.log('No journal landing page data found, using fallback');
      return {
        props: {
          data: {
            title: "Journal Series",
            templates: [{
              hero_section: {
                enabled: true,
                title: "Journal Series",
                category: "Research & Insights",
                description: "Explore our collection of journals featuring in-depth research, case studies, and industry insights."
              }
            }]
          },
          seoData,
        },
      };
    }

    // Transform the CMS data structure to match what AferrMaster expects
    const transformedData = {
      title: landingPageData.title || "Journal Series",
      seo: landingPageData.seo || null,
      templates: [{
        hero_section: landingPageData.hero_section || null,
        brands_section: landingPageData.brands_section || null,
        details_section: landingPageData.details_section || null,
        details_section_2: landingPageData.details_section_2 || null,
        case_studies_section: landingPageData.case_studies_section || null,
        video_carousel_section: landingPageData.video_carousel_section || null,
        stats_section: landingPageData.stats_section || null,
        final_cta_section: landingPageData.final_cta_section || null,
      }]
    };

    return {
      props: {
        data: transformedData,
        seoData,
      },
    };
  } catch (error) {
    console.error("Error fetching journal landing page data:", error);
    return {
      props: {
        data: {
          title: "Journal Series",
          templates: [{
            hero_section: {
              enabled: true,
              title: "Journal Series",
              category: "Research & Insights", 
              description: "Explore our collection of journals featuring in-depth research, case studies, and industry insights."
            }
          }]
        },
        seoData: {
          metaTitle: "Journal Series - Evivve",
          metaDescription: "Explore our collection of journals featuring in-depth research, case studies, and industry insights.",
        },
      },
    };
  }
}

import { gql } from "@apollo/client";
import client from "lib/apollo-client/ApolloClient";

const generateSitemap = (
  authorsData,
  categoriesData,
  tagsData,
  blogsData,
  useCasesData,
  // thankyouPagesData
  glossaryPagesData,
  newsroomPagesData,
  landingPagesData,
  knowledgeBasePagesData,
  releaseNotesPagesData
) => {
  let xml = "";
  let siteUrl = "https://evivve.com";
  xml += `
  <url>
  <loc>${siteUrl}/</loc>
  <lastmod>2024-02-29T11:52:14+00:00</lastmod>
  <priority>1.00</priority>
  </url>
  <url>
    <loc>${siteUrl}/about-us/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/contact/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/careers/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/privacy-policy/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/evivvo-pedia/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/cookie-policy/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/game-download/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/game/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/play-live/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/play-now/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/pricing/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/terms-of-service/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/testimonials/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/glossary/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/newsroom/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/knowledge-base/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${siteUrl}/release-notes/</loc>
    <lastmod>2024-02-29T11:52:14+00:00</lastmod>
    <priority>0.80</priority>
  </url>
  `;

  const filterPages = (data) =>
    data.filter((item) => {
      const metaRobots = item?.attributes?.seo?.metaRobots || "";
      return (
        !metaRobots.includes("noindex") && !metaRobots.includes("nofollow")
      );
    });

  const mapData = (data, pathPrefix = "") =>
    data.map((item) => {
      xml += `<url>
          <loc>${siteUrl + pathPrefix + item.attributes.slug}/</loc>
          <lastmod>${
            item.attributes.updatedAt || item.attributes.createdAt
          }</lastmod>
        </url>`;
    });

  mapData(filterPages(authorsData), "/author/");
  mapData(filterPages(categoriesData), "/categories/");
  mapData(filterPages(tagsData), "/tags/");
  mapData(filterPages(blogsData), "/");
  mapData(filterPages(useCasesData), "/");
  mapData(filterPages(landingPagesData), "/");
  // mapData(filterPages(thankyouPagesData), "/");
  mapData(filterPages(glossaryPagesData), "/glossary/");
  mapData(filterPages(newsroomPagesData), "/newsroom/");
  mapData(filterPages(knowledgeBasePagesData), "/knowledge-base/");
  mapData(filterPages(releaseNotesPagesData), "/release-notes/");

  return `<?xml version="1.0" encoding="UTF-8"?>
      <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
      http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
        ${xml}
      </urlset>`;
};

const getAuthors = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getAuthorsData {
        authors {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.authors?.data) {
    return data?.authors?.data || [];
  }
};

const getCategories = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getCategoriesData {
        categories {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.categories?.data) {
    return data?.categories?.data || [];
  }
};

const getTags = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getTagsData {
        tags {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.tags?.data) {
    return data?.tags?.data || [];
  }
};

const getBlogs = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getBlogsData {
        blogs {
          data {
            attributes {
              createdAt
              updatedAt
              publish_date
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.blogs?.data) {
    return data?.blogs?.data || [];
  }
};

const getUsecases = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getUsecasesData {
        useCases {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.useCases?.data) {
    return data?.useCases?.data || [];
  }
};

const getLandingPages = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getLandingPagesData {
        landingPages {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.landingPages?.data) {
    return data?.landingPages?.data || [];
  }
};

const getThankyouPages = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getThankyouPagesData {
        thankYouPages {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.thankYouPages?.data) {
    return data?.thankYouPages?.data || [];
  }
};

const getGlossaryPages = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getGlossaryPagesData {
        glossaries {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.glossaries?.data) {
    return data?.glossaries?.data || [];
  }
};

const getNewsroomPages = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getNewsroomPagesData {
        pressReleases {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.pressReleases?.data) {
    return data?.pressReleases?.data || [];
  }
};

const getKnowledgeBasePages = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getKnowledgeBasePagesData {
        knowledgeBases {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.knowledgeBases?.data) {
    return data?.knowledgeBases?.data || [];
  }
};

const getReleaseNotesPages = async () => {
  const { data, errors } = await client.query({
    query: gql`
      query getReleaseNotesPagesData {
        releaseNotes {
          data {
            attributes {
              createdAt
              updatedAt
              slug
              seo {
                metaRobots
              }
            }
          }
        }
      }
    `,
  });
  if (data?.releaseNotes?.data) {
    return data?.releaseNotes?.data || [];
  }
};

export async function getServerSideProps({ res }) {
  const authorsData = await getAuthors();
  const categoriesData = await getCategories();
  const tagsData = await getTags();
  const blogsData = await getBlogs();
  const useCasesData = await getUsecases();
  // const thankyouPagesData = await getThankyouPages();
  const glossaryPagesData = await getGlossaryPages();
  const newsroomPagesData = await getNewsroomPages();
  const landingPagesData = await getLandingPages();
  const knowledgeBasePagesData = await getKnowledgeBasePages();
  const releaseNotesPagesData = await getReleaseNotesPages();

  res.setHeader("Content-Type", "text/xml");
  res.write(
    generateSitemap(
      authorsData,
      categoriesData,
      tagsData,
      blogsData,
      useCasesData,
      // thankyouPagesData
      glossaryPagesData,
      newsroomPagesData,
      landingPagesData,
      knowledgeBasePagesData,
      releaseNotesPagesData
    )
  );
  res.end();

  return {
    props: {},
  };
}

const SitemapIndex = () => null;
export default SitemapIndex;

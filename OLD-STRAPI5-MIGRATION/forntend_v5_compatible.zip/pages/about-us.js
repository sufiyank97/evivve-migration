import React from "react";
import { gql } from "@apollo/client";
import client from "../lib/apollo-client/ApolloClient";
import { getAboutPage } from "graphql/getAboutPage";
import dynamic from "next/dynamic";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
const AboutArea = dynamic(() => import("@/components/AboutUs/AboutArea"));
const Designer = dynamic(() => import("@/components/AboutUs/Designer"));
const History = dynamic(() => import("@/components/AboutUs/History"));
const Scientists = dynamic(() => import("@/components/AboutUs/Scientists"));
const JoinOurCommunity = dynamic(() =>
  import("@/components/AboutUs/JoinOurCommunity")
);
const VisionAndMission = dynamic(() =>
  import("@/components/AboutUs/VisionAndMission")
);
const Seo = dynamic(() => import("@/components/Common/seo"));
import CKEditor from "@/utils/CkEditor";
import Schema from "@/components/Common/Schema";

const AboutUs = ({ aboutData }) => {
  return (
    <>
      <Seo data={aboutData?.seo} />
      {aboutData?.schema && <Schema schema={aboutData?.schema} />}
      <BreadCrumbs currentPage={aboutData?.banner?.title || "About Us"} />
      <AboutArea data={aboutData?.second_section} />
      <VisionAndMission data={aboutData?.vision_and_mission} />
      <div className="container">
        <div className="about-description">
          <CKEditor content={aboutData?.about_description} id />
        </div>
      </div>
      <Designer data={aboutData?.third_section} />
      <History data={aboutData?.history_section} />
      {aboutData?.member_section?.show_section && (
        <Scientists data={aboutData?.member_section} />
      )}
      <JoinOurCommunity
        image={aboutData?.bottom_section?.image}
        title={aboutData?.bottom_section?.title}
        button={aboutData?.bottom_section?.bottom_button}
        description={aboutData?.bottom_section?.description}
      />
    </>
  );
};

export default AboutUs;

export async function getServerSideProps(context) {
  const { data, errors } = await client.query({
    query: gql`
      ${getAboutPage(context?.preview)}
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/about-us/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      aboutData: data?.about || null,
    },
  };
}

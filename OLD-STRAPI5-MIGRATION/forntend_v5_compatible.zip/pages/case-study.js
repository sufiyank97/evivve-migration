import React from "react";
import AferrMaster from "@/components/LandingPages/aferrMaster/AferrMaster";
import dynamic from "next/dynamic";
import { fetchCaseStudyLandingPage } from "graphql/getLandingPage";
const Seo = dynamic(() => import("@/components/Common/seo"));
import Schema from "@/components/Common/Schema";

export default function CaseStudyLandingPage({ data, seoData }) {
  return (
    <>
      <Seo seoData={seoData} />
      <Schema schemaData={seoData} />
      <AferrMaster data={data} />
    </>
  );
}

export async function getServerSideProps() {
  try {
    console.log('Fetching case study landing page data...');
    const { data } = await fetchCaseStudyLandingPage();
    
    console.log('Case study landing page data received:', data);
    
    const landingPageData = data?.caseStudyLanding?.data?.attributes;
    const seoData = landingPageData?.seo || {
      metaTitle: "Case Studies - Evivve",
      metaDescription: "Discover real-world success stories and case studies showcasing the impact of our innovative solutions.",
    };

    // If no data is available, return a fallback structure
    if (!landingPageData) {
      console.log('No case study landing page data found, using fallback');
      return {
        props: {
          data: {
            title: "Case Studies",
            templates: [{
              hero_section: {
                enabled: true,
                title: "Case Studies",
                category: "Success Stories",
                description: "Discover real-world success stories and case studies showcasing the impact of our innovative solutions."
              }
            }]
          },
          seoData,
        },
      };
    }
    // Transform the CMS data structure to match what AferrMaster expects
    const transformedData = {
      title: landingPageData.title || "Case Studies",
      seo: landingPageData.seo || null,
      templates: [{
        hero_section: landingPageData.hero_section || null,
        brands_section: landingPageData.brands_section || null,
        details_section: landingPageData.details_section || null,
        details_section_2: landingPageData.details_section_2 || null,
        case_studies_section: landingPageData.case_studies_section || null,
        video_carousel_section: landingPageData.video_carousel_section || null,
        stats_section: landingPageData.stats_section || null,
        final_cta_section: landingPageData.final_cta_section || null,
      }]
    };

    return {
      props: {
        data: transformedData,
        seoData,
      },
    };
  } catch (error) {
    console.error("Error fetching case study landing page data:", error);
    return {
      props: {
        data: {
          title: "Case Studies",
          templates: [{
            hero_section: {
              enabled: true,
              title: "Case Studies",
              category: "Success Stories",
              description: "Discover real-world success stories and case studies showcasing the impact of our innovative solutions."
            }
          }]
        },
        seoData: {
          metaTitle: "Case Studies - Evivve",
          metaDescription: "Discover real-world success stories and case studies showcasing the impact of our innovative solutions.",
        },
      },
    };
  }
}

import PaysOffSection from "@/components/CaseStudy/PaysOffSection";
import Seo from "@/components/Common/seo";
import Form from "@/components/LandingPages/template3/Form";
import Template4Brands from "@/components/LandingPages/template4/Template4Brands";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { gql } from "@apollo/client";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import Image from "next/image";
import React from "react";

export default function BookADemoPage({ data }) {
  return (
    <>
      <Seo data={data?.seo} />
      <main className="book-a-demo-main-wrap">
        <div className="book-a-demo-wrap">
          <img
            src="/images/book-a-demo-bg-design.png"
            alt="bg-design"
            className="book-a-demo-bg-design"
          />
          <img
            src="/images/book-a-demo-bg-stripe.png"
            alt="bg-stripe"
            className="book-a-demo-bg-stripe"
          />
          <div className="container">
            <div>
              <div>
                <h1 className="book-a-demo-title">{data?.title}</h1>
                <div className="book-a-demo-desc">
                  <CKEditor content={data?.description} />
                </div>
                {data?.image?.url && (
                  <div className="book-a-demo-img-wrap">
                    <img
                      src={replaceImageUrl(data?.image?.url)}
                      alt="bg-design"
                    />
                  </div>
                )}
              </div>
              <div className="landing-page-template5-form-sticky-wrap">
                <div className="landing-page-template5-form-wrap">
                  <div className="template5-form-wrap book-a-demo-form">
                    <Form
                      data={{
                        form_onload: data?.form_onload,
                        form_onsubmit: data?.form_onsubmit,
                        preview_form: data?.form,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {data?.brands_section && (
          <Template4Brands
            data={data?.brands_section}
            customStyle={"book-a-demo-brands"}
          />
        )}
        {data?.pay_offs_section && (
          <PaysOffSection data={data?.pay_offs_section} />
        )}
      </main>
    </>
  );
}

// export async function getServerSideProps({ preview }) {
//   const { data, errors } = await client.query({
//     query: gql`
//         query BookADemoPageData {
//           bookADemo ${preview ? "(publicationState:PREVIEW)" : ""} {
//             data {
//               attributes {
//                 title
//                 description
//                 image {
//                     data {
//                         attributes {
//                             url
//                         }
//                     }
//                 }
//                 form
//                 form_onload
//                 form_onsubmit
//                 brands_section {
//                   title
//                   brands {
//                     data {
//                       attributes {
//                         image {
//                           data {
//                             attributes {
//                               url
//                             }
//                           }
//                         }
//                       }
//                     }
//                   }
//                 }
//                 pay_offs_section {
//                   title
//                   list {
//                     title
//                     description
//                   }
//                 }
//                 ${getSeoData}
//               }
//             }
//           }
//         }
//       `,
//   });
//   if (errors?.length > 0) {
//     return {
//       redirect: {
//         destination: `/500?url=/schedule-a-call/`,
//         permanent: true,
//       },
//     };
//   }

//   return {
//     props: {
//       data: data?.bookADemo?.data?.attributes || null,
//     },
//   };
// }

export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
      query BookADemoPageData($status: PublicationStatus) {
        bookADemo(status: $status) {
          title
          description
          image {
            url
          }
          form
          form_onload
          form_onsubmit
          brands_section {
            title
            brands {
              image {
                url
              }
            }
          }
          pay_offs_section {
            title
            list {
              title
              description
            }
          }
          ${getSeoData}
        }
      }
    `,
    variables: {
      status: preview ? 'DRAFT' : 'PUBLISHED',
    },
  });

  if (errors?.length > 0) {
    console.error('GraphQL errors:', errors);
    return {
      redirect: {
        destination: `/500?url=/schedule-a-call/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      data: data?.bookADemo || null,
    },
  };
}

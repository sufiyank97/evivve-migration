import React, { useState } from "react";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import dynamic from "next/dynamic";
const ExperienceEvivve = dynamic(() =>
  import("@/components/Common/ExperienceEvivve")
);
import Link from "next/link";
const BreadCrumbs = dynamic(() =>
  import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
const Zoho = dynamic(() => import("@/components/Blog/BlogDetails/Zoho"));
const GridContent = dynamic(() => import("@/components/Blog/GridContent"));

const Blogs = ({ blogsData, blogPage, totalPages }) => {
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);

  const getBlogsData = async (value) => {
    if (value.length > 0) {
      let { data, errors } = await client.query({
        query: gql`
          query getBlogsSearchedData {
            blogs(
              filters: {
                title: {
                  containsi: "${value}"
                }
              }
            ) {
              data {
                attributes {
                  title
                  slug
                }
              }
            }
          }
        `,
      });
      if (errors?.length > 0) {
        console.log("errors:", errors);
      } else {
        setSearchResults(data?.blogs?.data);
      }
    } else {
      setSearchResults([]);
    }
  };

  return (
    <>
      <BreadCrumbs currentPage={blogPage?.title} />
      <div className="page-title-area">
        <div className="container">
          <div className="page-title-content page-title-content2 d-lg-flex align-items-lg-center justify-content-lg-between">
            <div className="col-lg-3"></div>
            <div>
              <h1>
                {/* Evivvo Pedia */}
                {blogPage?.title}
              </h1>
              <h5 className="text-uppercase">
                {/* Game, Facilitation, Design, Tips & Tricks */}
                {blogPage?.description}
              </h5>
            </div>
            <div
              className="form search-input bg-f2003c"
              style={{ position: "relative" }}
            >
              <div className="form-group d-flex">
                <input
                  type="text"
                  name="name"
                  className="form-control"
                  placeholder="Search..."
                  value={search}
                  onChange={(e) => {
                    getBlogsData(e.target.value);
                    setSearch(e.target.value);
                  }}
                />
                <div className="px-3 bg-f2003c d-flex align-items-center icon-wrap">
                  <i className="bx bx-search" style={{ color: "#ffffff" }}></i>
                </div>
              </div>
              {searchResults.length > 0 && (
                <div className="search-dropdown">
                  {searchResults?.map((item, i) => {
                    return (
                      <Link href={`/${item?.attributes?.slug}`} key={i}>
                        <a
                          onClick={() => {
                            setSearch("");
                            setSearchResults([]);
                          }}
                        >
                          {item?.attributes?.title}
                        </a>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <GridContent blogsData={blogsData} totalPages={totalPages} />
      {blogPage?.newsletter_section && (
        <Zoho
          embedCode={blogPage?.newsletter_section?.description}
          form_onsubmit={blogPage?.newsletter_section?.form_onsubmit}
          form_onload={blogPage?.newsletter_section?.form_onload}
        />
      )}
      <ExperienceEvivve
        title={blogPage?.bottom_section?.title}
        description={blogPage?.bottom_section?.description}
        margin={"my-5"}
      />
    </>
  );
};

export default Blogs;

export async function getServerSideProps(context) {
  let pageNumber = context.query.page || 1;
  const { data, errors } = await client.query({
    query: gql`
      query getBlogsData {
        blogs(pagination: { page: ${pageNumber}, pageSize: 1 }) {
          data {
            attributes {
              title
              slug
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              description
              createdAt
              publish_date
              category {
                data {
                  attributes {
                    title
                  }
                }
              }
              tag {
                data {
                  attributes {
                    title
                    slug
                  }
                }
              }
            }
          }
          meta {
            pagination {
              page
              pageSize
              total
              pageCount
            }
          }
        }
        blogPage ${context?.preview ? "(publicationState:PREVIEW)" : ""} {
          data {
            attributes {
              title
              description
              newsletter_section {
                description
              }
              bottom_section {
                title
                description
              }
            }
          }
        }
      }
    `,
  });
  // console.log("data:", data);
  // console.log("errors:", errors);
  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/evivvo-pedia/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      blogsData: data?.blogs?.data || null,
      blogPage: data?.blogPage?.data?.attributes || null,
      totalPages: data?.blogs?.meta?.pagination?.pageCount || null,
    },
  };
}

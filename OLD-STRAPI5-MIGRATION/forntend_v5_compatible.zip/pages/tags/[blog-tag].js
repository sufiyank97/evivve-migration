import React from "react";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import { getSeoData } from "graphql/getSeoData";
import dynamic from "next/dynamic";
const Seo = dynamic(() => import("@/components/Common/seo"));
import Schema from "@/components/Common/Schema";
const GridContent = dynamic(() => import("@/components/Blog/GridContent"));

const BlogCategories = ({ blogsData, totalPages }) => {
  const tagData = blogsData[0]?.attributes?.tags?.data?.[0]?.attributes;
  return (
    <>
      <Seo data={tagData?.seo} />
      {tagData?.schema && <Schema schema={tagData?.schema} />}
      <div className="page-title-area">
        <div className="container">
          <div className="page-title-content">
            <h1>Tag: {tagData?.title}</h1>
          </div>
        </div>
      </div>
      <GridContent blogsData={blogsData} totalPages={totalPages} />
    </>
  );
};

export default BlogCategories;

export async function getServerSideProps({ preview, params, query }) {
  const tagSlug = params["blog-tag"];
  let pageNumber = query.page || 1;
  const { data, errors } = await client.query({
    query: gql`
      query getTags {
        blogs(
          filters: { tags: { slug: { eq: "${tagSlug}" } } }
          pagination: { page: ${pageNumber}, pageSize: 6 }
          sort: "createdAt:desc"
        ) {
          data {
            id
            attributes {
              slug
              title
              createdAt
              publish_date
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              categories {
                data {
                  attributes {
                    title
                    slug
                    newsletter_section {
                      description
                    }
                  }
                }
              }
              tags (filters: { slug: { eq: "${tagSlug}" } } ) {
                data {
                  attributes {
                    title
                    slug
                    schema
                    ${getSeoData}
                  }
                }
              }
            }
          }
          meta {
            pagination {
              page
              pageSize
              total
              pageCount
            }
          }
        }
      }
    `,
  });

  // const { data, errors } = await client.query({
  //   query: gql`
  //     query getTag {
  //       tags(
  //        ${preview ? "publicationState:PREVIEW," : ""}
  //       filters: {
  //         slug: {
  //           eq: "${tagSlug}"
  //         }
  //       }
  //       ) {
  //         data {
  //           attributes {
  //             slug
  //             title
  //              blogs {
  //               data {
  //                 id
  //                 attributes {
  //                   slug
  //                   title
  //                   createdAt
  //                   image {
  //                     data {
  //                       attributes {
  //                         url
  //                       }
  //                     }
  //                   }
  //                   categories {
  //                     data {
  //                       attributes {
  //                         title
  //                         slug
  //                       }
  //                     }
  //                   }
  //                   tags {
  //                     data {
  //                       attributes {
  //                         title
  //                         slug
  //                       }
  //                     }
  //                   }
  //                 }
  //               }
  //             }
  //           }
  //         }
  //       }
  //     }
  //   `,
  // });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/${blogData?.slug}`,
        permanent: true,
      },
    };
  } else if (
    data?.blogs?.data?.length === 0 ||
    data?.tags?.data?.length === 0
  ) {
    return {
      redirect: {
        destination: `/evivvo-pedia/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      // tagData: data?.tags?.data?.[0]?.attributes || [],
      blogsData: data?.blogs?.data || [],
      totalPages: data?.blogs?.meta?.pagination?.pageCount || null,
    },
  };
}

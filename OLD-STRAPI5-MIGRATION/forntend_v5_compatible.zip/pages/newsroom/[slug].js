import BreadCrumbs from "@/components/Common/BreadCrumbs/BreadCrumbs";
import Seo from "@/components/Common/seo";
import Ctas from "@/components/Newsroom/Ctas";
import PressReleaseCards from "@/components/Newsroom/PressReleaseCards";
import CKEditor from "@/utils/CkEditor";
import { gql } from "@apollo/client";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import React from "react";

export default function Newsroom({ data, recentData }) {
  return (
    <>
      <Seo data={data?.seo} />
      <div className="press-release-breadcrumbs">
        <BreadCrumbs
          crumbs={[{ name: "Newsroom", link: "/newsroom" }]}
          currentPage={data?.title}
        />
      </div>
      <main className="press-release-main">
        <div className="container">
          <div className="press-release-detail-title">
            <h1>{data?.title}</h1>
          </div>
          <div className="press-release-detail-description">
            <CKEditor content={data?.description} />
          </div>
          {recentData?.length > 0 && (
            <div className="recent-press-releases-wrap">
              <h2 className="recent-press-releases-title">
                Recent Press Releases
              </h2>
              <PressReleaseCards pressReleases={recentData} />
            </div>
          )}
        </div>
        <Ctas ctasData={data?.ctas} />
      </main>
    </>
  );
}

export async function getServerSideProps({ preview, params }) {
  const slug = params["slug"];
  const { data, errors } = await client.query({
    query: gql`
       query pressReleaseData {
  pressReleases(filters: { slug: { eq: "${slug}" } }) {
    title
    slug
    description
    ctas {
      description_type {
        ... on ComponentCommonButton {
          button_text
          button_icon
          button_link
          button_target
        }
        ... on ComponentButtonButtonImageText {
          image {
            url
          }
          title
          description
          button_image_text_button {
            button_text
            button_icon
            button_link
            button_target
          }
        }
        ... on ComponentButtonButtonText {
          description
          button_text_button {
            button_text
            button_icon
            button_link
            button_target
          }
        }
        ... on ComponentButtonNewsletter {
          description
          form_onload
          form_onsubmit
        }
        ... on ComponentCommonAppDownload {
          sectionTitle
          title
          image {
            url
          }
          playstoreButtonText
          playstoreButtonLink
          applestoreButtonText
          applestoreButtonLink
        }
        ... on ComponentPopupPopup {
          title
          description
          popup_button {
            button_text
            button_icon
            button_link
            button_target
          }
          image {
            url
          }
        }
        ... on ComponentKnowledgeBase3CardsCtas {
          card {
            title
            description
            image {
              url
            }
            link_title
            link_href
            link_target
          }
        }
      }
    }

    seo {
      metaTitle
      metaDescription
      metaImage {
        url
      }
      metaSocial {
        socialNetwork
        title
        description
        image {
          url
        }
      }
      keywords
      metaRobots
      structuredData
      metaViewport
      canonicalURL
    }
  }
}
      `,
  });
  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/newsroom/${slug}`,
        permanent: true,
      },
    };
  }

  if (!data?.pressReleases[0]) {
    return {
      redirect: {
        destination: `/404?url=/newsroom/${slug}`,
        permanent: true,
      },
    };
  }

  const recentPressReleasesData = await client.query({
    query: gql`
        query recentPressReleasesData {
  pressReleases(
    filters: { slug: { ne: "${slug}" } }
    pagination: { limit: 4 }
  ) {
    title
    slug
    date
  }
}

      `,
  });
  return {
    props: {
      data: data?.pressReleases[0] || null,
      recentData: recentPressReleasesData?.data?.pressReleases,
    },
  };
}

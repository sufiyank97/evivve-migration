import BreadCrumbs from "@/components/Common/BreadCrumbs/BreadCrumbs";
import Seo from "@/components/Common/seo";
import Faq from "@/components/knowledgebase/Faq";
import LoadMoreButton from "@/components/Newsroom/common/LoadMoreButton";
import Ctas from "@/components/Newsroom/Ctas";
import Notes from "@/components/ReleaseNotes/Notes";
import NotesMobile from "@/components/ReleaseNotes/NotesMobile";
import { gql } from "@apollo/client";
import axios from "axios";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import Link from "next/link";
import React, { useState } from "react";

const topicsLimit = 6;

export default function index({
  knowledgeBasePageData,
  versionsResponse,
  topicsResponse,
}) {
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [topics, setTopics] = useState(topicsResponse);

  const handleSearchOnChange = async (e) => {
    const value = e.target.value;
    setSearch(value);
    if (value.length > 0) {
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_STRAPI_URL}api/knowledge-base/search?searchingText=${value}`
      );
      const data = res?.data?.data;
      if (data) {
        setSearchResults(data);
      }
    } else {
      setSearchResults([]);
    }
  };

  const [isLoading, setIsLoading] = useState(false);
  const handleLoadMore = async () => {
    try {
      setIsLoading(true);
      const res = await axios.get(
        `${
          process.env.NEXT_PUBLIC_STRAPI_URL
        }api/knowledge-base-page/topics?start=${topicsLimit}&limit=${
          topicsResponse?.meta?.total - topicsLimit
        }`
      );

      setTopics((prevTopics) => ({
        data: [...prevTopics.data, ...res.data.data],
        meta: {
          ...res.data.meta,
          total: res.data.meta.total,
          start: prevTopics.meta.start + topicsLimit,
          hasMore: res.data.meta.hasMore,
        },
      }));
    } catch (error) {
      console.error("Error fetching topics:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Seo data={knowledgeBasePageData?.seo} />
      <BreadCrumbs currentPage={"Knowledge Base"} />
      <div className="page-title-area">
        <div className="container">
          <div className="page-title-content">
            {knowledgeBasePageData?.sub_title && (
              <span className="sub-title">
                {knowledgeBasePageData?.sub_title}
              </span>
            )}
            <h1>{knowledgeBasePageData?.title}</h1>
            <form className="knowledge-base-search-form">
              <label>
                <i className="bx bx-search"></i>
              </label>
              <input
                type="text"
                className="input-search"
                placeholder="Search..."
                value={search}
                autoComplete="off"
                onChange={handleSearchOnChange}
              />
              <button type="button">Search</button>
              {searchResults.length > 0 && (
                <div className="search-dropdown">
                  {searchResults?.map((item, i) => {
                    return (
                      <Link
                        href={`/knowledge-base/${item?.attributes?.slug}`}
                        key={i}
                      >
                        <a
                          onClick={() => {
                            setSearch("");
                            setSearchResults([]);
                          }}
                        >
                          {item?.attributes?.title}
                        </a>
                      </Link>
                    );
                  })}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
      <div className="container">
        <div className="release-notes-page-description-area knowledge-base-page-topics-area">
          <Notes versions={versionsResponse} />
          <div>
            <h1 className="release-notes-page-title">
              {knowledgeBasePageData?.knowledge_base_topic_title}
            </h1>
            <div className="knowledge-base-page-topics-cards">
              {topics?.data?.map((topic, index) => {
                const base_version = topic?.inv_version || "";
                return (
                  <Link href={`/knowledge-base/${topic?.slug}`} key={index}>
                    <a>
                      <p
                        style={{
                          color: "#5B105A",
                          textTransform: "capitalize",
                          fontWeight: "700",
                          opacity: base_version ? "1" : "0",
                        }}
                      >
                        // {base_version} //
                      </p>
                      <p style={{ color: "black" }}>{topic?.title}</p>
                    </a>
                  </Link>
                );
              })}
            </div>
            {topics?.meta?.hasMore && (
              <div style={{ marginTop: "50px" }}>
                <LoadMoreButton
                  text={isLoading ? "Loading..." : "Load More"}
                  onClickFun={handleLoadMore}
                  disabled={isLoading}
                />
              </div>
            )}
          </div>
        </div>
        {knowledgeBasePageData?.featured_faq && (
          <Faq data={knowledgeBasePageData?.featured_faq} />
        )}
      </div>
      <NotesMobile versionsResponse={versionsResponse} />
      <Ctas ctasData={knowledgeBasePageData?.ctas} />
    </>
  );
}

export async function getServerSideProps({ preview }) {
  const { data, errors } = await client.query({
    query: gql`
          query knowledgeBasePageData {
            knowledgeBasePage ${preview ? "(publicationState:PREVIEW)" : ""} {
              data {
                  attributes {
                    sub_title
                    title
                    knowledge_base_topic_title
                    featured_faq {
                      title
                      faq {
                        question
                        answer
                      }
                    }
                    ctas{
                      data{
                        attributes{
                          description_type {
                            ... on ComponentCommonButton {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            ... on ComponentButtonButtonImageText {
                              image {
                                data {
                                  attributes {
                                    url
                                  }
                                }
                              }
                              title
                              description
                              button_image_text_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                            }
                            ... on ComponentButtonButtonText {
                              description
                              button_text_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                            }
                            ... on ComponentButtonNewsletter {
                              description
                              form_onload
                              form_onsubmit
                            }
                            ... on ComponentCommonAppDownload {
                              sectionTitle
                              title
                              image {
                                data {
                                  attributes {
                                    url
                                  }
                                }
                              }
                              playstoreButtonText
                              playstoreButtonLink
                              applestoreButtonText
                              applestoreButtonLink
                            }
                            ... on ComponentPopupPopup{
                              title
                              description
                              popup_button {
                                button_text
                                button_icon
                                button_link
                                button_target
                              }
                              image{
                                data{
                                  attributes{
                                    url
                                  }
                                }
                              }
                            }
                            ... on ComponentKnowledgeBase3CardsCtas {
                              card {
                                title
                                description
                                image {
                                  data {
                                    attributes {
                                      url
                                    }
                                  }
                                }
                                link_title
                                link_href
                                link_target
                              }
                            }
                          }
                        }
                      }
                    }
                    ${getSeoData}
                  }
              }
            }
          }
        `,
  });
  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/knowledge-base/`,
        permanent: true,
      },
    };
  }

  const [versionsResult, topicsResult] = await Promise.all([
    axios.get(
      `${process.env.NEXT_PUBLIC_STRAPI_URL}api/knowledge-base/base-versions`
    ),
    axios.get(
      `${process.env.NEXT_PUBLIC_STRAPI_URL}api/knowledge-base-page/topics?start=0&limit=${topicsLimit}`
    ),
  ]);

  const versionsResponse = versionsResult?.data?.data;
  const topicsResponse = topicsResult?.data;

  return {
    props: {
      knowledgeBasePageData: data?.knowledgeBasePage?.data?.attributes || null,
      versionsResponse: versionsResponse || [],
      topicsResponse: topicsResponse || [],
    },
  };
}

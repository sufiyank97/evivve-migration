import React from "react";
import dynamic from "next/dynamic";
const EventDetailsComponent = dynamic(() =>
  import("@/components/Events/EventDetailsComponent")
);
const BannerComponent = dynamic(() =>
  import("@/components/Common/Banner/BannerComponent")
);
import { gql } from "@apollo/client";
import client from "lib/apollo-client/ApolloClient";
import Schema from "@/components/Common/Schema";

export default function EventDetails({ eventData }) {
  return (
    <>
      {eventData?.schema && <Schema schema={eventData?.schema} />}
      <BannerComponent title="Event Details" />
      <EventDetailsComponent eventData={eventData} />
    </>
  );
}

export async function getServerSideProps({ params }) {
  const eventSlug = params["event-details"];
  const { data, errors } = await client.query({
    query: gql`
      query getEvents {
        events(filters: {
            slug: {
              eq: "${eventSlug}"
            }
          }) {
          data {
            attributes {
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              title
              slug
              Date
              location
              description
              schema
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/events/`,
        permanent: true,
      },
    };
  } else if (data?.events?.data?.length === 0) {
    return {
      redirect: {
        destination: `/events/`,
        permanent: true,
      },
    };
  }
  return {
    props: {
      eventData: data?.events?.data[0]?.attributes || null,
    },
  };
}

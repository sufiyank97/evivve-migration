import React from "react";
import dynamic from "next/dynamic";
const EventsList = dynamic(() => import("@/components/Events/EventsList"));
const BannerComponent = dynamic(() =>
  import("@/components/Common/Banner/BannerComponent")
);
import { gql } from "@apollo/client";
import client from "lib/apollo-client/ApolloClient";

export default function Events({ eventsData, totalPages }) {
  return (
    <>
      <BannerComponent title="Events" />
      <EventsList eventsData={eventsData} totalPages={totalPages} />
    </>
  );
}

export async function getServerSideProps({ req, query }) {
  let pageNumber = query.page || 1;
  const { data, errors } = await client.query({
    query: gql`
      query getEvents {
        events(pagination: { page: ${pageNumber}, pageSize: 1 }) {
          data {
            attributes {
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              title
              slug
              Date
              location
            }
          }
          meta {
            pagination {
              page
              pageSize
              total
              pageCount
            }
          }
        }
      }
    `,
  });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/events/`,
        permanent: true,
      },
    };
  }
  return {
    props: {
      eventsData: data?.events?.data,
      totalPages: data?.events?.meta?.pagination?.pageCount || null,
    },
  };
}

import React, { useState } from "react";
// import AOS from "aos";
import "../node_modules/aos/dist/aos.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "/styles/flaticon.css";
import "/styles/boxicons.min.css";
import "swiper/css/bundle";
import "swiper/css/effect-fade";
import "swiper/css/pagination";
import "swiper/css/navigation";
import "react-tabs/style/react-tabs.css";
import "/styles/faq.css";
import "/styles/global.css";
import "/styles/style.css";
import "/styles/header.css";
import "/styles/footer.css";
import "/styles/contact.css";
import "/styles/about.css";
import "/styles/404.css";
import "/styles/auth.css";
import "/styles/aferr-master.css";
import "/styles/case-study-detail.css";
import "/styles/blog.css";
import "/styles/responsive.css";
import "/styles/onboarding.css";
import "/styles/usecases.css";
import "/styles/webinar.css";
import "/styles/template-pages-custom-navbar.css";
import "/styles/landing-page-template3.css";
import "/styles/landing-page-template4.css";
import "/styles/landing-page-template5.css";
import "/styles/pricing.css";
import "/styles/newsroom.css";
import "/styles/release-notes.css";
import "/styles/case-study.css";
import "/styles/play-live.css";
import "/styles/adventure.css";
import "/styles/labs.css";
import "/styles/new-play-now.css";
import "../components/Common/Pagination/Pagination.css";
import "react-tooltip/dist/react-tooltip.css";
import "react-lite-youtube-embed/dist/LiteYouTubeEmbed.css";

import ScrollToTop from "@/components/Layout/ScrollToTop";

import Head from "next/head";
import dynamic from "next/dynamic";
const Navbar = dynamic(() => import("@/components/Layout/Navigations/Navbar1"));
const FooterTwo = dynamic(() => import("@/components/Layout/Footer/FooterTwo"));
import { useRouter } from "next/router";
import axios from "axios";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import Cookies from "js-cookie";
import { AppContextProvider } from "context/AppContextProvider";
import Script from "next/script";

function MyApp({
  Component,
  pageProps,
  onboarding,
  commonData,
  host,
  landingPagesData,
  headerData,
  footerData,
}) {
  React.useEffect(() => {
    // AOS && AOS?.init();
    const aosInit = async () => {
      const AOS = await import("aos");
      AOS.init();
    };
    aosInit();
  }, []);
  const router = useRouter();

  const hideNavbar = [
    // "/404",
    "/500",
    "/coming-soon",
    "/forgot-password",
    // "/sign-in",
    // "/sign-up",
    // "/thank-you",
    "/onboarding",
    "/",
  ];
  const hideFooter = [
    // "/404",
    "/500",
    "/coming-soon",
    "/forgot-password",
    // "/sign-in",
    // "/sign-up",
    // "/thank-you",
    "/onboarding",
    "/",
  ];

  const [showOnboarding, setShowOnboarding] = useState(
    // onboarding ? false : true
    false
  );

  const hideNavandFooter = showOnboarding && router.pathname === "/";

  const filteredLandingPagesSlugs = landingPagesData
    ?.filter((page) =>
      page?.attributes?.templates?.some(
        (template) =>
          template?.__typename === "ComponentLandingPageMasterclass" ||
          template?.__typename === "ComponentLandingPageTemplate2" ||
          template?.__typename === "ComponentLandingPageTemplate4"
      )
    )
    ?.map((page) => page?.attributes?.slug);

  const hideNavbarAndFooterInLandingPages = filteredLandingPagesSlugs?.includes(
    router.query["blog-details"]
  );

  return (
    <>
      <Head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Evivve</title>
        {commonData?.favIcon?.data && (
          <link
            rel="shortcut icon"
            href={commonData?.favIcon?.data?.attributes?.url}
          />
        )}
      </Head>
      <Script id="show-banner" strategy="afterInteractive">
        {`!function(){var e=[].slice.call(document.querySelectorAll("video.lazy"));if("IntersectionObserver"in window){var r=new IntersectionObserver(function(e,t){e.forEach(function(e){if(e.isIntersecting){for(var t in e.target.children){var a=e.target.children[t];"string"==typeof a.tagName&&"SOURCE"===a.tagName&&(a.src=a.dataset.src)}e.target.load(),e.target.classList.remove("lazy"),r.unobserve(e.target)}})});e.forEach(function(e){r.observe(e)})}}();`}
      </Script>
      <AppContextProvider headerData={headerData}>
        {!hideNavandFooter &&
          !hideNavbar.includes(router.pathname) &&
          !hideNavbarAndFooterInLandingPages && (
            <Navbar
              header={headerData}
              logo={commonData?.logo?.data?.attributes?.url}
              top_sticky_stripe={commonData?.top_sticky_stripe}
              host={host}
            />
          )}
        <Component
          {...pageProps}
          commonData={commonData}
          showOnboarding={showOnboarding}
          setShowOnboarding={setShowOnboarding}
          headerData={headerData}
          footerData={footerData}
          logo={commonData?.logo?.data?.attributes?.url}
          top_sticky_stripe={commonData?.top_sticky_stripe}
          host={host}
        />
        {!hideFooter.includes(router.pathname) &&
          !hideNavbarAndFooterInLandingPages && (
            <FooterTwo
              footerData={footerData}
              commonData={commonData}
              showOnboarding={showOnboarding}
            />
          )}
        <ScrollToTop />
      </AppContextProvider>
    </>
  );
}

MyApp.getInitialProps = async ({ ctx }) => {
  const { req } = ctx;
  const host = req?.headers?.host;

  const onboarding =
    req?.cookies["evivve-onboarding-completed"] ||
    (typeof window !== "undefined"
      ? Cookies.get("evivve-onboarding-completed")
      : null);

  // Apollo query for Strapi v5
  const { data, errors } = await client.query({
    query: gql`
      query getData {
        common {
          logo {
            url
          }
          favIcon {
            url
          }
          social_media {
            name
            link
          }
          download_app {
            android {
              url
              width
              height
            }
            ios {
              url
              width
              height
            }
            android_link
            ios_link
          }
          footer {
            footer_description
            copyright
            logo {
              url
            }
          }
          top_sticky_stripe {
            description
            top_sticky_stripe_button {
              button_text
              button_icon
              button_link
              button_target
            }
            visible
          }
        }
        landingPages {
          title
          slug
          templates {
            __typename
          }
        }
      }
    `,
  });

  if (errors && errors.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/`,
        permanent: true,
      },
    };
  }

  // Axios call for navigation
  const res = await axios.get(
    `${process.env.NEXT_PUBLIC_STRAPI_URL}api/navigation/all`
  );
  const headerData =
    res?.data?.data
      ?.find((item) => item?.attributes?.title === "Header")
      ?.attributes?.items?.data.sort(
        (a, b) => a?.attributes?.order - b?.attributes?.order
      ) || [];

  const footerData =
    res?.data?.data
      ?.find((item) => item?.attributes?.title === "Footer")
      ?.attributes?.items?.data.sort(
        (a, b) => a?.attributes?.order - b?.attributes?.order
      ) || [];

  return {
    onboarding,
    commonData: data?.common || null,
    host: host || "",
    landingPagesData: data?.landingPages || null,
    headerData,
    footerData,
  };
};

export default MyApp;

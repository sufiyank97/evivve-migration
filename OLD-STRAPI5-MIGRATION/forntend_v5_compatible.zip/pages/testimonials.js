import BottomSection from "@/components/CaseStudy/BottomSection";
import FirstSection from "@/components/CaseStudy/FirstSection";
import PaysOffSection from "@/components/CaseStudy/PaysOffSection";
import TeamSection from "@/components/CaseStudy/TeamSection";
import Testimonials from "@/components/CaseStudy/Testimonials";
import Seo from "@/components/Common/seo";
import Template4Brands from "@/components/LandingPages/template4/Template4Brands";
import { gql } from "@apollo/client";
import { getSeoData } from "graphql/getSeoData";
import client from "lib/apollo-client/ApolloClient";
import React from "react";

export default function NewTestimonials({ caseStudyData }) {
  return (
    <>
      <Seo data={caseStudyData?.seo} />
      <main className="new-testimonials-main">
        <FirstSection data={caseStudyData?.first_section_swiper_list} />
        {caseStudyData?.brands_section && (
          <Template4Brands data={caseStudyData?.brands_section} />
        )}
        {caseStudyData?.team_section && (
          <TeamSection data={caseStudyData?.team_section} />
        )}
        {caseStudyData?.testimonials && (
          <Testimonials data={caseStudyData?.testimonials} />
        )}
        {caseStudyData?.pay_offs_section && (
          <PaysOffSection data={caseStudyData?.pay_offs_section} />
        )}
        {caseStudyData?.get_started && (
          <BottomSection data={caseStudyData?.get_started} />
        )}
      </main>
    </>
  );
}

export async function getServerSideProps({ preview }) {
  const queryString = preview
    ? `query CaseStudyPageData {
        caseStudies(publicationState: PREVIEW, filters: { slug: { eq: "testimonials" } }) {
          data {
            id
            attributes {
              first_section_swiper_list {
                title
                description
                video
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              brands_section {
                title
                brands {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
              }
              team_section {
                title
                team_section_list {
                  title
                  video
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  logo {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                }
              }
              testimonials {
                title
                testimonials {
                  data {
                    attributes {
                      title
                      description
                      name
                      designation
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      linkedin
                    }
                  }
                }
              }
              pay_offs_section {
                title
                list {
                  title
                  description
                }
              }
              get_started {
                title
                case_study_get_started_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              ${getSeoData}
            }
          }
        }
      }`
    : `query CaseStudyPageData {
        caseStudies(filters: { slug: { eq: "testimonials" } }) {
          data {
            id
            attributes {
              first_section_swiper_list {
                title
                description
                video
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              brands_section {
                title
                brands {
                  data {
                    attributes {
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
              }
              team_section {
                title
                team_section_list {
                  title
                  video
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  logo {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                }
              }
              testimonials {
                title
                testimonials {
                  data {
                    attributes {
                      title
                      description
                      name
                      designation
                      image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                      linkedin
                    }
                  }
                }
              }
              pay_offs_section {
                title
                list {
                  title
                  description
                }
              }
              get_started {
                title
                case_study_get_started_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              ${getSeoData}
            }
          }
        }
      }`;

  const { data, errors } = await client.query({
    query: gql(queryString),
  });
  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/testimonials/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      caseStudyData: data?.caseStudies?.data?.[0]?.attributes || null,
    },
  };
}

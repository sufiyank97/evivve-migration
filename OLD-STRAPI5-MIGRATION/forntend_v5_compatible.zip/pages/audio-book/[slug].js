import React, { useContext, useEffect } from "react";
import dynamic from "next/dynamic";
import { fetchAudioBookData } from "graphql/getAudioBook";
import { convertToBase64 } from "@/utils/helper";
const Seo = dynamic(() => import("@/components/Common/seo"));
import { AppContext } from "context/AppContextProvider";
import { useRouter } from "next/router";
import Schema from "@/components/Common/Schema";
import CaseStudyDetail from "@/components/LandingPages/aferrMaster/CaseStudyDetail";

const AudioBookPage = ({ audioBookData, seoData }) => {
  const { setLoading } = useContext(AppContext);
  const router = useRouter();

  useEffect(() => {
    if (setLoading) {
      setLoading(false);
    }
  }, [setLoading]);

  if (!audioBookData) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <h1>Audio Book Not Found</h1>
        <p>The audio book "{router.query.slug}" could not be found.</p>
        <a href="/audio-book">← Back to Audio Books</a>
      </div>
    );
  }

  const { attributes } = audioBookData;
  const { templates } = attributes;

  // Get the first template (since we only expect one per audio book)
  const template = templates?.[0];

  if (!template) {
    return <div>No template found for this audio book</div>;
  }

  return (
    <>
      <Seo seoData={seoData} />
      <Schema schemaData={seoData} />
      <CaseStudyDetail data={template} />
    </>
  );
};

export async function getServerSideProps(context) {
  const { params } = context;
  const { preview } = context.query;
  const { slug } = params;

  try {
    console.log(`Fetching audio book data for slug: ${slug}`);
    const { data, error } = await fetchAudioBookData(slug, preview);
    
    console.log("Audio book query result:", { data, error });
    
    if (error) {
      console.error("GraphQL error:", error);
      return {
        redirect: {
          destination: `/500?url=${encodeURIComponent(`/audio-book/${slug}`)}`,
          permanent: false,
        },
      };
    }
    
    if (!data?.audioBooks?.data?.length) {
      console.log("No audio book found for slug:", slug);
      return {
        redirect: {
          destination: `/404?url=${encodeURIComponent(`/audio-book/${slug}`)}`,
          permanent: false,
        },
      };
    }

    const audioBookData = data.audioBooks.data[0];
    const seoData = audioBookData.attributes.seo || null;

    return {
      props: {
        audioBookData,
        seoData,
      },
    };
  } catch (error) {
    console.error("Error fetching audio book data:", error);
    return {
      redirect: {
        destination: `/500?url=${encodeURIComponent(`/audio-book/${slug}`)}`,
        permanent: false,
      },
    };
  }
}

export default AudioBookPage;

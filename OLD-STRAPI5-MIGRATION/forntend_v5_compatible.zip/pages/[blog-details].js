import React, { useContext, useEffect, useState } from "react";
import dynamic from "next/dynamic";
const DetailsContent = dynamic(
  () => import("@/components/Blog/BlogDetails/DetailsContent")
);
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import Link from "next/link";
import {
  fetchBlogData,
  fetchLandingPages,
  fetchPopularBlogs,
  fetchScienceLabPages,
  fetchThankYouPages,
  fetchUseCases,
  // getBlogDetail,
} from "graphql/getBlogDetails";
const BreadCrumbs = dynamic(
  () => import("@/components/Common/BreadCrumbs/BreadCrumbs")
);
import { convertToBase64 } from "@/utils/helper";
const Seo = dynamic(() => import("@/components/Common/seo"));
import { AppContext } from "context/AppContextProvider";
import { useRouter } from "next/router";
import Schema from "@/components/Common/Schema";
import Template3 from "@/components/LandingPages/template3/Template3";
import ScrollProgress from "@/components/Common/ScrollProgress";
import Template4 from "@/components/LandingPages/template4/Template4";
import Template5 from "@/components/LandingPages/template5/Template5";
import PlayLiveMainComponent from "@/components/Play/PlayLiveMainComponent";
import Adventure from "@/components/LandingPages/adventure/Adventure";
const BannerSection = dynamic(
  () => import("@/components/UseCases/BannerSection")
);
const BenifitsSection = dynamic(
  () => import("@/components/UseCases/BenifitsSection")
);
const ExploreSection = dynamic(
  () => import("@/components/UseCases/ExploreSection")
);
const Features = dynamic(() => import("@/components/UseCases/Features"));
const ReadySection = dynamic(
  () => import("@/components/UseCases/ReadySection")
);
const UseCaseDescription = dynamic(
  () => import("@/components/UseCases/UseCaseDescription")
);
const Faq = dynamic(() => import("@/components/Pricing/Faq"));
const DescriptionTypes = dynamic(
  () => import("@/components/UseCases/DescriptionTypes")
);
const ExitIntentPopup = dynamic(
  () => import("@/components/Common/ExitIntentPopup")
);
const ThankYou = dynamic(() =>
  import("@/components/ThankYou/ThankYou").then((mod) => mod.ThankYou)
);
const Template1 = dynamic(
  () => import("@/components/LandingPages/template1/Template1"),
  {
    ssr: false,
  }
);
const Template2 = dynamic(
  () => import("@/components/LandingPages/template2/Template2"),
  {
    ssr: false,
  }
);
import NewPricingFaq from "@/components/NewPricing/Faq";
import ScienceLab from "@/components/Labs/ScienceLab";

const BlogDetails = ({
  blogData,
  popularBlogs,
  useCasesData,
  thankYouPagesData,
  landingPagesData,
  scienceLabPagesData,
  top_sticky_stripe,
  logo,
  headerData,
  footerData,
  commonData,
  host,
}) => {
  const blog = blogData ? blogData[0] : {};
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [relatedBlogs, setRelatedBlogs] = useState([]);
  const blogId = blogData ? blogData[0]?.documentId : null;
  const { showStripe } = useContext(AppContext);

  const getBlogsData = async (value) => {
    if (value?.length > 0) {
      let { data, errors } = await client.query({
        query: gql`
  query getBlogsSearchedData {
    blogs_connection(
      filters: {
        title: {
          containsi: "${value}"
        }
      }
    ) {
      nodes {
        title
        slug
      }
      pageInfo {
        total
      }
    }
  }
`,
      });
      if (errors?.length > 0) {
        console.log("errors:", errors);
      } else {
        setSearchResults(data?.blogs?.data);
      }
    } else {
      setSearchResults([]);
    }
  };

  const removeDuplicateBlogs = (data) => {
    const uniqueBlogIds = new Set();
    const uniqueBlogs = data?.map((tag) => {
      if (tag?.attributes?.blogs && tag?.attributes?.blogs?.data) {
        const uniqueBlogsData = tag.attributes.blogs.data.filter((blog) => {
          if (!uniqueBlogIds.has(blog.id)) {
            uniqueBlogIds.add(blog.id);
            return true;
          }
          return false;
        });
        tag.attributes.blogs.data = uniqueBlogsData;
      }
      return tag;
    });

    return uniqueBlogs;
  };

  const getRelatedBlogs = (...arrays) => {
    const newArray = [];

    for (let i = 0; i < 3; i++) {
      // const currentArray = arrays[i];

      for (const currentArray of arrays) {
        if (currentArray && currentArray.length > i) {
          newArray.push(currentArray[i]);
        }
        if (newArray.length === 3) {
          break; // Break the inner loop once three elements are added to newArray
        }
      }

      if (newArray.length === 3) {
        break; // Break the outer loop if three elements are already in newArray
      }
    }

    return newArray;
  };

  const updateImageToBase64 = async (item) => {
    const base64Image = await convertToBase64(item?.image?.url);
    return {
      ...item,
      base64Image,
    };
  };

  const getTagsData = async () => {
    const tagSlugArray = blog?.tags?.map((item) => item?.slug);
    console.log("tagSlugArray", tagSlugArray);

    if (tagSlugArray?.length > 0) {
      const { data, errors } = await client.query({
        query: gql`
        query getTag {
  tags(filters: { slug: { in: [${tagSlugArray.map(
    (slug) => `"${slug}"`
  )}] } }) {
    slug
    title
    blogs(
      filters: {
        slug: { ne: "${blog?.slug}" }
      }
      sort: "createdAt:desc"
    ) {
      documentId
      slug
      title
      createdAt
      publish_date
      image {
        url
      }
      categories {
        title
        slug
      }
      tags {
        title
        slug
      }
    }
  }
}
      `,
      });
      console.log(data, "tagsData");
      
      if (data?.tags === 0) {
        return {
          redirect: {
            destination: `/evivvo-pedia/`,
            permanent: true,
          },
        };
      }

      const modifiedData = removeDuplicateBlogs(data?.tags);
      const sortedArray = modifiedData
        ?.filter((tag) => tag?.blogs?.length > 0)
        ?.sort((a, b) => b?.blogs?.length - a?.blogs?.length)
        .slice(0, 3);
      // console.log("sortedArray", sortedArray);

      // Function to extract blogs array from each object
      const extractBlogsArray = (tagObject) => {
        const blogsData = tagObject?.blogs || [];
        return blogsData;
      };

      // Create separate arrays for each tag
      const tagArrays = sortedArray?.map((tag) => extractBlogsArray(tag));
      // console.log("tagArrays", tagArrays);
      const resultArray = getRelatedBlogs(...tagArrays);
      // console.log("resultArray", resultArray);
      let asyncCalls = [];
      resultArray?.map((item) => {
        asyncCalls.push(updateImageToBase64(item));
      });
      const relatedBlogArray = await Promise.all(asyncCalls);
      console.log("relatedBlogArray", relatedBlogArray);
      setRelatedBlogs(relatedBlogArray);
    }
  };

  const [popup, setPopup] = useState({});
  const [showPopup, setShowPopup] = useState(false);
  const [exitIntentCloseCookies, setExitIntentCloseCookies] = useState(false);
  const router = useRouter();
  const currentSlug = router.asPath;

  const getPopupData = () => {
    let filteredPopupData = [];
    if (blogData && blogData[0]) {
      filteredPopupData = blogData[0]?.ctas?.filter((item) =>
        item?.description_type?.find(
          (subItem) => subItem?.__typename === "ComponentPopupPopup"
        )
      );
    } else if (useCasesData && useCasesData[0]) {
      filteredPopupData = useCasesData[0]?.ctas?.filter((item) =>
        item?.description_type?.find(
          (subItem) => subItem?.__typename === "ComponentPopupPopup"
        )
      );
    }
    const popupData =
      filteredPopupData &&
      filteredPopupData[0]?.attributes?.description_type[0];
    setPopup(popupData);
  };

  useEffect(() => {
    getTagsData();
    getPopupData();
  }, [blogData]);

  useEffect(() => {
    const exitIntentClosed = sessionStorage.getItem(
      `exit-intent-close-${currentSlug}`
    );
    exitIntentClosed
      ? setExitIntentCloseCookies(true)
      : setExitIntentCloseCookies(false);
  }, [router.asPath]);

  useEffect(() => {
    const handleMouseLeave = (event) => {
      if (event.clientY < (showStripe ? 150 : 100) && !exitIntentCloseCookies) {
        // console.log("event", event.clientY);
        setShowPopup(true);
      }
    };

    const handleMouseMove = () => {
      setExitIntentCloseCookies(
        sessionStorage.getItem(`exit-intent-close-${currentSlug}`) === "true"
      );
    };

    !exitIntentCloseCookies &&
      popup &&
      document.addEventListener("mousemove", handleMouseLeave);

    !exitIntentCloseCookies && popup
      ? document.addEventListener("mousemove", handleMouseMove)
      : document.removeEventListener("mousemove", handleMouseMove);

    return () => {
      document.removeEventListener("mousemove", handleMouseLeave);
      document.removeEventListener("mousemove", handleMouseMove);
    };
  }, [exitIntentCloseCookies]);

  const handleCloseExitIntentPopup = () => {
    setShowPopup(false);
    sessionStorage.setItem(`exit-intent-close-${currentSlug}`, true);
    setExitIntentCloseCookies(true);
  };

  if (blogData?.length > 0) {
    return (
      <>
        <Seo data={blog?.seo} />
        {blog?.schema && <Schema schema={blog?.schema} />}
        <BreadCrumbs
          currentPage={blog?.title}
          crumbs={[{ name: "Evivvo Pedia", link: "evivvo-pedia" }]}
        />
        <ScrollProgress />
        <div className="page-title-area pb-0">
          <div className="container blog-detail-banner">
            <div className="page-title-content mt-5">
              {/* <span className="sub-title green-color">Blog Details</span> */}
              <h1>
                <span>
                  {blog?.title?.substring(0, blog?.title?.length * (1 / 2))}
                </span>
                <span>
                  {blog?.title?.substring(
                    blog?.title?.length * (1 / 2),
                    blog?.title?.length
                  )}
                </span>
              </h1>
            </div>
            <div className="widget-area pt-5 pb-3 d-flex justify-content-end">
              <div className="widget widget_search">
                <div
                  className="form search-input bg-f2003c"
                  style={{ position: "relative" }}
                >
                  <div className="form-group d-flex">
                    <input
                      type="text"
                      name="name"
                      className="form-control"
                      placeholder="Search..."
                      value={search}
                      onChange={(e) => {
                        getBlogsData(e.target.value);
                        setSearch(e.target.value);
                      }}
                    />
                    <div className="px-3 bg-f2003c d-flex align-items-center icon-wrap">
                      <i
                        className="bx bx-search"
                        style={{ color: "#ffffff" }}
                      ></i>
                    </div>
                  </div>
                  {searchResults.length > 0 && (
                    <div className="search-dropdown">
                      {searchResults?.map((item, i) => {
                        return (
                          <Link href={`/${item?.attributes?.slug}`} key={i}>
                            <a
                              onClick={() => {
                                setSearch("");
                                setSearchResults([]);
                              }}
                            >
                              {item?.attributes?.title}
                            </a>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        <DetailsContent
          blogData={blog}
          popularBlogs={popularBlogs}
          blogId={blogId}
          relatedBlogs={relatedBlogs}
        />
        {showPopup && popup && (
          <ExitIntentPopup
            data={popup}
            handleCloseExitIntentPopup={handleCloseExitIntentPopup}
          />
        )}
      </>
    );
  } else if (useCasesData?.length > 0) {
    return (
      <div className="usecases">
        <Seo data={useCasesData[0]?.attributes?.seo} />
        {useCasesData[0]?.attributes?.schema && (
          <Schema schema={useCasesData[0]?.attributes?.schema} />
        )}
        <BreadCrumbs currentPage={useCasesData[0]?.attributes?.slug} />
        <BannerSection data={useCasesData[0]?.attributes?.banner} />
        <BenifitsSection data={useCasesData[0]?.attributes?.benefits} />
        <UseCaseDescription data={useCasesData[0]?.attributes?.description} />
        <Features data={useCasesData[0]?.attributes?.features} />
        <ReadySection data={useCasesData[0]?.attributes?.ready_section} />
        <ExploreSection data={useCasesData[0]?.attributes?.explore} />
        {useCasesData[0]?.attributes?.faq_section && (
          // <Faq faqData={useCasesData[0]?.attributes?.faq_section} />
          <NewPricingFaq
            title={useCasesData[0]?.attributes?.faq_section?.title}
            faq={useCasesData[0]?.attributes?.faq_section?.faq}
          />
        )}
        <DescriptionTypes
          description_type={useCasesData[0]?.attributes?.description_type}
          ctas={useCasesData[0]?.attributes?.ctas}
        />
        {showPopup && popup && (
          <ExitIntentPopup
            data={popup}
            handleCloseExitIntentPopup={handleCloseExitIntentPopup}
          />
        )}
      </div>
    );
  } else if (thankYouPagesData?.length > 0) {
    return <ThankYou thankYouData={thankYouPagesData[0]?.attributes} />;
  } else if (landingPagesData?.length > 0) {
    if (
      landingPagesData[0]?.attributes?.templates[0]?.__typename ===
      "ComponentLandingPageMasterclass"
    ) {
      return (
        <Template1
          data={landingPagesData[0]?.attributes}
          top_sticky_stripe={top_sticky_stripe}
          logo={logo}
          headerData={headerData}
          footerData={footerData}
          commonData={commonData}
          host={host}
        />
      );
    } else if (
      landingPagesData[0]?.attributes?.templates[0]?.__typename ===
      "ComponentLandingPageTemplate2"
    ) {
      return (
        <Template2
          data={landingPagesData[0]?.attributes}
          top_sticky_stripe={top_sticky_stripe}
          logo={logo}
          headerData={headerData}
          footerData={footerData}
          commonData={commonData}
          host={host}
        />
      );
    } else if (
      landingPagesData[0]?.attributes?.templates[0]?.__typename ===
      "ComponentLandingPageTemplate3"
    ) {
      return <Template3 data={landingPagesData[0]?.attributes} />;
    } else if (
      landingPagesData[0]?.attributes?.templates[0]?.__typename ===
      "ComponentLandingPageTemplate4"
    ) {
      return (
        <Template4
          data={landingPagesData[0]?.attributes}
          top_sticky_stripe={top_sticky_stripe}
          logo={logo}
          headerData={headerData}
          footerData={footerData}
          commonData={commonData}
          host={host}
        />
      );
    } else if (
      landingPagesData[0]?.attributes?.templates[0]?.__typename ===
      "ComponentLandingPageTemplate5"
    ) {
      return <Template5 data={landingPagesData[0]?.attributes} />;
    } else if (
      landingPagesData[0]?.attributes?.templates[0]?.__typename ===
      "ComponentLandingPageLiveSession"
    ) {
      return <PlayLiveMainComponent data={landingPagesData[0]?.attributes} />;
    } else if (
      landingPagesData[0]?.attributes?.templates[0]?.__typename ===
      "ComponentLandingPageAdventure"
    ) {
      return <Adventure data={landingPagesData[0]?.attributes} />;
    } else return null;
  } else if (scienceLabPagesData?.length > 0) {
    return <ScienceLab labData={scienceLabPagesData[0]?.attributes} />;
  } else {
    return null;
  }
};

export default BlogDetails;

export async function getServerSideProps(context) {
  const blogSlug = context?.params["blog-details"];

  try {
    const [
      blogData,
      popularBlogs,
      useCasesData,
      thankYouPagesData,
      landingPagesData,
      scienceLabPagesData,
    ] = await Promise.all([
      fetchBlogData(blogSlug, context?.preview),
      // fetchPopularBlogs(),
      // fetchUseCases(blogSlug, context?.preview),
      // fetchThankYouPages(blogSlug, context?.preview),
      // fetchLandingPages(blogSlug, context?.preview),
      // fetchScienceLabPages(blogSlug, context?.preview),
    ]);

    // // Handling no data case
    // if (
    //   !blogData?.data?.blogs?.data?.length &&
    //   !thankYouPagesData?.data?.thankYouPages?.data?.length &&
    //   !useCasesData?.data?.useCases?.data?.length &&
    //   !landingPagesData?.data?.landingPages?.data?.length &&
    //   !scienceLabPagesData?.data?.scienceLabs?.data?.length
    // ) {
    //   return {
    //     redirect: {
    //       destination: `/evivvo-pedia/`,
    //       permanent: true,
    //     },
    //   };
    // }
    console.log("blogData:--------->", blogData?.data?.blogs);

    return {
      props: {
        blogData: blogData?.data?.blogs || [],
        popularBlogs:
          popularBlogs?.data?.popularBlogs?.data?.[0]?.attributes?.blogs
            ?.data || [],
        useCasesData: useCasesData?.data?.useCases?.data || null,
        thankYouPagesData: thankYouPagesData?.data?.thankYouPages?.data || null,
        landingPagesData: landingPagesData?.data?.landingPages?.data || null,
        scienceLabPagesData:
          scienceLabPagesData?.data?.scienceLabs?.data || null,
      },
    };
  } catch (error) {
    // console.log("error:", error?.networkError?.result?.errors);
    console.log("Error in blog page --->", error);

    // Redirect to 500 on error
    return {
      redirect: {
        destination: `/500?url=/${context?.params["blog-details"]}`,
        permanent: true,
      },
    };
  }
}

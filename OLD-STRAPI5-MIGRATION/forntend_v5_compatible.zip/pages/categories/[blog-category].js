import React from "react";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import dynamic from "next/dynamic";
const Zoho = dynamic(() => import("@/components/Blog/BlogDetails/Zoho"));
const GridContent = dynamic(() => import("@/components/Blog/GridContent"));
import { getSeoData } from "graphql/getSeoData";
import Schema from "@/components/Common/Schema";
const Seo = dynamic(() => import("@/components/Common/seo"));

const BlogCategories = ({ blogsData, totalPages }) => {
  const categoryData =
    blogsData[0]?.attributes?.categories?.data?.[0]?.attributes;
  return (
    <>
      <Seo data={categoryData?.seo} />
      {categoryData?.schema && <Schema schema={categoryData?.schema} />}
      <div className="page-title-area">
        <div className="container">
          <div className="page-title-content">
            <h1>Category: {categoryData?.title}</h1>
          </div>
        </div>
      </div>
      <GridContent blogsData={blogsData} totalPages={totalPages} />
      {categoryData?.newsletter_section && (
        <div className="mb-5">
          <Zoho
            embedCode={categoryData?.newsletter_section?.description}
            form_onsubmit={categoryData?.newsletter_section?.form_onsubmit}
            form_onload={categoryData?.newsletter_section?.form_onload}
          />
        </div>
      )}
    </>
  );
};

export default BlogCategories;

export async function getServerSideProps({ preview, params, query }) {
  const categorySlug = params["blog-category"];
  let pageNumber = query.page || 1;
  const { data, errors } = await client.query({
    query: gql`
      query getCategries {
        blogs(
          filters: { categories: { slug: { eq: "${categorySlug}" } } }
          pagination: { page: ${pageNumber}, pageSize: 6 }
          sort: "createdAt:desc"
        ) {
          data {
            id
            attributes {
              slug
              title
              createdAt
              publish_date
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              categories (filters: { slug: { eq: "${categorySlug}" } } ) {
                data {
                  attributes {
                    title
                    slug
                    newsletter_section {
                      description
                    }
                    schema
                    ${getSeoData}
                  }
                }
              }
              tags {
                data {
                  attributes {
                    title
                    slug
                  }
                }
              }
            }
          }
          meta {
            pagination {
              page
              pageSize
              total
              pageCount
            }
          }
        }
      }
    `,
  });

  // const { data, errors } = await client.query({
  //   query: gql`
  //     query getCategries {
  //       categories(
  //        ${preview ? "publicationState:PREVIEW," : ""}
  //       filters: {
  //         slug: {
  //           eq: "${categorySlug}"
  //         }
  //       }
  //       ) {
  //         data {
  //           attributes {
  //             slug
  //             title
  //             newsletter_section {
  //               icon {
  //                 data {
  //                   attributes {
  //                     url
  //                   }
  //                 }
  //               }
  //               heading
  //               description
  //             }
  //              blogs {
  //               data {
  //                 id
  //                 attributes {
  //                   slug
  //                   title
  //                   createdAt
  //                   image {
  //                     data {
  //                       attributes {
  //                         url
  //                       }
  //                     }
  //                   }
  //                   categories {
  //                     data {
  //                       attributes {
  //                         title
  //                         slug
  //                       }
  //                     }
  //                   }
  //                   tags {
  //                     data {
  //                       attributes {
  //                         title
  //                         slug
  //                       }
  //                     }
  //                   }
  //                 }
  //               }
  //             }
  //           }
  //         }
  //       }
  //     }
  //   `,
  // });

  if (errors?.length > 0) {
    return {
      redirect: {
        destination: `/500?url=/${blogData?.slug}`,
        permanent: true,
      },
    };
  } else if (
    data?.blogs?.data?.length === 0 ||
    data?.categories?.data?.length === 0
  ) {
    return {
      redirect: {
        destination: `/evivvo-pedia/`,
        permanent: true,
      },
    };
  }

  return {
    props: {
      // categoryData: data?.categories?.data?.[0]?.attributes || [],
      blogsData: data?.blogs?.data || [],
      totalPages: data?.blogs?.meta?.pagination?.pageCount || null,
    },
  };
}

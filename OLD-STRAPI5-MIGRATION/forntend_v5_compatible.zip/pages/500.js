import React from "react";
import Link from "next/link";
import Image from "next/image";

import errorImg from "@/public/images/four-zero-four.png";

export default function Custom500() {
  return (
    <div className="error-area">
      <div className="d-table">
        <div className="d-table-cell">
          <div className="container">
            <div className="error-content">
              <Image src={errorImg} alt="error-image" loading="lazy" />

              <h3>Error 500 : Something went wrong</h3>

              <p>
                The page you are looking for might have been removed had its
                name changed or is temporarily unavailable.
              </p>

              <Link href="/">
                <a className="btn-style-one red-light-color bttn o-hidden">
                  Back to Home <i className="bx bx-chevron-right"></i>
                  <span></span>
                </a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { useEffect } from "react";

export default function JourneySection({ data }) {
  useEffect(() => {
    const cards = document.querySelectorAll(
      ".new-play-now-journey-section-step-text-box"
    );
    if (!cards.length) return;

    let lastScrollY = window.scrollY;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const card = entry.target;
          const wrapper = card.closest(
            ".new-play-now-journey-section-step-wrapper"
          );

          if (entry.isIntersecting) {
            // Only animate if not already visited
            if (!card.classList.contains("visited")) {
              wrapper?.classList.add("animate-timeline");
              wrapper
                ?.querySelector(".new-play-now-journey-section-dot")
                ?.classList.add("visited-dot");
              wrapper
                ?.querySelector(".new-play-now-journey-section-col-img-wrapper")
                ?.classList.add("visited-image-wrapper");
              card.classList.add("visited");
            }
          }
        });
      },
      { 
        threshold: 0.4,
        rootMargin: '0px 0px -10% 0px' // Only trigger when card is 10% into viewport
      }
    );

    cards.forEach((c) => observer.observe(c));

    // Reset logic with scroll direction detection
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const isScrollingUp = currentScrollY < lastScrollY;
      lastScrollY = currentScrollY;

      const section = document.querySelector(
        ".new-play-now-journey-section-container"
      );
      if (!section) return;

      const rect = section.getBoundingClientRect();
      
      // Only reset when scrolling up AND section top is back in viewport
      if (isScrollingUp && rect.top >= window.innerHeight * 0.1) {
        cards.forEach((card) => {
          const wrapper = card.closest(
            ".new-play-now-journey-section-step-wrapper"
          );
          wrapper?.classList.remove("animate-timeline");
          wrapper
            ?.querySelector(".new-play-now-journey-section-dot")
            ?.classList.remove("visited-dot");
          wrapper
            ?.querySelector(".new-play-now-journey-section-col-img-wrapper")
            ?.classList.remove("visited-image-wrapper");
          card.classList.remove("visited");
        });
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div className="container">
      <div className="new-play-now-journey-section-container">
        <h1
          className="new-play-now-journey-section-h1"
          data-aos="fade-up"
          data-aos-duration="1200"
        >
          {data?.title}
        </h1>
        {data?.cards?.length > 0 &&
          data?.cards?.map((step, index) => (
            <div
              key={index}
              className="new-play-now-journey-section-step-wrapper"
            >
              <div className="new-play-now-journey-section-col new-play-now-journey-section-col-img-wrapper">
                {step?.image?.url && (
                  <img
                    src={replaceImageUrl(step?.image?.url)}
                    alt={step?.title}
                    className="new-play-now-journey-section-col-img"
                  />
                )}
              </div>
              <div className="new-play-now-journey-section-dot"></div>
              <div className="new-play-now-journey-section-col">
                <div className="new-play-now-journey-section-step-text-box">
                  <div className="new-play-now-journey-section-step-text-content">
                    <h3>STEP {String(index + 1).padStart(2, "0")}</h3>
                    <h2>{step?.title}</h2>
                    <p>{step?.description}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
}
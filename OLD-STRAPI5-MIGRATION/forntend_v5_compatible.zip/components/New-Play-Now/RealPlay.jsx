import React, { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";

export default function RealPlay({ data }) {
  useEffect(() => {
    AOS.init({
      duration: 800,
      once: true,
      mirror: false,
    });
  }, []);

  return (
    <div className="new-play-now-real-play-container">
      <div className="container">
        <div className="new-play-now-real-play-wrapper">
          <h1
            className="new-play-now-real-play-h1"
            data-aos="fade-up"
            data-aos-duration="1200"
          >
            {data?.title}
          </h1>

          {data?.cards?.length > 0 && (
            <div className="new-play-now-real-play-cards">
              {data?.cards.map((item, index) => (
                <div
                  key={index}
                  className="new-play-real-play-card"
                  data-aos={index % 2 === 0 ? "fade-right" : "fade-left"}
                  data-aos-duration="800"
                  data-aos-delay={200 + index * 200}
                >
                  <img
                    src={replaceImageUrl(item?.icon?.url)}
                    alt={item?.title}
                    className="new-play-real-play-card-icon"
                  />
                  <div className="new-play-real-play-card-text-container">
                    <h2>{item?.title}</h2>
                    <CKEditor content={item?.description} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

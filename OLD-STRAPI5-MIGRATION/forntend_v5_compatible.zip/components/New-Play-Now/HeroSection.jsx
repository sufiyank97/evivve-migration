import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

const HeroSection = ({ data, setShowModal }) => {
  return (
    <div className="new-play-now-hero-container">
      <div className="new-play-now-hero-wrapper">
        <p
          className="new-play-now-hero-wrapper-titlecase-text"
          data-aos="fade-up"
        >
          {data?.sub_title}
        </p>
        <h1 data-aos="fade-up">{data?.title}</h1>
        {data?.new_play_now_hero_button?.button_text &&
          (data?.button_type === "form" ? (
            <button
              className="new-play-now-dynamic-section-btn"
              data-aos="fade-up"
              onClick={() => setShowModal(true)}
            >
              {data?.new_play_now_hero_button?.button_text}
            </button>
          ) : (
            <a
              href={data?.new_play_now_hero_button?.button_link || ""}
              target={
                data?.new_play_now_hero_button?.button_target === "blank"
                  ? "_blank"
                  : "_self"
              }
              className="new-play-now-dynamic-section-btn"
              data-aos="fade-up"
            >
              {data?.new_play_now_hero_button?.button_text}
            </a>
          ))}
        {data?.image?.url && (
          <div className="new-play-now-hero-wrapper-image">
            <img
              src={replaceImageUrl(data?.image?.url)}
              alt="main-image"
            />
          </div>
        )}
        <div className="new-play-now-hero-dant-extrasmall"></div>
        <div className="new-play-now-hero-dant-big1"></div>
        <div className="new-play-now-hero-dant-big2"></div>
      </div>
    </div>
  );
};

export default HeroSection;

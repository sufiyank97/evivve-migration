import React, { useEffect } from "react";
import { Helmet } from "react-helmet";
import parse from "html-react-parser";

export default function PlayLiveZohoForm({
  zoho_form_type,
  form,
  form_onload,
  form_onsubmit,
}) {
  useEffect(() => {
    if (form_onload) {
      const handleOnLoad = () => {
        eval(form_onload);
      };

      // Add event listener
      window.addEventListener("load", handleOnLoad);

      // Cleanup function to remove the event listener
      return () => {
        window.removeEventListener("load", handleOnLoad);
      };
    }
  }, []);
  return (
    <>
      <Helmet>
        <script
          type="text/javascript"
          src="https://fsut-zc1.maillist-manage.in/js/optin.min.js"
          onload={form_onload || ""}
        ></script>

        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{
            __html: `function runOnFormSubmit_${form_onsubmit}(
                th
              ) {}`,
          }}
        />
      </Helmet>

      {zoho_form_type === "form" ? (
        <div className="play-embed-code-wrap play-page-zoho-code">
          {parse(`${form}`)}
        </div>
      ) : (
        <></>
      )}
    </>
  );
}

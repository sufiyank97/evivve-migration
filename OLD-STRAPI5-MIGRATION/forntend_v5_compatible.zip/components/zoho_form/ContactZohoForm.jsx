import Link from "next/link";
import React, { useEffect } from "react";
import { Helmet } from "react-helmet";
import parse from "html-react-parser";

export default function ContactZohoForm({ data }) {
  useEffect(() => {
    const handleOnLoad = () => {
      eval(data?.form_onload);
    };

    // Add event listener
    window.addEventListener("load", handleOnLoad);

    // Cleanup function to remove the event listener
    return () => {
      window.removeEventListener("load", handleOnLoad);
    };
  }, []);
  return (
    <>
      <Helmet>
        <script
          type="text/javascript"
          src="https://fsut-zc1.maillist-manage.in/js/optin.min.js"
          onload={data?.form_onload}
        ></script>
        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{
            __html: `
				function runOnFormSubmit_${data?.form_onsubmit}(th) {}
			`,
          }}
        />
      </Helmet>

      {data?.zoho_form_type === "button" ? (
        data?.zoho_form_button?.button_text ? (
          <Link
            href={data?.zoho_form_button?.button_link || ""}
            target={
              data?.zoho_form_button?.button_target === "blank"
                ? "_blank"
                : "_self"
            }
          >
            <a
              className="register-button"
              target={
                data?.zoho_form_button?.button_target === "blank"
                  ? "_blank"
                  : "_self"
              }
            >
              {data?.zoho_form_button?.button_text}
            </a>
          </Link>
        ) : (
          ""
        )
      ) : (
        <>
          <div className="form contact-form contact-zoho-form">
            <div className="">{parse(`${data?.form}`)}</div>
          </div>
        </>
      )}
    </>
  );
}

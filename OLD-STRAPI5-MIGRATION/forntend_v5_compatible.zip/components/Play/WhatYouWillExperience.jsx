import CKEditor from "@/utils/CkEditor";
import React, { useEffect, useRef } from "react";

export default function WhatYouWillExperience({ data }) {
  useEffect(() => {
    const durationPerCard = 1500; // 1.5s per card
    const fadeOutDuration = 300;
    const allBorders = document.querySelectorAll(".progress-bar");
    let index = 0;
    let timeoutId;

    const animateCard = () => {
      if (index < allBorders.length) {
        const el = allBorders[index];
        el.style.transition = `width ${durationPerCard}ms linear`;
        el.style.width = "100%";
        index++;

        timeoutId = setTimeout(animateCard, durationPerCard);
      } else {
        // All cards filled, fade out
        setTimeout(() => {
          allBorders.forEach((el) => {
            el.style.transition = `opacity ${fadeOutDuration}ms ease`;
            el.style.opacity = "0";
          });

          // Reset after fade-out
          setTimeout(() => {
            allBorders.forEach((el) => {
              el.style.transition = "none";
              el.style.width = "0%";
              el.style.opacity = "1";
            });

            index = 0;
            // Wait one animation frame to restart cleanly
            requestAnimationFrame(() => {
              setTimeout(animateCard, 50); // tiny delay to allow DOM reset
            });
          }, fadeOutDuration);
        }, durationPerCard);
      }
    };

    animateCard(); // start animation

    return () => clearTimeout(timeoutId); // clean up on unmount
  }, []);

  return (
    <section className="what-you-will-experience">
      <div className="container">
        <h1>{data?.title}</h1>
        <div className="what-you-will-experience-list">
          {data?.experience_cards?.map((item, index) => {
            return (
              <div className="what-you-will-experience-card" key={index}>
                <div className="what-you-will-experience-list-border">
                  <div className="progress-bar"></div>
                </div>
                <div>
                  {item?.icon?.data?.attributes?.url && (
                    <img src={item?.icon?.data?.attributes?.url} alt="icon" />
                  )}
                  <p className="what-you-will-experience-list-title">
                    {item?.title}
                  </p>
                  <div className="what-you-will-experience-list-desc">
                    <CKEditor content={item?.description} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

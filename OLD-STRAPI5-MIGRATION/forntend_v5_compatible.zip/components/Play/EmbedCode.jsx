import React from "react";

export default function EmbedCode({ embed_code }) {
  return (
    <div className="play-embed-code-wrap">
      <div>
        <div dangerouslySetInnerHTML={{ __html: embed_code }} />
      </div>
    </div>
  );
}

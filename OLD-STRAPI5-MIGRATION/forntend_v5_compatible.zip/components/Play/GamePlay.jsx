import React from "react";
import styles from "./Play.module.css";
import Link from "next/link";
import CKEditor from "@/utils/CkEditor";

export default function GamePlay({ play_section }) {
  return (
    <div className={styles.gameplay_wrapper}>
      <div className="container">
        <div className={styles.gameplay}>
          {play_section?.length > 0 &&
            play_section?.map((section, index) => {
              return (
                <div key={index}>
                  <span className={styles.title_tag}>
                    {/* {section?.heading} */}
                  </span>
                  <h4>
                    {section?.title} <br /> EVIVVE GAME
                  </h4>
                  {section?.description && (
                    <CKEditor content={section?.description} />
                  )}
                  <Link
                    href={section?.game_button?.button_link || ""}
                    passHref
                    target={section?.game_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
                  >
                    <a className={styles.link_btn} target="_blank">
                      {section?.game_button?.button_text || "Play Now"}
                    </a>
                  </Link>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}

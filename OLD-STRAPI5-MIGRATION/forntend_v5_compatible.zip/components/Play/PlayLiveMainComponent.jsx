import React, { useState } from "react";
import Form from "../LandingPages/template3/Form";
import HeroSection from "./HeroSection";
import Template4Brands from "../LandingPages/template4/Template4Brands";
import WhatYouWillExperience from "./WhatYouWillExperience";
import WhyJoin from "./WhyJoin";
import Adventure from "./Adventure";
import Join from "./Join";
import Seo from "../Common/seo";
import Testimonials from "../CaseStudy/Testimonials";
import Faq from "../NewPricing/Faq";

export default function PlayLiveMainComponent({ data }) {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <Seo data={data?.seo} />
      <main className="play-live-main-wrap">
        <HeroSection
          setShowModal={setShowModal}
          data={data?.templates[0]?.Banner}
        />
        {data?.templates[0]?.brands && (
          <Template4Brands data={data?.templates[0]?.brands} />
        )}
        {data?.templates[0]?.experience && (
          <WhatYouWillExperience data={data?.templates[0]?.experience} />
        )}
        {data?.templates[0]?.join && (
          <WhyJoin data={data?.templates[0]?.join} />
        )}
        {data?.templates[0]?.stripe_image?.data?.attributes?.url && (
          <section className="game-img-section-wrap">
            <div className="container">
              <div className="game-img-wrap">
                <img
                  src={data?.templates[0]?.stripe_image?.data?.attributes?.url}
                  alt="image"
                />
              </div>
            </div>
          </section>
        )}
        {data?.templates[0]?.adventure && (
          <Adventure data={data?.templates[0]?.adventure} />
        )}
        {/* {data?.templates[0]?.join_stripe && (
          <Join
            data={data?.templates[0]?.join_stripe}
            setShowModal={setShowModal}
          />
        )} */}
        {data?.templates[0]?.testimonial_section && (
          <Testimonials data={data?.templates[0]?.testimonial_section} />
        )}
        {data?.templates[0]?.join_stripe && (
          <Join
            data={data?.templates[0]?.join_stripe}
            setShowModal={setShowModal}
          />
        )}
        {data?.templates[0]?.faq && (
          <Faq
            title={data?.templates[0]?.faq?.title}
            faq={data?.templates[0]?.faq?.faq_list}
          />
        )}
      </main>
      {showModal && data?.templates[0]?.form && (
        <div className="template2-popup-form-overlay">
          <div className="template2-popup-form-wrap preview-modal-form play-live-form">
            <h1
              style={{
                textAlign: "center",
                fontSize: "30px",
                color: "#5B105A",
              }}
            >
              {data?.templates[0]?.form?.title}
            </h1>
            <Form
              data={{
                form_onload: data?.templates[0]?.form?.form_onload,
                form_onsubmit: data?.templates[0]?.form?.form_onsubmit,
                preview_form: data?.templates[0]?.form?.form,
              }}
            />
            <button
              onClick={() => setShowModal(false)}
              className="template2-popup-close-btn"
            >
              <i class="bx bx-x"></i>
            </button>
          </div>
        </div>
      )}
    </>
  );
}

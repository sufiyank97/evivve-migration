import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function WhyJoin({ data }) {
  return (
    <section className="why-join-section-wrap container">
      <h1>{data?.title}</h1>
      <div className="why-join-list">
        {data?.join_cards?.map((item, index) => {
          return (
            <div key={index}>
              {item?.icon?.data?.attributes?.url && (
                <div className="why-join-list-icon-bg">
                  <img src={item?.icon?.data?.attributes?.url} alt="icon" />
                </div>
              )}
              <p className="why-join-list-title">{item?.title}</p>
              <div className="why-join-list-desc">
                <CKEditor content={item?.description} />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

import React from "react";

const Features = ({ data }) => {
  return (
    <div className="features-area bg-f3feff pt-100">
      <div className="container">
        <div className="section-title">
          {/* <span className="sub-title light-green-color">Key Features</span> */}
          <h2>{data?.title || "Most probably included best features ever"}</h2>
        </div>
        <div className="row justify-content-center">
          {data?.featureList?.map((item, i) => {
            return (
              <div
                className="col-lg-4 col-md-6 col-sm-6"
                data-aos="fade-up"
                data-aos-duration="1200"
                key={i}
                data-aos-delay={i * 100}
              >
                <div className="single-features-box">
                  <div className="icon">
                    <i className={item?.icon}></i>
                  </div>
                  <h3>{item?.title}</h3>
                  <p>{item?.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Features;

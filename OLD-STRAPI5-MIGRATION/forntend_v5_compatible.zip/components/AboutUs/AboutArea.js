import React from "react";
import Link from "next/link";
import Image from "next/image";
import NextImage from "next/future/image";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { createId } from "@/utils/CreateId";

const AboutArea = ({ data }) => {
  return (
    <div className="about-area-section">
      <div className="container">
        <div className="row d-lg-flex justify-content-lg-center">
          <div className="">
            <div
              className="about-content-section text-center m-spinner"
              // data-aos="fade-up"
              // data-aos-duration="1200"
            >
              {data?.heading && (
                <span className="sub-title">
                  <Image
                    src="/images/spinner.png"
                    alt="spinner"
                    width={34}
                    height={34}
                    loading="lazy"
                  />
                  {/* About Us */}
                  {data?.heading}
                </span>
              )}
              <h2 id={createId(data?.title)}>
                {/* Drive Digital Revolution Through Data Science */}
                {data?.title}
              </h2>
              {/* <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna.
              </p> */}
              <div className="about-us-img-wrap hide-on-small-screen">
                {data?.image?.url && (
                  <Image
                    src={replaceImageUrl(data?.image?.url)}
                    alt={data?.title}
                    className="about-us-img"
                    // priority
                    loading="eager"
                    layout="fill"
                    objectFit="cover"
                    objectPosition={"center"}
                  />
                )}
              </div>
              <div className="about-us-img-wrap hide-on-desktop">
                {data?.image?.url && (
                  <picture>
                    <source
                      media="(max-width:699px)"
                      srcSet={
                        replaceImageUrl(data?.image?.url) ||
                        ""
                      }
                      type="image/webp"
                    />
                    <source
                      media="(max-width:640px)"
                      srcSet={
                        replaceImageUrl(data?.image?.url) ||
                        ""
                      }
                      type="image/webp"
                    />
                    <Image
                      src={replaceImageUrl(data?.image?.url)}
                      alt={data?.title}
                      className="about-us-img"
                      // priority
                      loading="eager"
                      layout="fill"
                      objectFit="cover"
                      objectPosition={"center"}
                    />
                  </picture>
                )}
              </div>
              <div className="about-us-description">
                <CKEditor
                  content={data?.description}
                  customStyle={"about-us-ckeditor"}
                  id
                />
                <ul className="features-list">
                  {data?.points?.map((point, index) => {
                    return (
                      <li key={index}>
                        {point?.image && (
                          <NextImage
                            src={point?.image?.url}
                            alt="market"
                            width={50}
                            height={44}
                            loading="lazy"
                            style={{ borderRadius: "0" }}
                          />
                        )}
                        <h3>{point?.title}</h3>
                        <p>{point?.description}</p>
                      </li>
                    );
                  })}
                </ul>
                <CKEditor content={data?.description1} id />
              </div>
              {/* <ul className="features-list">
                <li>
                  <NextImage
                    src="/images/about/market.png"
                    alt="market"
                    width={50}
                    height={44}
                  />
                  <h3>10 Years</h3>
                  <p>On the market</p>
                </li>
                <li>
                  <NextImage
                    src="/images/about/market.png"
                    alt="market"
                    width={50}
                    height={44}
                  />
                  <h3>10 Years</h3>
                  <p>On the market</p>
                </li>
                <li>
                  <NextImage
                    src="/images/about/market.png"
                    alt="market"
                    width={50}
                    height={44}
                  />
                  <h3>10 Years</h3>
                  <p>On the market</p>
                </li>
                <li>
                  <NextImage
                    src="/images/about/market.png"
                    alt="market"
                    width={50}
                    height={44}
                  />
                  <h3>10 Years</h3>
                  <p>On the market</p>
                </li>
              </ul> */}
              {/* <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna.
              </p> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutArea;

import Image from "next/image";
import NextImage from "next/future/image";
import React from "react";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { createId } from "@/utils/CreateId";

const Scientists = ({ data }) => {
  console.log(data?.members[0]?.image?.url, "Data--->");
  
  return (
    <div className="scientist-section ptb-70">
      <div className="container">
        <div className="m-section-title m-spinner">
          {data?.heading && (
            <span className="sub-title">
              <Image
                src="/images/spinner.png"
                alt="spinner"
                width={34}
                height={34}
                loading="lazy"
              />
              {/* TEAM MEMBERS */}
              {data?.heading}
            </span>
          )}
          <h2 id={createId(data?.title)}>
            {/* Meet Our Scientists */}
            {data?.title}
          </h2>
          <CKEditor content={data?.description} id />
        </div>
        <div className="row">
          {data?.members?.map((member, index) => {
            return (
              <div key={index} className="col-lg-3 col-sm-6 col-md-6">
                <div className="single-scientist-box">
                  <div className="image">
                    {member?.image && (
                      <NextImage
                        src={replaceImageUrl(
                          member?.image?.url
                        )}
                        alt="team"
                        height={350}
                        width={250}
                        loading="lazy"
                      />
                    )}
                  </div>
                  <div className="content">
                    <h3 id={createId(member?.name)}>{member?.name}</h3>
                    <span>{member?.role}</span>
                    <ul className="social">
                      {member?.facebook_link && (
                        <li>
                          <a
                            href={
                              member?.facebook_link ||
                              "https://www.facebook.com/"
                            }
                            className="d-block"
                            target="_blank"
                            rel="noreferrer"
                          >
                            <i className="bx bxl-facebook"></i>
                          </a>
                        </li>
                      )}
                      {member?.twiter_link && (
                        <li>
                          <a
                            href={member?.twiter_link || "https://twitter.com/"}
                            className="d-block"
                            target="_blank"
                            rel="noreferrer"
                          >
                            <i className="bx bxl-twitter"></i>
                          </a>
                        </li>
                      )}
                      {member?.instagram_link && (
                        <li>
                          <a
                            href={
                              member?.instagram_link ||
                              "https://www.instagram.com/"
                            }
                            className="d-block"
                            target="_blank"
                            rel="noreferrer"
                          >
                            <i className="bx bxl-instagram"></i>
                          </a>
                        </li>
                      )}
                      {member?.linkedIn_link && (
                        <li>
                          <a
                            href={
                              member?.linkedIn_link ||
                              "https://www.linkedin.com/"
                            }
                            className="d-block"
                            target="_blank"
                            rel="noreferrer"
                          >
                            <i className="bx bxl-linkedin"></i>
                          </a>
                        </li>
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}

          {/* <div className="col-lg-3 col-sm-6 col-md-6">
            <div className="single-scientist-box">
              <div className="image">
                <NextImage
                  src="/images/about/team1.png"
                  alt="team"
                  height={350}
                  width={250}
                />
              </div>
              <div className="content">
                <h3>Merv Adrian</h3>
                <span>Data Management</span>
                <ul className="social">
                  <li>
                    <a
                      href="https://www.facebook.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-facebook"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://twitter.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-twitter"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.instagram.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-instagram"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.linkedin.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-linkedin"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-sm-6 col-md-6">
            <div className="single-scientist-box">
              <div className="image">
                <NextImage
                  src="/images/about/team2.png"
                  alt="team"
                  height={350}
                  width={250}
                />
              </div>
              <div className="content">
                <h3>Kirk Borne</h3>
                <span>Data Scientist</span>
                <ul className="social">
                  <li>
                    <a
                      href="https://www.facebook.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-facebook"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://twitter.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-twitter"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.instagram.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-instagram"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.linkedin.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-linkedin"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-sm-6 col-md-6">
            <div className="single-scientist-box">
              <div className="image">
                <NextImage
                  src="/images/about/team1.png"
                  alt="team"
                  height={350}
                  width={250}
                />
              </div>
              <div className="content">
                <h3>Merv Adrian</h3>
                <span>Data Management</span>
                <ul className="social">
                  <li>
                    <a
                      href="https://www.facebook.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-facebook"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://twitter.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-twitter"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.instagram.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-instagram"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.linkedin.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-linkedin"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-sm-6 col-md-6">
            <div className="single-scientist-box">
              <div className="image">
                <NextImage
                  src="/images/about/team2.png"
                  alt="team"
                  height={350}
                  width={250}
                />
              </div>
              <div className="content">
                <h3>Kirk Borne</h3>
                <span>Data Scientist</span>
                <ul className="social">
                  <li>
                    <a
                      href="https://www.facebook.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-facebook"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://twitter.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-twitter"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.instagram.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-instagram"></i>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.linkedin.com/"
                      className="d-block"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="bx bxl-linkedin"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div> */}
        </div>
      </div>
    </div>
  );
};

export default Scientists;

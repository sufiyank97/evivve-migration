import Image from "next/image";
import NextImage from "next/future/image";
import React from "react";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { createId } from "@/utils/CreateId";

const History = ({ data }) => {
  return (
    <div className="history-section ptb-100 bg-fafafb">
      <div className="container">
        <div className="m-section-title m-spinner">
          {data?.heading && (
            <span className="sub-title">
              <Image
                src="/images/spinner.png"
                alt="contact"
                width={34}
                height={34}
                loading="lazy"
              />
              {/* OUR HISTORY */}
              {data?.heading}
            </span>
          )}
          <h2 id={createId(data?.title)}>
            {/* Evivve&apos;s Journey and History */}
            {data?.title}
          </h2>
        </div>
        <ol className="history-timeline">
          {data?.points?.map((point, index) => {
            const dateObject = new Date(point?.date);
            return (
              <li key={index} className="timeline-block">
                <div className="timeline-date">
                  {point?.show_date && <span>{dateObject.getFullYear()}</span>}
                  {/* {dateObject.toLocaleDateString("en-US", {
                    month: "long",
                  })}{" "}
                  {dateObject.getDate()}
                  <sup>th</sup> */}
                </div>
                <div className="timeline-icon">
                  <span className="dot-badge"></span>
                </div>
                <div className="timeline-content">
                  <div className="row align-items-center">
                    <div className="col-lg-7 col-md-12">
                      <div className="content">
                        <h3 id={createId(point?.title)}>{point?.title}</h3>
                        {/* <p>
                          Real innovations and a positive customer experience
                          are the heart of successful communication. Lorem ipsum
                          dolor sit amet, sectetur adipiscing elit, tempor
                          incididunt ut labore et dolore magna.
                        </p> */}
                        <CKEditor content={point?.description} />
                      </div>
                    </div>
                    <div className="col-lg-5 col-md-12">
                      <div className="image">
                        {point?.image?.data && (
                          <NextImage
                            src={replaceImageUrl(
                              point?.image?.data?.attributes?.url
                            )}
                            width={400}
                            height={600}
                            alt="history"
                            loading="lazy"
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ol>
        {/* <ol className="history-timeline">
          <li className="timeline-block">
            <div className="timeline-date">
              <span>2010</span>February 20<sup>th</sup>
            </div>
            <div className="timeline-icon">
              <span className="dot-badge"></span>
            </div>
            <div className="timeline-content">
              <div className="row align-items-center">
                <div className="col-lg-7 col-md-12">
                  <div className="content">
                    <h3>Founded</h3>
                    <p>
                      Real innovations and a positive customer experience are
                      the heart of successful communication. Lorem ipsum dolor
                      sit amet, sectetur adipiscing elit, tempor incididunt ut
                      labore et dolore magna.
                    </p>
                  </div>
                </div>
                <div className="col-lg-5 col-md-12">
                  <div className="image">
                    <NextImage
                      src="/images/about/history1.jpg"
                      width={750}
                      height={650}
                      alt="history"
                    />
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li className="timeline-block">
            <div className="timeline-date">
              <span>2013</span>January 14<sup>th</sup>
            </div>
            <div className="timeline-icon">
              <span className="dot-badge"></span>
            </div>
            <div className="timeline-content">
              <div className="row align-items-center">
                <div className="col-lg-7 col-md-12">
                  <div className="content">
                    <h3>Global Success</h3>
                    <p>
                      Real innovations and a positive customer experience are
                      the heart of successful communication. Lorem ipsum dolor
                      sit amet, sectetur adipiscing elit, tempor incididunt ut
                      labore et dolore magna.
                    </p>
                  </div>
                </div>
                <div className="col-lg-5 col-md-12">
                  <div className="image">
                    <NextImage
                      src="/images/about/history1.jpg"
                      width={750}
                      height={650}
                      alt="history"
                    />
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li className="timeline-block">
            <div className="timeline-date">
              <span>2016</span>March 25<sup>th</sup>
            </div>
            <div className="timeline-icon">
              <span className="dot-badge"></span>
            </div>
            <div className="timeline-content">
              <div className="row align-items-center">
                <div className="col-lg-7 col-md-12">
                  <div className="content">
                    <h3>Founded Data Center</h3>
                    <p>
                      Real innovations and a positive customer experience are
                      the heart of successful communication. Lorem ipsum dolor
                      sit amet, sectetur adipiscing elit, tempor incididunt ut
                      labore et dolore magna.
                    </p>
                  </div>
                </div>
                <div className="col-lg-5 col-md-12">
                  <div className="image">
                    <NextImage
                      src="/images/about/history1.jpg"
                      width={750}
                      height={650}
                      alt="history"
                    />
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li className="timeline-block">
            <div className="timeline-date">
              <span>2020</span>December 10<sup>th</sup>
            </div>
            <div className="timeline-icon">
              <span className="dot-badge"></span>
            </div>
            <div className="timeline-content">
              <div className="row align-items-center">
                <div className="col-lg-7 col-md-12">
                  <div className="content">
                    <h3>International Award</h3>
                    <p>
                      Real innovations and a positive customer experience are
                      the heart of successful communication. Lorem ipsum dolor
                      sit amet, sectetur adipiscing elit, tempor incididunt ut
                      labore et dolore magna.
                    </p>
                  </div>
                </div>
                <div className="col-lg-5 col-md-12">
                  <div className="image">
                    <NextImage
                      src="/images/about/history1.jpg"
                      width={750}
                      height={650}
                      alt="history"
                    />
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ol> */}
      </div>
    </div>
  );
};

export default History;

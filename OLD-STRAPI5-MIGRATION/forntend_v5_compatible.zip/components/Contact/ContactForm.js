import React, { useState, useEffect } from "react";
import baseUrl from "@/utils/baseUrl";
import Image from "next/image";
import { useRouter } from "next/router";
import axios from "axios";
import { ThankYou } from "../ThankYou/ThankYou";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import ContactZohoForm from "../zoho_form/ContactZohoForm";

const ContactForm = ({ contactData, setIsVisible }) => {
  const data = contactData?.second_section;
  const thankYouData = contactData?.thankYou;
  const router = useRouter();
  const initialData = {
    name: "",
    email: "",
    phoneNumber: "",
    message: "",
  };
  const [formData, setFormData] = useState(initialData);
  const [buttonLoading, setButtonLoading] = useState(false);
  const [showRegexError, setShowRegexError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();

    var validEmailRegex =
      /^([a-z A-Z 0-9 \. _]+)@([a-z A-Z]{2,15}).([a-z A-Z]{2,6})(.[a-z]{2,6})?$/;
    var validPhoneRegex = /^[0-9]{10}$/;
    if (formData.phoneNumber && !formData.phoneNumber.match(validPhoneRegex)) {
      setShowRegexError("Please provide correct Phone Number");
    } else if (formData.email && !validEmailRegex.test(formData.email)) {
      setShowRegexError("Please provide correct Email Address");
    } else {
      setShowRegexError(null);
      try {
        setButtonLoading(true);
        // console.log("formData", formData);
        const res = await axios.post(
          `${process.env.NEXT_PUBLIC_STRAPI_URL}api/contacts`,
          {
            data: formData,
          }
        );
        // console.log("data:", res);
        setFormData(initialData);
        setIsVisible(true);
        // router.push("/thank-you");
      } catch (error) {
        console.log("error", error);
      } finally {
        setButtonLoading(false);
      }
    }
  };

  return (
    <>
      <div className="contact-area">
        <div className="container">
          <div className="m-section-title m-spinner">
            {/* <span className="sub-title">
              <Image
                src="/images/spinner.png"
                alt="contact"
                width={34}
                height={34}
              />
              {data?.heading}
            </span> */}
            <h2>
              {/* Ready to Get Started? */}
              {data?.title}
            </h2>
            <p>
              {/* Your email address will not be published. Required fields are
              marked * */}
              {data?.description}
            </p>
          </div>
          <div className="row">
            {data?.image?.data && (
              <div className="col-lg-6 col-md-12">
                <div className="contact-image hide-on-small-screen">
                  <picture>
                    <source
                      media="(max-width:699px)"
                      srcSet={
                        replaceImageUrl(data?.image?.data?.attributes?.url) ||
                        ""
                      }
                      type="image/webp"
                    />
                    <source
                      media="(max-width:640px)"
                      srcSet={
                        replaceImageUrl(data?.image?.data?.attributes?.url) ||
                        ""
                      }
                      type="image/webp"
                    />
                    <Image
                      src={replaceImageUrl(data?.image?.data?.attributes?.url)}
                      alt="contact"
                      // width={516}
                      // height={427}
                      layout="fill"
                      quality={75}
                      // loading="eager"
                      priority
                    />
                  </picture>
                </div>
                <div className="contact-image hide-on-desktop">
                  <Image
                    src={replaceImageUrl(data?.image?.data?.attributes?.url)}
                    alt="contact"
                    layout="fill"
                    quality={75}
                    loading="eager"
                    // priority
                  />
                  {/* <picture>
                    <source
                      media="(max-width:699px)"
                      srcSet={
                        replaceImageUrl(data?.image?.data?.attributes?.url) ||
                        ""
                      }
                      type="image/webp"
                    />
                    <source
                      media="(max-width:640px)"
                      srcSet={
                        replaceImageUrl(data?.image?.data?.attributes?.url) ||
                        ""
                      }
                      type="image/webp"
                    />
                    <Image
                      src={replaceImageUrl(data?.image?.data?.attributes?.url)}
                      alt="contact"
                      // width={516}
                      // height={427}
                      layout="fill"
                      quality={75}
                      // loading="eager"
                      priority
                    />
                  </picture> */}
                </div>
              </div>
            )}

            {/* <div className="col-lg-6 col-md-12">
              <div className="form contact-form">
                <form onSubmit={handleSubmit}>
                  <div className="row">
                    <div className="col-lg-12 col-md-6">
                      <div className="form-group">
                        <input
                          type="text"
                          name="name"
                          className="form-control"
                          placeholder="Your name"
                          required
                          value={formData.name}
                          onChange={(e) =>
                            setFormData({ ...formData, name: e.target.value })
                          }
                        />
                      </div>
                    </div>
                    <div className="col-lg-12 col-md-6">
                      <div className="form-group">
                        <input
                          type="email"
                          name="email"
                          className="form-control"
                          placeholder="Your email address"
                          required
                          value={formData.email}
                          onChange={(e) => {
                            setShowRegexError(null);
                            setFormData({
                              ...formData,
                              email: e.target.value,
                            });
                          }}
                        />
                      </div>
                    </div>
                    <div>
                      <div className="form-group">
                        <input
                          type="number"
                          name="number"
                          className="form-control"
                          placeholder="Your phone number"
                          required
                          value={formData.phoneNumber}
                          onChange={(e) => {
                            setShowRegexError(null);
                            setFormData({
                              ...formData,
                              phoneNumber: e.target.value,
                            });
                          }}
                        />
                      </div>
                    </div>
                    <div className="col-lg-12 col-md-12 col-sm-12">
                      <div className="form-group">
                        <textarea
                          name="text"
                          cols="30"
                          rows="6"
                          className="form-control"
                          placeholder="Write your message..."
                          required
                          value={formData.message}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              message: e.target.value,
                            })
                          }
                        ></textarea>
                      </div>
                    </div>
                    {showRegexError && (
                      <p className="text-[12px] text-red-600">
                        {showRegexError}
                      </p>
                    )}
                    <div className="col-lg-12 col-md-12 col-sm-12">
                      <button
                        type="submit"
                        className={`btn-style-two orange-color2 bttn o-hidden btn1`}
                        disabled={buttonLoading}
                      >
                        Send Message
                        <span></span>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div> */}
            {/* <!--Zoho Campaigns Web-Optin Form Starts Here--> */}
            <div className="col-lg-6 col-md-12">
              <ContactZohoForm
                data={{
                  zoho_form_type: contactData?.zoho_form_type,
                  zoho_form_button: contactData?.zoho_form_button,
                  form: contactData?.form,
                  form_onload: contactData?.form_onload,
                  form_onsubmit: contactData?.form_onsubmit,
                }}
              />
            </div>
            {/* <!--Zoho Campaigns Web-Optin Form Ends Here--> */}
          </div>
        </div>
      </div>
    </>
  );
};

export default ContactForm;

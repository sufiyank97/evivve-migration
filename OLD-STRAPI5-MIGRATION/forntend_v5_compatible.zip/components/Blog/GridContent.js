import React from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import { formattedDate } from "@/utils/helper";
import Pagination from "../Common/Pagination/Pagination";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

const GridContent = ({ blogsData, totalPages }) => {
  const router = useRouter();
  return (
    <div className="blog-area ptb-100">
      <div className="container">
        <div className="row">
          {blogsData?.map((item, i) => {
            const blog = item;
            return (
              <div
                key={i}
                className="col-xl-4 col-lg-6 col-md-6"
                onClick={() => router.push(`/${blog?.slug}`)}
                // data-aos="fade-up"
                // data-aos-duration="1200"
              >
                <div className="single-blog-post">
                  <div className="image">
                    <Link href={`/${blog?.slug}`} prefetch={false}>
                      <a className="d-block">
                        <Image
                          src={replaceImageUrl(blog?.image?.url)}
                          alt="blog-image"
                          width={355}
                          height={255}
                          priority
                        />
                      </a>
                    </Link>
                  </div>
                  <div className="content">
                    <ul className="meta">
                      {blog?.tags?.data?.length > 0 && (
                        <li>
                          <i className="bx bx-purchase-tag-alt"></i>
                          <Link
                            prefetch={false}
                            href={`/tags/${blog?.tags?.data?.[0]?.attributes?.slug}`}
                          >
                            <a onClick={(e) => e.stopPropagation()}>
                              {blog?.tags?.data?.[0]?.attributes?.title}
                            </a>
                          </Link>
                        </li>
                      )}
                      <li>
                        <i className="bx bx-calendar-check"></i>
                        {formattedDate(blog?.publish_date || blog?.createdAt)}
                      </li>
                    </ul>
                    <h3>
                      <Link href={`/${blog?.slug}`} prefetch={false}>
                        <a>{blog?.title}</a>
                      </Link>
                    </h3>
                  </div>
                </div>
              </div>
            );
          })}

          {totalPages > 1 ? <Pagination totalPages={totalPages} /> : ""}
        </div>
      </div>
    </div>
  );
};

export default GridContent;

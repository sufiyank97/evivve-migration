import React from "react";
import MessageIcon from "../Common/Icon/MessageIcon";
import CKEditor from "@/utils/CkEditor";

const EmailSub = ({ heading, description, newsletterData, margin }) => {
  return (
    <div className={`email-subs ${margin}`}>
      <div className="container">
        <div className="email-subs-wrap text-center">
          <div className="icon">
            <MessageIcon />
          </div>
          <h2
            className="h1 email-subs-section-title"
            style={{
              maxWidth: "780px",
              marginLeft: "auto",
              marginRight: "auto",
            }}
          >
            {newsletterData?.heading}
          </h2>
          {/* <div className="email-subs-section-description">
            {description
              ? description
              : "Stay up to date! Get all the latest posts delivered straight to your inbox."}
          </div> */}
          <CKEditor
            content={newsletterData?.description}
            customStyle="email-subs-section-description"
          />

          <div className="form-wrap">
            <form className="text-left">
              <div className="field-group-inline">
                <input
                  type="text"
                  name="name"
                  className="form-field"
                  id="name"
                  placeholder="Your name"
                  required=""
                  autoComplete="off"
                  value=""
                />
                <input
                  type="email"
                  name="email"
                  className="form-field"
                  id="email"
                  placeholder="Your email address"
                  required=""
                  autoComplete="off"
                  value=""
                />
                <button className="btn" type="submit">
                  <span>Subscribe</span>
                </button>
              </div>
              <div className="message-container"></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailSub;

import React, { useEffect } from "react";
import { Helmet } from "react-helmet";
import parse from "html-react-parser";

export default function Zoho({
  embedCode,
  form_onsubmit,
  form_onload,
  custom,
}) {
  useEffect(() => {
    const handleOnLoad = () => {
      eval(form_onload);
    };

    // Add event listener
    window.addEventListener("load", handleOnLoad);

    // Cleanup function to remove the event listener
    return () => {
      window.removeEventListener("load", handleOnLoad);
    };
  }, []);

  if (!embedCode) {
    return null;
  }
  return (
    <>
      <Helmet>
        <script
          type="text/javascript"
          src="https://fsut-zc1.maillist-manage.in/js/optin.min.js"
          onload={form_onload}
        ></script>
        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{
            __html: `function runOnFormSubmit_${form_onsubmit}(
                th
              ) {}`,
          }}
        />
      </Helmet>
      {custom ? (
        <div className="play-embed-code-wrap">
          <div style={{ borderRadius: "16px" }}>{parse(`${embedCode}`)}</div>
        </div>
      ) : (
        <div className="container zoho-form">{parse(`${embedCode}`)}</div>
      )}
    </>
  );
}

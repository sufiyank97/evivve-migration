import React, { useContext, useEffect, useState } from "react";
import Image from "next/image";
import NextImage from "next/future/image";
import Link from "next/link";
import Sidebar from "../Sidebar";
import { useRouter } from "next/router";
import CKEditor from "@/utils/CkEditor";
import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import { convertToBase64, formattedDate, formattedDate2 } from "@/utils/helper";
import axios from "axios";
import dynamic from "next/dynamic";
const ButtonText = dynamic(() => import("@/components/Common/ButtonText"));
const JoinOurCommunity = dynamic(
  () => import("@/components/AboutUs/JoinOurCommunity")
);
import Button from "@/components/Common/Button";
const Zoho = dynamic(() => import("./Zoho"));
import AppDownload from "@/components/Courses/AppDownload";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Author from "@/components/Glossary/Author";
import { AppContext } from "context/AppContextProvider";
import KeyTakeaways from "./KeyTakeaways";
import CtasCard from "@/components/knowledgebase/CtasCard";

const DetailsContent = ({ blogData, popularBlogs, blogId, relatedBlogs }) => {
  console.log("blogDataaaaaaaa", blogData);
  const authorData = blogData?.author || null;
  const router = useRouter();
  const [categories, setCategories] = useState([]);
  const initialData = {
    blog: blogId,
    name: "",
    email: "",
    website: "",
    comment: "",
    parent_comment: null,
  };
  const [formDataArray, setFormDataArray] = useState([
    initialData,
    initialData,
  ]);
  const [storedUser, setStoredUser] = useState(null);
  const [buttonLoading, setButtonLoading] = useState(false);
  const [blogComments, setBlogComments] = useState([]);
  const [selectedReplyId, setSelectedReplyId] = useState(null);
  const [cta, setCta] = useState([]);
  const { showStripe } = useContext(AppContext);

  useEffect(() => {
    const filteredCtasData = blogData?.ctas?.filter((item) =>
      item?.description_type?.some(
        (subItem) => subItem?.__typename === "ComponentButtonNewsletter"
      )
    );
    setCta(filteredCtasData);
  }, [blogData]);

  const [hydrated, setHydrated] = useState(false); //to check page is loaded
  useEffect(() => {
    setHydrated(true);
  }, []);

  const handleCommentChange = (index, field, value) => {
    setFormDataArray((prevData) => {
      const newData = [...prevData];
      newData[index] = { ...newData[index], [field]: value };
      return newData;
    });
  };

  const handleReplyClick = (replyId) => {
    if (selectedReplyId) {
      setSelectedReplyId(null);
    } else setSelectedReplyId(replyId);
  };

  // form to post comment
  const PostComment = ({ index, formData, onCommentChange, onSubmit }) => {
    const handleInputChange = (field, value) => {
      onCommentChange(index, field, value);
    };
    const handleFormSubmit = (e) => {
      e.preventDefault();
      onSubmit();
    };
    return (
      <div className="comment-respond">
        <h3 className="comment-reply-title">Leave A Reply</h3>
        <p className="comment-notes">
          <span id="email-notes">
            Your email address will not be published.
          </span>{" "}
          Required fields are marked <span className="required">*</span>
        </p>
        <form className="comment-form" onSubmit={handleFormSubmit}>
          <div className="row">
            <div className="col-lg-6 col-md-6 col-sm-6">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Your Name"
                  required
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                />
              </div>
            </div>
            <div className="col-lg-6 col-md-6 col-sm-6">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Your Email"
                  required
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                />
              </div>
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Website"
                  value={formData.website}
                  onChange={(e) => handleInputChange("website", e.target.value)}
                />
              </div>
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="form-group">
                <textarea
                  className="form-control"
                  cols="30"
                  rows="5"
                  placeholder="Your Comment..."
                  required
                  value={formData.comment}
                  onChange={(e) => handleInputChange("comment", e.target.value)}
                ></textarea>
              </div>
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="checkme"
                  required
                />
                <label className="form-check-label" htmlFor="checkme">
                  Save my name, email, and website in this browser for the next
                  time I comment.
                </label>
              </div>
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12">
              <button
                type="submit"
                className="submit-btn btn1"
                disabled={buttonLoading}
              >
                Post Your Comment
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  };

  // to display comment Recursive approach
  const Comment = ({ key, comment, allComments }) => {
    const replies = allComments.filter(
      (c) =>
        c?.attributes.parent_comment === comment?.id &&
        c?.attributes.parent_comment !== null
    );

    return (
      <li key={key} className="comment">
        <div className="comment-body">
          <footer className="comment-meta">
            <div className="comment-author vcard">
              <div className="avatar">
                <Image
                  src={"/images/profile-img.jpg"}
                  width={80}
                  height={80}
                  alt="user"
                  loading="lazy"
                />
              </div>
              <b className="fn">{comment?.attributes?.name}</b>
            </div>
            <div className="comment-metadata">
              <span>{formattedDate2(comment?.attributes?.createdAt)}</span>
            </div>
          </footer>
          <div className="comment-content">
            <p>{comment?.attributes?.comment}</p>
          </div>
          <div className="reply">
            <a
              className="comment-reply-link"
              onClick={() => handleReplyClick(comment.id)}
            >
              Reply
            </a>
          </div>
          {selectedReplyId === comment.id &&
            PostComment({
              index: 0,
              formData: formDataArray[0],
              onCommentChange: handleCommentChange,
              onSubmit: () => handleSubmit(0),
            })}
        </div>
        {replies.length > 0 && (
          <ol className="children">
            {replies.map((reply, index) =>
              Comment({
                key: index,
                comment: reply,
                allComments: allComments,
              })
            )}
          </ol>
        )}
      </li>
    );
  };

  const CommentSection = ({ comments }) => {
    // Create a copy of comments array to avoid mutating the original array
    const commentsCopy = [...comments];
    // Find the root comments (comments without a parent_comment)
    const rootComments = commentsCopy.filter(
      (comment) => comment?.attributes?.parent_comment === null
    );
    return (
      <ol className="comment-list">
        {rootComments.map((comment, index) =>
          Comment({
            key: index,
            comment: comment,
            allComments: commentsCopy,
          })
        )}
      </ol>
    );
  };

  const areObjectsEqual = (obj1, obj2) => {
    const keys1 = Object.keys(obj1);
    const keys2 = Object.keys(obj2);

    if (keys1.length !== keys2.length) {
      return false;
    }

    for (const key of keys1) {
      if (obj1[key] !== obj2[key]) {
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (index) => {
    const formData = formDataArray[index];
    const user = {
      name: formData?.name,
      email: formData?.email,
      website: formData?.website,
    };
    const areUsersEqual = areObjectsEqual(user, storedUser);
    // console.log("areUsersEqual", areUsersEqual);

    if (!areUsersEqual) {
      // Convert the user object to a JSON string
      const userString = JSON.stringify(user);

      // Store the user string in localStorage
      localStorage.setItem("user", userString);
    }
    // console.log("formData", formData);
    try {
      setButtonLoading(true);
      if (index === 0) {
        formData.parent_comment = selectedReplyId;
      }
      // console.log("formData", formData);
      const res = await axios.post(
        `${process.env.NEXT_PUBLIC_STRAPI_URL}api/blog-comments`,
        {
          data: formData,
        }
      );
      // console.log("data:", res);
      const initialDataForUser = {
        blog: blogId,
        name: user.name || "",
        email: user.email || "",
        website: user.website || "",
        comment: "",
        parent_comment: null,
      };
      setFormDataArray([initialDataForUser, initialDataForUser]);
      if (index === 0) {
        setSelectedReplyId(null);
      }
      getComments(blogData?.slug);
    } catch (error) {
      console.log("error", error);
    } finally {
      setButtonLoading(false);
    }
  };

  const getCategoriesAndTags = async () => {
    const { data, errors } = await client.query({
      query: gql`
        query getCategriesAndTag {
          categories {
            slug
            title
            blogs {
              documentId
            }
          }
        }
      `,
    });

    if (errors?.length > 0) {
      return {
        redirect: {
          destination: `/500?url=/${blogData?.slug}`,
          permanent: true,
        },
      };
    }
    console.log("data for categor", data);

    const sortArray = data?.categories
      ?.sort((a, b) => b?.blogs.length - a?.blogs?.length)
      ?.slice(0, 10);
    // console.log("sortArray", sortArray);

    setCategories(sortArray || []);
  };

  const getComments = async (slug) => {
    const { data, errors } = await client.query({
      query: gql`
        query getComments {
  blogs(filters: { slug: { eq: "${slug}" } }) {
    blog_comments(filters: { approve_by_admin: { eq: true } }) {
      documentId
      name
      email
      comment
      parent_comment
      approve_by_admin
      createdAt
    }
  }
}

      `,
    });

    if (errors?.length > 0) {
      return {
        redirect: {
          destination: `/500?url=/${blogData?.slug}`,
          permanent: true,
        },
      };
    }

    // console.log(
    //   "comments",
    //   data?.blogs?.data?.[0]?.attributes?.blog_comments?.data
    // );

    setBlogComments(
      data?.blogs?.data?.[0]?.attributes?.blog_comments?.data || []
    );
  };

  const getUserData = () => {
    // Get user data from localStorage
    const storedUserString = localStorage.getItem("user");

    // Parse the user string back to an object
    const storedUser = JSON.parse(storedUserString);

    // Check if storedUser is null or undefined
    if (storedUser !== null && storedUser !== undefined) {
      setStoredUser(storedUser);
      // Create initial data for each form based on the retrieved user data
      const initialDataForUser = {
        blog: blogId,
        name: storedUser.name || "",
        email: storedUser.email || "",
        website: storedUser.website || "",
        comment: "",
        parent_comment: null,
      };

      // Set the initial state of formDataArray
      setFormDataArray([initialDataForUser, initialDataForUser]);
    }
  };

  useEffect(() => {
    getCategoriesAndTags();
    getComments(blogData?.slug);
    getUserData();
  }, []);
  // console.log("blogComments", blogComments);

  const shareUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/${blogData?.slug}`;

  return (
    <div className="blog-details-area pt-100">
      <div className="container">
        <div className="d-lg-flex gap-4">
          <div className="sidebar-wrapper flex-shrink-0">
            <div
              className={`left-sidebar ${
                showStripe ? "left-sidebar-with-top-stripe" : ""
              }`}
            >
              <Sidebar
                categories={categories}
                tableOfContent={blogData?.description_type}
                slug={blogData?.slug}
                popularBlogs={popularBlogs}
              />
            </div>
          </div>

          <div className="">
            <div className="blog-details-desc green-color">
              <div className="post-thumb hide-on-desktop">
                <Image
                  src={replaceImageUrl(blogData?.image?.url)}
                  alt="blog-details"
                  priority
                  // loading="eager"
                  layout="fill"
                  quality={75}
                  objectFit="cover"
                  objectPosition={"center"}
                />
                {/* <picture>
                  <source
                    media="(max-width:699px)"
                    srcSet={
                      replaceImageUrl(blogData?.image?.data?.attributes?.url) ||
                      ""
                    }
                    type="image/webp"
                  />
                  <source
                    media="(max-width:640px)"
                    srcSet={
                      replaceImageUrl(blogData?.image?.data?.attributes?.url) ||
                      ""
                    }
                    type="image/webp"
                  />
                  <Image
                    src={replaceImageUrl(
                      blogData?.image?.data?.attributes?.url
                    )}
                    alt="blog-details"
                    layout="fill"
                    objectFit="cover"
                    objectPosition={"center"}
                    priority="low"
                    // loading="eager"
                    quality={75}
                  />
                </picture> */}
              </div>
              <div className="post-thumb hide-on-small-screen">
                <Image
                  src={replaceImageUrl(blogData?.image?.url)}
                  alt="blog-details"
                  priority
                  // loading="lazy"
                  layout="fill"
                  // quality={75}
                  // objectFit="cover"
                  // objectPosition={"center"}
                />
                {/* <picture>
                  <source
                    media="(max-width:699px)"
                    srcSet={
                      replaceImageUrl(blogData?.image?.data?.attributes?.url) ||
                      ""
                    }
                    type="image/webp"
                  />
                  <source
                    media="(max-width:640px)"
                    srcSet={
                      replaceImageUrl(blogData?.image?.data?.attributes?.url) ||
                      ""
                    }
                    type="image/webp"
                  />
                  <Image
                    src={replaceImageUrl(
                      blogData?.image?.data?.attributes?.url
                    )}
                    alt="blog-details"
                    layout="fill"
                    objectFit="cover"
                    objectPosition={"center"}
                    // priority="low"
                    loading="lazy"
                    quality={75}
                  />
                </picture> */}
              </div>
              <div className="post-meta">
                <ul>
                  {/* <li>
                    <i className="bx bx-purchase-tag-alt"></i>
                    <Link href="/blogs/blog-tag">
                      <a>{blogData?.tags?.data?.[0]?.attributes?.title}</a>
                    </Link>
                  </li> */}
                  <li>
                    <i className="bx bx-calendar-check"></i>
                    {/* 25 Nov, 2021 */}
                    {formattedDate(
                      blogData?.publish_date || blogData?.createdAt
                    )}
                  </li>
                </ul>
              </div>
              {/* <CKEditor content={blogData?.description} id /> */}
              {blogData?.description_type?.map((item, index) => {
                if (item?.__typename === "ComponentButtonButtonImageText") {
                  return (
                    <div key={index} className="blog-join-our-community-area">
                      <JoinOurCommunity
                        key={index}
                        image={item?.image?.url}
                        title={item?.title}
                        button={item?.button_image_text_button}
                        description={item?.description}
                      />
                    </div>
                  );
                } else if (item?.__typename === "ComponentButtonButtonText") {
                  return <ButtonText key={index} data={item} />;
                } else if (item?.__typename === "ComponentCommonButton") {
                  return <Button key={index} data={item} />;
                } else if (item?.__typename === "ComponentCommonEditor") {
                  return (
                    <React.Fragment key={index}>
                      <CKEditor content={item?.description} id />
                    </React.Fragment>
                  );
                } else if (item?.__typename === "ComponentBlogKeyTakeaways") {
                  return <KeyTakeaways key={index} data={item} />;
                }
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="container mt-5">
        {/* 9.5 */}
        <div className="section-9-5 blog-details-desc">
          <div className="tags-parentDiv post-footer">
            <div className="tags blog-tags">
              {blogData?.tags?.length > 0 &&
                blogData?.tags?.map((tag, index) => {
                  return (
                    <Link key={index} href={`/tags/${tag?.slug}` || ""}>
                      <a target="_blank">{tag?.title}</a>
                    </Link>
                  );
                })}
            </div>
            <div className="article-share">
              <ul className="social">
                <li>
                  <span>Share:</span>
                </li>
                <li>
                  <a
                    href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
                      `${shareUrl}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="facebook"
                    className="facebook"
                  >
                    <i className="bx bxl-facebook"></i>
                  </a>
                </li>
                <li>
                  <a
                    href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(
                      `${shareUrl}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="twitter"
                    aria-label="twitter"
                  >
                    <i className="bx bxl-twitter"></i>
                  </a>
                </li>
                <li>
                  <a
                    href={`http://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(
                      `${shareUrl}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="linkedin"
                    aria-label="linkedin"
                  >
                    <i className="bx bxl-linkedin"></i>
                  </a>
                </li>
                <li>
                  <a
                    href="https://www.instagram.com/"
                    className="instagram"
                    target="_blank"
                    rel="noreferrer"
                    aria-label="instagram"
                  >
                    <i className="bx bxl-instagram"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          {/* {authorData && (
            <div className="mt-5 blog-author">
              {authorData?.image?.data ? (
                <Image
                  src={replaceImageUrl(
                    authorData?.image?.data?.attributes?.url
                  )}
                  height={100}
                  width={100}
                  alt="user"
                  loading="lazy"
                  style={{ borderRadius: "50%" }}
                />
              ) : (
                <div className="default-image"></div>
              )}
              <h4 className="blog-author-name">
                <Link href={`/author/${authorData?.slug}` || ""}>
                  <a>{authorData?.name}</a>
                </Link>
              </h4>
              <span>{authorData?.skill}</span>
              <CKEditor content={authorData?.bio} customStyle="mt-3" />
            </div>
          )} */}
          {authorData && <Author authorData={authorData} hideAddress />}
        </div>

        {/* 9.6 */}
        {relatedBlogs?.length > 0 && (
          <div className="section-9-6">
            <h3>Related Post</h3>
            <div className="mt-3 related-posts">
              {relatedBlogs?.map((item, i) => {
                const blog = item;
                const image = replaceImageUrl(blog?.image?.url);
                return (
                  <div
                    key={i}
                    className="post"
                    onClick={() => router.push(`/${blog?.slug}`)}
                  >
                    <div
                      className="post-img-div"
                      style={{ borderRadius: "7px", overflow: "hidden" }}
                    >
                      {blog?.image && (
                        <Link href={blog?.slug || ""}>
                          <a style={{ borderRadius: "7px" }}>
                            <NextImage
                              src={image}
                              alt="blog-details"
                              width={365}
                              height={265}
                              // layout="fill"
                              style={{
                                borderRadius: "7px",
                                width: "100%",
                                height: "100%",
                              }}
                              loading="lazy"
                            />
                          </a>
                        </Link>
                      )}
                      <div className="post-tag">{blog?.tags?.[0]?.title}</div>
                    </div>
                    <div className="post-data">
                      <p>
                        <i className="bx bx-time"></i>{" "}
                        {formattedDate(blog?.publish_date || blog?.createdAt)}
                      </p>
                      <p>
                        <i className="bx bx-comment-dots"></i> (0) Comment
                      </p>
                    </div>
                    <h3>
                      <Link href={blog?.slug || ""}>
                        <a>{blog?.title}</a>
                      </Link>
                    </h3>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        {/* {blogData?.description_type?.map((item, index) => {
          if (item?.__typename === "ComponentButtonNewsletter") {
            return (
              hydrated && <Zoho key={index} embedCode={item?.description} />
            );
          }
        })} */}
        {cta?.map((item, i) => {
          return item?.description_type?.map((subItem, index) => {
            if (subItem?.__typename === "ComponentButtonNewsletter") {
              return (
                <Zoho
                  key={index}
                  embedCode={subItem?.description}
                  form_onsubmit={subItem?.form_onsubmit}
                  form_onload={subItem?.form_onload}
                />
              );
            }
          });
        })}

        {blogData?.ctas?.map((item, i) => {
          return item?.description_type?.map((subItem, index) => {
            if (subItem?.__typename === "ComponentKnowledgeBase3CardsCtas") {
              return <CtasCard key={index} data={subItem} />;
            }
          });
        })}

        <div className="comments-area green-color">
          {blogComments?.length > 0 && (
            <>
              <h3 className="comments-title">
                {blogComments?.length === 1
                  ? `${blogComments?.length} Comment:`
                  : `${blogComments?.length} Comments:`}
              </h3>
              {/* Render comments */}
              {CommentSection({ comments: blogComments })}
            </>
          )}

          {PostComment({
            index: 1,
            formData: formDataArray[1],
            onCommentChange: handleCommentChange,
            onSubmit: () => handleSubmit(1),
          })}
        </div>
      </div>

      {/* category for max 992px */}
      {categories?.length > 0 && (
        <div className="container">
          <div className="widget-area" style={{ marginTop: "50px" }}>
            <div className="widget widget_categories hideCategory">
              <h3 className="widget-title">
                <span>Categories</span>
              </h3>
              <ul>
                {categories?.map((category, index) => {
                  const count = category?.blogs?.length;
                  return (
                    <li key={index}>
                      <Link
                        href={
                          count > 0
                            ? `/categories/${category?.slug}`
                            : `/${blogData?.slug}`
                        }
                      >
                        <a>
                          {category?.title}{" "}
                          <span className="count">({count})</span>
                        </a>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
      )}
      {/* end */}

      {blogData?.ctas?.data?.map((item, i) => {
        return item?.attributes?.description_type?.map((subItem, index) => {
          if (subItem?.__typename === "ComponentButtonButtonImageText") {
            return (
              <JoinOurCommunity
                key={index}
                image={subItem?.image?.url}
                title={subItem?.title}
                button={subItem?.button_image_text_button}
                description={subItem?.description}
              />
            );
          } else if (subItem?.__typename === "ComponentButtonButtonText") {
            return <ButtonText key={index} data={subItem} />;
          } else if (subItem?.__typename === "ComponentCommonButton") {
            return (
              <div key={index} style={{ width: "max-content", margin: "1rem auto" }}>
                <Button key={index} data={subItem} />
              </div>
            );
          } else if (subItem?.__typename === "ComponentCommonAppDownload") {
            return <AppDownload download_app_section={subItem} key={index} />;
          }
        });
      })}
    </div>
  );
};

export default DetailsContent;

import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function KeyTakeaways({ data }) {
  return (
    <div className="key-takeaways-wrap">
      <h2>{data?.title}</h2>
      <CKEditor content={data?.description} />
    </div>
  );
}

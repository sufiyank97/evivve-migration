import React, { useEffect } from "react";

const ZohoCareers = () => {
  useEffect(() => {
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src =
      "https://static.zohocdn.com/recruit/embed_careers_site/javascript/v1.0/embed_jobs.js";

    const widgetId = "rec_job_listing_div";

    script.onload = () => {
      rec_embed_js.load({
        widget_id: widgetId,
        page_name: "Careers",
        source: "CareerSite",
        site: "https://gamitar.zohorecruit.in",
        empty_job_msg: "No current Openings",
      });
    };

    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return (
    <div className="embed_jobs_head embed_jobs_with_style_3 embed_jobs_with_style">
      <div className="embed_jobs_head2">
        <div className="embed_jobs_head3">
          <div id="rec_job_listing_div"></div>
        </div>
      </div>
    </div>
  );
};

export default ZohoCareers;

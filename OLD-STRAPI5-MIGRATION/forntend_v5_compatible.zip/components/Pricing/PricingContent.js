import React, { Fragment } from "react";
// import Link from "next/link";
import { Tooltip } from "react-tooltip";

const PricingContent = ({ plansData }) => {
  return (
    <div className="pricing-area bg-f1f5fd pb-75">
      <div className="container">
        <div
          className="row"
          style={{
            justifyContent: "center",
            alignItems: "stretch",
            rowGap: "25px",
          }}
        >
          {plansData?.map((plan, i) => {
            return (
              <div
                key={i}
                className={`col-lg-3 col-md-6 ${i === 4 ? "pricing-plan" : ""}`}
                data-aos="fade-up"
                data-aos-duration="1200"
                // style={{ height: "100%" }}
              >
                <div
                  className="single-pricing-box"
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    height: "100%",
                  }}
                >
                  <div>
                    <h3>{plan?.plan_name}</h3>
                    {plan?.price_text ? (
                      <p className="price-text">{plan?.price_text}</p>
                    ) : plan?.price?.length > 0 ? (
                      <div>
                        {plan?.price?.map((priceItem, index) => {
                          return (
                            <div className="price" key={index}>
                              ${priceItem?.price}
                              <span>/{priceItem?.plan_type}</span>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      ""
                    )}
                    <p>{plan?.description}</p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                    }}
                  >
                    <ul className="features-list">
                      {plan?.plan_features?.map((feature, i) => {
                        return (
                          <Fragment key={i}>
                            <li>
                              {/* <i className="flaticon-draw-check-mark"></i> */}
                              <span className={"check-icon pricing-check-icon"}>
                                <i
                                  className={`bx bx-${
                                    feature?.applicable ? "check" : "x"
                                  }`}
                                  style={{
                                    color: feature?.applicable
                                      ? "inherit"
                                      : "red",
                                  }}
                                ></i>
                              </span>
                              {feature?.name}
                              {feature?.tooltip_text &&
                                feature?.show_tooltip && (
                                  <div
                                    className={"tooltip"}
                                    data-tooltip-id="my-tooltip"
                                    data-tooltip-content={feature?.tooltip_text}
                                  >
                                    <i class="bx bx-info-circle"></i>
                                  </div>
                                )}
                            </li>
                          </Fragment>
                        );
                      })}
                    </ul>
                    <div style={{ textAlign: "center" }}>
                      <a
                        href={plan?.pricing_button?.button_link || "/contact"}
                        target={plan?.pricing_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
                        className="btn-style-one light-green-color"
                        // style={{ left: "50%", transform: "translateX(-50%)" }}
                      >
                        {plan?.pricing_button?.button_text}
                        {/* <i className="bx bx-chevron-right"></i> */}
                      </a>
                    </div>
                  </div>
                  {plan?.most_popular && (
                    <div className="popular-tag">Most Popular</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        {plansData?.map((plan, i) => {
          if (i === 4) {
            return (
              <div
                key={i}
                className={`col-lg-3 col-md-6 pricing-plan-5th-card`}
                data-aos="fade-up"
                data-aos-duration="1200"
                // style={{ height: "100%" }}
              >
                <div
                  className="single-pricing-box"
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    height: "100%",
                  }}
                >
                  <div>
                    <h3>{plan?.plan_name}</h3>
                    {plan?.price_text ? (
                      <p className="price-text">{plan?.price_text}</p>
                    ) : plan?.price?.length > 0 ? (
                      <div>
                        {plan?.price?.map((priceItem, index) => {
                          return (
                            <div className="price" key={index}>
                              ${priceItem?.price}
                              <span>/{priceItem?.plan_type}</span>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      ""
                    )}
                    <p>{plan?.description}</p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                    }}
                  >
                    <ul className="features-list">
                      {plan?.plan_features?.map((feature, i) => {
                        return (
                          <Fragment key={i}>
                            <li>
                              {/* <i className="flaticon-draw-check-mark"></i> */}
                              <span className={"check-icon pricing-check-icon"}>
                                <i
                                  className={`bx bx-${
                                    feature?.applicable ? "check" : "x"
                                  }`}
                                  style={{
                                    color: feature?.applicable
                                      ? "inherit"
                                      : "red",
                                  }}
                                ></i>
                              </span>
                              {feature?.name}
                            </li>
                          </Fragment>
                        );
                      })}
                    </ul>
                    <div style={{ textAlign: "center" }}>
                      <a
                        href={plan?.pricing_button?.button_link || "/contact"}
                        target={plan?.pricing_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
                        className="btn-style-one light-green-color"
                        // style={{ left: "50%", transform: "translateX(-50%)" }}
                      >
                        {plan?.pricing_button?.button_text}
                        {/* <i className="bx bx-chevron-right"></i> */}
                      </a>
                    </div>
                  </div>
                  {plan?.most_popular && (
                    <div className="popular-tag">Most Popular</div>
                  )}
                </div>
              </div>
            );
          }
        })}
      </div>
      <Tooltip id="my-tooltip" className="pricing-tool-tip" />
    </div>
  );
};

export default PricingContent;

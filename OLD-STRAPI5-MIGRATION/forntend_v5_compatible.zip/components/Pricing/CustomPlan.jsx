// import Link from "next/link";
import React from "react";

export default function CustomPlan({ data }) {
  return (
    <div className="container">
      <div className="pricing-custom-plan">
        <div>
          <h1 className="pricing-custom-plan-title">{data?.title}</h1>
          <p className="pricing-custom-plan-content">{data?.description}</p>
          {data?.custom_plan_button?.button_text && (
            <div style={{ textAlign: "center" }}>
              <a
                href={data?.custom_plan_button?.button_link || ""}
                target={data?.custom_plan_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
                className="btn-style-one light-green-color"
              >
                {data?.custom_plan_button?.button_text}
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

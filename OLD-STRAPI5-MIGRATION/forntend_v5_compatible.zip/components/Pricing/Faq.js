import React from "react";
import dynamic from "next/dynamic";
const Accordion = dynamic(() => import("../Accordion"));
import Link from "next/link";

const questionsAnswers = [
  {
    question: "How many team members can I invite?",
    answer:
      "You can invite up to 2 additional users on the Free plan. There is no limit on team members for the Premium plan.",
  },
  {
    question: "What is the maximum file upload size?",
    answer:
      "No more than 2GB. All files in your account must fit your allotted storage space.",
  },
  {
    question: "How do I reset my password?",
    answer: `Click “Forgot password” from the login page or “Change password” from your profile page. A reset link will be emailed to you.`,
  },
  {
    question: "Can I cancel my subscription?",
    answer: `Yes! Send us a message and we’ll process your request no questions asked.`,
  },
];

const Faq = ({ faqData }) => {
  return (
    <div className="faq-area bg-f3feff ptb-100">
      <div className="container">
        <div className="section-title">
          <span className="sub-title">{faqData?.heading}</span>
          <h2>{faqData?.title}</h2>
        </div>
        <div className="faq-accordion style-two">
          <div className="accordion" id="faqAccordion">
            <Accordion questionsAnswers={faqData?.faq} />
          </div>
        </div>
        {(faqData?.heading_text || faqData?.link_text) && (
          <div style={{ textAlign: "center" }} className="mt-5 section-13-4">
            {faqData?.heading_text && (
              <h4 className="mb-3">{faqData?.heading_text}</h4>
            )}
            <Link href={faqData?.link_url} target={faqData?.link_target}>
              {faqData?.link_text}
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default Faq;

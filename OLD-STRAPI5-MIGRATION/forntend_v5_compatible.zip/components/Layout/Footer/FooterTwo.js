import React from "react";
import Link from "next/link";
import Image from "next/image";

import whiteLogo from "@/public/images/bluepurple-evivve-logo.png";
import { useRouter } from "next/router";

const FooterTwo = ({ footerData, commonData, showOnboarding }) => {
  const currentYear = new Date().getFullYear();
  const router = useRouter();

  const hideFooterOnOnboardingScreen =
    showOnboarding && router.pathname === "/";
  return (
    <div
      className="template-footer-two pt-100"
      style={{
        background: "#341A5A !important",
        zIndex: hideFooterOnOnboardingScreen ? "-1" : "0",
        position: hideFooterOnOnboardingScreen ? "absolute" : "",
        top: hideFooterOnOnboardingScreen ? "-1000px" : "",
      }}
    >
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-6 col-md-12">
            <div className="single-footer-widget" style={{ maxWidth: "450px" }}>
              <Link href="/" prefetch={false}>
                <a className="logo" aria-label="logo">
                  {commonData?.footer?.logo?.data ? (
                    <Image
                      src={commonData?.footer?.logo?.data?.attributes?.url}
                      alt="logo"
                      width={135}
                      height={38}
                      style={{ borderRadius: "0" }}
                      loading="lazy"
                    />
                  ) : (
                    <Image
                      src={whiteLogo}
                      alt="logo"
                      width={135}
                      height={38}
                      style={{ borderRadius: "0" }}
                      loading="lazy"
                    />
                  )}
                </a>
              </Link>
              <p>
                {/* A Multiplayer Online Game-Based Learning (MOGL) Tool for
                leadership and team development */}
                {commonData?.footer?.footer_description}
              </p>
              {/* <ul className="footer-contact-info">
                <li>
                  <i className="bx bx-phone-call"></i>
                  <a href="tel:+1-485-456-0102">+1-485-456-0102</a>
                </li>
                <li>
                  <i className="bx bx-envelope"></i>
                  <a href="mailto:hello@abev.com">hello@abev.com</a>
                </li>
                <li>
                  <i className="bx bx-map"></i>
                  2750 Quadra Street Victoria, Canada.
                </li>
              </ul> */}
            </div>
          </div>

          <div className="col-lg-6 col-md-12">
            <div className="footer-links-wraper-div">
              {footerData?.length > 0 ? (
                footerData?.map((footer, index) => {
                  return (
                    <div key={index} className="single-footer-widget">
                      <h3>{footer?.attributes?.title}</h3>
                      <ul className="quick-links">
                        <>
                          {footer?.attributes?.children?.data?.map(
                            (item, index) => {
                              return (
                                <li key={index}>
                                  <Link
                                    prefetch={false}
                                    href={item?.attributes?.url || ""}
                                  >
                                    <a
                                      target={
                                        item?.attributes?.target || "_self"
                                      }
                                    >
                                      {item?.attributes?.title}
                                    </a>
                                  </Link>
                                </li>
                              );
                            }
                          )}
                          {index === 0 && (
                            <>
                              <li>
                                <Link
                                  href={
                                    commonData?.download_app?.ios_link || ""
                                  }
                                  prefetch={false}
                                >
                                  <a
                                    className="footer-app-img"
                                    aria-label="apple-store"
                                  >
                                    {commonData?.download_app?.ios?.data ? (
                                      <Image
                                        src={
                                          commonData?.download_app?.ios?.data
                                            ?.attributes?.url
                                        }
                                        alt=""
                                        width={
                                          commonData?.download_app?.ios?.data
                                            ?.attributes?.width
                                        }
                                        height={
                                          commonData?.download_app?.ios?.data
                                            ?.attributes?.height
                                        }
                                        style={{ borderRadius: "0" }}
                                        loading="lazy"
                                      />
                                    ) : (
                                      <Image
                                        src={"/images/apple-store.png"}
                                        alt=""
                                        width={34}
                                        height={35}
                                        style={{ borderRadius: "0" }}
                                        loading="lazy"
                                      />
                                    )}
                                  </a>
                                </Link>
                              </li>
                              <li>
                                <Link
                                  href={
                                    commonData?.download_app?.android_link || ""
                                  }
                                  prefetch={false}
                                >
                                  <a
                                    className="footer-app-img"
                                    aria-label="play-store"
                                  >
                                    {commonData?.download_app?.android?.data ? (
                                      <Image
                                        src={
                                          commonData?.download_app?.android
                                            ?.data?.attributes?.url
                                        }
                                        alt=""
                                        width={
                                          commonData?.download_app?.android
                                            ?.data?.attributes?.width
                                        }
                                        height={
                                          commonData?.download_app?.android
                                            ?.data?.attributes?.height
                                        }
                                        style={{ borderRadius: "0" }}
                                        loading="lazy"
                                      />
                                    ) : (
                                      <Image
                                        src={"/images/play-store.png"}
                                        alt=""
                                        width={34}
                                        height={35}
                                        style={{ borderRadius: "0" }}
                                        loading="lazy"
                                      />
                                    )}
                                  </a>
                                </Link>
                              </li>
                            </>
                          )}
                        </>
                      </ul>
                    </div>
                  );
                })
              ) : (
                <>
                  <div className="single-footer-widget">
                    <h3>Evivve Game</h3>
                    <ul className="quick-links">
                      <li>
                        <Link href="" prefetch={false}>
                          <a>Evivve Facilitation Certification</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a>Facilitation Assistant</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a>VUCA Leadership Training Workshops</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a aria-label="apple-store">
                            <Image
                              src={"/images/apple-store.png"}
                              alt=""
                              width={34}
                              height={35}
                              loading="lazy"
                            />
                          </a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a aria-label="play-store">
                            <Image
                              src={"/images/play-store.png"}
                              alt=""
                              width={27}
                              height={30}
                              loading="lazy"
                            />
                          </a>
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div className="single-footer-widget">
                    <h3>Resources</h3>
                    <ul className="quick-links">
                      <li>
                        <Link href="" prefetch={false}>
                          <a>Blog</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a>Success Stories</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a>Testimonials</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a>Help Center</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a>Game Updates</a>
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div className="single-footer-widget">
                    <h3>Company</h3>
                    <ul className="quick-links">
                      <li>
                        <Link href="/about-us" prefetch={false}>
                          <a>About Us</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="/contact" prefetch={false}>
                          <a>Contact Us</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="/careers" prefetch={false}>
                          <a>Careers</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="" prefetch={false}>
                          <a>Media & Press kit</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="/privacy-policy" prefetch={false}>
                          <a>Privacy Policy</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="/terms-conditions" prefetch={false}>
                          <a>Terms of Use</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="/cookie-policy" prefetch={false}>
                          <a>Cookie Policy</a>
                        </Link>
                      </li>
                    </ul>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* <div className="col-lg-4 col-md-6">
            <div className="single-footer-widget">
              <h3>Newsletter</h3>
              <div className="box">
                <p>Latest resources, sent to your inbox weekly</p>
                <form className="newsletter-form">
                  <input
                    type="text"
                    className="input-newsletter"
                    placeholder="Enter your email address"
                    name="EMAIL"
                    required={true}
                    autoComplete="off"
                  />
                  <button
                    type="submit"
                    className="btn-style-one red-light-color"
                  >
                    Subscribe Now <i className="bx bx-chevron-right"></i>
                  </button>
                </form>
              </div>
            </div>
          </div> */}
        </div>
      </div>

      <div className="copyright-area">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-6 col-md-7">
              <p>© {currentYear} Evivve. All rights reserved</p>
            </div>
            <div className="col-lg-6 col-md-5">
              <ul className="social-links">
                {commonData?.social_media?.length > 0 ? (
                  commonData?.social_media?.map((item, index) => {
                    return (
                      <li key={index}>
                        <a
                          href={item?.link || ""}
                          target="_blank"
                          rel="noreferrer"
                          aria-label="item?.name"
                        >
                          <i className={item?.name}></i>
                        </a>
                      </li>
                    );
                  })
                ) : (
                  <>
                    <li>
                      <a
                        href="https://www.facebook.com/"
                        target="_blank"
                        rel="noreferrer"
                        aria-label="facebook"
                      >
                        <i className="flaticon-facebook-app-symbol"></i>
                      </a>
                    </li>
                    <li>
                      <a
                        href="https://www.linkedin.com/"
                        target="_blank"
                        rel="noreferrer"
                        aria-label="linkedin"
                      >
                        <i className="flaticon-linkedin"></i>
                      </a>
                    </li>
                    <li>
                      <a
                        href="https://www.youtube.com/"
                        target="_blank"
                        rel="noreferrer"
                        aria-label="youtube"
                      >
                        <i className="flaticon-youtube"></i>
                      </a>
                    </li>
                  </>
                )}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FooterTwo;

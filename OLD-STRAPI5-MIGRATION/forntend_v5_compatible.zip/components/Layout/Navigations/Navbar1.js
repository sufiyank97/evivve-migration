import React, { useContext, useEffect, useRef, useState } from "react";
import Link from "@/utils/ActiveLink";
import Image from "next/image";
import dynamic from "next/dynamic";

import imagelogo from "@/public/images/bluepurple-evivve-logo.png";
const TopStickyStripe = dynamic(() => import("../TopStickyStripe"));
import { AppContext } from "context/AppContextProvider";
import { useRouter } from "next/router";

const Navbar = ({ header, logo, top_sticky_stripe, host, hide }) => {
  const [menu, setMenu] = React.useState(true);
  const [windowWidth, setWindowWidth] = React.useState(0);
  const [headerData, setHeaderData] = React.useState([]);
  const { showStripe, setShowStripe } = useContext(AppContext);
  const router = useRouter();
  const [activeDropDownIndex, setActiveDropDownIndex] = useState(null);
  const [activeSubDropDownIndex, setActiveSubDropDownIndex] = useState(null);

  const toggleDropdown = (index) => {
    setActiveDropDownIndex((prev) => (prev === index ? null : index));
    setActiveSubDropDownIndex(null); // Close any open subdropdown when switching dropdowns
  };

  const toggleSubDropdown = (index) => {
    setActiveSubDropDownIndex((prev) => (prev === index ? null : index));
  };

  const toggleNavbar = () => {
    setMenu(!menu);
  };

  React.useEffect(() => {
    let elementId = document.getElementById("navbar");
    document.addEventListener("scroll", () => {
      if (window.scrollY > 170 || router.pathname === "/") {
        elementId.classList.add("is-sticky");
      } else {
        elementId.classList.remove("is-sticky");
      }
    });
  });

  useEffect(() => {
    const element = document.getElementById("navbar");

    const handleScroll = () => {
      const scrolled = window.scrollY;
      const isHome = router.pathname === "/";

      // Sticky behavior (optional)
      if (scrolled > 170) {
        element.classList.add("is-sticky");
      } else {
        element.classList.remove("is-sticky");
      }

      // --- NAVBAR VISIBILITY RULES ---
      if (isHome) {
        // On home page only: hide if scroll < 175
        if (scrolled < 175) {
          element.classList.add("slide-up");
          element.classList.remove("slide-down", "visible");
        } else {
          element.classList.remove("slide-up");
          element.classList.add("slide-down", "visible");
        }
      } else {
        // On ALL other pages: always show
        element.classList.remove("slide-up");
        element.classList.add("slide-down", "visible");
      }
    };

    // Run once on load
    handleScroll();

    // Attach scroll listener
    window.addEventListener("scroll", handleScroll);

    // Cleanup
    return () => window.removeEventListener("scroll", handleScroll);
  }, [router.pathname]); // ✅ NO showStripe here!

  React.useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    // Check if window is defined (client-side)
    if (typeof window !== "undefined") {
      setWindowWidth(window.innerWidth);
      window.addEventListener("resize", handleResize);

      // Remove the event listener when the component unmounts
      return () => {
        window.removeEventListener("resize", handleResize);
      };
    }
  }, []);

  const hasScrolledRef = useRef(false);
  const isScrollingRef = useRef(false);
  const scrollAttemptRef = useRef(null);

  useEffect(() => {
    const handleHashChange = (url) => {
      const hash = url?.split("#")[1];
      if (hash && !hasScrolledRef.current) {
        const scrollToElement = () => {
          const element = document.querySelector("#" + hash);
          if (element) {
            if (isScrollingRef.current) return;
            isScrollingRef.current = true;

            const scrollAndCheckPosition = () => {
              const elementTop =
                element.getBoundingClientRect().top +
                window.pageYOffset -
                (showStripe ? 175 : 100);
              window.scrollTo({
                top: elementTop,
                behavior: "smooth",
              });

              const checkScrollPosition = () => {
                const currentScrollPosition = window.pageYOffset;

                if (Math.abs(currentScrollPosition - elementTop) > 1) {
                  // If positions don't match, try scrolling again
                  scrollAttemptRef.current = setTimeout(
                    scrollAndCheckPosition,
                    200
                  );
                } else {
                  // Scroll position reached
                  isScrollingRef.current = false;
                  hasScrolledRef.current = true;
                }
              };

              // Delay to give time for the scroll to complete before checking position
              setTimeout(checkScrollPosition, 500);
            };

            scrollAndCheckPosition();
          } else {
            // Retry after a short delay if the element isn't found yet
            scrollAttemptRef.current = setTimeout(scrollToElement, 200);
          }
        };

        scrollToElement();
      }
    };

    const handlePageLoad = () => {
      if (router.asPath.includes("#")) {
        setTimeout(() => handleHashChange(router.asPath), 300);
      }
    };

    const handleRouteChange = (url) => {
      // Only reset hasScrolledRef if the pathname has changed
      if (url.split("#")[0] !== router.asPath.split("#")[0]) {
        hasScrolledRef.current = false;
      }
      if (url.includes("#")) {
        setTimeout(() => handleHashChange(url), 300);
      }
    };

    handlePageLoad();

    router.events.on("routeChangeComplete", handleRouteChange);

    return () => {
      router.events.off("routeChangeComplete", handleRouteChange);
      if (scrollAttemptRef.current) {
        clearTimeout(scrollAttemptRef.current);
      }
    };
  }, [router]);

  const addAttributes = async (data) => {
    const isSubMenuPresent = data?.attributes?.children?.data?.some(
      (item) =>
        item?.attributes?.children?.data &&
        item?.attributes?.children?.data?.length > 0
    );
    const width = isSubMenuPresent
      ? calculateWidth(data, isSubMenuPresent)
      : null;
    return {
      ...data,
      isSubMenuPresent,
      width: width,
    };
  };

  const updateHeaderData = async () => {
    let asyncCall = [];
    await header?.map((header) => asyncCall.push(addAttributes(header)));
    const updatedArray = await Promise.all(asyncCall);
    setHeaderData(updatedArray);
  };

  const containerRef = useRef();
  const [containerElement, setContainerElement] = useState(null);

  React.useEffect(() => {
    updateHeaderData();
  }, [header, containerElement]);

  useEffect(() => {
    setContainerElement(containerRef?.current);
  }, [containerRef?.current]);

  const calculateWidth = (header, isSubMenuPresent) => {
    if (windowWidth >= 992) {
      if (isSubMenuPresent && header?.attributes?.children?.data?.length > 1) {
        const percentage =
          (100 / 3) * header?.attributes?.children?.data?.length;
        // const containerElement =
        //   document.getElementById("m-container") || containerRef.current;
        // console.log("containerElement:", containerElement);
        // console.log("containerRef.current:", containerRef.current);
        if (containerElement) {
          const computedStyle = window.getComputedStyle(containerElement);

          // Extract the width property from the computed style
          const containerSize = computedStyle.getPropertyValue("width");
          const numericPart = parseInt(containerSize, 10);
          const pixelValue = (percentage / 100) * numericPart;
          return `${pixelValue}px`;
        } else return `${percentage}%`;
      } else {
        return "270px";
      }
    } else {
      return "100%";
    }
  };

  const classOne = menu
    ? "collapse navbar-collapse mean-menu"
    : "collapse navbar-collapse show";
  const classTwo = menu
    ? "navbar-toggler navbar-toggler-right collapsed"
    : "navbar-toggler navbar-toggler-right";

  const hideMobileMenu = () => {
    !menu && setMenu(true);
  };

  useEffect(() => {
    const href = "https://" + host + router.asPath;
    href === top_sticky_stripe?.top_sticky_stripe_button?.button_link &&
      setShowStripe(false);
  }, []);

  return (
    <>
      {showStripe && top_sticky_stripe?.visible && router.pathname !== "/" && (
        <div className="stripe-extra-top-padding"></div>
      )}
      <div
        id="navbar"
        className={`navbar-area ${
          !hide && showStripe && top_sticky_stripe?.visible
            ? "navbar-area-with-stripe"
            : ""
        }`}
      >
        {!hide && showStripe && top_sticky_stripe?.visible && (
          <TopStickyStripe top_sticky_stripe={top_sticky_stripe} />
        )}
        {headerData?.length > 0 && (
          <div className="main-nav">
            <div className="container" ref={containerRef} id="m-container">
              <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <Link href="/" prefetch={false}>
                  <a className="navbar-brand logo">
                    {logo ? (
                      <Image
                        src={logo}
                        alt="site logo"
                        width={135}
                        height={38}
                        loading="lazy"
                      />
                    ) : (
                      <Image
                        src={imagelogo}
                        alt="site logo"
                        width={135}
                        height={38}
                        loading="lazy"
                      />
                    )}
                  </a>
                </Link>

                <button
                  onClick={toggleNavbar}
                  className={classTwo}
                  type="button"
                  data-toggle="collapse"
                  data-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span className="icon-bar top-bar"></span>
                  <span className="icon-bar middle-bar"></span>
                  <span className="icon-bar bottom-bar"></span>
                </button>

                {/* desktop */}
                <div
                  className={`${classOne} menu-desktop`}
                  id="navbarSupportedContent"
                >
                  <ul className="navbar-nav">
                    {headerData
                      ?.slice(0, headerData?.length - 1)
                      .map((header, index) => {
                        return (
                          <li
                            key={index}
                            className={`nav-item ${
                              header?.isSubMenuPresent ? "megamenu" : ""
                            } ${
                              header?.attributes?.children?.data?.length > 1
                                ? "double-child"
                                : "single-child"
                            } ${
                              index ===
                              headerData?.slice(0, headerData?.length - 1)
                                ?.length -
                                1
                                ? header?.attributes?.children?.data?.length > 2
                                  ? `multiple-child ${
                                      header?.attributes?.children?.data
                                        ?.length < 4
                                        ? "last-nav-item"
                                        : ""
                                    }`
                                  : ""
                                : header?.attributes?.children?.data?.length > 3
                                ? "multiple-child"
                                : ""
                            }`}
                            // style={{ position: "relative" }}
                          >
                            <Link
                              href={header?.attributes?.url || ""}
                              prefetch={false}
                            >
                              <a
                                onClick={hideMobileMenu}
                                className={`${
                                  header?.attributes?.children?.data?.length > 0
                                    ? "dropdown-toggle"
                                    : ""
                                } nav-link`}
                                target={header?.attributes?.target || "_self"}
                              >
                                {header?.attributes?.title}
                              </a>
                            </Link>
                            {header?.attributes?.children?.data?.length > 0 && (
                              <ul
                                className={`dropdown-menu ${
                                  header?.isSubMenuPresent
                                    ? "dropdown-menu-sub-menu"
                                    : ""
                                }`}
                                style={{
                                  width: header.width,
                                }}
                              >
                                {header?.isSubMenuPresent ? (
                                  <li key={index} className="nav-item">
                                    <div className="container">
                                      <div className="row sub-menu">
                                        {header?.attributes?.children?.data?.map(
                                          (submenu, index) => {
                                            //max column 3
                                            return (
                                              <div
                                                key={index}
                                                className={`col-12 col-sm-${
                                                  header?.attributes?.children
                                                    ?.data?.length === 1
                                                    ? "12"
                                                    : "6"
                                                } col-lg-${12 / 4} mtb-5`}
                                              >
                                                <ul className="megamenu-submenu">
                                                  <h6 className="submenu-title">
                                                    {submenu?.attributes?.url
                                                      ?.length > 0 &&
                                                    submenu?.attributes?.url !==
                                                      "#" ? (
                                                      <Link
                                                        href={
                                                          submenu?.attributes
                                                            ?.url || ""
                                                        }
                                                        prefetch={false}
                                                      >
                                                        <a
                                                          target={
                                                            submenu?.attributes
                                                              ?.target ||
                                                            "_self"
                                                          }
                                                        >
                                                          {submenu?.attributes?.title?.split(
                                                            "?"
                                                          )[0] || ""}
                                                        </a>
                                                      </Link>
                                                    ) : (
                                                      submenu?.attributes?.title?.split(
                                                        "?"
                                                      )[0] || ""
                                                    )}
                                                  </h6>
                                                  {submenu?.attributes?.children?.data?.map(
                                                    (childMenu, index) => {
                                                      const title =
                                                        childMenu?.attributes
                                                          ?.title || "";
                                                      const dateMatch =
                                                        title.match(
                                                          /\(([^)]+)\)/
                                                        ); // Match content inside parentheses
                                                      const mainTitle =
                                                        title.replace(
                                                          /\s*\([^)]*\)/,
                                                          ""
                                                        ); // Remove date from the title
                                                      const date = dateMatch
                                                        ? dateMatch[1]
                                                        : null; // Extract date if present
                                                      return (
                                                        <li
                                                          key={index}
                                                          className="nav-item"
                                                        >
                                                          <Link
                                                            href={
                                                              childMenu
                                                                ?.attributes
                                                                ?.url || ""
                                                            }
                                                            activeClassName="active"
                                                            prefetch={false}
                                                          >
                                                            <a
                                                              onClick={
                                                                hideMobileMenu
                                                              }
                                                              className="nav-link"
                                                              target={
                                                                childMenu
                                                                  ?.attributes
                                                                  ?.target ||
                                                                "_self"
                                                              }
                                                            >
                                                              <span>
                                                                {mainTitle}
                                                              </span>
                                                              {date && (
                                                                <span className="submenu-date">
                                                                  {date}
                                                                </span>
                                                              )}
                                                            </a>
                                                          </Link>
                                                        </li>
                                                      );
                                                    }
                                                  )}
                                                  {submenu?.attributes?.title?.includes(
                                                    "?"
                                                  ) &&
                                                    submenu?.attributes?.title.split(
                                                      "?"
                                                    )[1]?.length > 0 &&
                                                    submenu?.attributes?.url
                                                      ?.length > 0 &&
                                                    submenu?.attributes?.url !==
                                                      "#" && (
                                                      <Link
                                                        href={
                                                          submenu?.attributes
                                                            ?.url || ""
                                                        }
                                                        prefetch={false}
                                                      >
                                                        <a
                                                          className="menu-see-all-button"
                                                          target={
                                                            submenu?.attributes
                                                              ?.target ||
                                                            "_self"
                                                          }
                                                        >
                                                          {
                                                            submenu?.attributes?.title.split(
                                                              "?"
                                                            )[1]
                                                          }
                                                        </a>
                                                      </Link>
                                                    )}
                                                </ul>
                                              </div>
                                            );
                                          }
                                        )}
                                      </div>
                                    </div>
                                  </li>
                                ) : (
                                  header?.attributes?.children?.data?.map(
                                    (submenu, index) => {
                                      const subMenuTitle =
                                        submenu?.attributes?.title || "";
                                      const subMenuDateMatch =
                                        subMenuTitle.match(/\(([^)]+)\)/); // Match content inside parentheses
                                      const subMenuMainTitle =
                                        subMenuTitle.replace(
                                          /\s*\([^)]*\)/,
                                          ""
                                        ); // Remove date from the title
                                      const subMenuDate = subMenuDateMatch
                                        ? subMenuDateMatch[1]
                                        : null; // Extract date if present
                                      return (
                                        <li key={index} className="nav-item">
                                          <Link
                                            href={
                                              submenu?.attributes?.url || ""
                                            }
                                            activeClassName="active"
                                            prefetch={false}
                                          >
                                            <a
                                              onClick={hideMobileMenu}
                                              className="nav-link"
                                            >
                                              {/* {submenu?.attributes?.title} */}
                                              <span>{subMenuMainTitle}</span>
                                              {subMenuDate && (
                                                <span className="submenu-date">
                                                  {subMenuDate}
                                                </span>
                                              )}
                                            </a>
                                          </Link>
                                        </li>
                                      );
                                    }
                                  )
                                )}
                              </ul>
                            )}
                          </li>
                        );
                      })}
                  </ul>
                </div>
                {/* mobile */}
                <div
                  className={`${classOne} menu-mobile ${
                    !menu ? "menu-mobile-show" : ""
                  }`}
                  id="navbarSupportedContent"
                >
                  <ul className="navbar-nav">
                    {headerData
                      ?.slice(0, headerData?.length - 1)
                      .map((header, index) => {
                        return (
                          <li
                            key={index}
                            className={`nav-item ${
                              header?.isSubMenuPresent ? "megamenu" : ""
                            } ${
                              header?.attributes?.children?.data?.length > 1
                                ? "double-child"
                                : "single-child"
                            }`}
                            // style={{ position: "relative" }}
                            // style={{ marginTop: index === 0 ? "0px" : "12px" }}
                          >
                            {header?.attributes?.children?.data?.length > 0 ? (
                              <button
                                onClick={() =>
                                  header?.attributes?.url?.length === 0 &&
                                  toggleDropdown(index)
                                }
                                className={`dropdown-toggle nav-link`}
                              >
                                {header?.attributes?.url?.length === 0 ? (
                                  header?.attributes?.title
                                ) : (
                                  <Link
                                    href={header?.attributes?.url || ""}
                                    activeClassName="active"
                                    prefetch={false}
                                  >
                                    <a
                                      onClick={hideMobileMenu}
                                      className="nav-link"
                                      target={
                                        header?.attributes?.target || "_self"
                                      }
                                    >
                                      {header?.attributes?.title}
                                    </a>
                                  </Link>
                                )}
                                <i
                                  class="bx bx-chevron-down"
                                  style={{
                                    display: "block",
                                    rotate:
                                      activeDropDownIndex === index
                                        ? "-180deg"
                                        : "0deg",
                                    fontSize: "24px",
                                    transition: "all 0.3s ease",
                                  }}
                                  onClick={() =>
                                    header?.attributes?.url?.length !== 0 &&
                                    toggleDropdown(index)
                                  }
                                ></i>
                              </button>
                            ) : (
                              <Link
                                href={header?.attributes?.url || ""}
                                prefetch={false}
                              >
                                <a
                                  onClick={hideMobileMenu}
                                  className={` nav-link`}
                                  target={header?.attributes?.target || "_self"}
                                >
                                  {header?.attributes?.title}
                                </a>
                              </Link>
                            )}
                            {activeDropDownIndex === index &&
                              header?.attributes?.children?.data?.length >
                                0 && (
                                <ul
                                  className={`dropdown-menu ${
                                    header?.isSubMenuPresent
                                      ? "dropdown-menu-sub-menu"
                                      : ""
                                  }`}
                                  style={{
                                    width: header.width,
                                  }}
                                >
                                  {header?.isSubMenuPresent ? (
                                    <li key={index} className="nav-item">
                                      <div className="container">
                                        <div className="row sub-menu">
                                          {header?.attributes?.children?.data?.map(
                                            (submenu, subIndex) => {
                                              //max column 3
                                              return (
                                                <div
                                                  key={subIndex}
                                                  className={`col-12 col-sm-${
                                                    header?.attributes?.children
                                                      ?.data?.length === 1
                                                      ? "12"
                                                      : "6"
                                                  } col-lg-${12 / 4} mtb-5`}
                                                >
                                                  <ul className="megamenu-submenu">
                                                    <button
                                                      onClick={() =>
                                                        toggleSubDropdown(
                                                          `${index}-${subIndex}`
                                                        )
                                                      }
                                                      className={`submenu-title`}
                                                    >
                                                      {submenu?.attributes?.url
                                                        ?.length > 0 &&
                                                      submenu?.attributes
                                                        ?.url !== "#" ? (
                                                        <Link
                                                          href={
                                                            submenu?.attributes
                                                              ?.url || ""
                                                          }
                                                          prefetch={false}
                                                        >
                                                          <a
                                                            target={
                                                              submenu
                                                                ?.attributes
                                                                ?.target ||
                                                              "_self"
                                                            }
                                                            onClick={
                                                              hideMobileMenu
                                                            }
                                                          >
                                                            {
                                                              submenu?.attributes?.title.split(
                                                                "?"
                                                              )[0]
                                                            }
                                                          </a>
                                                        </Link>
                                                      ) : (
                                                        submenu?.attributes?.title?.split(
                                                          "?"
                                                        )[0] || ""
                                                      )}
                                                      <i
                                                        class="bx bx-chevron-down"
                                                        style={{
                                                          display: "block",
                                                          rotate:
                                                            activeSubDropDownIndex ===
                                                            `${index}-${subIndex}`
                                                              ? "-180deg"
                                                              : "0deg",
                                                          fontSize: "20px",
                                                          transition:
                                                            "all 0.3s ease",
                                                        }}
                                                      ></i>
                                                    </button>
                                                    {activeSubDropDownIndex ===
                                                      `${index}-${subIndex}` &&
                                                      submenu?.attributes?.children?.data?.map(
                                                        (
                                                          childMenu,
                                                          childIndex
                                                        ) => {
                                                          const title =
                                                            childMenu
                                                              ?.attributes
                                                              ?.title || "";
                                                          const dateMatch =
                                                            title.match(
                                                              /\(([^)]+)\)/
                                                            ); // Match content inside parentheses
                                                          const mainTitle =
                                                            title.replace(
                                                              /\s*\([^)]*\)/,
                                                              ""
                                                            ); // Remove date from the title
                                                          const date = dateMatch
                                                            ? dateMatch[1]
                                                            : null; // Extract date if present
                                                          return (
                                                            <li
                                                              key={childIndex}
                                                              className="nav-item"
                                                            >
                                                              <Link
                                                                href={
                                                                  childMenu
                                                                    ?.attributes
                                                                    ?.url || ""
                                                                }
                                                                activeClassName="active"
                                                                prefetch={false}
                                                              >
                                                                <a
                                                                  onClick={
                                                                    hideMobileMenu
                                                                  }
                                                                  className="nav-link"
                                                                  target={
                                                                    childMenu
                                                                      ?.attributes
                                                                      ?.target ||
                                                                    "_self"
                                                                  }
                                                                >
                                                                  <span>
                                                                    {mainTitle}
                                                                  </span>
                                                                  {date && (
                                                                    <span className="submenu-date">
                                                                      {date}
                                                                    </span>
                                                                  )}
                                                                </a>
                                                              </Link>
                                                            </li>
                                                          );
                                                        }
                                                      )}
                                                    {activeSubDropDownIndex ===
                                                      `${index}-${subIndex}` &&
                                                      submenu?.attributes?.title?.includes(
                                                        "?"
                                                      ) &&
                                                      submenu?.attributes?.title.split(
                                                        "?"
                                                      )[1]?.length > 0 &&
                                                      submenu?.attributes
                                                        ?.url !== "#" && (
                                                        <Link
                                                          href={
                                                            submenu?.attributes
                                                              ?.url || ""
                                                          }
                                                          prefetch={false}
                                                        >
                                                          <a
                                                            className="menu-see-all-button"
                                                            target={
                                                              submenu
                                                                ?.attributes
                                                                ?.target ||
                                                              "_self"
                                                            }
                                                            onClick={
                                                              hideMobileMenu
                                                            }
                                                          >
                                                            {
                                                              submenu?.attributes?.title.split(
                                                                "?"
                                                              )[1]
                                                            }
                                                          </a>
                                                        </Link>
                                                      )}
                                                  </ul>
                                                </div>
                                              );
                                            }
                                          )}
                                        </div>
                                      </div>
                                    </li>
                                  ) : (
                                    header?.attributes?.children?.data?.map(
                                      (submenu, subIndex) => {
                                        const subMenuTitle =
                                          submenu?.attributes?.title || "";
                                        const subMenuDateMatch =
                                          subMenuTitle.match(/\(([^)]+)\)/); // Match content inside parentheses
                                        const subMenuMainTitle =
                                          subMenuTitle.replace(
                                            /\s*\([^)]*\)/,
                                            ""
                                          ); // Remove date from the title
                                        const subMenuDate = subMenuDateMatch
                                          ? subMenuDateMatch[1]
                                          : null; // Extract date if present
                                        return (
                                          <li
                                            key={subIndex}
                                            className="nav-item"
                                          >
                                            <Link
                                              href={
                                                submenu?.attributes?.url || ""
                                              }
                                              activeClassName="active"
                                              prefetch={false}
                                            >
                                              <a
                                                onClick={hideMobileMenu}
                                                className="nav-link"
                                              >
                                                {/* {submenu?.attributes?.title} */}
                                                <span>{subMenuMainTitle}</span>
                                                {subMenuDate && (
                                                  <span className="submenu-date">
                                                    {subMenuDate}
                                                  </span>
                                                )}
                                              </a>
                                            </Link>
                                          </li>
                                        );
                                      }
                                    )
                                  )}
                                </ul>
                              )}
                          </li>
                        );
                      })}
                  </ul>
                </div>

                <div className="others-option">
                  <Link
                    href={
                      headerData?.[headerData?.length - 1]?.attributes?.url ||
                      ""
                    }
                    prefetch={false}
                  >
                    <a
                      className="btn-style-one blue-dark-color"
                      target={
                        headerData?.[headerData?.length - 1]?.attributes
                          ?.target || "_self"
                      }
                      // style={{ textTransform: "capitalize" }}
                    >
                      {/* Request A Demo <i className="bx bx-chevron-right"></i> */}
                      {headerData?.[headerData?.length - 1]?.attributes?.title}
                    </a>
                  </Link>
                </div>
              </nav>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default Navbar;

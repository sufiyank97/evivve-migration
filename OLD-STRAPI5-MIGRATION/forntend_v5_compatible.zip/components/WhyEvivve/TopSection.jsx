import React from "react";
import NextImage from "next/future/image";
import "swiper/css/effect-fade";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Link from "next/link";
import CKEditor from "@/utils/CkEditor";

const TopSection = ({ top_section_data }) => {
  return (
    <div className={`onboarding-wrap home-hero-section`}>
      <div className="m-container">
        <div className="image-text-wrapper">
          <div
            className={`image-style delay-anime-3s hide-on-mobile screen3-bg-img`}
          >
            <NextImage
              src={
                replaceImageUrl(
                  top_section_data?.background_image?.url
                ) || ""
              }
              alt="bgImage3"
              width={2880}
              height={1506}
            />
          </div>
          <div
            className={`image-style delay-anime-3s hide-on-desktop screen3-bg-img`}
          >
            <NextImage
              src={
                replaceImageUrl(
                  top_section_data?.mobile_background_image?.data?.attributes
                    ?.url
                ) || ""
              }
              alt="bgImage3"
              width={2880}
              height={1506}
            />
          </div>
          <div
            className={`screen2-step2-text-fade-in text-wrapper screen2-step2-text`}
          >
            <h2 className="screen2-title screen2-step2-title">
              {top_section_data?.title || ""}
            </h2>
            <div
              className="screen2-step2-content"
              style={{ textAlign: "left" }}
            >
              <CKEditor content={top_section_data?.description} />
            </div>
            <div className="screen2-step2-btns-wrap">
              <Link href={top_section_data?.button1_link || ""}>
                <a target="_blank">
                  <button className="btn-style-outline">
                    {top_section_data?.button1_text || ""}
                  </button>
                </a>
              </Link>
              <Link href={top_section_data?.videoUrl || ""}>
                <a target="_blank">
                  <button className="btn-style-2">
                    {top_section_data?.button2_text || ""}
                  </button>
                </a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopSection;


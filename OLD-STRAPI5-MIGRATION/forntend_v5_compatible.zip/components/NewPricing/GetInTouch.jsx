import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function GetInTouch({ data }) {
  return (
    <div className="get-in-touch-wrap">
      <img
        src="/images/get-in-touch.png"
        alt="image"
        className="get-in-touch-image"
      />
      <div className="container">
        <div className="get-in-touch-content-wrap">
          <h2 className="get-in-touch-title">{data?.title}</h2>
          <div className="get-in-touch-description">
            <CKEditor content={data?.description} />
          </div>
          {data?.get_in_touch_button?.button_text && (
            <a
              href={data?.get_in_touch_button?.button_link || ""}
              target={
                data?.get_in_touch_button?.button_target === "blank"
                  ? "_blank"
                  : "_self"
              }
              className="btn1 get-in-touch-btn"
            >
              {data?.get_in_touch_button?.button_text}
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

import React from "react";

export default function PricingCards({ data }) {
  return (
    <div className="container">
      <div className="pricing-recommended-card-wrap">
        <h1 className="pricing-recommended-card-title">{data?.title}</h1>
        {data?.recommended && (
          <div className="pricing-card-border">
            <div className="pricing-recommended-card">
              <div className="pricing-recommended-card-content-wrap">
                <div className="pricing-recommended-card-content-title-wrap">
                  <p className="title">{data?.recommended?.title}</p>
                  <p className="price">
                    {data?.recommended?.price_and_credits}
                  </p>
                </div>
                {data?.recommended?.list?.length > 0 && (
                  <ul className="pricing-card-check-list">
                    {data?.recommended?.list?.map((item, index) => {
                      return <li key={index}>{item?.text}</li>;
                    })}
                  </ul>
                )}
                {data?.recommended?.new_pricing_card_button?.button_text && (
                  <a
                    href={
                      data?.recommended?.new_pricing_card_button?.button_link ||
                      ""
                    }
                    target={
                      data?.recommended?.new_pricing_card_button
                        ?.button_target === "blank"
                        ? "_blank"
                        : "_self"
                    }
                    className="pricing-card-btn"
                  >
                    {data?.recommended?.new_pricing_card_button?.button_text}
                  </a>
                )}
              </div>
            </div>
          </div>
        )}
        <div className="reports-cards-wrap">
          <h2 className="reports-cards-title">{data?.reports_title}</h2>
          {data?.pricing_cards?.length > 0 && (
            <div className="reports-cards">
              {data?.pricing_cards?.map((item, index) => {
                return (
                  <div
                    key={index}
                    className={`${
                      item?.most_popular ? "pricing-card-border" : ""
                    }`}
                  >
                    <div
                      className={`${
                        item?.most_popular
                          ? "reports-card most-popular"
                          : "reports-card"
                      }`}
                    >
                      {item?.most_popular && (
                        <div className="most-popular-tag">{item?.tag_line}</div>
                      )}
                      <p className="reports-card-title">{item?.title}</p>
                      <div>
                        <p className="reports-card-price">
                          {item?.price_and_credits}
                        </p>
                        {item?.list?.length > 0 && (
                          <ul className="pricing-card-check-list">
                            {item?.list?.map((listItem, i) => {
                              return <li key={i}>{listItem?.text}</li>;
                            })}
                          </ul>
                        )}
                      </div>
                      <div style={{ flex: "1" }}></div>
                      {item?.new_pricing_card_button?.button_text && (
                        <a
                          href={
                            item?.new_pricing_card_button?.button_link || ""
                          }
                          target={
                            item?.new_pricing_card_button?.button_target ===
                            "blank"
                              ? "_blank"
                              : "_self"
                          }
                          className="pricing-card-btn reports-card-btn"
                        >
                          {item?.new_pricing_card_button?.button_text}
                        </a>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

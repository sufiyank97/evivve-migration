import React from "react";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function CaseStudyCard({ data }) {
  const imageUrl = data?.image?.data?.attributes?.url 
    ? replaceImageUrl(data.image.data.attributes.url)
    : null;
  return (
    <div className="case-study-card-simple">
      <div className="case-study-card-image" >
        {imageUrl ? (
          <Image
            src={imageUrl}
            alt={data?.title || "Case Study"}
            width={423}
            height={283}
            style={{ objectFit: 'cover', width: '100%', height: '100%' }}
            className="case-study-img"
          />
        ) : (
          <div className="case-study-placeholder">
            <span>Case Study Image</span>
          </div>
        )}
       
        
      </div>
      
      <div className="case-study-card-content">
        <h3 className="case-study-card-title font-inter-regular">
          {data?.title || "Case Study Title"}
        </h3>
        
        <p className="case-study-card-description font-inter-light">
          {data?.description?.slice(0, 115) + "..." || "Case study description goes here."}
        </p>
        
        {data?.button && (
          <div className="case-study-read-more-btn-container">

          <a 
            href={data.button.button_link || "#"}
            className="case-study-read-more-btn font-inter-light"
            target={data.button.button_target === "_blank" ? "_blank" : "_self"}
          >
            Read More
           </a> 
           <i className="bx bx-right-arrow-alt rotate-45-deg"></i>
          </div>
         
        )}
      </div>
    </div>
  );
}

import React from "react";
import Image from "next/image";
import imagess from "./2img.png"
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function HeroSection({ data, show_initial_animation, setAnimationsComplete }) {
  const backgroundImageUrl = data?.background_image?.data?.attributes?.url 
    ? replaceImageUrl(data.background_image.data.attributes.url)
    : null;

  return (
    <section className="aferr-hero-section">
      {/* Background Image Layer */}
      <div 
        className="hero-background-image"
        style={{
          backgroundImage: `url(${backgroundImageUrl?backgroundImageUrl:""})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center center',
          backgroundRepeat: 'no-repeat'
        }}
      />
      
      {/* Gradient Overlay Layer */}
      <div 
        className="hero-gradient-overlay"
        style={{
          background: data?.gradient_overlay
        }}
      />
  
      {/* Content */}
      <div className="hero-content">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="hero-text-content">
                <h1 className="hero-title font-inter-medium">
                  {data?.title || "Case studies"}
                </h1>
                <h2 className="hero-subtitle font-inter-medium">
                  {data?.description || "Lorem Ipsum is simply dummy text of the printing and typesetting industry."}
                </h2>
                {data?.cta_button && (
                  <div className="hero-buttons">
                    <a 
                      href={data.cta_button.link || "#"}
                      className="btn btn-primary hero-cta-btn"
                      target={data.cta_button.target === "blank" ? "_blank" : "_self"}
                    >
                      {data.cta_button.text || "Get Started"}
                    </a>
                    {data?.secondary_button && (
                      <a 
                        href={data.secondary_button.link || "#"}
                        className="btn btn-secondary hero-secondary-btn"
                        target={data.secondary_button.target === "blank" ? "_blank" : "_self"}
                      >
                        {data.secondary_button.text || "Learn More"}
                      </a>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

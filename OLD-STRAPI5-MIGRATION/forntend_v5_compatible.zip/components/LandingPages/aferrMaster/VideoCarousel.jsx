import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation } from "swiper";
import Link from "next/link";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function VideoCarousel({ data }) {
  const videos = data?.videos || [
    {
      title: "Game Based Learning By Mohsin Memon",
      thumbnail: { data: { attributes: { url: "/images/placeholder-video-1.jpg" } } },
      video_url: "https://www.youtube.com/watch?v=example1",
      description: "Learn about game-based learning strategies"
    },
    {
      title: "Driving Behavior Change with the Evivve Game",
      thumbnail: { data: { attributes: { url: "/images/placeholder-video-2.jpg" } } },
      video_url: "https://www.youtube.com/watch?v=example2",
      description: "Discover how Evivve games drive behavior change"
    },
    {
      title: "Engaging busy learners through Immersive games",
      thumbnail: { data: { attributes: { url: "/images/placeholder-video-3.jpg" } } },
      video_url: "https://www.youtube.com/watch?v=example3",
      description: "Explore immersive learning experiences"
    },
    {
      title: "Advanced Learning Techniques",
      thumbnail: { data: { attributes: { url: "/images/placeholder-video-4.jpg" } } },
      video_url: "https://www.youtube.com/watch?v=example4",
      description: "Master advanced learning methodologies"
    }
  ];

  return (
    <section className="aferr-video-carousel-section">
      <div className="container">
        <div className="video-carousel-header">
          <h2 className="video-carousel-title">
            {data?.title || "WEBINAR"}
          </h2>
        </div>
      </div>
      
      <div className="video-carousel-swiper">
        <Swiper
          autoplay={{
            delay: 3000,
            disableOnInteraction: false,
          }}
          navigation={true}
          loop={true}
          modules={[Navigation, Autoplay]}
          className="mySwiper"
          centeredSlides={true}
          slidesPerView={2}
          spaceBetween={30}
          breakpoints={{
            0: {
              slidesPerView: 1.2,
              spaceBetween: 20,
            },
            500: {
              slidesPerView: 1.5,
              spaceBetween: 25,
            },
            768: {
              slidesPerView: 2,
              spaceBetween: 30,
            },
            1024: {
              slidesPerView: 2.5,
              spaceBetween: 35,
            },
            1400: {
              slidesPerView: 3,
              spaceBetween: 40,
            },
          }}
        >
          {videos.map((video, index) => {
            const thumbnailUrl = video.thumbnail?.data?.attributes?.url 
              ? replaceImageUrl(video.thumbnail.data.attributes.url)
              : null;

            return (
              <SwiperSlide key={index}>
                <div className="video-card">
                  <div className="video-thumbnail">
                    {thumbnailUrl ? (
                      <Image
                        src={thumbnailUrl}
                        alt={video.title}
                        width={400}
                        height={225}
                        className="thumbnail-image"
                      />
                    ) : (
                      <div className="video-placeholder">
                        <div className="placeholder-content">
                          <i className="bx bx-play-circle"></i>
                          <span>Video Thumbnail</span>
                        </div>
                      </div>
                    )}
                    
                    {/* YouTube Play Button Overlay */}
                    <div className="play-button-overlay">
                      <Link href={video.video_url || "#"}>
                        <a target="_blank" className="play-button">
                          <i className="bx bx-play"></i>
                        </a>
                      </Link>
                    </div>

                    {/* Video Actions */}
                    <div className="video-actions">
                      <Link href={video.video_url || "#"}>
                        <a target="_blank" className="watch-youtube">
                          Watch on YouTube
                        </a>
                      </Link>
                      <div className="action-buttons">
                        <button className="action-btn" title="Watch Later">
                          <i className="bx bx-time"></i>
                        </button>
                        <button className="action-btn" title="Share">
                          <i className="bx bx-share-alt"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="video-description">
                    <h3 className="video-title">{video.title}</h3>
                    {video.description && (
                      <p className="video-desc">{video.description}</p>
                    )}
                  </div>
                </div>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    </section>
  );
}

import React from "react";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";

export default function DetailsSection({ data }) {
  const imageUrl = data?.image?.data?.attributes?.url 
    ? replaceImageUrl(data.image.data.attributes.url)
    : null;
  return (
    <section className="aferr-details-section">
      <div className="container">
        <div className="row align-items-center">
          {/* Left Side - Text Content */}
          <div className="col-lg-6 col-md-12">
            <div className="details-text-content">
              <h2 className="details-title1 font-inter-extrabold" style={{fontSize:"32px !important"}}>
                {data?.title || "Lorem Ipsum Is Simply"}
              </h2>
              <div className="details-description1 font-inter-medium" style={{fontSize:"20px !important"}}>
                {data?.description ? (
                  <CKEditor content={data.description} />
                ) : (
                  <p>
                    Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.
                  </p>
                )}
              </div>
              {data?.button && (
                <div className="details-button">
                  <a 
                    href={data.button.link || "#"}
                    className="btn-style-one blue-dark-color"
                    target={data.button.target === "blank" ? "_blank" : "_self"}
                  >
                    {data.button.text || "Learn More"}
                  </a>
                </div>
              )}
            </div>
          </div>
          
          {/* Right Side - Image with Stats Overlay */}
          <div className="col-lg-6 col-md-12">
            <div className="details-image-wrapper">
                <div className="details-image-container">
                 
                  {/* Stats Quadrants Overlay */}
                  {data?.stats_quadrants && data.stats_quadrants.length > 0 && (
                    <div className="stats-quadrants-overlay">
                      {data.stats_quadrants.map((quadrant, index) => (
                        <div 
                          key={index}
                          className={`stats-quadrant stats-quadrant-${quadrant.position}`}
                        >
                          <div className="stats-quadrant-content">
                            <div className="stats-value font-inter-semibold">
                              {quadrant.stat_value}
                            </div>
                            
                            <div className="stats-description font-inter-regular">
                              {quadrant.stat_description}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
               
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

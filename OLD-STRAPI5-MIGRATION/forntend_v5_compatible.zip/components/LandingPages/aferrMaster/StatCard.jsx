import React from "react";

export default function StatCard({ data }) {
  return (
    <div className="stat-card">
      <div className="stat-value">
        {data?.stat_value || "0"}
      </div>
      <div className="stat-description">
        {data?.stat_description || "Stat Description"}
      </div>
    </div>
  );
}

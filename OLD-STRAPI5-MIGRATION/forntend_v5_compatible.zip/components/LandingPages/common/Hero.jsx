import React, { useEffect, useRef, useState } from "react";

export default function Hero({
  setAnimationsComplete,
  agendaSectionRef,
  screen,
  setScreen,
  wheelEventCount,
  setWheelEventCount,
  data,
  RegisterSectionRef,
  reverseScreen,
  setReverseScreen,
  children,
  show_custom_navbar,
  setActiveSection,
  show_initial_animation,
  template,
}) {
  const heroSectionRef = useRef();
  const screen1ContentRef = useRef();
  const screen2ContentRef = useRef();
  const screen3ContentRef = useRef();
  const mobileScreen2Ref = useRef();
  const mobileScreen3Ref = useRef();

  let animationrunning = false;

  const handleScroll = (e) => {
    if (!animationrunning) {
      const direction = e.deltaY > 25 ? 1 : e.deltaY < -25 ? -1 : 0;

      if (direction !== 0) {
        setWheelEventCount((prevCount) => {
          const newCount = Math.min(Math.max(prevCount + direction, 0), 4);
          if (newCount !== prevCount) {
            animationrunning = true;
            setTimeout(() => (animationrunning = false), 1500);
          }
          return newCount;
        });
      }
    }
  };

  useEffect(() => {
    if (document.documentElement.clientWidth >= 1024) {
      if (wheelEventCount <= 0) {
        setWheelEventCount(0);
      }
      if (wheelEventCount === 1 && screen === 1) {
        if (
          (data?.screen2 && data?.screen3) ||
          (data?.screen2 && !data?.screen3)
        ) {
          setScreen(2);
          setReverseScreen(null);
          animationrunning = true;
          setTimeout(() => {
            animationrunning = false;
          }, 1500);
        } else if (!data?.screen2 && data?.screen3) {
          setScreen(3);
          setReverseScreen(null);
          animationrunning = true;
          setTimeout(() => {
            animationrunning = false;
          }, 1500);
        } else if (!data?.screen2 && !data?.screen3) {
          setScreen(5);
          setReverseScreen(null);
          animationrunning = true;
          setActiveSection &&
            setActiveSection(template === 4 ? "template4-brands" : "time-date");
          setTimeout(() => {
            setAnimationsComplete(true);
            const registerSection = document.getElementById(
              template === 4 ? "template4-brands" : "time-date"
            );

            if (registerSection) {
              const checkVisibility = setInterval(() => {
                if (registerSection.offsetHeight > 0) {
                  // Scroll only if the section is now visible
                  window.scrollTo({
                    behavior: "smooth",
                    // top: registerSection.offsetTop,
                    top: 0,
                  });
                  clearInterval(checkVisibility); // Stop checking once done
                }
              }, 100); // Check every 100ms until the element is visible
            }
            animationrunning = false;
          }, 1500);
        }
      } else if (wheelEventCount === 2 && screen === 2) {
        if (data?.screen3) {
          setScreen(3);
          setReverseScreen(null);
          animationrunning = true;
          setTimeout(() => {
            animationrunning = false;
          }, 1500);
        } else {
          setScreen(5);
          setReverseScreen(null);
          animationrunning = true;
          setActiveSection &&
            setActiveSection(template === 4 ? "template4-brands" : "time-date");
          setTimeout(() => {
            setAnimationsComplete(true);
            const registerSection = document.getElementById(
              template === 4 ? "template4-brands" : "time-date"
            );

            if (registerSection) {
              const checkVisibility = setInterval(() => {
                if (registerSection.offsetHeight > 0) {
                  // Scroll only if the section is now visible
                  window.scrollTo({
                    behavior: "smooth",
                    // top: registerSection.offsetTop,
                    top: 0,
                  });
                  clearInterval(checkVisibility); // Stop checking once done
                }
              }, 100); // Check every 100ms until the element is visible
            }
            animationrunning = false;
          }, 1500);
        }
      } else if (
        (wheelEventCount === 3 && screen === 3) ||
        (wheelEventCount === 2 && screen === 3 && !data?.screen2)
      ) {
        if (template === 4) {
          setScreen(5);
          setReverseScreen(null);
          animationrunning = true;
          setActiveSection &&
            setActiveSection(template === 4 ? "template4-brands" : "time-date");
          setTimeout(() => {
            setAnimationsComplete(true);
            const registerSection = document.getElementById(
              template === 4 ? "template4-brands" : "time-date"
            );

            if (registerSection) {
              const checkVisibility = setInterval(() => {
                if (registerSection.offsetHeight > 0) {
                  // Scroll only if the section is now visible
                  window.scrollTo({
                    behavior: "smooth",
                    // top: registerSection.offsetTop,
                    top: 0,
                  });
                  clearInterval(checkVisibility); // Stop checking once done
                }
              }, 100); // Check every 100ms until the element is visible
            }
            animationrunning = false;
          }, 1500);
        } else {
          setScreen(4);
          setReverseScreen(null);
          animationrunning = true;
          setTimeout(() => {
            animationrunning = false;
          }, 1500);
        }
      } else if (
        (wheelEventCount === 4 && screen === 4) ||
        (wheelEventCount === 3 && screen === 4 && !data?.screen2)
      ) {
        setScreen(5);
        setReverseScreen(null);
        animationrunning = true;
        setActiveSection &&
          setActiveSection(template === 4 ? "template4-brands" : "time-date");
        setTimeout(() => {
          setAnimationsComplete(true);
          const registerSection = document.getElementById(
            template === 4 ? "template4-brands" : "time-date"
          );

          if (registerSection) {
            const checkVisibility = setInterval(() => {
              if (registerSection.offsetHeight > 0) {
                // Scroll only if the section is now visible
                window.scrollTo({
                  behavior: "smooth",
                  // top: registerSection.offsetTop,
                  top: 0,
                });
                clearInterval(checkVisibility); // Stop checking once done
              }
            }, 100); // Check every 100ms until the element is visible
          }
          animationrunning = false;
        }, 1500);
      } else if (wheelEventCount === 0 && screen === 2) {
        setScreen(1);
        setReverseScreen(1);
        animationrunning = true;
        setTimeout(() => {
          animationrunning = false;
        }, 1500);
      } else if (
        (wheelEventCount === 1 && screen === 3) ||
        (!data?.screen2 && wheelEventCount === 0 && screen === 3)
      ) {
        if (!data?.screen2) {
          setScreen(1);
          setReverseScreen(1);
          animationrunning = true;
          setTimeout(() => {
            animationrunning = false;
          }, 1500);
        } else {
          setScreen(2);
          setReverseScreen(2);
          animationrunning = true;
          setTimeout(() => {
            animationrunning = false;
          }, 1500);
        }
      } else if (
        (wheelEventCount === 2 && screen === 4) ||
        (!data?.screen2 && wheelEventCount === 1 && screen === 4)
      ) {
        setScreen(3);
        setReverseScreen(3);
        animationrunning = true;
        setTimeout(() => {
          animationrunning = false;
        }, 1500);
      } else if (wheelEventCount === 3 && screen === 5) {
        if (!data?.screen3) {
          setScreen(2);
          setReverseScreen(1);
        } else if (!data?.screen2 && !data?.screen3) {
          setScreen(1);
          setReverseScreen(0);
        } else if (data?.screen3) {
          if (template === 4) {
            setScreen(3);
            setReverseScreen(3);
          } else {
            setScreen(4);
            setReverseScreen(4);
          }
        }
        setAnimationsComplete(false);
        // animationrunning = true;
        // setTimeout(() => {
        //   animationrunning = false;
        // }, 1500);
      }
    }
  }, [wheelEventCount]);

  useEffect(() => {
    if (document.documentElement.clientWidth >= 1024) {
      if (!animationrunning) {
        heroSectionRef?.current?.addEventListener("wheel", handleScroll);
      }

      return () => {
        heroSectionRef?.current?.removeEventListener("wheel", handleScroll);
      };
    }
  }, []);

  useEffect(() => {
    if (screen1ContentRef.current) {
      // Get the height of the screen 1 content
      const screen1Height = screen1ContentRef.current.offsetHeight;
      screen1ContentRef.current &&
        (screen1ContentRef.current.style.marginTop = `35px`);
      // Set the margin top of screen 2 content to be equal to screen 1 height
      screen2ContentRef.current &&
        (screen2ContentRef.current.style.marginTop = `-${
          screen1Height + 50
        }px`);
      screen3ContentRef.current &&
        (screen3ContentRef.current.style.marginTop = `-${
          screen1Height + 80
        }px`);
    }
  }, []);

  const scrollToSection = async (id) => {
    let isScrolling = false;
    const performScroll = (section) => {
      if (section && section.offsetHeight > 0) {
        section.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });

        // Check if the section is actually scrolled into view
        const rect = section.getBoundingClientRect();
        if (rect.top >= 0 && rect.bottom <= window.innerHeight) {
          console.log("Scroll successful to section:", id);
          return true;
        } else {
          console.warn("Section not fully in view after scroll attempt.");
        }
      }
      return false;
    };

    const waitForScrollCompletion = () =>
      new Promise((resolve) => {
        let lastScrollY = window.scrollY;
        const checkScroll = setInterval(() => {
          if (window.scrollY === lastScrollY) {
            clearInterval(checkScroll);
            isScrolling = false; // Reset scrolling state
            resolve();
          } else {
            lastScrollY = window.scrollY;
          }
        }, 100);
      });

    if (show_custom_navbar) {
      await setAnimationsComplete(true);
      setTimeout(async () => {
        const section = document.getElementById(id);
        if (section) {
          if (!isScrolling) {
            isScrolling = true;
            performScroll(section);
            await waitForScrollCompletion();

            // Check if the section is not scrolled after the initial attempt
            const rect = section.getBoundingClientRect();
            if (!(rect.top >= 0 && rect.bottom <= window.innerHeight)) {
              console.log("Rescrolling to section after scroll completion.");
              performScroll(section); // Rescroll only once
            }
            isScrolling = false;
          }
          setTimeout(() => {
            setScreen(5); // Final screen update
            setReverseScreen(null);
          }, 1000);
        }
      }, 500);
    } else {
      setScreen(5);
      setReverseScreen(null);
      setTimeout(() => {
        setAnimationsComplete(true);
        const checkVisibility = setInterval(() => {
          if (section.offsetHeight > 0) {
            // Scroll only if the section is now visible
            window.scrollTo({
              behavior: "smooth",
              top: 0,
            });
            clearInterval(checkVisibility); // Stop checking once done
          }
        }, 100);
      }, 1500);
    }
  };

  const handleBtnClick = (id) => {
    if (document.documentElement.clientWidth >= 1024) {
      if (screen === 1) {
        if (
          (data?.screen2 && data?.screen3) ||
          (data?.screen2 && !data?.screen3)
        ) {
          setScreen(2);
          setWheelEventCount(1);
          setReverseScreen(null);
        } else if (!data?.screen2 && data?.screen3) {
          setScreen(3);
          setWheelEventCount(2);
          setReverseScreen(null);
        } else if (!data?.screen2 && !data?.screen3) {
          scrollToSection(id);
        }
      } else if (screen === 2) {
        if (data?.screen3) {
          setScreen(3);
          setWheelEventCount(2);
          setReverseScreen(null);
        } else {
          scrollToSection(id);
        }
      } else if (screen === 3) {
        if (template === 4) {
          scrollToSection(id);
        } else {
          setScreen(4);
          setWheelEventCount(3);
          setReverseScreen(null);
        }
      } else if (screen === 4) {
        scrollToSection(id);
      }
    } else {
      // mobileScreen2Ref.current.style.scrollMarginTop = "-100px";
      if (data?.screen2) {
        mobileScreen2Ref.current.style.scrollMarginTop = "10px";
        mobileScreen2Ref.current?.scrollIntoView({ behavior: "smooth" });
      } else if (!data?.screen2 && data?.screen3) {
        mobileScreen3Ref.current.style.scrollMarginTop = "10px";
        mobileScreen3Ref.current?.scrollIntoView({
          behavior: "smooth",
        });
      } else if (!data?.screen2 && !data?.screen3) {
        mobileScreen3ButtonClick(id);
      }
    }
  };

  const mobileScreen3ButtonClick = (id) => {
    setAnimationsComplete(true);
    const section = document.getElementById(id);
    if (section) {
      if (show_custom_navbar) {
        if (id === "testimonials") {
          section.style.scrollMarginTop = "250px";
        } else {
          section.style.scrollMarginTop = "50px";
        }
      }
      section.scrollIntoView({
        behavior: "smooth",
      });
    }
  };

  const [scrollToRegister, setScrollToRegister] = useState(false);

  useEffect(() => {
    if (scrollToRegister && RegisterSectionRef.current) {
      const scrollToSection = () => {
        RegisterSectionRef.current.scrollIntoView({ behavior: "smooth" });

        // Check if the section is at the top after the smooth scroll completes
        setTimeout(() => {
          const rect = RegisterSectionRef.current.getBoundingClientRect();
          if (rect.top > 1) {
            // If not at the top, adjust the scroll position
            RegisterSectionRef.current.scrollIntoView({ behavior: "smooth" });
          }
          setScrollToRegister(false);
        }, 1000); // Adjust this timeout based on your page's scroll duration
      };

      scrollToSection();
    }
  }, [scrollToRegister]);

  const registerButtonClick = async () => {
    await setAnimationsComplete(true);

    setTimeout(() => {
      // Get the element by its ID
      const registerSectionElement = document.getElementById("register");

      if (registerSectionElement) {
        // Set scroll margin for the section
        registerSectionElement.style.scrollMarginTop = "-20px";

        // Use requestAnimationFrame to ensure the style is applied before scrolling
        requestAnimationFrame(() => {
          // Scroll into the view and wait for the scroll to complete
          setScrollToRegister(true);

          // Set a timeout to ensure the scroll has completed
          setTimeout(async () => {
            // Update screen to 4 after the scroll
            if (template === 4) {
              await setScreen(3);
            } else {
              await setScreen(4);
            }
            setReverseScreen(null);

            // Delay the screen 5 update slightly to ensure smooth transition
            setTimeout(async () => {
              await setScreen(5); // Final screen update
            }, 300);
          }, 500); // Adjust timeout based on your scroll behavior duration
        });
      }
    }, 500); // Adjust the initial delay as needed for your animations
  };

  const registerMobileButtonClick = () => {
    setAnimationsComplete(true);
    setScrollToRegister(true);
  };

  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const containerRect = heroSectionRef.current
        ?.getElementsByClassName("container")[0]
        ?.getBoundingClientRect();
      // Change the value based on your scroll threshold (e.g., 50px)

      if (containerRect?.top < -60) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    // Add scroll event listener
    heroSectionRef?.current?.addEventListener("scroll", handleScroll);

    return () => {
      // Cleanup event listener
      heroSectionRef?.current?.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const childProps = {
    heroSectionRef,
    screen,
    reverseScreen,
    data,
    isScrolled,
    screen1ContentRef,
    screen2ContentRef,
    screen3ContentRef,
    handleBtnClick,
    registerButtonClick,
    mobileScreen2Ref,
    mobileScreen3Ref,
    mobileScreen3ButtonClick,
    registerMobileButtonClick,
    show_custom_navbar,
    show_initial_animation,
  };

  return (
    <section id="home">
      {React.Children.map(children, (child) =>
        React.cloneElement(child, { ...childProps })
      )}
    </section>
  );
}

import React from "react";

export default function Count({ data }) {
  return (
    <section className="container" id="count">
      <div className="count-wrap">
        {data?.map((item, i) => {
          return (
            <div key={i}>
              <div className="count-number">{item?.count_number}</div>
              <div className="count-text">{item?.count_text}</div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

import React, { useEffect, useState } from "react";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { BsPlayBtnFill } from "react-icons/bs";
import ReactPlayer from "react-player";
import Image from "next/image";

export default function YoutubeVideo({
  screen,
  videoUrl,
  handleBtnClick,
  video_thumbnail,
  screen2Present,
}) {
  const [thumbnail, setThumbnail] = useState(null);
  const [play, setPlay] = useState(false);

  useEffect(() => {
    generateThumbnail(replaceImageUrl(videoUrl));
  }, [videoUrl]);

  const generateThumbnail = (videoUrl) => {
    const video = document.createElement("video");
    video.src = videoUrl;
    video.crossOrigin = "anonymous"; // If the video is hosted on a different domain
    video.addEventListener("loadeddata", () => {
      video.currentTime = 1; // Set to capture the frame at the 2-second mark (adjust as needed)
    });

    video.addEventListener("seeked", () => {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      setThumbnail(canvas.toDataURL("image/png"));
    });
  };

  useEffect(() => {
    screen === 4 ? setPlay(true) : setPlay(false);
  }, [screen]);

  return (
    <div
      className={`s3Video-wrap ${
        screen === 4 || screen === 5 ? "s3Video-wrap-screen4" : ""
      }`}
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
      }}
    >
      <div className="s3Video-desktop" style={{ height: "100%" }}>
        {(screen === 3 ||
          screen === 2 ||
          (!screen2Present && screen === 1)) && (
          <div className="s3Video-thumbnail-wrap">
            <Image
              src={video_thumbnail || ""}
              alt="Thumbnail-img"
              layout="fill"
              style={{ cursor: "pointer" }}
              onClick={handleBtnClick}
            />
            <BsPlayBtnFill
              className="s3VideoThumbnail_btn"
              onClick={handleBtnClick}
            />
          </div>
        )}
        {screen > 3 && (
          <ReactPlayer
            light={<img src={video_thumbnail} alt="Thumbnail" />}
            playing={play}
            controls
            playIcon={<BsPlayBtnFill className="s3VideoThumbnail_btn" />}
            url={replaceImageUrl(videoUrl)}
            style={{ margin: "auto" }}
          />
        )}
      </div>
      <div className="s3Video-mobile" style={{ height: "100%" }}>
        {videoUrl && (
          <ReactPlayer
            light={<img src={video_thumbnail} alt="Thumbnail" />}
            playing
            controls
            playIcon={<BsPlayBtnFill className="s3VideoThumbnail_btn" />}
            url={replaceImageUrl(videoUrl)}
            style={{ margin: "auto" }}
          />
        )}
      </div>
    </div>
  );
}

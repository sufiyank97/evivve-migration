import Image from "next/image";
import React, { useEffect, useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function Certifications({ data }) {
  const sectionRef = useRef(null);
  const certifactionsWrapRef = useRef(null);
  const [certifactionsWrapHeight, setCertifactionsWrapHeight] = useState(null);
  const [clickedCard, setClickedCard] = useState(null); // Store clicked card index
  const [originalPositions, setOriginalPositions] = useState([]); // Store original positions
  const [swiperInstance, setSwiperInstance] = useState(null);
  const resizeObserverRef = useRef(null);

  // Function to update height
  const updateHeight = () => {
    if (certifactionsWrapRef?.current) {
      // Force a reflow to ensure accurate measurements
      void certifactionsWrapRef.current.offsetHeight;

      requestAnimationFrame(() => {
        const height =
          certifactionsWrapRef.current.getBoundingClientRect().height;
        setCertifactionsWrapHeight(height);
      });
    }
  };

  useEffect(() => {
    // Initial height measurement after a short delay to ensure content is rendered
    const timeoutId = setTimeout(updateHeight, 100);
    // Set up ResizeObserver to track height changes
    resizeObserverRef.current = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.target === certifactionsWrapRef.current) {
          updateHeight();
        }
      }
    });

    if (certifactionsWrapRef.current) {
      resizeObserverRef.current.observe(certifactionsWrapRef.current);
    }

    // Handle window resize
    const handleResize = () => {
      updateHeight();
    };
    window.addEventListener("resize", handleResize);

    if (document.documentElement.clientWidth >= 1024) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              const container = entry.target;
              const elements = container.querySelectorAll(
                ".certification-card"
              );
              const certificationsDiv = container.querySelector(
                ".certifications-wrap"
              );

              // Get the bounding rectangle of the section
              const sectionRect = container.getBoundingClientRect();
              const certificationsDivRect =
                certificationsDiv.getBoundingClientRect();

              // Calculate and store the original positions of each card relative to the section
              const newPositions =
                originalPositions?.length > 0
                  ? originalPositions
                  : Array.from(elements).map((element, index) => {
                      const rect = element.getBoundingClientRect();
                      return {
                        top:
                          rect.top -
                          sectionRect.top -
                          70 -
                          (index === 1
                            ? +30
                            : index === 2
                            ? +50
                            : index === 4 || index === 5 || index === 6
                            ? -60
                            : 0), // Relative to the section
                        left:
                          rect.left -
                          certificationsDivRect.left +
                          (document.documentElement.clientWidth > 1360
                            ? 150
                            : 70) -
                          (index === 4 ? -50 : index === 6 ? +20 : 0), // Relative to the section
                      };
                    });

              // Move cards to center
              elements.forEach((element) => {
                element.style.position = "absolute";
                element.style.top = "30%";
                element.style.left = "40%";
              });

              // Animate back to original position after a short delay
              setTimeout(() => {
                // Save positions to state
                originalPositions?.length === 0 &&
                  setOriginalPositions(newPositions);

                elements.forEach((element, index) => {
                  const originalPosition =
                    originalPositions?.length > 0
                      ? originalPositions[index]
                      : newPositions[index];

                  // Set back to the original position
                  element.style.top = `${originalPosition.top}px`;
                  element.style.left = `${originalPosition.left}px`;
                });
              }, 1000); // Delay before cards return to original position

              observer.unobserve(container); // Unobserve after animation
            }
          });
        },
        { threshold: 0.1 }
      );

      if (sectionRef.current) {
        observer.observe(sectionRef.current);
      }

      return () => {
        if (sectionRef.current) {
          observer.unobserve(sectionRef.current);
        }
        if (resizeObserverRef.current) {
          resizeObserverRef.current.disconnect();
        }
        window.removeEventListener("resize", handleResize);
        clearTimeout(timeoutId);
      };
    }
  }, [data]);

  // Handle card click
  const handleCardClick = (index) => {
    setClickedCard(index); // Set the clicked card index
    if (swiperInstance) swiperInstance.autoplay.stop();
  };

  return (
    <section
      className="certifications-main-wrap"
      ref={sectionRef}
      id="testimonials"
      style={{
        scrollPaddingTop:
          typeof window !== "undefined" &&
          document?.documentElement?.clientWidth >= 1024
            ? ""
            : "50px",
      }}
    >
      <div className="container position-relative">
        <CKEditor content={data?.title} customStyle={"certifications-title"} />
        <div
          ref={certifactionsWrapRef}
          className="certifications-wrap"
          style={{ minHeight: `${certifactionsWrapHeight}px` }}
        >
          {data?.cards?.map((item, index) => {
            const isClicked = clickedCard === index; // Check if the card is clicked
            const originalPosition = originalPositions[index]; // Get original position of card
            return (
              <div
                key={index}
                className={`certification-card ${
                  isClicked ? "certification-card-open" : ""
                }`}
                style={{
                  backgroundColor: item?.bg_color,
                  ...(isClicked
                    ? {
                        position: "fixed",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -50%)", // Move to center
                        zIndex: 1001,
                        scale: "1.2",
                      }
                    : originalPositions?.length > 0
                    ? {
                        position: "absolute", // Move back to original position
                        top: `${originalPosition?.top}px`,
                        left: `${originalPosition?.left}px`,
                      }
                    : {}),
                }}
                onClick={() => handleCardClick(index)}
              >
                <Image
                  src={replaceImageUrl(item?.image?.data?.attributes?.url)}
                  alt="image"
                  width={200}
                  height={200}
                />
                <p className="certification-card-name">{item?.name}</p>
                <p
                  className="certification-card-desc"
                  style={
                    !isClicked
                      ? {
                          overflow: "hidden",
                          display: "-webkit-box",
                          "-webkit-box-orient": "vertical",
                          "-webkit-line-clamp": "2",
                        }
                      : {}
                  }
                >
                  {item?.description}
                </p>
              </div>
            );
          })}
        </div>
        <div className="certifications-swiper-wrap">
          <Swiper
            spaceBetween={16}
            autoplay={{
              delay: 1500,
              disableOnInteraction: false,
            }}
            loop
            slidesPerView={"auto"}
            modules={[Autoplay]}
            onSwiper={(swiper) => setSwiperInstance(swiper)} // Get Swiper instance
            className="mySwiper certifications-swiper"
          >
            {data?.cards?.map((item, index) => {
              return (
                <SwiperSlide key={index}>
                  <div
                    className={`certification-card`}
                    style={{
                      backgroundColor: item?.bg_color,
                    }}
                    onClick={() => handleCardClick(index)}
                  >
                    <Image
                      src={replaceImageUrl(item?.image?.data?.attributes?.url)}
                      alt="image"
                      width={200}
                      height={200}
                    />
                    <p className="certification-card-name">{item?.name}</p>
                    <p
                      className="certification-card-desc"
                      style={{
                        overflow: "hidden",
                        display: "-webkit-box",
                        "-webkit-box-orient": "vertical",
                        "-webkit-line-clamp": "2",
                      }}
                    >
                      {item?.description}
                    </p>
                  </div>
                </SwiperSlide>
              );
            })}
          </Swiper>
        </div>
        {/* Overlay for clicked card */}
        {clickedCard !== null && (
          <div
            className="certification-card-overlay"
            onClick={() => {
              setClickedCard(null);
              if (swiperInstance) swiperInstance.autoplay.start();
            }}
          >
            <div className="swiper-card-clicked">
              <div
                className={`certification-card`}
                style={{
                  backgroundColor: data?.cards[clickedCard]?.bg_color,
                }}
                onClick={(e) => e.stopPropagation()}
              >
                <Image
                  src={replaceImageUrl(
                    data?.cards[clickedCard]?.image?.data?.attributes?.url
                  )}
                  alt="image"
                  width={200}
                  height={200}
                />
                <p className="certification-card-name">
                  {data?.cards[clickedCard]?.name}
                </p>
                <p className="certification-card-desc">
                  {data?.cards[clickedCard]?.description}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

import CKEditor from "@/utils/CkEditor";
import React, { useState } from "react";

export default function Faq({ data }) {
  const [showIndex, setShowIndex] = useState(null);

  return (
    <section className="container ptb-70" id="faq">
      <h1
        style={{
          color: "#5B105A",
          textAlign: "center",
          marginBottom: "50px",
        }}
      >
        {data?.title}
      </h1>
      <div className="faq-wrap">
        {data?.faq_list?.map((item, index) => {
          return (
            <div
              key={index}
              onClick={() => setShowIndex(index === showIndex ? null : index)}
            >
              <div className="faq-question">
                <p>{item?.question}</p>
                <div className="faq-icon">
                  <img
                    src="/images/webinar/arrow-down-icon.svg"
                    alt="icon"
                    style={{
                      transform:
                        index === showIndex
                          ? "rotate(-180deg)"
                          : "rotate(0deg)",
                    }}
                  />
                </div>
              </div>
              <div
                className={`faq-answer ${index === showIndex ? "open" : ""}`}
                style={{
                  maxHeight: index === showIndex ? "max-content" : "0",
                }}
              >
                <CKEditor content={item?.answer} />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

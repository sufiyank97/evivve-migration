import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React, { useEffect, useState, useRef } from "react";

export default function Navbar({
  fav_logo,
  masterclass_logo,
  evivve_logo,
  mobile_logo,
  setAnimationsComplete,
  setReverseScreen,
  setScreen,
  animationsComplete,
  setWheelEventCount,
  links,
  activeSection,
  setActiveSection,
  show_initial_animation,
}) {
  const [menu, setMenu] = useState(false);
  // const [activeSection, setActiveSection] = useState("home");
  const [scrollEnabled, setScrollEnabled] = useState(true);
  const [isScrolling, setIsScrolling] = useState(false);

  const buttonRefs = useRef([]);
  const [selectedButtonStyle, setSelectedButtonStyle] = useState({
    width: 0,
    height: 0,
    left: 0,
    top: 0,
  });

  const toggleNavbar = () => {
    setMenu(!menu);
  };

  const handleScroll = () => {
    if (!scrollEnabled || isScrolling) return;

    // Loop through each section
    const sections = Array.from(document.querySelectorAll("[id]")).filter(
      (el) => links.some((link) => link.link === el.id)
    );

    let newActiveSection = null; // Variable to track which section should be active

    sections.forEach((section) => {
      const rect = section.getBoundingClientRect();
      if (rect.top <= 176 && rect.top >= 0) {
        // This section's top has reached or passed 176px from the top of the viewport
        newActiveSection = section.id; // Set the new active section

        // Log only if the section has changed
        if (activeSection !== section.id) {
          setActiveSection(section.id); // Update active section state
        }

        return; // Exit loop once we find the active section
      }
    });
  };

  const scrollToSection = async (id) => {
    let prevId = activeSection;

    if (activeSection === id) return;

    setScrollEnabled(false); // Disable scroll-based updates
    setIsScrolling(true); // Indicate programmatic scroll is in progress
    setActiveSection(id); // Immediately update active section state

    if (document.documentElement.clientWidth >= 1024) {
      // Handle home section separately
      if (id === "home") {
        setAnimationsComplete(false);
        setScreen(1);
        setWheelEventCount(0);
        setReverseScreen(1);
        setActiveSection(id);
      } else {
        // Set animationsComplete only if it's not already true
        if (!animationsComplete) {
          await setAnimationsComplete(true);
        }
        // Get the section element by ID
        const section = document.getElementById(id);
        if (section) {
          // Delay the scroll to ensure smooth transition
          if (!animationsComplete) {
            setTimeout(() => {
              requestAnimationFrame(() => {
                if (prevId === "home" && id === "time-date") {
                  setScreen(5);
                  setReverseScreen(null);
                } else {
                  // Allow any animations to complete with a slight delay
                  section.scrollIntoView({
                    behavior: "smooth",
                    block: "start",
                  });
                  setTimeout(() => {
                    setScreen(5); // Final screen update
                    setReverseScreen(null);
                  }, 1000); // Delay for smoother transition
                }
              });
            }, 500);
          } else {
            // Direct scroll if animations are complete
            section.scrollIntoView({
              behavior: "smooth",
              block: "start",
            });
          }
        }
      }
    } else {
      setAnimationsComplete(true);
      // Get the section element by ID
      const section = document.getElementById(id);
      if (section) {
        if (id === "testimonials") {
          section.style.scrollMarginTop = "250px";
        } else {
          section.style.scrollMarginTop = "50px";
        }
        section.scrollIntoView({
          behavior: "smooth",
        });
      }
    }
    // Close the menu
    setMenu(false);

    setTimeout(() => {
      setScrollEnabled(true); // Re-enable scroll-based updates after delay
      setIsScrolling(false); // Re-enable scroll-based updates
    }, 1500); // Delay to allow smooth scrolling to complete
  };

  useEffect(() => {
    const scrollListener = () => handleScroll();
    window.addEventListener("scroll", scrollListener);
    return () => {
      window.removeEventListener("scroll", scrollListener);
    };
  }, [activeSection, scrollEnabled]);

  useEffect(() => {
    function setTabPosition() {
      const currentTab = buttonRefs.current.find(
        (button) => button.dataset.link === activeSection
      );

      setSelectedButtonStyle({
        width: currentTab?.clientWidth || 0,
        height: currentTab?.clientHeight || 0,
        left: currentTab?.offsetLeft || 0,
        top: currentTab?.offsetTop || 0,
      });
    }
    setTabPosition();
    window.addEventListener("resize", setTabPosition);
    return () => window.removeEventListener("resize", setTabPosition);
  }, [activeSection]);

  return (
    <div
      className={`template-pages-custom-navbar ${
        show_initial_animation
          ? ""
          : "hide_initial_animation_template-pages-custom-navbar"
      }`}
      style={{ borderBottom: `1px solid ${menu ? "white" : "transparent"}` }}
    >
      <div
        className="container"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "30px",
        }}
      >
        {mobile_logo && (
          <div className="custom-navbar-mobile-logo">
            <Image
              src={replaceImageUrl(mobile_logo)}
              alt="logo"
              width={340}
              height={212}
            />
          </div>
        )}
        <div className="custom-navbar-logo">
          {fav_logo && (
            <div className={`custom-navbar-fav-logo`}>
              <Image
                src={replaceImageUrl(fav_logo)}
                alt="logo"
                width={40}
                height={40}
              />
            </div>
          )}
          {evivve_logo && (
            <div className={`custom-navbar-evivve-logo`}>
              <Image
                src={replaceImageUrl(evivve_logo)}
                alt="logo"
                width={130}
                height={30}
              />
            </div>
          )}
          {masterclass_logo && (
            <div className={`custom-navbar-masterclass-logo`}>
              <Image
                src={replaceImageUrl(masterclass_logo)}
                alt="masterclass-logo"
                width={183}
                height={30}
              />
            </div>
          )}
        </div>
        <button onClick={toggleNavbar} className={`custom-navbar-menu-button`}>
          {menu ? <i className="bx bx-x"></i> : <i className="bx bx-menu"></i>}
        </button>
        <div className="custom-navbar-links-wrap">
          {links?.map((item, index) => {
            return (
              <button
                className={`custom-navbar-link ${
                  activeSection === item.link ? "active" : ""
                }`}
                data-link={item.link}
                onClick={() => scrollToSection(item.link)}
                key={index}
                ref={(el) => (buttonRefs.current[index] = el)} // Store refs for positions
              >
                {item?.title}
              </button>
            );
          })}
          <div
            style={{
              ...selectedButtonStyle,
              zIndex: -1,
              transition: "0.3s ease-in-out",
              position: "absolute",
              borderRadius: "15px",
              backgroundColor: "white",
            }}
          ></div>
        </div>
        {menu && (
          <div className={`custom-navbar-drop-down hide-scrollbar`}>
            {links?.map((item, index) => {
              return (
                <button
                  className={`custom-navbar-link ${
                    activeSection === item.link ? "active" : ""
                  }`}
                  onClick={() => scrollToSection(item.link)}
                  key={index}
                >
                  {item?.title}
                </button>
              );
            })}
            {/* <div
              style={{
                ...selectedButtonStyle,
                zIndex: -1,
                transition: "0.3s ease-in-out",
                position: "absolute",
                borderRadius: "15px",
                backgroundColor: "white",
              }}
            ></div> */}
          </div>
        )}
      </div>
    </div>
  );
}

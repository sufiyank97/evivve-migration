import React from "react";
import BrandsSwiper from "./BrandsSwiper";
import Link from "next/link";

export default function Brands({ data, button, showOnboarding }) {
  return (
    <section className="brands-main-wrap" id={showOnboarding ? "" : "brands"}>
      <div className="container">
        <h1
          style={{
            color: "#E8C48F",
            marginBottom: "40px",
            textAlign: "center",
          }}
        >
          <span>{data?.title1 || data?.title}</span>
          {data?.title_icon && (
            <span>
              {" "}
              <i class={data?.title_icon || ""}></i>{" "}
            </span>
          )}
          <span>{data?.title2}</span>
        </h1>
        {data?.description && (
          <p className="brands-description">{data?.description}</p>
        )}
        <div className="brands-wrap">
          {(data?.brands1?.length > 0 ||
            data?.brands?.length > 0 ||
            data?.client_logos?.length > 0) && (
            <div>
              <BrandsSwiper
                data={
                  data?.brands1 ||
                  data?.brands ||
                  data?.client_logos
                }
                speed={2000}
              />
            </div>
          )}
          {(data?.brands2?.length > 0 ||
            data?.client_logos2?.length > 0) && (
            <div>
              <BrandsSwiper
                data={data?.brands2 || data?.client_logos2}
                speed={2500}
              />
            </div>
          )}
          {(data?.brands3?.length > 0 ||
            data?.client_logos3?.length > 0) && (
            <div>
              <BrandsSwiper
                data={data?.brands3 || data?.client_logos3}
                speed={3000}
              />
            </div>
          )}
          <div className="brands-shade brands-left-shade"></div>
          <div className="brands-shade"></div>
        </div>
        {button?.button_text && (
          <Link
            href={button?.button_link || ""}
            passHref
            target={button?.button_target === "blank" ? "_blank" : "_self"}
          >
            <div className="link btn1 brands-btn">
              {button?.button_text}{" "}
              {button?.button_icon && <i className={button?.button_icon}></i>}
            </div>
          </Link>
        )}
      </div>
    </section>
  );
}

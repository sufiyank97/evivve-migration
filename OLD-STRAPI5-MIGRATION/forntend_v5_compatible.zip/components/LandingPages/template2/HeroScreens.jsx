import React from "react";
import YoutubeVideo from "../common/YoutubeVideo";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import CKEditor from "@/utils/CkEditor";

export default function HeroScreens({
  heroSectionRef,
  screen,
  reverseScreen,
  data,
  isScrolled,
  screen1ContentRef,
  screen2ContentRef,
  screen3ContentRef,
  handleBtnClick,
  registerButtonClick,
  mobileScreen2Ref,
  mobileScreen3Ref,
  mobileScreen3ButtonClick,
  registerMobileButtonClick,
  show_custom_navbar,
  show_initial_animation,
  setShowModal,
  formData,
  template,
}) {
  return (
    <>
      <section
        ref={heroSectionRef}
        className={`webinar-main-wrap ${
          screen === 5 ? "hide-webinar-animation-screen" : ""
        }`}
        style={{ position: "relative", zIndex: "0" }}
      >
        <div
          className={`bg-img-1 ${
            show_initial_animation ? "" : "hide_initial_animation_bg-img-1"
          }`}
        >
          {data?.bg_img_1?.data?.attributes?.url && (
            <Image
              src={replaceImageUrl(data?.bg_img_1?.data?.attributes?.url)}
              alt="image"
              layout="fill"
            />
          )}
        </div>
        <div
          className={`bg-img-2 ${
            show_initial_animation ? "" : "hide_initial_animation_bg-img-2"
          }`}
        >
          {data?.bg_img_2?.data?.attributes?.url && (
            <Image
              src={replaceImageUrl(data?.bg_img_2?.data?.attributes?.url)}
              alt="image"
              layout="fill"
            />
          )}
        </div>
        <div className="container position-relative h-100">
          <div
            className={`webinar-main-logo ${
              show_initial_animation
                ? ""
                : "hide_initial_animation_webinar-main-logo"
            }`}
          >
            <Image
              src={replaceImageUrl(data?.e_logo?.data?.attributes?.url)}
              alt="logo"
              layout="fill"
            />
          </div>
          <div
            className={`${
              show_custom_navbar
                ? !show_initial_animation
                  ? "hide_initial_animation_show_custom_navbar-hide-logos"
                  : "show_custom_navbar-hide-logos"
                : ""
            }`}
          >
            <div
              className={`webinar-evivve-fav-logo ${
                show_initial_animation
                  ? ""
                  : "hide_initial_animation_webinar-evivve-fav-logo"
              } ${screen === 4 || screen === 5 ? "fav-logo-slide-up" : ""} ${
                reverseScreen === 3 ||
                (!data?.screen2 && !data?.screen3 && reverseScreen === 1) ||
                (data?.screen2 && !data?.screen3 && reverseScreen === 2)
                  ? "fav-logo-slide-down"
                  : (screen !== 1 && screen !== 4 && screen !== 5) ||
                    reverseScreen === 1
                  ? "webinar-evivve-fav-logo-no-animation"
                  : ""
              }`}
            >
              <Image
                src={replaceImageUrl(data?.fav_logo?.data?.attributes?.url)}
                alt="logo"
                width={45}
                height={45}
              />
            </div>
            <div
              className={`webinar-logo-text-wrap ${
                show_initial_animation
                  ? ""
                  : "hide_initial_animation_webinar-logo-text-wrap"
              } ${screen === 4 || screen === 5 ? "logo-text-slide-up" : ""} ${
                reverseScreen === 3 ||
                (!data?.screen2 && !data?.screen3 && reverseScreen === 1) ||
                (data?.screen2 && !data?.screen3 && reverseScreen === 2)
                  ? "logo-text-slide-down"
                  : (screen !== 1 && screen !== 4 && screen !== 5) ||
                    reverseScreen === 1
                  ? "webinar-logo-text-wrap-no-animation"
                  : ""
              }`}
            >
              <div
                className={`webinar-logo-text ${
                  show_initial_animation
                    ? ""
                    : "hide_initial_animation_webinar-logo-text"
                }`}
              >
                <div className="webinar-evivve-masterclass-logos">
                  <Image
                    src={replaceImageUrl(
                      data?.evivve_logo?.data?.attributes?.url
                    )}
                    alt="logo"
                    // layout="fill"
                    width={334}
                    height={77}
                  />
                  <div
                    className={`masterclass-logo ${
                      show_initial_animation
                        ? ""
                        : "hide_initial_animation_masterclass-logo"
                    }`}
                  >
                    <img
                      src={replaceImageUrl(
                        data?.masterclass_logo?.data?.attributes?.url
                      )}
                      alt="masterclass-logo"
                      // layout="fill"
                      // width={697}
                      // height={77}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div
              className={`webinar-text-logo-mobile-wrap ${
                show_initial_animation
                  ? ""
                  : "hide_initial_animation_webinar-text-logo-mobile-wrap"
              }`}
              style={{
                backgroundColor: isScrolled ? "#5b105a" : "transparent",
              }}
            >
              <div
                className={`webinar-text-logo-mobile-wrap2 ${
                  show_initial_animation
                    ? ""
                    : "hide_initial_animation_webinar-text-logo-mobile-wrap2"
                }`}
              >
                <Image
                  src={replaceImageUrl(
                    data?.mobile_logo?.data?.attributes?.url
                  )}
                  alt="logo"
                  width={340}
                  height={212}
                />
              </div>
            </div>
          </div>
          {/* screens */}
          <div
            className={`webinar-screen-1-wrap webinar-screen-wrap ${
              show_initial_animation
                ? ""
                : "hide_initial_animation_webinar-screen-1-wrap"
            } ${
              screen === 4 || screen === 5
                ? "webinar-screen-wrap-padding-reduce"
                : ""
            } ${
              reverseScreen === 3 || screen !== 4 || screen !== 5
                ? show_custom_navbar
                  ? !show_initial_animation
                    ? "hide_initial_animation_custom-nav-padding-increase"
                    : "custom-nav-padding-increase"
                  : "webinar-screen-wrap-padding-increase"
                : ""
            } webinar-screen-1-mobile-wrap`}
            style={{
              position: screen === 4 || screen === 5 ? "relative" : "unset",
            }}
          >
            <div
              className={`webinar-screen-1-content-wrap ${
                show_initial_animation
                  ? ""
                  : "hide_initial_animation_webinar-screen-1-content-wrap"
              } webinar-screen-content-wrap ${
                screen !== 4 ? "hide-overflow-content" : ""
              }`}
              style={{
                position: screen === 4 || screen === 5 ? "unset" : "relative",
              }}
            >
              <div>
                <div
                  className={`webinar-screen-1-content-wrap ${
                    show_initial_animation
                      ? ""
                      : "hide_initial_animation_webinar-screen-1-content-wrap"
                  } ${screen !== 1 ? "webinar-screen-1-content-slideup" : ""} ${
                    reverseScreen === 1
                      ? "webinar-screen-1-content-slidedown"
                      : ""
                  }`}
                  ref={screen1ContentRef}
                >
                  <CKEditor
                    content={data?.screen1?.title}
                    customStyle={"webinar-content-title"}
                  />
                  <CKEditor
                    content={data?.screen1?.description}
                    customStyle={"webinar-content-desc"}
                  />
                </div>
                {data?.screen2 && (
                  <div
                    className={`webinar-screen-2-content-wrap ${
                      screen === 2 ? "webinar-screen-2-content-animation" : ""
                    } ${
                      reverseScreen === 1
                        ? "webinar-screen-2-content-animation-slidedown"
                        : reverseScreen === 2
                        ? "webinar-screen-2-content-animation-slidedown2"
                        : ""
                    } ${
                      screen === 3 || screen === 4 || screen === 5
                        ? "webinar-screen-1-content-slideup"
                        : ""
                    }`}
                    ref={screen2ContentRef}
                  >
                    <CKEditor
                      content={data?.screen2?.title}
                      customStyle={"webinar-content-title"}
                    />
                    <CKEditor
                      content={data?.screen2?.description}
                      customStyle={"webinar-content-desc"}
                    />
                  </div>
                )}
                {data?.screen3 && (
                  <div
                    className={`webinar-screen-2-content-wrap webinar-screen-3-content-wrap ${
                      screen === 3 ? "webinar-screen-2-content-animation" : ""
                    } ${
                      reverseScreen === 2 ||
                      (!data?.screen2 && reverseScreen === 1)
                        ? "webinar-screen-2-content-animation-slidedown"
                        : reverseScreen === 3
                        ? "webinar-screen-3-content-fade-down"
                        : ""
                    } ${
                      screen === 4 || screen === 5
                        ? "webinar-screen-3-content-fade-up"
                        : ""
                    }`}
                    ref={screen3ContentRef}
                  >
                    <CKEditor
                      content={data?.screen3?.title}
                      customStyle={"webinar-content-title"}
                    />
                    <CKEditor
                      content={data?.screen3?.description}
                      customStyle={"webinar-content-desc"}
                    />
                  </div>
                )}
                <button
                  className={`webinar-btn ${
                    screen === 4 || screen === 5
                      ? show_custom_navbar
                        ? "show_custom_navbar-webinar-screen-4-btn"
                        : "webinar-screen-4-btn"
                      : ""
                  } ${
                    reverseScreen === 3 ||
                    (!data?.screen2 && !data?.screen3 && reverseScreen === 1) ||
                    (data?.screen2 && !data?.screen3 && reverseScreen === 2)
                      ? "webinar-reverse-screen-3-btn"
                      : ""
                  } ${
                    !show_initial_animation &&
                    screen === 1 &&
                    reverseScreen === null
                      ? "hide_initial_animation_webinar-btn"
                      : ""
                  }`}
                  onClick={() => {
                    if (template === 4) {
                      setShowModal(true);
                    } else {
                      if (screen === 1) {
                        if (formData?.zoho_form_type === "button") {
                          window.open(
                            data?.register_button?.button_link,
                            "_blank"
                          );
                        } else {
                          setShowModal(true);
                        }
                      } else {
                        handleBtnClick("register");
                      }
                    }
                  }}
                >
                  <span
                    className={`${
                      screen === 4 || screen === 5
                        ? "webinar-btn-fade-in"
                        : "webinar-btn-fade-out"
                    }`}
                  >
                    {data?.screen4_button_text}
                  </span>
                  <span
                    className={`${
                      screen === 3
                        ? "webinar-btn-fade-in"
                        : "webinar-btn-fade-out"
                    }`}
                  >
                    {data?.screen3?.button_text}
                  </span>
                  <span
                    className={`${
                      screen === 2
                        ? "webinar-btn-fade-in"
                        : "webinar-btn-fade-out"
                    }`}
                  >
                    {data?.screen2?.button_text}
                  </span>
                  <span
                    className={`${
                      screen === 1
                        ? "webinar-btn-fade-in"
                        : "webinar-btn-fade-out"
                    }`}
                  >
                    {data?.screen1?.button_text}
                  </span>
                </button>
                {/* {screen === 3 && (
                <button
                  onClick={() => registerButtonClick()}
                  className={`webinar-btn screen3-register-btn`}
                >
                  Register
                </button>
              )} */}
              </div>
            </div>
            <div
              className="webinar-screen-img-wrap"
              style={{
                overflow:
                  screen !== 1 && screen !== 4 && screen !== 5 ? "hidden" : "",
                zIndex: screen === 4 ? "10" : "",
              }}
            >
              <div
                className={`webinar-screen-1-img-wrap2 ${
                  show_initial_animation
                    ? ""
                    : "hide_initial_animation_webinar-screen-1-img-wrap2"
                } ${screen !== 1 ? "webinar-screen-1-img-slideup" : ""} ${
                  reverseScreen === 1 ? "webinar-screen-1-img-slidedown" : ""
                }`}
              >
                <Image
                  src={replaceImageUrl(
                    data?.screen1?.image?.data?.attributes?.url
                  )}
                  alt="screen1-img"
                  layout="fill"
                />
              </div>
              {data?.screen2 && (
                <div
                  className={`webinar-screen-2-img-wrap2 ${
                    screen === 2 && reverseScreen !== 2
                      ? "webinar-screen-2-img-slidein"
                      : ""
                  } ${
                    reverseScreen === 1
                      ? "webinar-screen-2-img-slidedown"
                      : reverseScreen === 2
                      ? "webinar-screen-2-img-slidedown2"
                      : ""
                  } ${
                    screen === 3 || screen === 4 || screen === 5
                      ? "webinar-screen-2-img-slideup"
                      : ""
                  }`}
                  style={{
                    visibility:
                      screen === 1 && reverseScreen !== 1
                        ? "hidden"
                        : "visible",
                  }}
                >
                  <Image
                    src={replaceImageUrl(
                      data?.screen2?.image?.data?.attributes?.url
                    )}
                    alt="screen2-img"
                    layout="fill"
                  />
                </div>
              )}
              {data?.screen3 && (
                <div
                  className={`webinar-screen-3-img-wrap2 ${
                    screen === 3 ? "webinar-screen-3-img-slidein" : ""
                  } ${
                    reverseScreen === 2 ||
                    (!data?.screen2 && reverseScreen === 1)
                      ? "webinar-screen-3-img-slidedown"
                      : reverseScreen === 3
                      ? "webinar-screen-3-img-slidedown2"
                      : ""
                  } ${
                    screen === 4 || screen === 5 ? "webinar-screen-4-img" : ""
                  }`}
                  style={{
                    visibility:
                      !data?.screen2 && screen === 1 && reverseScreen !== 1
                        ? "hidden"
                        : "visible",
                    marginTop:
                      show_custom_navbar && screen === 4 ? "-20px" : "",
                  }}
                >
                  {data?.screen3?.video?.data?.attributes?.url ? (
                    <YoutubeVideo
                      videoUrl={replaceImageUrl(
                        data?.screen3?.video?.data?.attributes?.url
                      )}
                      video_thumbnail={replaceImageUrl(
                        data?.screen3?.video_thumbnail?.data?.attributes?.url
                      )}
                      handleBtnClick={handleBtnClick}
                      screen={screen}
                      screen2Present={data?.screen2}
                    />
                  ) : data?.screen3?.image?.data?.attributes?.url ? (
                    <Image
                      src={data?.screen3?.image?.data?.attributes?.url}
                      alt="screen3-img"
                      layout="fill"
                    />
                  ) : (
                    ""
                  )}
                </div>
              )}
            </div>
          </div>
          {/* mobile screen 2 */}
          {data?.screen2 && (
            <div
              ref={mobileScreen2Ref}
              className={`webinar-screen-1-wrap webinar-screen-wrap ${
                show_initial_animation
                  ? ""
                  : "hide_initial_animation_webinar-screen-1-wrap"
              } webinar-screen-2-wrap-mobile`}
            >
              <div
                className={`webinar-screen-1-content-wrap ${
                  show_initial_animation
                    ? ""
                    : "hide_initial_animation_webinar-screen-1-content-wrap"
                } webinar-screen-content-wrap`}
              >
                <div>
                  <div
                    className={`webinar-screen-2-content-wrap webinar-screen-2-content-wrap-mobile`}
                  >
                    <CKEditor
                      content={data?.screen2?.title}
                      customStyle={"webinar-content-title"}
                    />
                    <CKEditor
                      content={data?.screen2?.description}
                      customStyle={"webinar-content-desc"}
                    />
                  </div>
                  <button
                    className={`webinar-btn`}
                    onClick={() => {
                      if (template === 4) {
                        setShowModal(true);
                      } else {
                        // mobileScreen3Ref.current.style.scrollMarginTop = "-70px";
                        if (data?.screen3) {
                          mobileScreen3Ref.current.style.scrollMarginTop =
                            "10px";
                          mobileScreen3Ref.current?.scrollIntoView({
                            behavior: "smooth",
                          });
                        } else {
                          mobileScreen3ButtonClick("register");
                        }
                      }
                    }}
                  >
                    {data?.screen2?.button_text}
                  </button>
                </div>
              </div>
              <div className="webinar-screen-img-wrap">
                <div
                  className={`webinar-screen-2-img-wrap2 webinar-screen-2-img-wrap2-mobile`}
                >
                  <Image
                    src={replaceImageUrl(
                      data?.screen2?.image?.data?.attributes?.url
                    )}
                    alt="screen2-img"
                    layout="fill"
                  />
                </div>
              </div>
            </div>
          )}
          {/* mobile screen 3 */}
          {data?.screen3 && (
            <div
              ref={mobileScreen3Ref}
              className={`webinar-screen-1-wrap webinar-screen-wrap ${
                show_initial_animation
                  ? ""
                  : "hide_initial_animation_webinar-screen-1-wrap"
              } webinar-screen-3-wrap-mobile`}
            >
              <div
                className={`webinar-screen-1-content-wrap ${
                  show_initial_animation
                    ? ""
                    : "hide_initial_animation_webinar-screen-1-content-wrap"
                } webinar-screen-content-wrap`}
              >
                <div>
                  <div
                    className={`webinar-screen-2-content-wrap webinar-screen-3-content-wrap webinar-screen-3-content-wrap-mobile`}
                  >
                    <CKEditor
                      content={data?.screen3?.title}
                      customStyle={"webinar-content-title"}
                    />
                    <CKEditor
                      content={data?.screen3?.description}
                      customStyle={"webinar-content-desc"}
                    />
                  </div>
                  <button
                    className={`webinar-btn`}
                    onClick={() => {
                      if (template === 4) {
                        setShowModal(true);
                      } else {
                        mobileScreen3ButtonClick("register");
                      }
                    }}
                  >
                    {data?.screen4_button_text}
                  </button>
                  {/* <br />
                <button
                  onClick={() => registerMobileButtonClick()}
                  className={`webinar-btn`}
                >
                  Register
                </button> */}
                </div>
              </div>
              <div className="webinar-screen-img-wrap webinar-screen-3-mobile-img-wrap">
                <div
                  className={`webinar-screen-3-img-wrap2 webinar-screen-3-img-wrap2-mobile`}
                >
                  {data?.screen3?.video?.data?.attributes?.url ? (
                    <YoutubeVideo
                      videoUrl={replaceImageUrl(
                        data?.screen3?.video?.data?.attributes?.url
                      )}
                      video_thumbnail={replaceImageUrl(
                        data?.screen3?.video_thumbnail?.data?.attributes?.url
                      )}
                      screen={screen}
                    />
                  ) : data?.screen3?.image?.data?.attributes?.url ? (
                    <Image
                      src={replaceImageUrl(
                        data?.screen3?.image?.data?.attributes?.url
                      )}
                      alt="screen3-img"
                      layout="fill"
                    />
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
}

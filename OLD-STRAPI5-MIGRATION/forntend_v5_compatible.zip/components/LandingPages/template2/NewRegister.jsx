import React from "react";
import Form from "../template3/Form";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function NewRegister({ data }) {
  return (
    <div className="template-2-form-main-wrap">
      <div className="container">
        <div className="template-2-form-wrap">
          <Form
            data={{
              form_onload: data?.form_onload,
              form_onsubmit: data?.form_onsubmit,
              preview_form: data?.form,
            }}
          />
        </div>
        <div className="template-2-form-content-wrap">
          <h2>{data?.title}</h2>
          <div className="template-2-form-content-profile-wrap">
            {data?.image?.data?.attributes?.url && (
              <div className="template-2-form-content-profile-img-wrap">
                <Image
                  src={data?.image?.data?.attributes?.url}
                  alt="profile image"
                  width={170}
                  height={170}
                />
              </div>
            )}
            <div className="template-2-form-content-profile-quote-wrap">
              <p>{data?.quote}</p>
              <div className="template-2-form-content-profile-details-wrap">
                {data?.company_image?.data?.attributes?.url && (
                  <Image
                    src={data?.company_image?.data?.attributes?.url}
                    alt="profile image"
                    width={50}
                    height={50}
                  />
                )}
                <div>
                  <p className="template-2-form-content-profile-name">
                    {data?.name}
                  </p>
                  <p>{data?.designation}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="template-2-form-brands-wrap">
            <p
              style={{
                textAlign: "center",
                fontWeight: "600",
              }}
            >
              {data?.brands_title}
            </p>
            <div className="template-2-form-brands">
              {data?.brands?.data?.map((brand, index) => {
                return (
                  <Image
                    src={replaceImageUrl(
                      brand?.attributes?.image?.data?.attributes?.url ||
                        brand?.image?.data?.attributes?.url
                    )}
                    alt=""
                    width={140}
                    height={34}
                    style={{ borderRadius: "0" }}
                    loading="lazy"
                    key={index}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useEffect } from "react";
import Brands from "../common/Brands";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";

export default function Template4Brands({
  // brands,
  // setAnimationsComplete,
  // setScreen,
  // setWheelEventCount,
  // screen2Present,
  // screen3Present,
  // setReverseScreen,
  // setActiveSection,
  // brandsSectionRef,
  data,
  customStyle,
}) {
  // useEffect(() => {
  //   if (document.documentElement.clientWidth >= 1024) {
  //     const handleWheel = (e) => {
  //       const section = brandsSectionRef?.current;
  //       // Check if the section is at the top of the viewport and the user is scrolling up
  //       if (section) {
  //         const sectionTop = section.getBoundingClientRect().top;
  //         if (sectionTop >= 0 && e.deltaY < -25) {
  //           setAnimationsComplete(false);
  //           if (screen3Present) {
  //             setScreen(3);
  //             setWheelEventCount(2);
  //             setReverseScreen(3);
  //           } else if (screen2Present && !screen3Present) {
  //             setScreen(2);
  //             setWheelEventCount(1);
  //             setReverseScreen(2);
  //           } else if (!screen2Present && !screen3Present) {
  //             setScreen(1);
  //             setWheelEventCount(0);
  //             setReverseScreen(1);
  //           }
  //           setActiveSection("home"); //setting active section state to home in navbar
  //         }
  //       }
  //     };

  //     // Add the wheel event listener
  //     brandsSectionRef?.current?.addEventListener("wheel", handleWheel);

  //     // Cleanup the event listener on component unmount
  //     return () => {
  //       brandsSectionRef?.current?.removeEventListener("wheel", handleWheel);
  //     };
  //   }
  // }, []);

  const brands = [
    "/images/brands/img1.png",
    "/images/brands/img2.png",
    "/images/brands/img3.png",
    "/images/brands/img4.png",
    "/images/brands/img5.png",
    "/images/brands/img6.png",
    "/images/brands/img7.png",
    "/images/brands/img8.png",
    "/images/brands/img9.png",
    "/images/brands/img10.png",
    "/images/brands/img11.png",
    "/images/brands/img12.png",
    "/images/brands/img13.png",
    "/images/brands/img14.png",
    "/images/brands/img15.png",
    "/images/brands/img16.png",
    "/images/brands/img17.png",
    "/images/brands/img18.png",
    "/images/brands/img19.png",
    "/images/brands/img20.png",
    "/images/brands/img21.png",
    "/images/brands/img22.png",
  ];
  return (
    <div
      // ref={brandsSectionRef}
      id="template4-brands"
      className={`template4-brands-wrap ${customStyle}`}
    >
      {/* <Brands data={brands} /> */}
      <p className="template4-brands-title">{data?.title}</p>
      {data?.brands?.length > 0 && (
        <Swiper
          autoplay={{
            delay: 0,
            disableOnInteraction: false,
            reverseDirection:true
          }}
          speed={2500}
          slidesPerView={"auto"}
          spaceBetween={50}
          breakpoints={{
            768: {
              spaceBetween: 50, // For tablets and above
            },
            480: {
              spaceBetween: 50, // Reduce space on smaller screens
            },
          }}
          loop={true}
          modules={[Autoplay]}
          className={"mySwiper home-brands-swiper"}
          onSwiper={(swiper) => {
            swiper.$wrapperEl[0].style.transitionTimingFunction = "linear";
          }}
        >
          {data?.brands?.map((brand, i) => {
            return (
              <SwiperSlide key={i}>
                <img
                  src={replaceImageUrl(
                    brand?.image?.url
                  )}
                  alt="brand"
                  style={{ borderRadius: "0" }}
                />
              </SwiperSlide>
            );
          })}
        </Swiper>
      )}
    </div>
  );
}

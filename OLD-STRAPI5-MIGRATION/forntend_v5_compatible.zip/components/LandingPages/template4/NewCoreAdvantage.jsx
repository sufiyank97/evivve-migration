import CKEditor from "@/utils/CkEditor";
import React, { useState, useEffect, useRef } from "react";

export default function NewCoreAdvantage({ data }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [lineHeight, setLineHeight] = useState(0);
  const [activationThreshold, setActivationThreshold] = useState(20);
  const timelineItemsRef = useRef(null);
  const lineRef = useRef(null);
  const trackerRef = useRef(null);
  const rafIdRef = useRef(null);

  useEffect(() => {
    const calculateLineHeightAndThreshold = () => {
      if (!timelineItemsRef.current) return;
      const items = timelineItemsRef.current.querySelectorAll(
        ".new-core-timeline-item"
      );
      if (!items.length) return;

      const lastItem = items[items.length - 1];
      const dot = lastItem.querySelector(".new-core-timeline-dot-2");
      const timelineTop = timelineItemsRef.current.getBoundingClientRect().top;
      const dotTop = dot
        ? dot.getBoundingClientRect().top
        : lastItem.getBoundingClientRect().top;

      const height = Math.max(0, dotTop - timelineTop);
      setLineHeight(height);
      if (lineRef.current) lineRef.current.style.height = `${height}px`;

      
      const dots = timelineItemsRef.current.querySelectorAll(
        ".new-core-timeline-dot-2"
      );
      if (dots.length > 1) {
        let totalSpacing = 0;
        for (let i = 1; i < dots.length; i++) {
          const prevTop = dots[i - 1].getBoundingClientRect().top;
          const currTop = dots[i].getBoundingClientRect().top;
          totalSpacing += currTop - prevTop;
        }
        const avgSpacing = totalSpacing / (dots.length - 1);
        setActivationThreshold(avgSpacing * 0.1);
      } else {
        setActivationThreshold(20); 
      }
    };

    calculateLineHeightAndThreshold();
    const timeoutId = setTimeout(calculateLineHeightAndThreshold, 300);

    let rafId = null;
    const onResize = () => {
      if (rafId) cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(calculateLineHeightAndThreshold);
    };
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);

    const imgs = timelineItemsRef.current?.querySelectorAll("img") ?? [];
    imgs.forEach((img) =>
      img.addEventListener("load", calculateLineHeightAndThreshold)
    );

    return () => {
      clearTimeout(timeoutId);
      if (rafId) cancelAnimationFrame(rafId);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
      imgs.forEach((img) =>
        img.removeEventListener("load", calculateLineHeightAndThreshold)
      );
    };
  }, [data?.list]);

  useEffect(() => {
    if (!timelineItemsRef.current) return;
    const dots = timelineItemsRef.current.querySelectorAll(
      ".new-core-timeline-dot-2"
    );
    if (!dots.length) return;

    const processScroll = () => {
      if (!trackerRef.current) return;

      const trackerRect = trackerRef.current.getBoundingClientRect();
      const trackerMiddle = trackerRect.top + trackerRect.height / 2;

      let newActiveIndex = activeIndex;
      let minDistance = Infinity;

      dots.forEach((dot, idx) => {
        const rect = dot.getBoundingClientRect();
        const dotMiddle = rect.top + rect.height / 2;
        const distance = Math.abs(dotMiddle - trackerMiddle);

        if (distance < minDistance) {
          minDistance = distance;
          newActiveIndex = idx;
        }
      });

      const rect = dots[newActiveIndex].getBoundingClientRect();
      const dotMiddle = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(dotMiddle - trackerMiddle);

      if (distanceFromCenter <= activationThreshold) {
        setActiveIndex(newActiveIndex);
      }
    };

    const onScroll = () => {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
      }
      rafIdRef.current = requestAnimationFrame(() => {
        processScroll();
        rafIdRef.current = null;
      });
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("touchmove", onScroll, { passive: true });
    window.addEventListener("wheel", onScroll, { passive: true });

    onScroll();

    return () => {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
      }
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("touchmove", onScroll);
      window.removeEventListener("wheel", onScroll);
    };
  }, [data?.list, activationThreshold, activeIndex]); 

  return (
    <div className="new-core-advantage-wrapper">
      {data?.title && <h3 className="new-core-advantage-h1">{data?.title}</h3>}
      <div className="new-core-advantage-ellipse1"></div>
      <div className="new-core-advantage-ellipse2"></div>
      <div className="new-core-advantage-ellipse3"></div>
      <div className="container">
        <div className="new-core-advantage-timeline-wrapper">
          {data?.image?.data?.attributes?.url && (
            <div className="new-core-timeline-left">
              <img
                src={data?.image?.data?.attributes?.url}
                alt="image"
                height={467}
                width={648}
              />
            </div>
          )}
          <div className="new-core-timeline-track">
            <div className="new-core-timeline-line">
              <div className="new-core-sticky" ref={trackerRef}>
                <div className="new-core-timeline-tracker-2"></div>
              </div>
              <div
                ref={lineRef}
                className="new-core-timeline-line-line-2"
                style={{ height: `${lineHeight}px` }}></div>
            </div>

            {data?.list?.length > 0 && (
              <div className="new-core-timeline-items" ref={timelineItemsRef}>
                {data?.list?.map((item, index) => (
                  <React.Fragment key={index}>
                    <div
                      className={`new-core-timeline-item${
                        item?.isLast ? " last" : ""
                      }`}
                      style={{
                        opacity: activeIndex === index ? 1 : 0.2,
                        transition: "opacity 0.4s ease",
                      }}>
                      <div
                        className="new-core-timeline-dot-2"
                        style={{
                          opacity: activeIndex === index ? 1 : 0.3,
                          transition: "opacity 0.4s ease",
                        }}></div>

                      <CKEditor
                        content={item?.description}
                        customStyle="new-core-timeline-p"
                      />
                    </div>

                    {!item?.isLast && (
                      <div className="new-core-spacer-75px"></div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            )}
          </div>
        </div>
        {data?.core_button && (
          <div className="new-core-button-container">
            <a
              className="new-core-advantage-button"
              href={data?.core_button?.button_link}
              target={data?.core_button?.button_target}>
              {data?.core_button?.button_text}
              <img
                src="/images/template4/solar_arrow-up-outline.svg"
                alt="button-icon"
              />
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
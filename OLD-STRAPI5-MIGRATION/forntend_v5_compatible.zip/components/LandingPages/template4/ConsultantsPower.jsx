import React, { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";

gsap.registerPlugin(ScrollTrigger);

export default function ConsultantsPower({ data }) {
  const [deviceType, setDeviceType] = useState("desktop");
  const [circleSize, setCircleSize] = useState(412);

  const debounce = (func, wait) => {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(this, args), wait);
    };
  };

  useEffect(() => {
    const checkDeviceType = () => {
      const width = window.innerWidth;
      let device = "desktop";

      if (width <= 767) {
        device = "mobile";
        setCircleSize(311);
      } else if (width <= 1024) {
        device = "tablet";
        setCircleSize(360);
      } else {
        device = "desktop";
        setCircleSize(412);
      }

      setDeviceType(device);
    };

    checkDeviceType();
    const debouncedCheckDeviceType = debounce(checkDeviceType, 100);
    window.addEventListener("resize", debouncedCheckDeviceType);
    return () => window.removeEventListener("resize", debouncedCheckDeviceType);
  }, []);

  const radius = circleSize / 2;
  const iconAngles = [-90, 30, 150].map((a) => (a * Math.PI) / 180);

  const generateDotsBetween = (start, end, count, color) => {
    const dots = [];
    const dotRadius = radius - 3;
    for (let i = 1; i <= count; i++) {
      const angle = start + ((end - start) * i) / (count + 1);
      const x = radius + dotRadius * Math.cos(angle);
      const y = radius + dotRadius * Math.sin(angle);
      dots.push({ x, y, color });
    }
    return dots;
  };

  const dots = [
    ...generateDotsBetween(iconAngles[0], iconAngles[1], 4, "#D08700"),
    ...generateDotsBetween(iconAngles[1], iconAngles[2], 4, "#ED011D"),
    ...generateDotsBetween(
      iconAngles[2],
      iconAngles[0] + 2 * Math.PI,
      4,
      "#9D24FD"
    ),
  ];

  const [isActive, setIsActive] = useState({
    aim: true,
    users: false,
    bulb: false,
  });

  const [borderProgress, setBorderProgress] = useState({
    aimToBulb: 0,
    bulbToUsers: 0,
    usersToAim: 0,
  });

  const containerRef = useRef(null);
  const card1Ref = useRef(null);
  const card2Ref = useRef(null);
  const card3Ref = useRef(null);
  const mainCard1Ref = useRef(null);
  const mainCard2Ref = useRef(null);
  const mainCard3Ref = useRef(null);
  const circle1Ref = useRef(null);
  const circle2Ref = useRef(null);
  const circle3Ref = useRef(null);

  useEffect(() => {
    if (deviceType === "desktop") {
      if (circle1Ref.current && circle2Ref.current && circle3Ref.current) {
        gsap.killTweensOf([
          circle1Ref.current,
          circle2Ref.current,
          circle3Ref.current,
        ]);
      }
      return;
    }
    if (circle1Ref.current && circle2Ref.current && circle3Ref.current) {
      const circumference = 2 * Math.PI * (radius - 5);
      gsap.set([circle1Ref.current, circle2Ref.current, circle3Ref.current], {
        strokeDasharray: `0 ${circumference}`,
      });
      const circleTimeline = gsap.timeline({ repeat: -1 });
      circleTimeline
        .to(circle1Ref.current, {
          strokeDasharray: `${circumference / 3} ${circumference}`,
          duration: 1.5,
          ease: "power2.inOut",
        })
        .to(
          circle2Ref.current,
          {
            strokeDasharray: `${circumference / 3} ${circumference}`,
            duration: 1.5,
            ease: "power2.inOut",
          },
          "-=0.75"
        )
        .to(
          circle3Ref.current,
          {
            strokeDasharray: `${circumference / 3} ${circumference}`,
            duration: 1.5,
            ease: "power2.inOut",
          },
          "-=0.75"
        )
        .to(
          [circle1Ref.current, circle2Ref.current, circle3Ref.current],
          {
            strokeDasharray: `0 ${circumference}`,
            duration: 1,
            ease: "power2.inOut",
          },
          "+=0.5"
        );

      return () => {
        circleTimeline.kill();
      };
    }
  }, [deviceType, radius]);

  useEffect(() => {
    if (deviceType !== "desktop") {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
      return;
    }

    if (
      !containerRef.current ||
      !card1Ref.current ||
      !card2Ref.current ||
      !card3Ref.current ||
      !mainCard1Ref.current ||
      !mainCard2Ref.current ||
      !mainCard3Ref.current
    )
      return;

    // Initial state setup
    gsap.set(mainCard1Ref.current, { y: 0, opacity: 1 });
    gsap.set([mainCard2Ref.current, mainCard3Ref.current], {
      y: 556,
      opacity: 0,
    });
    gsap.set([card1Ref.current, card2Ref.current, card3Ref.current], {
      y: 700,
      opacity: 0,
    });

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: containerRef.current,
        start: "top 15%",
        end: "+=2000",
        scrub: 1.5,
        pin: true,
        pinSpacing: true,
        anticipatePin: 1,
        immediateRender: true,
        onUpdate: (self) => {
          const progress = self.progress;
          const direction = self.direction;

          let aimToBulbProgress = 0;
          let bulbToUsersProgress = 0;
          let usersToAimProgress = 0;

          if (progress <= 0.33) {
            aimToBulbProgress = progress / 0.33;
          } else {
            aimToBulbProgress = 1;
          }

          if (progress > 0.33 && progress <= 0.66) {
            bulbToUsersProgress = (progress - 0.33) / 0.33;
          } else if (progress > 0.66) {
            bulbToUsersProgress = 1;
          }

          if (progress > 0.66 && progress <= 1) {
            usersToAimProgress = (progress - 0.66) / 0.34;
          } else if (progress >= 1) {
            usersToAimProgress = 1;
          }

          // Update border progress
          setBorderProgress({
            aimToBulb: Math.min(1, aimToBulbProgress),
            bulbToUsers: Math.min(1, bulbToUsersProgress),
            usersToAim: Math.min(1, usersToAimProgress),
          });

          // Handle reverse scrolling (going back up)
          if (direction === -1) {
            if (progress < 0.02) {
              // At the very top - all inactive (increased threshold)
              setIsActive({ aim: false, users: false, bulb: false });
              gsap.to(mainCard1Ref.current, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard2Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.22) {
              // Back to first section (adjusted threshold)
              setIsActive({ aim: true, users: false, bulb: false });
              gsap.to(mainCard1Ref.current, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard2Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.38) {
              // Back to first section with card preview (adjusted threshold)
              setIsActive({ aim: true, users: false, bulb: false });
              gsap.to(mainCard1Ref.current, {
                y: -30,
                opacity: 0.7,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard2Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to(card2Ref.current, {
                y: 500,
                opacity: 0.5,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.52) {
              // Back to second section (adjusted threshold)
              setIsActive({ aim: true, users: false, bulb: true });
              gsap.to(mainCard2Ref.current, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard1Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.68) {
              // Back to second section with card preview (adjusted threshold)
              setIsActive({ aim: true, users: false, bulb: true });
              gsap.to(mainCard2Ref.current, {
                y: -30,
                opacity: 0.7,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard1Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to(card3Ref.current, {
                y: 500,
                opacity: 0.5,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.82) {
              // Back to third section (adjusted threshold)
              setIsActive({ aim: true, users: true, bulb: true });
              gsap.to(mainCard3Ref.current, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard1Ref.current, mainCard2Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else {
              // At the top of third section
              setIsActive({ aim: true, users: true, bulb: true });
              gsap.to(mainCard3Ref.current, {
                y: -10,
                opacity: 0.9,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard1Ref.current, mainCard2Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            }
          }
          // Handle forward scrolling (adjusted thresholds for consistency)
          else {
            if (progress < 0.02) {
              // At the very top - all inactive (increased threshold)
              setIsActive({ aim: false, users: false, bulb: false });
              gsap.to(mainCard1Ref.current, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard2Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.25) {
              // First section active
              setIsActive({ aim: true, users: false, bulb: false });
              gsap.to(mainCard1Ref.current, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard2Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.4) {
              // First section with card preview
              setIsActive({ aim: true, users: false, bulb: false });
              gsap.to(mainCard1Ref.current, {
                y: -30,
                opacity: 0.7,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard2Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to(card2Ref.current, {
                y: 500,
                opacity: 0.5,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.55) {
              // Second section active
              setIsActive({ aim: true, users: false, bulb: true });
              gsap.to(mainCard2Ref.current, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard1Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.7) {
              // Second section with card preview
              setIsActive({ aim: true, users: false, bulb: true });
              gsap.to(mainCard2Ref.current, {
                y: -30,
                opacity: 0.7,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard1Ref.current, mainCard3Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to(card3Ref.current, {
                y: 500,
                opacity: 0.5,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else if (progress < 0.85) {
              // Third section active
              setIsActive({ aim: true, users: true, bulb: true });
              gsap.to(mainCard3Ref.current, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard1Ref.current, mainCard2Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            } else {
              setIsActive({ aim: true, users: true, bulb: true });
              gsap.to(mainCard3Ref.current, {
                y: -10,
                opacity: 0.9,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([mainCard1Ref.current, mainCard2Ref.current], {
                y: 556,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
              gsap.to([card1Ref.current, card2Ref.current, card3Ref.current], {
                y: 700,
                opacity: 0,
                duration: 0.5,
                ease: "power2.out",
              });
            }
          }
        },
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    };
  }, [deviceType]);

  const circumference = 2 * Math.PI * (radius - 5);
  const strokeDashValue = circumference / 3;

  if (deviceType === "mobile" || deviceType === "tablet") {
    return (
      <section className="consultants-power-wrap">
        {data?.title && (
          <h2 className="consultants-power-title">{data?.title}</h2>
        )}
        <div className="container">
          <div className="consultants-power-main-wrap">
            <div className="consultants-power-main-wrapper">
              <div className="consultants-power-content">
                {data?.cards?.map((card, index) => (
                  <div
                    id={`consultants-power-main-card${index + 1}`}
                    className="consultants-power-main-card"
                    key={index}
                    style={{
                      marginBottom:
                        index < data?.cards?.length - 1 ? "40px" : "0",
                    }}
                  >
                    <div
                      className={`consultants-power-icon consultants-power-card${
                        index + 1
                      }-icon`}
                    >
                      <img
                        src={replaceImageUrl(
                          card?.image?.data?.attributes?.url
                        )}
                        alt={card?.card_title}
                      />
                    </div>
                    <div className="consultants-power-card-content">
                      <p
                        className={`consultants-power-phase consultants-power-card${
                          index + 1
                        }-phase`}
                      >
                        {card?.sub_title}
                      </p>
                      <div className="consultants-power-main-content">
                        <h3 className="consultants-power-card-title">
                          {card?.card_title}
                        </h3>

                        <CKEditor
                          content={card?.description}
                          customStyle="consultants-power-card-description"
                        />
                        <div className="consultants-power-list-wrap">
                          <ul className="consultants-power-list">
                            {card?.list?.map((item, liIndex) => (
                              <li
                                className={`consultants-power-list-item consultants-power-list-card${
                                  index + 1
                                }-item`}
                                key={liIndex}
                              >
                                {item?.data}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="consultants-power-circle-wrapper">
                <svg
                  className="consultants-power-circle-svg"
                  width={circleSize}
                  height={circleSize}
                  viewBox={`0 0 ${circleSize} ${circleSize}`}
                >
                  <defs>
                    <linearGradient
                      id="aimToBulbGradient"
                      x1="100%"
                      y1="100%"
                      x2="0%"
                      y2="0%"
                    >
                      <stop offset="17.45%" stopColor="#9D24FD" />
                      <stop offset="30%" stopColor="#ED011D" />
                    </linearGradient>

                    <linearGradient
                      id="bulbToUsersGradient"
                      x1="-0%"
                      y1="-0%"
                      x2="100%"
                      y2="100%"
                    >
                      <stop offset="0%" stopColor="#D08700" />
                      <stop offset="21.41%" stopColor="#E8C48F" />
                      <stop offset="53.41%" stopColor="#EA0327" />
                    </linearGradient>

                    <linearGradient
                      id="usersToAimGradient"
                      x1="0%"
                      y1="0%"
                      x2="100%"
                      y2="100%"
                    >
                      <stop offset="16.01%" stopColor="#E8C48F" />
                      <stop offset="0%" stopColor="#D08700" />
                      <stop offset="86.5%" stopColor="#9D24FD" />
                    </linearGradient>
                  </defs>

                  <circle
                    cx={radius}
                    cy={radius}
                    r={radius - 5}
                    fill="none"
                    stroke="#E5E7EB"
                    strokeWidth="5"
                    strokeDasharray="8 8"
                  />

                  <circle
                    ref={circle1Ref}
                    cx={radius}
                    cy={radius}
                    r={radius - 5}
                    fill="none"
                    stroke="url(#aimToBulbGradient)"
                    strokeWidth="10"
                    style={{
                      strokeDasharray: `0 ${circumference}`,
                      transform: "rotate(-90deg)",
                      transformOrigin: `${radius}px ${radius}px`,
                    }}
                  />
                  <circle
                    ref={circle2Ref}
                    cx={radius}
                    cy={radius}
                    r={radius - 5}
                    fill="none"
                    stroke="url(#bulbToUsersGradient)"
                    strokeWidth="10"
                    style={{
                      strokeDasharray: `0 ${circumference}`,
                      strokeDashoffset: `-${strokeDashValue}`,
                      transform: "rotate(-90deg)",
                      transformOrigin: `${radius}px ${radius}px`,
                    }}
                  />
                  <circle
                    ref={circle3Ref}
                    cx={radius}
                    cy={radius}
                    r={radius - 5}
                    fill="none"
                    stroke="url(#usersToAimGradient)"
                    strokeWidth="10"
                    style={{
                      strokeDasharray: `0 ${circumference}`,
                      strokeDashoffset: `-${strokeDashValue * 2}`,
                      transform: "rotate(-90deg)",
                      transformOrigin: `${radius}px ${radius}px`,
                    }}
                  />
                </svg>

                {dots.map((dot, i) => (
                  <div
                    key={i}
                    className="circle-dot"
                    style={{
                      left: `${dot.x}px`,
                      top: `${dot.y}px`,
                      background: dot.color,
                    }}
                  ></div>
                ))}

                <img
                  src={replaceImageUrl(
                    data?.active_images?.data[0]?.attributes?.url
                  )}
                  alt="icon"
                  className="circle-icon aim-icon"
                  style={{
                    border: "2px solid #FFE1AB",
                    background: "#FEFBE8",
                  }}
                />

                <img
                  src={replaceImageUrl(
                    data?.active_images?.data[2]?.attributes?.url
                  )}
                  alt="icon"
                  className="circle-icon users-icon"
                  style={{
                    border: "2px solid #E6D7FA",
                    background: "#FAF5FF",
                  }}
                />

                <img
                  src={replaceImageUrl(
                    data?.active_images?.data[1]?.attributes?.url
                  )}
                  alt="icon"
                  className="circle-icon bulb-icon"
                  style={{
                    border: "2px solid #FFCECE",
                    background: "#FEF2F2",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const desktopCircumference = 2 * Math.PI * (radius - 5);
  const desktopStrokeDashValue = desktopCircumference / 3;

  return (
    <section className="consultants-power-wrap">
      {data?.title && (
        <h2 className="consultants-power-title">{data?.title}</h2>
      )}
      <div className="container">
        <div className="consultants-power-main-wrap">
          <div className="consultants-power-main-wrapper" ref={containerRef}>
            <div className="consultants-power-content">
              {data?.cards?.map((card, index) => (
                <div
                  className="consultants-power-main-card"
                  key={index}
                  ref={
                    index === 0 ? card1Ref : index === 1 ? card2Ref : card3Ref
                  }
                >
                  <div className="consultants-power-icon">
                    <img
                      src={replaceImageUrl(card?.image?.data?.attributes?.url)}
                      alt={card?.card_title}
                    />
                  </div>
                  <div className="consultants-power-card-content">
                    <p className="consultants-power-phase">{card?.sub_title}</p>
                    <div className="consultants-power-main-content">
                      <h3 className="consultants-power-card-title">
                        {card?.card_title}
                      </h3>
                      <CKEditor
                        content={card?.description}
                        customStyle="consultants-power-card-description"
                      />
                      <div className="consultants-power-list-wrap">
                        <ul className="consultants-power-list">
                          {card?.list?.map((item, liIndex) => (
                            <li
                              className="consultants-power-list-item"
                              key={liIndex}
                            >
                              {item?.data}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {data?.cards?.map((card, index) => (
                <div
                  id={`consultants-power-main-card${index + 1}`}
                  className="consultants-power-main-card"
                  key={`main-${index}`}
                  ref={
                    index === 0
                      ? mainCard1Ref
                      : index === 1
                      ? mainCard2Ref
                      : mainCard3Ref
                  }
                >
                  <div
                    className={`consultants-power-icon consultants-power-card${
                      index + 1
                    }-icon`}
                  >
                    <img
                      src={replaceImageUrl(card?.image?.data?.attributes?.url)}
                      alt={card?.card_title}
                    />
                  </div>
                  <div className="consultants-power-card-content">
                    <p
                      className={`consultants-power-phase consultants-power-card${
                        index + 1
                      }-phase`}
                    >
                      {card?.sub_title}
                    </p>
                    <div className="consultants-power-main-content">
                      <h3 className="consultants-power-card-title">
                        {card?.card_title}
                      </h3>
                      <CKEditor
                        content={card?.description}
                        customStyle="consultants-power-card-description"
                      />
                      <div className="consultants-power-list-wrap">
                        <ul className="consultants-power-list">
                          {card?.list?.map((item, liIndex) => (
                            <li
                              className={`consultants-power-list-item consultants-power-list-card${
                                index + 1
                              }-item`}
                              key={liIndex}
                            >
                              {item?.data}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="consultants-power-circle-wrapper">
              <svg
                className="consultants-power-circle-svg"
                width={circleSize}
                height={circleSize}
                viewBox={`0 0 ${circleSize} ${circleSize}`}
              >
                <defs>
                  <linearGradient
                    id="aimToBulbGradient"
                    x1="100%"
                    y1="100%"
                    x2="0%"
                    y2="0%"
                  >
                    <stop offset="17.45%" stopColor="#9D24FD" />
                    <stop offset="30%" stopColor="#ED011D" />
                  </linearGradient>

                  <linearGradient
                    id="bulbToUsersGradient"
                    x1="-0%"
                    y1="-0%"
                    x2="100%"
                    y2="100%"
                  >
                    <stop offset="0%" stopColor="#D08700" />
                    <stop offset="21.41%" stopColor="#E8C48F" />
                    <stop offset="53.41%" stopColor="#EA0327" />
                  </linearGradient>

                  <linearGradient
                    id="usersToAimGradient"
                    x1="0%"
                    y1="0%"
                    x2="100%"
                    y2="100%"
                  >
                    <stop offset="16.01%" stopColor="#E8C48F" />
                    <stop offset="0%" stopColor="#D08700" />
                    <stop offset="86.5%" stopColor="#9D24FD" />
                  </linearGradient>
                </defs>

                <circle
                  cx={radius}
                  cy={radius}
                  r={radius - 5}
                  fill="none"
                  stroke="#E5E7EB"
                  strokeWidth="5"
                  strokeDasharray="8 8"
                />

                <circle
                  cx={radius}
                  cy={radius}
                  r={radius - 5}
                  fill="none"
                  stroke="url(#aimToBulbGradient)"
                  strokeWidth="10"
                  style={{
                    strokeDasharray: `${
                      desktopStrokeDashValue * borderProgress.aimToBulb
                    } ${desktopCircumference}`,
                    transform: "rotate(-90deg)",
                    transformOrigin: `${radius}px ${radius}px`,
                    transition: "stroke-dasharray 0.3s ease",
                  }}
                />

                <circle
                  cx={radius}
                  cy={radius}
                  r={radius - 5}
                  fill="none"
                  stroke="url(#bulbToUsersGradient)"
                  strokeWidth="10"
                  style={{
                    strokeDasharray: `${
                      desktopStrokeDashValue * borderProgress.bulbToUsers
                    } ${desktopCircumference}`,
                    strokeDashoffset: `-${desktopStrokeDashValue}`,
                    transform: "rotate(-90deg)",
                    transformOrigin: `${radius}px ${radius}px`,
                    transition: "stroke-dasharray 0.3s ease",
                  }}
                />

                <circle
                  cx={radius}
                  cy={radius}
                  r={radius - 5}
                  fill="none"
                  stroke="url(#usersToAimGradient)"
                  strokeWidth="10"
                  style={{
                    strokeDasharray: `${
                      desktopStrokeDashValue * borderProgress.usersToAim
                    } ${desktopCircumference}`,
                    strokeDashoffset: `-${desktopStrokeDashValue * 2}`,
                    transform: "rotate(-90deg)",
                    transformOrigin: `${radius}px ${radius}px`,
                    transition: "stroke-dasharray 0.3s ease",
                  }}
                />
              </svg>

              {dots.map((dot, i) => (
                <div
                  key={i}
                  className="circle-dot"
                  style={{
                    left: `${dot.x}px`,
                    top: `${dot.y}px`,
                    background: dot.color,
                  }}
                ></div>
              ))}

              {/* Aim Icon */}
              <img
                src={
                  isActive.aim
                    ? replaceImageUrl(
                        data?.active_images?.data[0]?.attributes?.url
                      )
                    : replaceImageUrl(
                        data?.default_images?.data[0]?.attributes?.url
                      )
                }
                alt="icon"
                className="circle-icon aim-icon"
                style={{
                  border: isActive.aim
                    ? "2px solid #FFE1AB"
                    : "2px solid #E5E7EB",
                  background: isActive.aim ? "#FEFBE8" : "#ffffff",
                }}
              />

              {/* Users Icon */}
              <img
                src={
                  isActive.users
                    ? replaceImageUrl(
                        data?.active_images?.data[2]?.attributes?.url
                      )
                    : replaceImageUrl(
                        data?.default_images?.data[2]?.attributes?.url
                      )
                }
                alt="icon"
                className="circle-icon users-icon"
                style={{
                  border: isActive.users
                    ? "2px solid #E6D7FA"
                    : "2px solid #E5E7EB",
                  background: isActive.users ? "#FAF5FF" : "#ffffff",
                }}
              />

              <img
                src={
                  isActive.bulb
                    ? replaceImageUrl(
                        data?.active_images?.data[1]?.attributes?.url
                      )
                    : replaceImageUrl(
                        data?.default_images?.data[1]?.attributes?.url
                      )
                }
                alt="icon"
                className="circle-icon bulb-icon"
                style={{
                  border: isActive.bulb
                    ? "2px solid #FFCECE"
                    : "2px solid #E5E7EB",
                  background: isActive.bulb ? "#FEF2F2" : "#ffffff",
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

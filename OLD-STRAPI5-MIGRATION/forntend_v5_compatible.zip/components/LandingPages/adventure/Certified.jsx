import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function Certified({ data }) {
  return (
    <div className="adventure-certified-wrap">
      <div className="container">
        <h2>{data?.title}</h2>
        <div className="adventure-certified-content-wrap">
          {data?.image?.data?.attributes?.url && (
            <div className="adventure-certified-img-wrap">
              <img src={data?.image?.data?.attributes?.url} alt="image" />
            </div>
          )}
          <div className="adventure-certified-cards-wrap">
            {data?.cards?.map((item, index) => {
              return (
                <div key={index}>
                  <img src={item?.icon?.data?.attributes?.url} alt="icon" />
                  <p className="adventure-certified-card-title">
                    {item?.title}
                  </p>
                  <div className="adventure-certified-card-desc">
                    <CKEditor content={item?.description} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

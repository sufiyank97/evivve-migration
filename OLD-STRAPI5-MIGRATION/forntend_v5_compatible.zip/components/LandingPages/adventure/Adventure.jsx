import Seo from "@/components/Common/seo";
import React, { useState } from "react";
import Template4Brands from "../template4/Template4Brands";
import WhatYouWillExperience from "@/components/Play/WhatYouWillExperience";
import Testimonials from "@/components/CaseStudy/Testimonials";
import Faq from "@/components/NewPricing/Faq";
import Form from "../template3/Form";
import PaysOffSection from "@/components/CaseStudy/PaysOffSection";
import HeroSection from "./HeroSection";
import Certified from "./Certified";
import Stripe from "./Stripe";

export default function Adventure({ data }) {
  const [showModal, setShowModal] = useState(false);
  return (
    <>
      <Seo data={data?.seo} />
      <main className={`landing-page-adventure`}>
        {data?.templates[0]?.hero_section && (
          <HeroSection
            data={data?.templates[0]?.hero_section}
            setShowModal={setShowModal}
          />
        )}
        {data?.templates[0]?.brands && (
          <Template4Brands data={data?.templates[0]?.brands} />
        )}
        {data?.templates[0]?.experience && (
          <WhatYouWillExperience data={data?.templates[0]?.experience} />
        )}
        {data?.templates[0]?.certified && (
          <Certified data={data?.templates[0]?.certified} />
        )}
        {data?.templates[0]?.pay_offs_section && (
          <PaysOffSection data={data?.templates[0]?.pay_offs_section} />
        )}
       
        {data?.templates[0]?.testimonial_section && (
          <Testimonials data={data?.templates[0]?.testimonial_section} />
        )}
         {data?.templates[0]?.stripe && (
          <Stripe
            data={data?.templates[0]?.stripe}
            setShowModal={setShowModal}
          />
        )}
        {data?.templates[0]?.faq && (
          <Faq
            title={data?.templates[0]?.faq?.title}
            faq={data?.templates[0]?.faq?.faq_list}
          />
        )}
      </main>
      {showModal && data?.templates[0]?.form && (
        <div className="template2-popup-form-overlay">
          <div className="template2-popup-form-wrap preview-modal-form play-live-form">
            <Form
              data={{
                form_onload: data?.templates[0]?.form?.form_onload,
                form_onsubmit: data?.templates[0]?.form?.form_onsubmit,
                preview_form: data?.templates[0]?.form?.form,
              }}
            />
            <button
              onClick={() => setShowModal(false)}
              className="template2-popup-close-btn"
            >
              <i class="bx bx-x"></i>
            </button>
          </div>
        </div>
      )}
    </>
  );
}

import CKEditor from "@/utils/CkEditor";
import Image from "next/image";
import React from "react";

export default function Preview({ data, setShowModal }) {
  const imageUrl = data?.image?.data?.attributes?.url;

  return (
    <>
      <section className="preview-wrap" id="preview">
        <div className="container">
          <h1 className="preview-title">{data?.title}</h1>
          <div className="preview-content-wrap">
            <div className="">
              <div className="preview-content-list">
                <CKEditor content={data?.preview_list} />
              </div>
              {data?.button_text && (
                <button className="btn1" onClick={() => setShowModal(true)}>
                  {data?.button_text}
                </button>
              )}
            </div>
            {imageUrl && (
              <div className="">
                <Image src={imageUrl} alt="Image" width={475} height={615} />
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
}

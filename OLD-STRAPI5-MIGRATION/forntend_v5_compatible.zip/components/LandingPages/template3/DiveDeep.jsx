import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function DiveDeep({ data }) {
  return (
    <section className="dive-deep-wrap container">
      <h1 className="landing-page-template3-h1 dive-deep-title">
        {data?.title}
      </h1>
      <div className="dive-deep-list-wrap">
        {data?.dive_deep_list?.map((item, index) => {
          return (
            <div key={index}>
              <p className="dive-deep-list-title">{item?.title}</p>
              <div className="dive-deep-list-desc">
                <CKEditor content={item?.description} />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

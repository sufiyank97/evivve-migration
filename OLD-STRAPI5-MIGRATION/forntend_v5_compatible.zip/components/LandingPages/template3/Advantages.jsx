import CKEditor from "@/utils/CkEditor";
import React, { useState, useEffect, useRef } from "react";

export default function Advantages({ data }) {
  const [visibleIndexes, setVisibleIndexes] = useState([]);
  const containerRef = useRef([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const index = parseInt(entry.target.dataset.index, 10);
          if (entry.isIntersecting) {
            setVisibleIndexes((prev) => [...new Set([...prev, index])]);
          }
        });
      },
      {
        threshold: 0.5, // Trigger when 50% of the image is visible
      }
    );

    containerRef.current.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section className="advantages-wrap container">
      <h1 style={{ textAlign: "center" }} className="landing-page-template3-h1">
        {data?.title}
      </h1>
      <div className="advantages-list">
        {data?.advantages_list?.map((item, index) => {
          return (
            <div
              key={index}
              className={`advantage-item ${
                visibleIndexes.includes(index) ? "animate-overlay" : ""
              }`}
              ref={(el) => (containerRef.current[index] = el)}
              data-index={index}
            >
              <div>
                <h3
                  style={{ marginBottom: "15px" }}
                  className="landing-page-template3-h3"
                >
                  {item?.title}
                </h3>
                <div className="landing-page-template3-p">
                  <CKEditor content={item?.description} />
                </div>
              </div>
              <div>
                {item?.image?.data?.attributes?.url && (
                  <div className="advantages-list-image-container">
                    <img
                      src={item?.image?.data?.attributes?.url}
                      alt="Image"
                      className="advantages-list-img"
                    />
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

import CKEditor from "@/utils/CkEditor";
import Image from "next/image";
// import Link from "next/link";
import React from "react";

export default function AferrModel({ data, setShowModal }) {
  const imageUrl = data?.image?.data?.attributes?.url;
  return (
    <section className="aferr-model-wrap container">
      <div className="">
        <h1
          className="landing-page-template3-h1"
          style={{ marginBottom: "40px" }}
        >
          {data?.title}
        </h1>
        <div className="landing-page-template3-p">
          <CKEditor content={data?.description} />
        </div>
        {imageUrl && (
          <div className="aferr-model-mobile-image">
            {/* <Image src={imageUrl} alt="Image" width={620} height={590} /> */}
            <img src={imageUrl} alt="Image" />
          </div>
        )}
        {/* {data?.aferr_model_button?.button_text && (
          <Link
            href={data?.aferr_model_button?.button_link || ""}
            target={
              data?.aferr_model_button?.button_target === "blank"
                ? "_blank"
                : "_self"
            }
          >
            <a
              className="landing-page-btn"
              target={
                data?.aferr_model_button?.button_target === "blank"
                  ? "_blank"
                  : "_self"
              }
            >
              {data?.aferr_model_button?.button_text}
            </a>
          </Link>
        )} */}
        {data?.aferr_model_button?.button_text && (
          <button
            className="landing-page-btn"
            onClick={() => setShowModal(true)}
          >
            {data?.aferr_model_button?.button_text}
          </button>
        )}
      </div>
      {imageUrl && (
        <div className="aferr-model-desktop-image">
          {/* <Image src={imageUrl} alt="Image" width={620} height={590} /> */}
          <img src={imageUrl} alt="Image" />
        </div>
      )}
    </section>
  );
}

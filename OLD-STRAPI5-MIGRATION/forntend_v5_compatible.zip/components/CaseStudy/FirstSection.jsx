import Image from "next/image";
import React, { useEffect, useRef, useState } from "react";
import { Autoplay, EffectFade, Navigation } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import ReactPlayer from "react-player";
import CKEditor from "@/utils/CkEditor";

export default function FirstSection({ data }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [videoOpenIndex, setVideoOpenIndex] = useState(null);
  const swiperRef = useRef(null);

  const handleSlideChange = () => {
    const swiper = swiperRef.current?.swiper;
    const newIndex = swiper?.realIndex ?? 0;
    setActiveIndex(newIndex);

    setVideoOpenIndex((prev) => (prev === newIndex ? prev : null));
  };

  useEffect(() => {
    const swiper = swiperRef.current?.swiper;
    if (!swiper) return;

    if (videoOpenIndex === activeIndex) {
      swiper.autoplay?.stop();
    } else {
      swiper.autoplay?.start();
    }
  }, [videoOpenIndex, activeIndex]);

  return (
    <div className="container case-study-first-section-wrap">
      <Swiper
        spaceBetween={30}
        effect="fade"
        // loop
        navigation
        speed={1000}
        autoplay={{
          delay: 4000,
          disableOnInteraction: false,
        }}
        fadeEffect={{ crossFade: true }}
        modules={[EffectFade, Navigation, Autoplay]}
        className="mySwiper"
        ref={swiperRef}
        onSlideChange={handleSlideChange}
      >
        {data?.map((item, index) => (
          <SwiperSlide key={index}>
            {({ isActive, isDuplicate }) => {
              const swiper = swiperRef.current?.swiper;
              const realIndex = swiper?.realIndex ?? 0;

              const isVideoOpen = videoOpenIndex === index;
              const shouldPlayVideo =
                isVideoOpen && isActive && !isDuplicate && realIndex === index;

              return (
                <div className="case-study-card">
                  <div className="case-study-card-content">
                    <h1>{item?.title}</h1>
                    <div className="case-study-card-description">
                      <CKEditor content={item?.description} />
                    </div>
                    <button
                      onClick={() => {
                        const realIndex = swiperRef.current?.swiper?.realIndex;
                        setVideoOpenIndex((prev) =>
                          prev === realIndex ? null : realIndex
                        );
                      }}
                      className="case-study-card-btn"
                    >
                      {isVideoOpen ? "Close video" : "Watch video"}
                    </button>
                  </div>

                  <div className="case-study-card-img-wrap">
                    {shouldPlayVideo ? (
                      <ReactPlayer
                        url={replaceImageUrl(item?.video)}
                        playing
                        controls
                        width="100%"
                        height="100%"
                        onEnded={() => {
                          swiperRef.current?.swiper?.autoplay?.start();
                          setVideoOpenIndex(null);
                        }}
                      />
                    ) : (
                      <div
                        onClick={() => {
                          const realIndex =
                            swiperRef.current?.swiper?.realIndex;
                          setVideoOpenIndex(realIndex);
                        }}
                        className="case-study-card-img-clickable"
                      >
                        <Image
                          src={replaceImageUrl(
                            item?.image?.data?.attributes?.url
                          )}
                          alt="Image"
                          layout="fill"
                          objectFit="cover"
                          objectPosition="center"
                          quality={75}
                        />
                        <div className="overlay"></div>
                        <div className="play-icon">
                          <i className="bx bx-play"></i>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            }}
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React from "react";
import { Autoplay, Pagination } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";

export default function Testimonials({ data }) {
  return (
    <div className="case-study-testimonials-wrap container">
      <h2 className="case-study-title">{data?.title}</h2>
      {data?.testimonials?.data?.length > 0 && (
        <Swiper
          //   slidesPerView={1}
          spaceBetween={25}
          breakpoints={{
            320: { slidesPerView: 1 }, // Mobile
            640: { slidesPerView: 2 }, // Tablets
            1024: { slidesPerView: 3 }, // Desktops
          }}
          loop={true}
          pagination={{
            clickable: true,
          }}
          autoplay={{
            delay: 6000,
            disableOnInteraction: false,
          }}
          modules={[Pagination, Autoplay]}
          className="case-study-testimonials-swiper"
        >
          {data?.testimonials?.data?.map((testimonial, i) => {
            const item = testimonial?.attributes;
            return (
              <SwiperSlide key={i}>
                <div className="case-study-card-wrap">
                  <img
                    src="/images/new-testimonials-quote-icon.svg"
                    alt="quote-icon"
                    className="quote-icon"
                  />
                  <p className="case-study-card-title">{item?.title}</p>
                  <div className="case-study-card-description">
                    <CKEditor content={item?.description} />
                  </div>
                  <div style={{ flex: "1" }}></div>
                  <div className="case-study-card-profile-wrap">
                    <img
                      src={replaceImageUrl(item?.image?.data?.attributes?.url)}
                      alt="user"
                    />
                    <div>
                      <p className="case-study-card-name">{item?.name}</p>
                      <p className="case-study-card-designation">
                        {item?.designation}
                      </p>
                    </div>
                  </div>
                </div>
              </SwiperSlide>
            );
          })}
        </Swiper>
      )}
    </div>
  );
}

import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React, { useState } from "react";
import ReactPlayer from "react-player";

export default function TeamSection({ data }) {
  const [activeVideoIndex, setActiveVideoIndex] = useState(null);

  return (
    <div className="team-section-wrap container">
      <h2 className="case-study-title">{data?.title}</h2>
      <div className="teams-cards-wrap">
        {data?.team_section_list?.map((item, index) => {
          const isVideoOpen = activeVideoIndex === index;
          const videoUrl = replaceImageUrl(item?.video);

          return (
            <div key={index}>
              <div className="teams-card-img-wrap">
                {isVideoOpen && videoUrl ? (
                  <ReactPlayer
                    url={videoUrl}
                    playing
                    controls
                    width="100%"
                    height="100%"
                    onEnded={() => setActiveVideoIndex(null)}
                  />
                ) : (
                  <button
                    onClick={() =>
                      setActiveVideoIndex(
                        isVideoOpen ? null : index // toggle video
                      )
                    }
                  >
                    {item?.image?.data?.attributes?.url && (
                      <>
                        <Image
                          src={item?.image?.data?.attributes?.url}
                          alt="Image"
                          layout="fill"
                          objectFit="cover"
                          objectPosition="center"
                          quality={75}
                        />
                        <div className="overlay"></div>
                      </>
                    )}
                    {item?.logo?.data?.attributes?.url && (
                      <img
                        src={item?.logo?.data?.attributes?.url}
                        alt="logo"
                        className="teams-card-logo"
                      />
                    )}
                    <div className="play-icon">
                      <i className="bx bx-play"></i>
                    </div>
                  </button>
                )}
              </div>

              <div className="teams-card-content-wrap">
                <p>{item?.title}</p>
                <div style={{ flex: "1" }}></div>
                <button
                  onClick={() =>
                    setActiveVideoIndex(
                      isVideoOpen ? null : index // toggle video
                    )
                  }
                  className="teams-card-btn"
                >
                  <div className="play-icon">
                    <i className="bx bx-play"></i>
                  </div>
                  <span className="teams-card-btn-text">
                    {isVideoOpen ? "Close video" : "Watch video"}
                  </span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

import React from "react";

export default function PaysOffSection({ data }) {
  return (
    <div className="pays-off-wrap">
      <div className="container">
        <h3 className="pays-off-title">{data?.title}</h3>
        {data?.list?.length > 0 && (
          <div className="pays-off-list-wrap">
            {data?.list?.map((item, index) => {
              return (
                <>
                  {index !== 0 && (
                    <div
                      key={`${index}-divider`}
                      className="pays-off-list-divider"
                    ></div>
                  )}
                  <div key={index} className="pays-off-list-item">
                    <p className="pays-off-list-title">{item?.title}</p>
                    <p className="pays-off-list-description">
                      {item?.description}
                    </p>
                  </div>
                </>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

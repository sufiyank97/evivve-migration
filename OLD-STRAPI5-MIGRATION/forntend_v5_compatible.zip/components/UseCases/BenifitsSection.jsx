import CKEditor from "@/utils/CkEditor";
import Image from "next/image";
import React from "react";
import NextImage from "next/future/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function BenifitsSection({ data }) {
  return (
    <div className="usecases-benefits-wrap">
      <div className="container">
        <div className="usecases-benefits">
          <h2
            style={{
              maxWidth: "768px",
              marginLeft: "auto",
              marginRight: "auto",
              textAlign: "center",
            }}
          >
            {data?.title}
          </h2>
          <div className="benefits-list">
            {data?.benefits_detials?.map((item, i) => {
              return (
                <div key={i}>
                  <div>
                    <div className="benefis-list-img-title-wrap">
                      <div className="benefits-list-item-img-wrap">
                        {item?.image?.data?.attributes?.url && (
                          <NextImage
                            src={replaceImageUrl(item?.image?.data?.attributes?.url)}
                            alt={item?.title}
                            width={238}
                            height={248}
                            loading="lazy"
                          />
                        )}
                      </div>
                      <p className="benefit-title">{item?.title}</p>
                    </div>
                    <CKEditor
                      customStyle={"benefits-description"}
                      content={item?.description}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

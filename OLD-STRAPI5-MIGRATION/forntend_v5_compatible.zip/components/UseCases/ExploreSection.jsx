import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Image from "next/image";
import React from "react";

export default function ExploreSection({ data }) {
  return (
    <div className="container">
      <div className="usecases-explore">
        <div>
          {data?.image?.data?.attributes?.url && (
            <Image
              src={replaceImageUrl(data?.image?.data?.attributes?.url)}
              alt={data?.title}
              width={616}
              height={640}
              loading="lazy"
            />
          )}
        </div>
        <div>
          <h3 className="explore-title">{data?.title}</h3>
          <div className="explore-description">
            <CKEditor content={data?.description} />
          </div>
        </div>
      </div>
    </div>
  );
}

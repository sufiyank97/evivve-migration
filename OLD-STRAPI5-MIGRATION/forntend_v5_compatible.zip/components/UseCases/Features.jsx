import CKEditor from "@/utils/CkEditor";
import Image from "next/image";
import React from "react";
import NextImage from "next/future/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function Features({ data }) {
  return (
    <div className="container">
      <div className="usecases-features">
        <h2 className="title">{data?.title}</h2>
        <div className="features-details">
          <div>
            <p className="feature-details-title">
              {data?.subTitle} <span>{data?.subTitle_highlight}</span>
            </p>
            <CKEditor content={data?.description} />
          </div>
          <div>
            {data?.image?.data?.attributes?.url && (
              <NextImage
                src={replaceImageUrl(data?.image?.data?.attributes?.url)}
                alt={data?.title}
                width={616}
                height={640}
                loading="lazy"
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

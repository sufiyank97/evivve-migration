import React, { useEffect, useRef, useState } from "react";
import styles from "./home.module.css";
import Link from "next/link";
import CKEditor from "@/utils/CkEditor";
import LiteYouTubeEmbed from "react-lite-youtube-embed";
import { BsPlayBtnFill } from "react-icons/bs";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function FirstSection({ data }) {
  // const url =
  //   "https://evivve-strapi-admin.s3.ap-south-1.amazonaws.com/Evivve_Product_Demo_Video_d3bf6213d5.mp4";
  // const url="https://www.youtube.com/embed/nGLJfEUVIA0?si=wWz72w9MxCZFxMsM"
  const iframeRef = useRef();
  const videoRef = useRef();

  const [showVideo, setShowVideo] = useState(false);
  const [thumbnail, setThumbnail] = useState(null);

  const handleLearnMoreClick = async () => {
    // iframeRef?.current?.scrollIntoView({ behavior: "smooth" });
    // iframeRef?.current?.src && (iframeRef.current.src += "&autoplay=1");

    iframeRef?.current?.scrollIntoView({ behavior: "smooth" });

    await setShowVideo(true);
    if (videoRef.current) {
      videoRef.current.play();
    } else {
      const playButton = iframeRef.current?.querySelector(".lty-playbtn");
      if (playButton) {
        playButton.click();
      }
    }
  };

  function getYoutubeVideoId(url) {
    // Regular expressions for different link formats
    const regexLive = /\/live\/(.+?)(?:\?|$)/;
    const regexWatch = /\?v=([^&]+)/;
    const regexShare = /(?:\/|^)youtu(?:\.be\/|)([^&#?]+)/;
    const regexEmbed = /(?:\/embed\/|.*\/)([^&#?]+)/;

    // Try matching the URL against each regex
    let match;
    if ((match = url.match(regexLive))) {
      return match[1]; // ID for live stream
    } else if ((match = url.match(regexWatch))) {
      return match[1]; // ID from watch link
    } else if ((match = url.match(regexShare))) {
      return match[1]; // ID from share link
    } else if ((match = url.match(regexEmbed))) {
      return match[1]; // ID from embed link
    } else {
      return null;
    }
  }

  function isYouTubeUrl(url) {
    return url.includes("youtube.com") || url.includes("youtu.be");
  }

  useEffect(() => {
    if (data?.videoUrl && !isYouTubeUrl(data?.videoUrl)) {
      generateThumbnail(replaceImageUrl(data?.videoUrl));
    }
  }, [data]);

  const generateThumbnail = (videoUrl) => {
    const video = document.createElement("video");
    video.src = videoUrl;
    video.crossOrigin = "anonymous"; // If the video is hosted on a different domain
    video.addEventListener("loadeddata", () => {
      video.currentTime = 1; // Set to capture the frame at the 2-second mark (adjust as needed)
    });

    video.addEventListener("seeked", () => {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      setThumbnail(canvas.toDataURL("image/png"));
    });
  };

  return (
    <div className="container">
      <div className={`${styles.first_section}`}>
        <div>
          <h1>
            <span>{data?.title?.substring(0, data?.title?.length / 2)}</span>
            <span>
              {data?.title?.substring(
                data?.title?.length / 2,
                data?.title?.length
              )}
            </span>
          </h1>
          <CKEditor content={data?.description} />
          <div className={styles.btns_wrap}>
            {/* {data?.videoUrl && (
              <button onClick={handleLearnMoreClick} className={styles.btn1}>
                LEARN MORE
              </button>
            )} */}
            {/* <Link href={"/sign-up"}>
              <button className={styles.btn2}>SIGN UP</button>
            </Link> */}
            {data?.button?.map((button, index) => {
              if (button?.button_link) {
                return (
                  <Link href={button?.button_link} key={index}>
                    <button
                      data-aos="fade-up"
                      data-aos-duration="1200"
                      data-aos-delay="500"
                      className={index % 2 === 1 ? styles.btn2 : styles.btn1}
                    >
                      {button?.button_text}
                    </button>
                  </Link>
                );
              }
              return (
                <button
                  data-aos="fade-up"
                  data-aos-duration="1200"
                  data-aos-delay="500"
                  onClick={handleLearnMoreClick}
                  className={styles.btn1}
                >
                  {button?.button_text}
                </button>
              );
            })}
          </div>
        </div>
        {/* {data?.videoUrl && (
          <div className={styles.video} ref={iframeRef}>
            <LiteYouTubeEmbed
              id={getYoutubeVideoId(data?.videoUrl)}
              title="YouTube video player"
              // adNetwork={false}
              // params={autoplay ? "autoplay=1" : ""}
              // onIframeAdded={() => {
              //   // This callback is triggered when the iframe is added to the DOM
              //   if (autoplay) {
              //     const iframe = iframeRef.current.querySelector("iframe");
              //     if (iframe) {
              //       iframe.src += "&autoplay=1";
              //     }
              //   }
              // }}
            ></LiteYouTubeEmbed>
          </div>
        )} */}
        {data?.videoUrl && (
          <div
            className={styles.video}
            ref={iframeRef}
            style={{
              backgroundColor: isYouTubeUrl(data?.videoUrl)
                ? "rgba(0, 0, 0, 0.5)"
                : "rgba(0, 0, 0, 1)",
            }}
          >
            {isYouTubeUrl(data?.videoUrl) ? (
              <LiteYouTubeEmbed
                id={getYoutubeVideoId(data?.videoUrl)}
                title="YouTube video player"
              />
            ) : (
              <div style={{ width: "100%", height: "100%" }}>
                {!showVideo && thumbnail && (
                  <div
                    className={styles.s3VideoThumbnail}
                    onClick={handleLearnMoreClick}
                  >
                    <img
                      src={thumbnail}
                      alt="Video Thumbnail"
                      className={styles.thumbnailImage}
                    />
                    <BsPlayBtnFill className={styles.s3VideoThumbnail_btn} />
                  </div>
                )}
                {showVideo && (
                  <video ref={videoRef} controls className={styles.s3Video}>
                    <source
                      src={replaceImageUrl(data?.videoUrl)}
                      type="video/mp4"
                    />
                    Your browser does not support the video tag.
                  </video>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

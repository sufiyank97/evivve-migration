import CKEditor from "@/utils/CkEditor";
import Image from "next/image";
import React from "react";

export default function GetStarted({ data }) {
  return (
    <div className="home-get-started">
      <Image
        src={"/images/home-get-started-bg-design.png"}
        alt="bg-design"
        layout="fill"
        objectFit="cover"
        objectPosition={"center"}
        quality={75}
        style={{ borderRadius: "0" }}
      />
      <div className="container">
        <h2>{data?.title}</h2>
        <div className="home-get-started-desc-wrap">
          <CKEditor content={data?.description} />
        </div>
        {data?.get_started_button?.button_text && (
          <a
            href={data?.get_started_button?.button_link || ""}
            target={
              data?.get_started_button?.button_target === "blank"
                ? "_blank"
                : "_self"
            }
            className="home-get-started-button"
          >
            {data?.get_started_button?.button_text}
          </a>
        )}
      </div>
    </div>
  );
}

import React, { useEffect, useRef, useState } from "react";
import NextImage from "next/future/image";
import Cookies from "js-cookie";
import "swiper/css/effect-fade";
import Image from "next/image";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import YoutubeVideoPopup from "./YoutubeVideoPopup";
import Link from "next/link";
import CKEditor from "@/utils/CkEditor";

const Onboarding = ({
  showOnboarding,
  setShowOnboarding,
  onboardingData,
  setOnBoardingCompleted,
  top_section_data,
}) => {
  const [buttonOneClicked, setButtonOneClicked] = useState(false);
  const [buttonOneReverse, setButtonOneReverse] = useState(false);
  const [buttonTwoClicked, setButtonTwoClicked] = useState(false);
  const [buttonTwoReverse, setButtonTwoReverse] = useState(false);
  const [buttonThreeClicked, setButtonThreeClicked] = useState(false);
  let animationrunning = false;
  const [showYoutubeVideo, setShowYoutubeVideo] = useState(false);

  const section1TitleRef = useRef(null);

  const handleButtonOne = () => {
    setButtonOneClicked(true);
    setButtonOneReverse(false);
    animationrunning = true;
    setTimeout(() => {
      animationrunning = false;
    }, 3000);
  };
  const handleButtonTwo = () => {
    setButtonTwoClicked(true);
    setButtonTwoReverse(false);
    setTimeout(() => {
      Cookies.set("evivve-onboarding-completed", true, { expires: 365 });
      setOnBoardingCompleted(true);
      setShowOnboarding(false);
    }, 1500);
  };

  const [wheelEventCount, setWheelEventCount] = useState(0);

  const handleScroll = (e) => {
    if (e.deltaY > 25 && !animationrunning) {
      setWheelEventCount((prevCount) => prevCount + 1);
      animationrunning = true;
      setTimeout(() => {
        animationrunning = false;
      }, 3000);
    } else if (e.deltaY < -25 && !animationrunning) {
      // setWheelEventCount((prevCount) => prevCount - 1);
      // animationrunning = true;
      // setTimeout(() => {
      //   animationrunning = false;
      // }, 3000);
    }
  };

  useEffect(() => {
    if (showOnboarding) {
      if (wheelEventCount <= 0) {
        setWheelEventCount(0);
      }
      if (
        wheelEventCount === 1 &&
        !buttonOneClicked &&
        !buttonTwoClicked &&
        !buttonThreeClicked
      ) {
        setButtonOneClicked(true);
        setButtonOneReverse(false);
        animationrunning = true;
        setTimeout(() => {
          animationrunning = false;
        }, 3000);
      } else if (
        wheelEventCount === 2 &&
        buttonOneClicked &&
        !buttonTwoClicked &&
        !buttonThreeClicked
      ) {
        setButtonTwoClicked(true);
        setButtonTwoReverse(false);
        setTimeout(() => {
          Cookies.set("evivve-onboarding-completed", true, { expires: 365 });
          setOnBoardingCompleted(true);
          setShowOnboarding(false);
        }, 1500);
      } else if (
        !buttonOneReverse &&
        buttonOneClicked &&
        wheelEventCount === 0
      ) {
        setButtonOneReverse(true);
        setButtonOneClicked(false);
        animationrunning = true;
        setTimeout(() => {
          animationrunning = false;
        }, 3000);
      } else if (
        buttonTwoClicked &&
        buttonOneClicked &&
        !buttonTwoReverse &&
        wheelEventCount === 1
      ) {
        setButtonOneReverse(false);
        setButtonTwoReverse(true);
        setButtonTwoClicked(false);
        animationrunning = true;
        setTimeout(() => {
          animationrunning = false;
        }, 3000);
      }
    }
  }, [wheelEventCount]);

  useEffect(() => {
    if (!animationrunning && showOnboarding) {
      window.addEventListener("wheel", handleScroll);
    }

    return () => {
      window.removeEventListener("wheel", handleScroll);
    };
  }, []);

  return (
    <div
      className={`onboarding-wrap ${
        !showOnboarding ? "home-hero-section" : ""
      }`}
    >
      <div className="m-container">
        <div className="image-text-wrapper">
          {showOnboarding && (
            <>
              <div
                className={`${
                  buttonOneClicked ? "image-scaling" : ""
                } image-style fade-in-bgImage hide-on-mobile screen1-bg-img`}
              >
                <NextImage
                  src={
                    replaceImageUrl(
                      onboardingData?.screen1?.background_image?.data
                        ?.attributes?.url
                    ) || ""
                  }
                  alt="bgImage1"
                  width={1440}
                  height={755}
                />
              </div>
              <div
                className={`image-style  ${
                  buttonOneClicked ? "fade-in-bgImage2" : ""
                } ${
                  buttonTwoClicked ? "screen2-bg-fade-out" : ""
                } delay-anime-3s hide-on-mobile screen2-bg-img`}
              >
                <NextImage
                  src={
                    replaceImageUrl(
                      onboardingData?.screen2?.background_image?.data
                        ?.attributes?.url
                    ) || ""
                  }
                  alt="bgImage2"
                  width={2880}
                  height={1506}
                />
              </div>
              <div
                className={`${
                  buttonOneClicked ? "image-scaling" : ""
                } image-style fade-in-bgImage hide-on-desktop screen1-bg-img`}
              >
                <NextImage
                  src={
                    replaceImageUrl(
                      onboardingData?.screen1?.mobile_background_image?.data
                        ?.attributes?.url
                    ) || ""
                  }
                  alt="bgImage1"
                  width={750}
                  height={1624}
                />
              </div>
              <div
                className={`image-style  ${
                  buttonOneClicked ? "fade-in-bgImage2" : ""
                } ${
                  buttonTwoClicked ? "screen2-bg-fade-out" : ""
                } delay-anime-3s hide-on-desktop screen2-bg-img`}
              >
                <NextImage
                  src={
                    replaceImageUrl(
                      onboardingData?.screen2?.mobile_background_image?.data
                        ?.attributes?.url
                    ) || ""
                  }
                  alt="bgImage2"
                  width={750}
                  height={1624}
                />
              </div>
              <div
                className={`${
                  buttonOneClicked ? "screen1-screen2-animation" : ""
                } text-wrapper fade-in screen1-text-wrapper`}
              >
                <h1 ref={section1TitleRef} className="screen1-title">
                  {onboardingData?.screen1?.title || ""}
                </h1>
                <button
                  className="screen1-btn"
                  onClick={() => {
                    buttonOneClicked ? handleButtonTwo() : handleButtonOne();
                  }}
                >
                  {onboardingData?.screen1?.button_text || ""}
                </button>
              </div>
              <div
                className={`${
                  buttonTwoClicked ? "text-fade-out-2" : ""
                } text-wrapper screen2-text ${
                  buttonOneClicked ? "fade-in-screen2-text" : ""
                }`}
              >
                <h2 className={`screen2-title`}>
                  {onboardingData?.screen2?.title || ""}
                </h2>
                <button
                  className="btn-style-2"
                  onClick={() => handleButtonTwo()}
                >
                  {onboardingData?.screen2?.button_text || ""}
                </button>
              </div>
              <div
                className={`${
                  buttonOneClicked ? "image-scaling-2 bottom-0" : ""
                } image-style-2 fade-in-image-1 hide-on-mobile`}
                style={{
                  width: "100%",
                  bottom: "-100%",
                  zIndex: "2",
                }}
              >
                <NextImage
                  src={
                    replaceImageUrl(
                      onboardingData?.screen1?.persons_image?.data?.attributes
                        ?.url
                    ) || ""
                  }
                  alt="person-image"
                  width={1440}
                  height={755}
                />
              </div>
              <div
                className={`image-style-2 person-image-2 ${
                  buttonOneClicked ? "person-image-2-slide-from-left" : ""
                } ${
                  buttonTwoClicked ? "screen2-person-img-fade-out" : ""
                } hide-on-mobile`}
                style={{ width: "100%", height: "100%" }}
              >
                <Image
                  src={
                    replaceImageUrl(
                      onboardingData?.screen2?.persons_image?.data?.attributes
                        ?.url
                    ) || ""
                  }
                  alt="person-image-2"
                  layout="fill"
                />
              </div>
              <div
                className={`${
                  buttonOneClicked ? "image-scaling-2" : ""
                } image-style-2 fade-in-image-1 hide-on-desktop screen1-mobile-img`}
                style={{
                  width: "100%",
                  zIndex: "2",
                  scale: "1",
                }}
              >
                <NextImage
                  src={
                    replaceImageUrl(
                      onboardingData?.screen1?.mobile_persons_image?.data
                        ?.attributes?.url
                    ) || ""
                  }
                  strategy="eager"
                  priority
                  alt="person-image"
                  width={750}
                  height={1624}
                />
              </div>
              <div
                className={`image-style-2 person-image-2 ${
                  buttonOneClicked ? "person-image-2-slide-from-left" : ""
                } ${
                  buttonTwoClicked ? "screen2-person-img-fade-out" : ""
                } hide-on-desktop`}
                style={{ width: "100%", height: "100%" }}
              >
                <Image
                  src={
                    replaceImageUrl(
                      onboardingData?.screen2?.mobile_persons_image?.data
                        ?.attributes?.url
                    ) || ""
                  }
                  alt="person-image-2"
                  layout="fill"
                />
              </div>
            </>
          )}
          {top_section_data?.show_video_or_image === "video" ? (
            <>
              <div className="bg-video-overlay"></div>
              <video muted loop autoPlay className="bg-video">
                <source
                  src={top_section_data?.bg_video?.data?.attributes?.url}
                />
                Your browser does not support the video tag.
              </video>
            </>
          ) : (
            <>
              {onboardingData?.top_shade?.data?.attributes?.url && (
                <div className={`top-shade hide-on-mobile`}>
                  <NextImage
                    src={
                      replaceImageUrl(
                        onboardingData?.top_shade?.data?.attributes?.url
                      ) || ""
                    }
                    alt="shade"
                    width={1440}
                    height={171}
                  />
                </div>
              )}
              {onboardingData?.left_shade?.data?.attributes?.url && (
                <div
                  className={`left-shade ${
                    buttonOneClicked ? "left-shade-fade-out" : ""
                  } ${
                    buttonTwoClicked ? "left-shade-fade-in" : ""
                  } hide-on-mobile`}
                >
                  <NextImage
                    src={
                      replaceImageUrl(
                        onboardingData?.left_shade?.data?.attributes?.url
                      ) || ""
                    }
                    alt="shade"
                    width={783}
                    height={751}
                  />
                </div>
              )}
              {onboardingData?.mobile_shade?.data?.attributes?.url && (
                <div
                  className={`left-shade mobile-shade ${
                    buttonOneClicked ? "left-shade-fade-out" : ""
                  } ${
                    buttonTwoClicked ? "left-shade-fade-in" : ""
                  } hide-on-desktop`}
                  style={{ width: "100%" }}
                >
                  <picture style={{ width: "100%", height: "100%" }}>
                    <source
                      media="(max-width:699px)"
                      srcSet={
                        replaceImageUrl(
                          onboardingData?.mobile_shade?.data?.attributes?.url
                        ) || ""
                      }
                      type="image/webp"
                    />
                    <source
                      media="(max-width:640px)"
                      srcSet={
                        replaceImageUrl(
                          onboardingData?.mobile_shade?.data?.attributes?.url
                        ) || ""
                      }
                      type="image/webp"
                    />
                    <Image
                      src={
                        replaceImageUrl(
                          onboardingData?.mobile_shade?.data?.attributes?.url
                        ) || ""
                      }
                      layout="fill"
                      alt="shade"
                      quality={100}
                      loading="lazy"
                    />
                  </picture>
                </div>
              )}
              <div
                className={`image-style  ${
                  buttonTwoClicked ? "screen3-bg-fade-in" : ""
                } delay-anime-3s hide-on-mobile screen3-bg-img`}
              >
                <NextImage
                  src={
                    replaceImageUrl(
                      top_section_data?.background_image?.data?.attributes?.url
                    ) || ""
                  }
                  alt="bgImage3"
                  width={2880}
                  height={1506}
                />
              </div>
              <div
                className={`image-style  ${
                  buttonTwoClicked ? "screen3-bg-fade-in" : ""
                } delay-anime-3s hide-on-desktop screen3-bg-img`}
              >
                <NextImage
                  src={
                    replaceImageUrl(
                      top_section_data?.mobile_background_image?.data
                        ?.attributes?.url
                    ) || ""
                  }
                  alt="bgImage3"
                  width={2880}
                  height={1506}
                />
              </div>
            </>
          )}
          <div
            className={`${
              buttonTwoClicked || !showOnboarding
                ? "screen2-step2-text-fade-in"
                : ""
            } text-wrapper screen2-step2-text`}
          >
            <h2 className="screen2-title screen2-step2-title">
              {top_section_data?.title || ""}
            </h2>
            <div
              className="screen2-step2-content"
              style={{ textAlign: "left" }}
            >
              <CKEditor content={top_section_data?.description} />
            </div>
            <div className="screen2-step2-btns-wrap">
              <Link href={top_section_data?.button1_link || ""}>
                <a target="_blank">
                  <button className="btn-style-outline">
                    {top_section_data?.button1_text || ""}
                  </button>
                </a>
              </Link>
              <Link href={top_section_data?.videoUrl || ""}>
                <a target="_blank">
                  <button className="btn-style-2">
                    {top_section_data?.button2_text || ""}
                  </button>
                </a>
              </Link>
              {/* <button
                className="btn-style-2"
                onClick={() => setShowYoutubeVideo(true)}
              >
                {top_section_data?.button2_text || ""}
              </button> */}
            </div>
          </div>
        </div>
      </div>
      {showYoutubeVideo && (
        <YoutubeVideoPopup
          data={top_section_data}
          setShowYoutubeVideo={setShowYoutubeVideo}
        />
      )}
    </div>
  );
};

export default Onboarding;

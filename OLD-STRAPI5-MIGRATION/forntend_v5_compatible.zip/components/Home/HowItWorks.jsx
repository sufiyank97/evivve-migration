import React, { createRef, useContext, useEffect } from "react";
import styles from "./home.module.css";
import Link from "next/link";
import Image from "next/image";
import { useRef } from "react";
import CKEditor from "@/utils/CkEditor";
import { Tooltip } from "react-tooltip";
import { AppContext } from "context/AppContextProvider";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function HowItWorks({ title, steps }) {
  const stepref = useRef();
  const textAnimateRefs = useRef(steps?.map(() => createRef()));
  const { showStripe, navbarHeight } = useContext(AppContext);

  const handleNext = (index) => {
    stepref?.current?.children[index + 1]?.scrollIntoView({
      behavior: "smooth",
    });
  };

  useEffect(() => {
    textAnimate();
  }, []);

  const textAnimate = () => {
    steps?.forEach((step, stepIndex) => {
      if (step?.textanimate?.length > 0) {
        const texts = textAnimateRefs?.current[stepIndex]?.current?.children;
        let index = 0;
        animateFromLeft();

        function animateFromLeft() {
          for (let i = 0; i < texts?.length; i++) {
            texts[i]?.classList.remove(styles.text_in, styles.text_out);
          }
          texts[index]?.classList.add(styles.text_in);
          setTimeout(() => {
            texts[index]?.classList.add(styles.text_out);
            setTimeout(() => {
              index = (index + 1) % texts?.length;
              animateFromLeft();
            }, 500);
          }, 3000);
        }
      }
    });
  };

  return (
    <div style={{ position: "relative" }}>
      <div
        className={`${styles.how_it_works_title} ${
          showStripe ? styles.how_it_works_title_with_top_stripe : ""
        }`}
        style={{ top: `${navbarHeight}px` }}
      >
        <div className="container">
          <h1>{title}</h1>
        </div>
      </div>
      <div className="container">
        <div className={styles.how_it_works}>
          <div ref={stepref} className={styles.how_it_works_steps}>
            {steps?.map((step, i) => {
              return (
                <div key={i}>
                  <div>
                    <p className={styles.step_info}>{step?.step_info}</p>
                    <h2 className={styles.step_title}>
                      {/* {i + 1}. */}
                      {step?.title}{" "}
                      {step?.tooltip_text && (
                        <div
                          className={styles.tooltip}
                          data-tooltip-id="my-tooltip"
                          data-tooltip-content={step?.tooltip_text}
                        >
                          <i class="bx bx-info-circle"></i>
                        </div>
                      )}
                    </h2>
                    <div className={styles.step_description}>
                      <CKEditor
                        content={step?.description1}
                        customStyle={`home-how-it-works-desc1`}
                      />
                      {step?.textanimate?.length > 0 && (
                        <span
                          ref={textAnimateRefs.current[i]}
                          className={styles.text_animate}
                        >
                          {step?.textanimate?.map((item, index) => {
                            return <span key={index}>{item?.text}</span>;
                          })}
                        </span>
                      )}
                      <CKEditor
                        content={step?.description2}
                        customStyle={"home-how-it-works-desc2"}
                      />
                    </div>
                    {step?.points?.length > 0 && (
                      <div className={styles.step_points}>
                        {step?.points?.map((point, index) => {
                          return (
                            <div
                              key={index}
                              data-aos="fade-up"
                              data-aos-duration="1200"
                              data-aos-delay={index * 100}
                            >
                              <div className={styles.step_icon}>
                                <i className={point?.icon}></i>
                              </div>
                              <h4 className={styles.point_title}>
                                {point?.title}
                              </h4>
                            </div>
                          );
                        })}
                      </div>
                    )}
                    <div className={styles.btns}>
                      {/* {i !== steps?.length - 1 && (
                        <button
                          data-aos="fade-up"
                          data-aos-duration="1200"
                          data-aos-delay="500"
                          className={styles.btn1}
                          onClick={() => {
                            handleNext(i);
                          }}
                        >
                          Next
                        </button>
                      )} */}
                      {/* <Link href={"/game"}>
                        <button
                          data-aos="fade-up"
                          data-aos-duration="1200"
                          data-aos-delay="500"
                          className={styles.btn2}
                        >
                          play now
                        </button>
                      </Link> */}
                      {step?.how_it_work_buttons?.map((button, index) => {
                        return (
                          <a
                            href={button?.button_link}
                            target={
                              button?.button_target === "blank"
                                ? "_blank"
                                : "_self"
                            }
                            key={index}
                          >
                            <button
                              data-aos="fade-up"
                              data-aos-duration="1200"
                              data-aos-delay="500"
                              className={
                                index % 2 === 0 ? styles.btn2 : styles.btn1
                              }
                            >
                              {button?.button_text}
                            </button>
                          </a>
                        );
                      })}
                    </div>
                  </div>
                  <div className={styles.step_img_wrap}>
                    {step?.image && (
                      <Image
                        data-aos="fade-up"
                        data-aos-duration="1200"
                        src={replaceImageUrl(
                          step?.image?.url
                        )}
                        alt="How it works step image"
                        className={styles.step_image}
                        width={616}
                        height={640}
                        loading="lazy"
                      />
                    )}
                  </div>
                  <div className={styles.mobile_btns}>
                    {/* {i !== steps?.length - 1 && (
                      <button
                        data-aos="fade-up"
                        data-aos-duration="1200"
                        data-aos-delay="500"
                        className={styles.btn1}
                        onClick={() => {
                          handleNext(i);
                        }}
                      >
                        Next
                      </button>
                    )} */}
                    {step?.how_it_work_buttons?.map((button, index) => {
                      return (
                        <a
                          href={button?.button_link}
                          key={index}
                          target={
                            button?.button_target === "blank"
                              ? "_blank"
                              : "_self"
                          }
                        >
                          <button
                            data-aos="fade-up"
                            data-aos-duration="1200"
                            data-aos-delay="500"
                            className={
                              index % 2 === 0 ? styles.btn2 : styles.btn1
                            }
                            style={{ width: "100%" }}
                          >
                            {button?.button_text}
                          </button>
                        </a>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        <Tooltip id="my-tooltip" />
      </div>
    </div>
  );
}

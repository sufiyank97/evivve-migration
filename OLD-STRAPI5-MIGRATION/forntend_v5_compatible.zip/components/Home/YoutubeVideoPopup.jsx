import React, { useEffect, useRef, useState } from "react";
// import LiteYouTubeEmbed from "react-lite-youtube-embed";
import styles from "./home.module.css";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import { BsPlayBtnFill } from "react-icons/bs";
import ReactPlayer from "react-player";

export default function YoutubeVideoPopup({ data, setShowYoutubeVideo }) {
  // const iframeRef = useRef();
  // const videoRef = useRef();

  // const [showVideo, setShowVideo] = useState(false);
  const [thumbnail, setThumbnail] = useState(null);

  // const handleLearnMoreClick = async () => {
  //   iframeRef?.current?.scrollIntoView({ behavior: "smooth" });

  //   await setShowVideo(true);
  //   if (videoRef.current) {
  //     videoRef.current.play();
  //   } else {
  //     const playButton = iframeRef.current?.querySelector(".lty-playbtn");
  //     if (playButton) {
  //       playButton.click();
  //     }
  //   }
  // };

  // function getYoutubeVideoId(url) {
  //   // Regular expressions for different link formats
  //   const regexLive = /\/live\/(.+?)(?:\?|$)/;
  //   const regexWatch = /\?v=([^&]+)/;
  //   const regexShare = /(?:\/|^)youtu(?:\.be\/|)([^&#?]+)/;
  //   const regexEmbed = /(?:\/embed\/|.*\/)([^&#?]+)/;

  //   // Try matching the URL against each regex
  //   let match;
  //   if (
  //     (match = url.match(regexLive)) ||
  //     (match = url.match(regexWatch)) ||
  //     (match = url.match(regexShare)) ||
  //     (match = url.match(regexEmbed))
  //   ) {
  //     return match[1]; // ID for live stream
  //   } else {
  //     return null;
  //   }
  // }

  // function isYouTubeUrl(url) {
  //   return url.includes("youtube.com") || url.includes("youtu.be");
  // }

  useEffect(() => {
    // if (data?.videoUrl && !isYouTubeUrl(data?.videoUrl)) {
    // }
    generateThumbnail(replaceImageUrl(data?.videoUrl));
  }, [data]);

  const generateThumbnail = (videoUrl) => {
    const video = document.createElement("video");
    video.src = videoUrl;
    video.crossOrigin = "anonymous"; // If the video is hosted on a different domain
    video.addEventListener("loadeddata", () => {
      video.currentTime = 1; // Set to capture the frame at the 2-second mark (adjust as needed)
    });

    video.addEventListener("seeked", () => {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      setThumbnail(canvas.toDataURL("image/png"));
    });
  };

  return (
    <div
      onClick={() => setShowYoutubeVideo(false)}
      className="youtube-video-popup"
    >
      <div>
        <div className="react-player-video" onClick={(e) => e.stopPropagation()}>
          {/* {data?.videoUrl && (
            <div
              className={styles.video}
              ref={iframeRef}
              style={{
                backgroundColor: isYouTubeUrl(data?.videoUrl)
                  ? "rgba(0, 0, 0, 0.5)"
                  : "rgba(0, 0, 0, 1)",
              }}
            >
              {isYouTubeUrl(data?.videoUrl) ? (
                <LiteYouTubeEmbed
                  id={getYoutubeVideoId(data?.videoUrl)}
                  title="YouTube video player"
                />
              ) : (
                <div style={{ width: "100%", height: "100%" }}>
                  {!showVideo ? (
                    thumbnail ? (
                      <div
                        className={styles.s3VideoThumbnail}
                        onClick={handleLearnMoreClick}
                      >
                        <img
                          src={thumbnail}
                          alt="Video Thumbnail"
                          className={styles.thumbnailImage}
                        />
                        <BsPlayBtnFill
                          className={styles.s3VideoThumbnail_btn}
                        />
                      </div>
                    ) : (
                      <div className={styles.s3VideoLoading}>
                        <svg className={styles.spinner} viewBox="0 0 50 50">
                          <circle
                            className={styles.path}
                            cx="25"
                            cy="25"
                            r="20"
                            fill="none"
                            strokeWidth="5"
                          ></circle>
                        </svg>
                      </div>
                    )
                  ) : (
                    <video ref={videoRef} controls className={styles.s3Video}>
                      <source
                        src={replaceImageUrl(data?.videoUrl)}
                        type="video/mp4"
                      />
                      Your browser does not support the video tag.
                    </video>
                  )}
                </div>
              )}
            </div>
          )} */}
          {data?.videoUrl && (
            <ReactPlayer
              light={<img src={thumbnail} alt="Thumbnail" />}
              playing
              controls
              playIcon={
                <BsPlayBtnFill className={styles.s3VideoThumbnail_btn} />
              }
              // height={"100%"}
              url={replaceImageUrl(data?.videoUrl)}
            />
          )}
        </div>
        <button
          onClick={() => setShowYoutubeVideo(false)}
          className="youtube-video-popup-btn"
        >
          Back to Website
        </button>
      </div>
    </div>
  );
}

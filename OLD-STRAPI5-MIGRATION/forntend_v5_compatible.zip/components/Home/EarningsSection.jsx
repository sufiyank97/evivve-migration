import React from "react";
import styles from "./home.module.css";
import Link from "next/link";
import CKEditor from "@/utils/CkEditor";

export default function EarningsSection({ data }) {
  return (
    <div className={styles.earnings}>
      <div className="container">
        <h1 className={styles.earnings_title}>{data?.title}</h1>
        <CKEditor content={data?.description} />
        <div className={styles.btns}>
          <a
            href={data?.earning_button?.button_link || ""}
            target={data?.earning_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
          >
            <button className={styles.btn2}>
              {data?.earning_button?.button_text}
            </button>
          </a>
        </div>
      </div>
    </div>
  );
}

import React, { useContext, useEffect, useState } from "react";
import JoinOurCommunity from "../AboutUs/JoinOurCommunity";
import ButtonText from "../Common/ButtonText";
import Button from "../Common/Button";
import AppDownload from "../Courses/AppDownload";
import Zoho from "../Blog/BlogDetails/Zoho";
import { useRouter } from "next/router";
import ExitIntentPopup from "../Common/ExitIntentPopup";
import { AppContext } from "context/AppContextProvider";
import CtasCard from "../knowledgebase/CtasCard";

export default function Ctas({ ctasData }) {
  const [popup, setPopup] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [exitIntentCloseCookies, setExitIntentCloseCookies] = useState(false);
  const router = useRouter();
  const currentSlug = router.asPath;
  const { showStripe } = useContext(AppContext);

  const getPopupData = () => {
    let filteredPopupData = ctasData?.filter((item) =>
      item?.description_type?.find(
        (subItem) => subItem?.__typename === "ComponentPopupPopup"
      )
    );
    if (filteredPopupData && filteredPopupData[0]) {
      setPopup(filteredPopupData[0]?.description_type[0]);
    }
  };

  useEffect(() => {
    getPopupData();
  }, [ctasData]);

  useEffect(() => {
    const exitIntentClosed = sessionStorage.getItem(
      `exit-intent-close-${currentSlug}`
    );
    exitIntentClosed
      ? setExitIntentCloseCookies(true)
      : setExitIntentCloseCookies(false);
  }, [currentSlug]);

  useEffect(() => {
    const handleMouseLeave = (event) => {
      if (event.clientY < (showStripe ? 150 : 100) && !exitIntentCloseCookies) {
        setShowPopup(true);
      }
    };

    const handleMouseMove = () => {
      setExitIntentCloseCookies(
        sessionStorage.getItem(`exit-intent-close-${currentSlug}`) === "true"
      );
    };

    !exitIntentCloseCookies &&
      popup &&
      document.addEventListener("mousemove", handleMouseLeave);

    !exitIntentCloseCookies && popup
      ? document.addEventListener("mousemove", handleMouseMove)
      : document.removeEventListener("mousemove", handleMouseMove);

    return () => {
      document.removeEventListener("mousemove", handleMouseLeave);
      document.removeEventListener("mousemove", handleMouseMove);
    };
  }, [exitIntentCloseCookies]);

  const handleCloseExitIntentPopup = () => {
    setShowPopup(false);
    sessionStorage.setItem(`exit-intent-close-${currentSlug}`, true);
    setExitIntentCloseCookies(true);
  };

  return (
    <div>
      {ctasData?.map((item, i) => {
        return item?.description_type?.map((subItem, index) => {
          if (subItem?.__typename === "ComponentButtonButtonImageText") {
            return (
              <JoinOurCommunity
                key={index}
                image={subItem?.image}
                title={subItem?.title}
                button={subItem?.button_image_text_button}
                description={subItem?.description}
              />
            );
          } else if (subItem?.__typename === "ComponentButtonButtonText") {
            return <ButtonText key={index} data={subItem} />;
          } else if (subItem?.__typename === "ComponentCommonButton") {
            return (
              <div style={{ width: "max-content", margin: "1rem auto" }}>
                <Button key={index} data={subItem} />
              </div>
            );
          } else if (subItem?.__typename === "ComponentCommonAppDownload") {
            return <AppDownload download_app_section={subItem} key={index} />;
          } else if (subItem?.__typename === "ComponentButtonNewsletter") {
            return (
              <Zoho
                key={index}
                embedCode={subItem?.description}
                form_onsubmit={subItem?.form_onsubmit}
                form_onload={subItem?.form_onload}
              />
            );
          } else if (
            subItem?.__typename === "ComponentKnowledgeBase3CardsCtas"
          ) {
            return <CtasCard key={index} data={subItem} />;
          }
        });
      })}
      {showPopup && popup && (
        <ExitIntentPopup
          data={popup}
          handleCloseExitIntentPopup={handleCloseExitIntentPopup}
        />
      )}
    </div>
  );
}

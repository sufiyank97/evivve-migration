import React, { useEffect, useState } from "react";
import TitleTag from "./common/TitleTag";
import LoadMoreButton from "./common/LoadMoreButton";
import { createTitleId } from "./common/createTitleId";
import axios from "axios";
import PressReleaseCards from "./PressReleaseCards";

export default function Section3({ data }) {
  const [pressReleases, setPressReleases] = useState([]);
  const [query, setQuery] = useState({ page: 1, pageSize: 6 });
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  // Function to determine the pageSize based on screen width
  const determinePageSize = () => {
    return window.innerWidth < 767 ? 3 : 6; // Mobile: 3, Desktop: 6
  };

  const fetchPressReleases = async (page = 1, pageSize = 6) => {
    try {
      setIsLoading(true);
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_STRAPI_URL}api/newsroom/pressreleases?page=${page}&pageSize=${pageSize}`
      );

      const { count, pressReleasesData } = res.data;
      setTotalCount(Number(count));

      // Append new data to the existing list
      setPressReleases((prev) =>
        page === 1 ? pressReleasesData : [...prev, ...pressReleasesData]
      );
    } catch (error) {
      console.error("Error fetching press releases:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoadMore = () => {
    const nextPage = query.page + 1;
    setQuery((prev) => ({ ...prev, page: nextPage }));
    fetchPressReleases(nextPage, query.pageSize);
  };

  useEffect(() => {
    // Set initial pageSize based on device type
    const initialPageSize = determinePageSize();
    setQuery((prev) => ({ ...prev, pageSize: initialPageSize }));

    // Fetch initial data
    fetchPressReleases(1, initialPageSize);

    // Optional: Add a resize listener to adjust pageSize dynamically
    const handleResize = () => {
      const newPageSize = determinePageSize();
      setQuery((prev) => ({ ...prev, pageSize: newPageSize }));
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <section className="newsroom-section3" id={createTitleId(data?.title)}>
      <div className="container">
        <TitleTag title={data?.title} />
        <PressReleaseCards pressReleases={pressReleases} />
        {pressReleases?.length < totalCount && (
          <LoadMoreButton
            text={isLoading ? "Loading..." : "Load More"}
            onClickFun={handleLoadMore}
            disabled={isLoading}
          />
        )}
      </div>
    </section>
  );
}

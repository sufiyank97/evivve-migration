export function createTitleId(title) {
  const titleId = title
    .toLowerCase() // Convert to lowercase
    .replace(/[^a-z0-9\s-]/g, "") // Remove special characters
    .trim() // Remove leading/trailing whitespace
    .replace(/\s+/g, "-"); // Replace spaces with hyphens
  return titleId;
}

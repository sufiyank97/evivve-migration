import React from "react";

export default function LoadMoreButton({ text, onClickFun, disabled }) {
  return (
    <button className="load-more" onClick={onClickFun} disabled={disabled}>
      <span>{text}</span>
    </button>
  );
}

import React from "react";
import Link from "next/link";
import CKEditor from "@/utils/CkEditor";
import { createTitleId } from "./common/createTitleId";

export default function Section4({ data }) {
  return (
    <section className="newsroom-section4" id={createTitleId(data?.title)}>
      <div className="container">
        <div className="newsroom-section4-wrap">
          <div style={{ position: "relative", zIndex: "1" }}>
            <h2 className="newsroom-section4-title">{data?.title}</h2>
            {data?.description && (
              <div className="newsroom-section4-description">
                <CKEditor content={data?.description} />
              </div>
            )}
            {data?.section4_button?.button_text && (
              <Link href={data?.section4_button?.button_link || ""}>
                <a
                  className="newsroom-btn2"
                  target={
                    data?.section4_button?.button_target
                      ? `_${data?.section4_button?.button_target}`
                      : "_blank"
                  }
                >
                  {data?.section4_button?.button_text}
                </a>
              </Link>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

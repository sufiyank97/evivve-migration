import Image from "next/image";
import React, { useContext, useEffect, useState, useCallback } from "react";
import { createTitleId } from "./common/createTitleId";
import { AppContext } from "context/AppContextProvider";

export default function Header({ titles }) {
  const { showStripe, navbarHeight } = useContext(AppContext);
  const [openDropDown, setOpenDropDown] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  const handleScroll = useCallback(() => {
    const threshold = showStripe ? 200 : 150; // Adjust threshold based on showStripe
    const sections = titles?.map((title) =>
      document.getElementById(createTitleId(title))
    );

    let newActiveSection = null;

    sections?.forEach((section) => {
      if (section) {
        const rect = section.getBoundingClientRect();
        if (rect.top <= threshold && rect.top >= 0) {
          newActiveSection = section.id;
        }
      }
    });

    if (newActiveSection && newActiveSection !== activeSection) {
      setActiveSection(newActiveSection);
    }
  }, [titles, activeSection, showStripe]);

  const handleStickyHeader = useCallback(() => {
    const headerElement = document.querySelector(".newsroom-header");
    if (window.scrollY > 170) {
      headerElement?.classList.add("is-sticky");
    } else {
      headerElement?.classList.remove("is-sticky");
    }
  }, []);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    handleScroll(); // Initial check to set the active section
    return () => window.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  useEffect(() => {
    document.addEventListener("scroll", handleStickyHeader);
    return () => document.removeEventListener("scroll", handleStickyHeader);
  }, [handleStickyHeader]);

  const scrollToSection = (id) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
    setOpenDropDown(false); // Close the dropdown
  };

  const renderTitleButtons = (wrapperClass, buttonClass) => (
    <div className={wrapperClass}>
      {titles?.map((item, index) => {
        const id = createTitleId(item);
        return (
          <button
            key={index}
            className={`${buttonClass} ${activeSection === id ? "active" : ""}`}
            onClick={() => scrollToSection(id)}
          >
            {item}
          </button>
        );
      })}
    </div>
  );

  return (
    <>
      <div
        className={`newsroom-header ${
          !showStripe ? "newsroom-header-without-top-stripe" : ""
        }`}
        style={{ top: `${navbarHeight}px` }}
      >
        <div className="container">
          <div className="newsroom-logo">
            <Image
              src={"/images/newsroom/Newsroom.svg"}
              alt="newsroom-logo"
              width={143}
              height={33}
            />
          </div>
          {renderTitleButtons(
            "newsroom-header-titles-wrap",
            "newsroom-header-title-button"
          )}
          <button
            className="newsroom-menu-button"
            onClick={() => setOpenDropDown(!openDropDown)}
          >
            <i
              className="bx bx-dots-vertical-rounded"
              style={{
                transform: openDropDown ? "rotate(-90deg)" : "rotate(0deg)",
                transition: "all 0.2s ease",
              }}
            ></i>
          </button>
        </div>

        {openDropDown && (
          <div className="newsroom-drop-down-overlay">
            <div className="newsroom-drop-down">
              {renderTitleButtons(
                "newsroom-drop-down-titles-wrap",
                "newsroom-drop-down-title-button"
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}

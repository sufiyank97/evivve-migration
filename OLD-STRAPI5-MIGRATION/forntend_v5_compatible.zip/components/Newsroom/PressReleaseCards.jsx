import Link from "next/link";
import React from "react";
import { convertDate } from "./common/convertDate";

export default function PressReleaseCards({ pressReleases }) {
  return (
    <div className="press-release-wrap">
      {pressReleases?.map((item, index) => {
        return (
          <div key={index}>
            <p className="press-release-title">{item?.title}</p>
            <div className="press-release-date-link">
              <p className="press-release-date">
                <i className="bx bx-calendar"></i>{" "}
                {convertDate(item?.date)}
              </p>
              <Link href={`/newsroom/${item?.slug}` || ""}>
                <a className="newsroom-btn press-release-btn">read more</a>
              </Link>
            </div>
          </div>
        );
      })}
    </div>
  );
}

import React from "react";
import styles from "./Events.module.css";
import Link from "next/link";
import moment from "moment";
import CKEditor from "@/utils/CkEditor";

export default function EventDetailsComponent({ eventData }) {
  return (
    <>
      <div className={styles.event_details_img_wrap}>
        <img
          src="https://rewy-gatsby.envytheme.com/static/events-details-057ca01b0bd4cf3c31fe3a2a74f7a859.jpg"
          alt=""
        />
        <div className={styles.event_details_timer}>
          <div>
            -459
            <span>Days</span>
          </div>
          <div>
            14
            <span>Hours</span>
          </div>
          <div>
            12
            <span>Minutes</span>
          </div>
          <div>
            30
            <span>Seconds</span>
          </div>
        </div>
      </div>
      <div className="container">
        <div className={styles.details_wrap}>
          <div className={styles.map_section}>
            <div className={styles.event_details_header}>
              <div>
                <i className="bx bx-calendar"></i>
                {moment(eventData?.Date).format("ddd, D MMM, YYYY")}
              </div>
              <div>
                <i className="bx bx-map"></i>
                {eventData?.location}
              </div>
              <div>
                <i className="bx bx-time"></i>
                {moment(eventData?.Date).format("h:mm A")}
              </div>
            </div>
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.9476519598093!2d-73.99185268459418!3d40.74117737932881!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259a3f81d549f%3A0xb2a39bb5cacc7da0!2s175%205th%20Ave%2C%20New%20York%2C%20NY%2010010%2C%20USA!5e0!3m2!1sen!2sbd!4v1588746137032!5m2!1sen!2sbd"
              title="Map"
              style={{ marginBottom: "40px", width: "100%", height: "400px" }}
            ></iframe>
            <div className={styles.events_details_desc_wrap}>
              {/* <h3>About The Event</h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis
                ipsum suspendisse ultrices gravida. Risus commodo viverra
                maecenas accumsan lacus vel facilisis.
              </p>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis
                ipsum suspendisse ultrices gravida. Risus commodo viverra
                maecenas accumsan lacus vel facilisis.
              </p>
              <h3>Where the event?</h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis
                ipsum suspendisse ultrices gravida. Risus commodo viverra
                maecenas accumsan lacus vel facilisis.
              </p>
              <h3>Who this event is for?</h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis
                ipsum suspendisse ultrices gravida. Risus commodo viverra
                maecenas accumsan lacus vel facilisis.
              </p> */}
              <CKEditor content={eventData?.description} />
            </div>
          </div>
          <div className={styles.booking_details_wrap}>
            <div>
              <ul className={styles.info}>
                <li className={styles.price}>
                  <div>
                    <span>Cost</span>
                    $149
                  </div>
                </li>
                <li>
                  <div>
                    <span>Total Slot</span>
                    1500
                  </div>
                </li>
                <li>
                  <div>
                    <span>Booked Slot</span>
                    350
                  </div>
                </li>
                <li>
                  <div>
                    <span>Pay With</span>
                    <div className={styles.payment_method}>
                      <img
                        src="/images/paypal-card.png"
                        className="shadow"
                        alt="payment-card"
                      />
                      <img
                        src="/images/visa-card.png"
                        className="shadow"
                        alt="payment-card"
                      />
                      <img
                        src="/images/american-express-card.png"
                        className="shadow"
                        alt="payment-card"
                      />
                    </div>
                  </div>
                </li>
              </ul>
              <div className={styles.btn_box_wrap}>
                <button>
                  <i className="bx bx-user"></i>Book Now
                  <span></span>
                </button>
              </div>
              <div className={styles.event_share}>
                <span>
                  Share This Course <i className="bx bx-share-alt"></i>
                </span>
                <ul>
                  <li>
                    <Link href={""}>
                      <div>
                        <i className="bx bxl-facebook"></i>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link href={""}>
                      <div>
                        <i className="bx bxl-twitter"></i>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link href={""}>
                      <div>
                        <i className="bx bxl-instagram"></i>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link href={""}>
                      <div>
                        <i className="bx bxl-linkedin"></i>
                      </div>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.event_speakers_wrap}>
        <div className="container">
          <h2>Event Speakers</h2>
          <div className={styles.speakers}>
            {[...Array(7)].map((_, i) => {
              return (
                <div key={i} className={styles.speaker_wrap}>
                  <div>
                    <div className={styles.speaker_img_wrap}>
                      <img
                        src="https://rewy-gatsby.envytheme.com/static/speaker1-f83ea8aef1080a8af73116f1838ffd7f.jpg"
                        alt=""
                      />
                      <ul>
                        <li>
                          <Link href={""}>
                            <div>
                              <i className="bx bxl-facebook"></i>
                            </div>
                          </Link>
                        </li>
                        <li>
                          <Link href={""}>
                            <div>
                              <i className="bx bxl-twitter"></i>
                            </div>
                          </Link>
                        </li>
                        <li>
                          <Link href={""}>
                            <div>
                              <i className="bx bxl-instagram"></i>
                            </div>
                          </Link>
                        </li>
                        <li>
                          <Link href={""}>
                            <div>
                              <i className="bx bxl-linkedin"></i>
                            </div>
                          </Link>
                        </li>
                      </ul>
                    </div>
                    <div className={styles.speaker_content_wrap}>
                      <h3>Merv Adrian</h3>
                      <span>Data Management</span>
                    </div>
                  </div>
                </div>
              );
            })}
            <div className={styles.message}>
              <div>
                <h3>
                  We will look and sound good! I am still in shock at how smooth
                  this process was. The professionalism, collaboration and the
                  design they come up is great.
                </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.subscribe_section}>
        <div className="container">
          <div className={styles.subscribe_wrap}>
            <div>
              <h2>Get details about upcoming events directly in your inbox!</h2>
            </div>
            <div>
              <div className={styles.subscribe_form}>
                <input
                  type="text"
                  className={styles.subscribe_input}
                  placeholder="Enter your email ID*"
                />
                <button className={styles.subscribe_btn}>subscribe</button>
              </div>
              <p>Please complete this required field.</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

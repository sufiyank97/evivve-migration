import React from "react";
import styles from "./Events.module.css";
import Link from "next/link";
import Image from "next/image";
import moment from "moment";
import { useRouter } from "next/router";
import Pagination from "../Common/Pagination/Pagination";

export default function EventsList({ eventsData, totalPages }) {
  const router = useRouter();
  return (
    <>
      <div className={`container ${styles.events_wrap}`}>
        {eventsData?.map((event, i) => {
          const item = event?.attributes;
          const inputDate = moment(item?.Date);
          return (
            <div
              key={i}
              className={styles.event_item}
              onClick={() => router.push(`/events/${item?.slug}`)}
            >
              <div>
                <div className={styles.img_wrap}>
                  {item?.image?.data && (
                    <Image
                      src={item?.image?.data?.attributes?.url}
                      alt="event-image"
                      width={410}
                      height={273}
                      loading="lazy"
                    />
                  )}
                  <span className={styles.date}>
                    {inputDate.format("ddd, D MMM, YYYY")}
                  </span>
                </div>
                <div className={styles.event_item_content_wrap}>
                  <h3>{item?.title}</h3>
                  <span className={styles.location}>
                    <i className="bx bx-map"></i> {item?.location}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {totalPages && <Pagination totalPages={totalPages} />}
    </>
  );
}

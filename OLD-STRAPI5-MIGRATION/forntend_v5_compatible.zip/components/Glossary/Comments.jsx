import { formattedDate2 } from "@/utils/helper";
import { gql } from "@apollo/client";
import axios from "axios";
import client from "lib/apollo-client/ApolloClient";
import Image from "next/image";
import React, { useEffect, useState } from "react";

export default function Comments({ glossaryData, glossaryId }) {
  const [storedUser, setStoredUser] = useState(null);
  const [selectedReplyId, setSelectedReplyId] = useState(null);
  const [blogComments, setBlogComments] = useState([]);
  const initialData = {
    glossary: glossaryId,
    name: "",
    email: "",
    website: "",
    comment: "",
    parent_comment: null,
  };
  const [formDataArray, setFormDataArray] = useState([
    initialData,
    initialData,
  ]);
  const [buttonLoading, setButtonLoading] = useState(false);

  const handleCommentChange = (index, field, value) => {
    setFormDataArray((prevData) => {
      const newData = [...prevData];
      newData[index] = { ...newData[index], [field]: value };
      return newData;
    });
  };

  const handleReplyClick = (replyId) => {
    if (selectedReplyId) {
      setSelectedReplyId(null);
    } else setSelectedReplyId(replyId);
  };

  // form to post comment
  const PostComment = ({ index, formData, onCommentChange, onSubmit }) => {
    const handleInputChange = (field, value) => {
      onCommentChange(index, field, value);
    };
    const handleFormSubmit = (e) => {
      e.preventDefault();
      onSubmit();
    };
    return (
      <div className="comment-respond">
        <h3 className="comment-reply-title">Leave A Reply</h3>
        <p className="comment-notes">
          <span id="email-notes">
            Your email address will not be published.
          </span>{" "}
          Required fields are marked <span className="required">*</span>
        </p>
        <form className="comment-form" onSubmit={handleFormSubmit}>
          <div className="row">
            <div className="col-lg-6 col-md-6 col-sm-6">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Your Name"
                  required
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                />
              </div>
            </div>
            <div className="col-lg-6 col-md-6 col-sm-6">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Your Email"
                  required
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                />
              </div>
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Website"
                  value={formData.website}
                  onChange={(e) => handleInputChange("website", e.target.value)}
                />
              </div>
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="form-group">
                <textarea
                  className="form-control"
                  cols="30"
                  rows="5"
                  placeholder="Your Comment..."
                  required
                  value={formData.comment}
                  onChange={(e) => handleInputChange("comment", e.target.value)}
                ></textarea>
              </div>
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="checkme"
                  required
                />
                <label className="form-check-label" htmlFor="checkme">
                  Save my name, email, and website in this browser for the next
                  time I comment.
                </label>
              </div>
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12">
              <button
                type="submit"
                className="submit-btn btn1"
                disabled={buttonLoading}
              >
                Post Your Comment
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  };

  // to display comment Recursive approach
  const Comment = ({ key, comment, allComments }) => {
    const replies = allComments.filter(
      (c) =>
        c?.attributes.parent_comment === comment?.id &&
        c?.attributes.parent_comment !== null
    );

    return (
      <li key={key} className="comment">
        <div className="comment-body">
          <footer className="comment-meta">
            <div className="comment-author vcard">
              <div className="avatar">
                <Image
                  src={"/images/profile-img.jpg"}
                  width={80}
                  height={80}
                  alt="user"
                  loading="lazy"
                />
              </div>
              <b className="fn">{comment?.attributes?.name}</b>
            </div>
            <div className="comment-metadata">
              <span>{formattedDate2(comment?.attributes?.createdAt)}</span>
            </div>
          </footer>
          <div className="comment-content">
            <p>{comment?.attributes?.comment}</p>
          </div>
          <div className="reply">
            <a
              className="comment-reply-link"
              onClick={() => handleReplyClick(comment.id)}
            >
              Reply
            </a>
          </div>
          {selectedReplyId === comment.id &&
            PostComment({
              index: 0,
              formData: formDataArray[0],
              onCommentChange: handleCommentChange,
              onSubmit: () => handleSubmit(0),
            })}
        </div>
        {replies.length > 0 && (
          <ol className="children">
            {replies.map((reply, index) =>
              Comment({
                key: index,
                comment: reply,
                allComments: allComments,
              })
            )}
          </ol>
        )}
      </li>
    );
  };

  const CommentSection = ({ comments }) => {
    // Create a copy of comments array to avoid mutating the original array
    const commentsCopy = [...comments];
    // Find the root comments (comments without a parent_comment)
    const rootComments = commentsCopy.filter(
      (comment) => comment?.attributes?.parent_comment === null
    );
    return (
      <ol className="comment-list">
        {rootComments.map((comment, index) =>
          Comment({
            key: index,
            comment: comment,
            allComments: commentsCopy,
          })
        )}
      </ol>
    );
  };

  const handleSubmit = async (index) => {
    const formData = formDataArray[index];
    const user = {
      name: formData?.name,
      email: formData?.email,
      website: formData?.website,
    };
    const areUsersEqual = areObjectsEqual(user, storedUser);
    // console.log("areUsersEqual", areUsersEqual);

    if (!areUsersEqual) {
      // Convert the user object to a JSON string
      const userString = JSON.stringify(user);

      // Store the user string in localStorage
      localStorage.setItem("user", userString);
    }
    // console.log("formData", formData);
    try {
      setButtonLoading(true);
      if (index === 0) {
        formData.parent_comment = selectedReplyId;
      }
      // console.log("formData", formData);
      const res = await axios.post(
        `${process.env.NEXT_PUBLIC_STRAPI_URL}api/glossary-comments`,
        {
          data: formData,
        }
      );
      // console.log("data:", res);
      const initialDataForUser = {
        glossary: glossaryId,
        name: user.name || "",
        email: user.email || "",
        website: user.website || "",
        comment: "",
        parent_comment: null,
      };
      setFormDataArray([initialDataForUser, initialDataForUser]);
      if (index === 0) {
        setSelectedReplyId(null);
      }
      getComments(glossaryData?.slug);
    } catch (error) {
      console.log("error", error);
    } finally {
      setButtonLoading(false);
    }
  };

  const getComments = async (slug) => {
    const { data, errors } = await client.query({
      query: gql`
        query getComments {
          glossaries(
          filters: {
            slug: {
              eq: "${slug}"
            }
          }
          ) {
            data {
              attributes {
                glossary_comments(filters: { approve_by_admin: { eq: true } }) {
                  data {
                    id
                    attributes {
                      name
                      email
                      comment
                      approve_by_admin
                      parent_comment
                      createdAt
                    }
                  }
                }
              }
            }
          }
        }
      `,
    });

    if (errors?.length > 0) {
      return {
        redirect: {
          destination: `/500?url=/${glossaryData?.slug}`,
          permanent: true,
        },
      };
    }

    setBlogComments(
      data?.glossaries?.data?.[0]?.attributes?.glossary_comments?.data || []
    );
  };

  const areObjectsEqual = (obj1, obj2) => {
    const keys1 = obj1 ? Object.keys(obj1) : null;
    const keys2 = obj2 ? Object.keys(obj2) : null;

    if (keys1?.length !== keys2?.length) {
      return false;
    }

    for (const key of keys1) {
      if (obj1[key] !== obj2[key]) {
        return false;
      }
    }

    return true;
  };

  const getUserData = () => {
    // Get user data from localStorage
    const storedUserString = localStorage.getItem("user");

    // Parse the user string back to an object
    const storedUserData = JSON.parse(storedUserString);

    // Check if storedUserData is null or undefined
    if (storedUserData !== null && storedUserData !== undefined) {
      setStoredUser(storedUserData);
      // Create initial data for each form based on the retrieved user data
      const initialDataForUser = {
        glossary: glossaryId,
        name: storedUserData.name || "",
        email: storedUserData.email || "",
        website: storedUserData.website || "",
        comment: "",
        parent_comment: null,
      };

      // Set the initial state of formDataArray
      setFormDataArray([initialDataForUser, initialDataForUser]);
    }
  };

  useEffect(() => {
    getComments(glossaryData?.slug);
    getUserData();
  }, []);

  return (
    <div className="container" style={{ marginBottom: "50px" }}>
      <div className="comments-area green-color">
        {blogComments?.length > 0 && (
          <>
            <h3 className="comments-title">
              {blogComments?.length === 1
                ? `${blogComments?.length} Comment:`
                : `${blogComments?.length} Comments:`}
            </h3>
            {/* Render comments */}
            {CommentSection({ comments: blogComments })}
          </>
        )}

        {PostComment({
          index: 1,
          formData: formDataArray[1],
          onCommentChange: handleCommentChange,
          onSubmit: () => handleSubmit(1),
        })}
      </div>
    </div>
  );
}

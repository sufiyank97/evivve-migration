import { formattedDate } from "@/utils/helper";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import Link from "next/link";
import { useRouter } from "next/router";
import React from "react";
import NextImage from "next/future/image";

export default function RelatedBlogs({ data }) {
  const router = useRouter();
  return (
    <div className="section-9-6" style={{ marginBottom: "70px" }}>
      <h3>Related Post</h3>
      <div className="mt-3 related-posts">
        {data?.map((item, i) => {
          const blog = item?.attributes;
          const image = replaceImageUrl(blog?.image?.data?.attributes?.url);
          return (
            <div
              key={i}
              className="post"
              onClick={() => router.push(`/${blog?.slug}`)}
            >
              <div
                className="post-img-div"
                style={{ borderRadius: "7px", overflow: "hidden" }}
              >
                {blog?.image?.data && (
                  <Link href={blog?.slug || ""}>
                    <a style={{ borderRadius: "7px" }}>
                      <NextImage
                        src={image}
                        alt="blog-details"
                        width={365}
                        height={265}
                        // layout="fill"
                        style={{
                          borderRadius: "7px",
                          width: "100%",
                          height: "100%",
                        }}
                        loading="lazy"
                      />
                    </a>
                  </Link>
                )}
                <div className="post-tag">
                  {blog?.tags?.data?.[0]?.attributes?.title}
                </div>
              </div>
              <div className="post-data">
                <p>
                  <i className="bx bx-time"></i>{" "}
                  {formattedDate(blog?.publish_date || blog?.createdAt)}
                </p>
                <p>
                  <i className="bx bx-comment-dots"></i> (0) Comment
                </p>
              </div>
              <h3>
                <Link href={blog?.slug || ""}>
                  <a>{blog?.title}</a>
                </Link>
              </h3>
            </div>
          );
        })}
      </div>
    </div>
  );
}

import React from "react";

export default function Share({ slug }) {
  const shareUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/${slug}`;
  return (
    <div
      className="tags-parentDiv post-footer"
      style={{ border: "none", paddingTop: "0", marginTop: "0" }}
    >
      <div></div>
      <div className="article-share">
        <ul className="social">
          <li>
            <span>Share:</span>
          </li>
          <li>
            <a
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
                `${shareUrl}`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="facebook"
              aria-label="facebook"
            >
              <i className="bx bxl-facebook"></i>
            </a>
          </li>
          <li>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(
                `${shareUrl}`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="twitter"
              aria-label="twitter"
            >
              <i className="bx bxl-twitter"></i>
            </a>
          </li>
          <li>
            <a
              href={`http://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(
                `${shareUrl}`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="linkedin"
              aria-label="linkedin"
            >
              <i className="bx bxl-linkedin"></i>
            </a>
          </li>
          <li>
            <a
              href="https://www.instagram.com/"
              className="instagram"
              target="_blank"
              rel="noreferrer"
              aria-label="instagram"
            >
              <i className="bx bxl-instagram"></i>
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
}

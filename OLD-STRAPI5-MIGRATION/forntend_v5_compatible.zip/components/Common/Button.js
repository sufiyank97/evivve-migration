import React from "react";

const Button = ({ data }) => {
  return (
    <a
      href={
        data?.buttonLink || data?.button_image_text_button?.button_link || ""
      }
      target={
        data?.button_image_text_button?.button_target === "blank"
          ? "_blank"
          : "_self"
      }
      className={`btn-style-two orange-color2 bttn o-hidden btn1`}
    >
      {data?.buttonText || data?.button_image_text_button?.button_text}
    </a>
  );
};

export default Button;

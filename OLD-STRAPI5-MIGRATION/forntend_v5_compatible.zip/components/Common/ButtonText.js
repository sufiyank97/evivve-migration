import CKEditor from "@/utils/CkEditor";
import React from "react";

export default function ButtonText({ data }) {
  return (
    <div className={`experience-evivve my-4`}>
      <div className="container">
        <div>
          <CKEditor content={data?.description} />
        </div>
        <a
          href={
            data?.button?.buttonLink ||
            data?.button_image_text_button?.button_link ||
            ""
          }
          className="btn1"
          target={data?.button_image_text_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
        >
          {data?.button?.buttonText || data?.button_image_text_button?.button_text}
          <i
            className={
              data?.button_text_button?.button_icon || "bx bx-right-arrow-alt"
            }
          ></i>
        </a>
      </div>
    </div>
  );
}

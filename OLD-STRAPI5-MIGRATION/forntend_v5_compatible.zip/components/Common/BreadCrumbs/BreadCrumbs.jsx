import Link from "next/link";
import React from "react";

export default function BreadCrumbs({ crumbs, currentPage }) {
  return (
    <div className="container" style={{ position: "relative" }}>
      <div className="breadcrumbs">
        <span>
          <Link href={"/"}>
            <a>
              Home
              <i class="bx bx-chevron-right"></i>
            </a>
          </Link>
        </span>
        {crumbs?.map((crumb, i) => {
          return (
            <React.Fragment key={i}>
              <span>
                <Link href={`/${crumb?.link}`}>{crumb?.name}</Link>
                <i class="bx bx-chevron-right"></i>
              </span>
            </React.Fragment>
          );
        })}
        {currentPage && <span className="currentpage">{currentPage}</span>}
      </div>
    </div>
  );
}

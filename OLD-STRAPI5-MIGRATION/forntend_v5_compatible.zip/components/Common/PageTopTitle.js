import Link from "next/link";
import React from "react";

const PageTopTitle = ({
  subTitle,
  title,
  subHeading,
  bgColor,
  button,
  zoho_form_type,
}) => {
  return (
    <div
      className="page-title-area"
      style={bgColor ? { backgroundColor: bgColor } : {}}
    >
      <div className="container">
        <div className="page-title-content">
          {subTitle && <span className="sub-title">{subTitle}</span>}
          <h1>{title}</h1>
          {subHeading && <p className="mt-3">{subHeading}</p>}
          {button?.button_text && zoho_form_type === "button" && (
            <Link
              href={button?.button_link || ""}
              target={button?.button_target === "blank" ? "_blank" : "_self"}
            >
              <a
                target={button?.button_target === "blank" ? "_blank" : "_self"}
                className="btn1 page-top-title-btn"
              >
                {button?.button_text}
              </a>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default PageTopTitle;

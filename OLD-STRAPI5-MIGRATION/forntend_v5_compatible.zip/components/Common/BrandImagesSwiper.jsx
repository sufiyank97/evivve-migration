import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import Image from "next/image";
import { Autoplay } from "swiper";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function BrandImagesSwiper({ data }) {
  return (
    <Swiper
      autoplay={{
        // delay: 2500,
        disableOnInteraction: false,
      }}
      slidesPerView={"auto"}
      spaceBetween={24}
      loop={true}
      modules={[Autoplay]}
      className={"mySwiper home-brands-swiper"}
    >
      {data?.map((brand, i) => {
        return (
          <SwiperSlide key={i}>
            <Image
              src={replaceImageUrl(
                brand?.attributes?.image?.data?.attributes?.url ||
                  brand?.image?.data?.attributes?.url
              )}
              alt=""
              width={131}
              height={31}
              style={{ borderRadius: "0" }}
              loading="lazy"
            />
          </SwiperSlide>
        );
      })}
    </Swiper>
  );
}

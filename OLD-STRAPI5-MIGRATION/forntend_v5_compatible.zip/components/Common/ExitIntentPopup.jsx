import Cookies from "js-cookie";
import React from "react";

export default function ExitIntentPopup({ data, handleCloseExitIntentPopup }) {
  return (
    <div className="exit-intent-modal-wrap">
      <div className="exit-intent-modal hide-scrollbar">
        <div className="exit-intent-modal-content">
          <p className="exit-intent-modal-title">{data?.title}</p>
          <p className="exit-intent-modal-description">{data?.description}</p>
          {(data?.button_text || data?.popup_button?.button_text) && (
            <a
              href={data?.button_link || data?.popup_button?.button_link || ""}
              target={data?.popup_button?.button_target === "blank"
                        ? "_blank"
                        : "_self"}
              className="exit-intent-modal-btn"
            >
              {data?.button_text || data?.popup_button?.button_text}
            </a>
          )}
        </div>
        <div className="exit-intent-modal-img-wrap">
          {data?.image?.data?.attributes?.url && (
            <img
              src={data?.image?.data?.attributes?.url}
              alt="exit-intent-modal-image"
              width={458}
              height={409}
              className="exit-intent-modal-img"
            />
          )}
          <div
            className="exit-intent-modal-close"
            onClick={handleCloseExitIntentPopup}
          >
            <img
              src={"/images/close-white-icon.svg"}
              alt="close-icon"
              width={22}
              height={22}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

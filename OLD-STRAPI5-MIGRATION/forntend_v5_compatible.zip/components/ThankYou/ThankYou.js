import React, { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";

import Seo from "../Common/seo";
import Schema from "../Common/Schema";
import ReactPlayer from "react-player";
import { BsPlayBtnFill } from "react-icons/bs";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import CKEditor from "@/utils/CkEditor";
import { useRouter } from "next/router";

export const ThankYou = ({ thankYouData }) => {
  const mediaUrl = thankYouData?.image?.data?.attributes?.url;
  const [mediaType, setMediaType] = useState("image");
  const [thumbnail, setThumbnail] = useState(null);
  const router = useRouter();
  const [formData, setFormData] = useState({
    email: "",
    firstname: "",
    lastname: "",
  });

  useEffect(() => {
    // Get form data from localStorage
    const storedData = JSON.parse(localStorage.getItem("submitted_user_data"));
    if (storedData) {
      setFormData(storedData);
    }
  }, [router]);

  function getFileExtension(url) {
    const urlParts = url?.split("?")[0]; // Remove query parameters
    const extension = urlParts?.split(".")?.pop()?.toLowerCase(); // Get the extension and make it lowercase

    // Known video extensions
    const videoExtensions = [
      "mp4",
      "webm",
      "ogv",
      "avi",
      "mov",
      "mkv",
      "flv",
      "wmv",
      "m4v",
      "3gp",
      "ts",
      "f4v",
    ];

    return videoExtensions.includes(extension) ? extension : null;
  }

  useEffect(() => {
    const urlType = getFileExtension(mediaUrl);
    if (urlType) {
      generateThumbnail(replaceImageUrl(mediaUrl));
      setMediaType("video");
    }
  }, [mediaUrl]);

  const generateThumbnail = (videoUrl) => {
    const video = document.createElement("video");
    video.src = videoUrl;
    video.crossOrigin = "anonymous"; // If the video is hosted on a different domain
    video.addEventListener("loadeddata", () => {
      video.currentTime = 1; // Set to capture the frame at the 2-second mark (adjust as needed)
    });

    video.addEventListener("seeked", () => {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      setThumbnail(canvas.toDataURL("image/png"));
    });
  };

  const buttonText =
    thankYouData?.buttonText || thankYouData?.thankyou_button?.button_text;
  const buttonIcon =
    thankYouData?.thankyou_button?.button_icon || "bx bx-chevron-right";
  const buttonLink =
    thankYouData?.buttonLink ||
    thankYouData?.thankyou_button?.button_link ||
    "/";
  const buttonTarget =
    thankYouData?.thankyou_button?.button_target === "blank"
      ? "_blank"
      : "_self";

  const handleDownload = async () => {
    try {
      const response = await fetch(thankYouData?.download_link);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");

      // Extract filename from URL, fallback to "download"
      const fileName =
        thankYouData?.download_link.split("/").pop().split("?")[0] ||
        "download";

      link.href = url;
      link.target = "_blank";
      link.download = fileName; // Ensures the correct filename
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Download failed:", error);
    }
  };

  return (
    <>
      <Seo data={thankYouData?.seo} />
      {thankYouData?.schema && <Schema schema={thankYouData?.schema} />}
      <div className="thank-you-area">
        <div
          style={{
            paddingTop: "50px",
          }}
        >
          <div className="">
            <div className="container">
              <div className="thank-you-content">
                <h3>{thankYouData?.heading}</h3>
                {mediaUrl &&
                  (mediaType === "image" ? (
                    <div style={{ margin: "2rem 0" }}>
                      <Image
                        src={mediaUrl}
                        alt="thank-you"
                        width={700}
                        height={400}
                        loading="lazy"
                        style={{ width: "100%" }}
                      />
                    </div>
                  ) : (
                    <div className="s3Video-wrap">
                      <ReactPlayer
                        light={<img src={thumbnail} alt="Thumbnail" />}
                        playing
                        controls
                        playIcon={
                          <BsPlayBtnFill className="s3VideoThumbnail_btn" />
                        }
                        url={replaceImageUrl(mediaUrl)}
                        style={{ margin: "auto", margin: "2rem 0" }}
                      />
                    </div>
                  ))}

                {/* <p style={{marginBottom:"1.5rem"}}>{thankYouData?.description}</p> */}
                <div style={{ marginBottom: "1.5rem" }}>
                  <CKEditor content={thankYouData?.ckeditor_description} />
                </div>
                {buttonText &&
                  (thankYouData?.button_type === "download" &&
                  thankYouData?.download_link ? (
                    <button
                      className="btn1"
                      style={{ margin: "auto" }}
                      onClick={handleDownload}
                    >
                      {buttonText}{" "}
                      <i
                        className="bx bx-download"
                        style={{ marginLeft: "8px" }}
                      ></i>
                    </button>
                  ) : (
                    <a
                      href={
                        router.asPath ===
                        "/welcome-to-stalwart-certification-program/"
                          ? `${buttonLink}?first_name=${formData?.firstname}&last_name=${formData?.lastname}&email=${formData?.email}&`
                          : buttonLink
                      }
                      target={buttonTarget}
                    >
                      <button className="btn1" style={{ margin: "auto" }}>
                        {buttonText} <i className={buttonIcon}></i>
                      </button>
                    </a>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

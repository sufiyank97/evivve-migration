import React, { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

export default function EvidenceBasedStrategy({ data }) {
  const imageContainerRef = useRef(null);
  const [isMobile, setIsMobile] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  // Check if screen is mobile
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth <= 1024);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);

    return () => {
      window.removeEventListener("resize", checkScreenSize);
    };
  }, []);

  // ScrollTrigger animation only for desktop
  useEffect(() => {
    if (isMobile) return; // Don't run animation on mobile

    data?.features.forEach((feature, index) => {
      const featureElement = document.querySelector(
        `.labs-evidence-based-feature:nth-child(${index + 1})`
      );

      if (featureElement) {
        ScrollTrigger.create({
          trigger: featureElement,
          start: "top 80%",
          end: "bottom bottom",
          pin: false,
          onEnter: () => {
            setActiveIndex(index);
          },
          onEnterBack: () => {
            setActiveIndex(index);
          },
        });
      }
    });

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    };
  }, [data?.features, isMobile]);

  // Animate images based on active index
  useEffect(() => {
    if (isMobile) return;

    const images =
      imageContainerRef.current?.querySelectorAll(".stacked-image");
    if (!images) return;

    images.forEach((img, index) => {
      if (index <= activeIndex) {
        // Current and previous images - stack them with active on top
        gsap.to(img, {
          y: 0,
          opacity: 1,
          zIndex: index,
          duration: 0.6,
          ease: "power2.out",
        });
      } else {
        // Future images - hide them below
        gsap.to(img, {
          y: 100,
          opacity: 0,
          zIndex: index,
          duration: 0.6,
          ease: "power2.out",
        });
      }
    });
  }, [activeIndex, isMobile, data?.features.length]);

  return (
    <section className="labs-evidence-based-strategy-container">
      <div className="labs-evidence-based-strategy-wrapper">
        <div className="labs-evidence-based-left-side">
          <div className="labs-evidence-based-heading-section">
            <h2>{data?.title}</h2>
            <CKEditor content={data?.description} />
          </div>
          <div className="labs-evidence-based-features-section">
            {data?.features?.map((feature, index) => (
              <div key={index} className="labs-evidence-based-feature">
                {isMobile ? (
                  <img
                    src={replaceImageUrl(feature?.image?.data?.attributes?.url)}
                    alt={feature?.title}
                    className="labs-evidence-based-feature-image-mobile"
                  />
                ) : (
                  <img
                    src={replaceImageUrl(feature?.icon?.data?.attributes?.url)}
                    alt={feature?.title}
                    className="labs-evidence-based-feature-icon"
                  />
                )}
                <div className="labs-evidence-based-feature-heading">
                  <h4>{feature?.title}</h4>
                  <span className="labs-evidence-based-feature-pill">
                    {feature?.pill}
                  </span>
                </div>
                <CKEditor content={data?.description} />
              </div>
            ))}
          </div>
        </div>

        {!isMobile && (
          <div className="labs-evidence-based-right-side">
            <div
              className="labs-evidence-based-image-container"
              ref={imageContainerRef}
            >
              {data?.features.map((feature, index) => (
                <img
                  key={index}
                  src={replaceImageUrl(feature?.image?.data?.attributes?.url)}
                  alt={`feature image ${index + 1}`}
                  className="stacked-image"
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                    opacity: index === 0 ? 1 : 0,
                    transform:
                      index === 0 ? "translateY(0)" : "translateY(100px)",
                  }}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

import React, { useState, useEffect, useRef } from "react";
import { gsap } from "gsap";
import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";

export default function ModelsAndFrameworkSection({ data }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMobile, setIsMobile] = useState(false);
  const imageRef = useRef(null);

  // Check if screen is mobile
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth <= 1024);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);

    return () => {
      window.removeEventListener("resize", checkScreenSize);
    };
  }, []);

  useEffect(() => {
    if (isMobile) return;

    if (imageRef.current) {
      gsap.fromTo(
        imageRef.current,
        { opacity: 0.4 },
        { opacity: 1, duration: 1, ease: "power3.out" }
      );
    }
  }, [activeIndex, isMobile]);

  useEffect(() => {
    if (isMobile) return; // Don't auto-rotate on mobile

    const timer = setTimeout(() => {
      setActiveIndex((prevIndex) => (prevIndex + 1) % data?.list?.length);
    }, 10000);

    return () => clearTimeout(timer);
  }, [activeIndex, data?.list?.length, isMobile]);

  const activeImage = data?.list[activeIndex]?.image?.data?.attributes?.url;

  return (
    <section className="labs-models-and-frameworks-container">
      <div className="labs-models-frameworks-wrapper">
        <div className="labs-models-frameworks-left-side">
          <div className="labs-models-frameworks-heading-content">
            <h2>{data?.title}</h2>
            <CKEditor content={data?.description} />
          </div>

          <div className="labs-models-frameworks-tabs-container">
            {data?.list?.map((tab, index) => (
              <div
                key={index}
                className={`labs-models-frameworks-tab-content ${
                  !isMobile && activeIndex === index ? "active" : ""
                }`}
                onClick={() => !isMobile && setActiveIndex(index)}
              >
                {isMobile && tab?.image?.data?.attributes?.url && (
                  <div className="labs-models-frameworks-image-container">
                    <img
                      src={replaceImageUrl(tab?.image?.data?.attributes?.url)}
                      alt={tab.title}
                    />
                  </div>
                )}
                <div className="labs-models-frameworks-tab">
                  {tab?.icon?.data?.attributes?.url && (
                    <div className="labs-models-frameworks-tab-img">
                      <img
                        src={replaceImageUrl(tab?.icon?.data?.attributes?.url)}
                        alt={tab.title}
                        style={{
                          opacity: isMobile || activeIndex === index ? 1 : 0.2,
                        }}
                      />
                    </div>
                  )}
                  <div className="labs-models-frameworks-tab-text-content">
                    <h3
                      style={{
                        color:
                          isMobile || activeIndex === index
                            ? "#261B07"
                            : "#8C8C8C",
                      }}
                    >
                      {tab.title}
                    </h3>
                    {(isMobile || activeIndex === index) && (
                      <CKEditor content={data?.description} />
                    )}
                  </div>
                </div>
                {isMobile && index !== data?.list?.length - 1 && (
                  <div className="labs-models-frameworks-static-border"></div>
                )}
                {!isMobile && (
                  <div className="labs-models-frameworks-progress-bar">
                    <div
                      className={`labs-models-frameworks-progress-fill ${
                        activeIndex === index ? "animating" : ""
                      }`}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {!isMobile && activeImage && (
          <div className="labs-models-frameworks-right-side">
            <div className="labs-models-frameworks-image-container">
              <div>
                <img
                  ref={imageRef}
                  key={activeImage}
                  src={replaceImageUrl(activeImage)}
                  alt={data?.list[activeIndex].title}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

import React from "react";
import Seo from "../Common/seo";
import HeroSection from "./HeroSection";
import StatsSection from "./StatsSection";
import ModelsAndFrameworkSection from "./ModelsAndFrameworkSection";
import InsideLabs from "./InsideLabs";
import Neuroscience from "./Neuroscience";
import EvidenceBasedStrategy from "./EvidenceBasedStrategy";
import ScienceBackedApproachSection from "./ScienceBackedApproachSection";
import CardsSection from "./CardsSection";
import Faq from "../NewPricing/Faq";
import CTASection from "./CTASection";

export default function ScienceLab({ labData }) {
  return (
    <>
      <Seo data={labData?.seo} />
      <main className="labs-content-wrap">
        <div style={{ backgroundColor: "#F0EBEF" }}>
          {labData?.hero_section && (
            <HeroSection data={labData?.hero_section} />
          )}
          {labData?.stats_section && (
            <StatsSection data={labData?.stats_section} />
          )}
          {labData?.models_and_frameworks_section && (
            <ModelsAndFrameworkSection
              data={labData?.models_and_frameworks_section}
            />
          )}
          {labData?.inside_labs_section && (
            <InsideLabs data={labData?.inside_labs_section} />
          )}
        </div>
        {labData?.neuro_science && (
          <Neuroscience data={labData?.neuro_science} />
        )}
        {labData?.evidence_based_strategy && (
          <EvidenceBasedStrategy data={labData?.evidence_based_strategy} />
        )}
        {labData?.science_backed_approach && (
          <ScienceBackedApproachSection
            data={labData?.science_backed_approach}
          />
        )}
        {labData?.approach_section && (
          <CardsSection data={labData?.approach_section} />
        )}
        {labData?.faq && (
          <Faq title={labData?.faq?.title} faq={labData?.faq?.faq_list} />
        )}
        {labData?.cta && <CTASection data={labData?.cta} />}
      </main>
    </>
  );
}

import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function HeroSection({ data }) {
  return (
    <div className="labs-hero">
      <div className="labs-hero-section-header"></div>
      <section className="labs-hero-section-container">
        <div className="labs-hero-section-wrap">
          <div className="container">
            <div className="labs-hero-section-wrapper">
              <p className="labs-hero-section-eyebrow">{data?.sub_title}</p>
              <div className="labs-hero-section-title">
                <CKEditor content={data?.title} />
              </div>
              <div className="labs-hero-section-subtitle">
                <CKEditor content={data?.description} />
              </div>
              {data?.labs_hero_section_button?.button_text && (
                <a
                  href={data?.labs_hero_section_button?.button_link || ""}
                  target={
                    data?.labs_hero_section_button?.button_target === "blank"
                      ? "_blank"
                      : "_self"
                  }
                  className="labs-hero-section-btn"
                >
                  <p>
                    <span></span>
                  </p>
                  {data?.labs_hero_section_button?.button_text}
                </a>
              )}
            </div>
          </div>
        </div>
      </section>
      {data?.background_video?.data?.attributes?.url && (
        <div className="labs-hero-section-video-container">
          <video
            src={replaceImageUrl(data?.background_video?.data?.attributes?.url)}
            autoPlay
            loop
            muted
            playsInline
          ></video>
        </div>
      )}
    </div>
  );
}

import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React, { useState, useEffect, useRef } from "react";

export default function CardsSection({ data }) {
  const [currentPage, setCurrentPage] = useState(0);
  const [isMobile, setIsMobile] = useState(false);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef(null);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 767);
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const displayedCards = isMobile ? [data?.cards[currentPage]] : data?.cards;

  const handleDotClick = (index) => {
    setCurrentPage(index);
  };

  // Touch handlers for mobile
  const handleTouchStart = (e) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;

    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe && currentPage < data?.cards.length - 1) {
      setCurrentPage(currentPage + 1);
    }

    if (isRightSwipe && currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }

    // Reset values
    setTouchStart(0);
    setTouchEnd(0);
  };

  // Mouse handlers for trackpad/mouse
  const handleMouseDown = (e) => {
    setIsDragging(true);
    setTouchStart(e.clientX);
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    setTouchEnd(e.clientX);
  };

  const handleMouseUp = () => {
    if (!isDragging) return;
    setIsDragging(false);

    if (!touchStart || !touchEnd) return;

    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe && currentPage < data?.cards.length - 1) {
      setCurrentPage(currentPage + 1);
    }

    if (isRightSwipe && currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }

    // Reset values
    setTouchStart(0);
    setTouchEnd(0);
  };

  const handleMouseLeave = () => {
    if (isDragging) {
      setIsDragging(false);
      setTouchStart(0);
      setTouchEnd(0);
    }
  };

  return (
    <section className="labs-cards-section-container">
      <div className="labs-cards-section-wrapper">
        <div className="container">
          <div className="labs-cards-section-text-container">
            <h1 className="labs-cards-section-title">{data?.title}</h1>
            <div className="labs-cards-section-subtitle">
              <CKEditor content={data?.description} />
            </div>
          </div>
        </div>

        <div
          className="labs-cards-section-cards-container container"
          onTouchStart={isMobile ? handleTouchStart : undefined}
          onTouchMove={isMobile ? handleTouchMove : undefined}
          onTouchEnd={isMobile ? handleTouchEnd : undefined}
          onMouseDown={isMobile ? handleMouseDown : undefined}
          onMouseMove={isMobile ? handleMouseMove : undefined}
          onMouseUp={isMobile ? handleMouseUp : undefined}
          onMouseLeave={isMobile ? handleMouseLeave : undefined}
          ref={containerRef}
          style={{ userSelect: isDragging ? "none" : "auto" }}
        >
          {displayedCards.map((card, index) => {
            const originalIndex = isMobile ? currentPage : index;
            return (
              <div
                key={originalIndex}
                className={`lab-cards-section-card ${
                  card.background_video?.data?.attributes?.url
                    ? "with-video"
                    : ""
                }`}
                style={{ background: card?.background_color || "#686A78" }}
              >
                {card.background_video?.data?.attributes?.url && (
                  <video
                    className="lab-cards-section-card-video"
                    src={replaceImageUrl(
                      card.background_video?.data?.attributes?.url
                    )}
                    autoPlay
                    loop
                    muted
                    playsInline
                  />
                )}

                {card.icon?.data?.attributes?.url && (
                  <img
                    src={replaceImageUrl(card.icon?.data?.attributes?.url)}
                    alt="card icon"
                    className="lab-cards-section-card-icon"
                  />
                )}

                <div className="lab-cards-section-card-content-wrap">
                  <h3
                    className="lab-cards-section-card-title"
                    style={{
                      color: card.background_video?.data?.attributes?.url
                        ? "#FFFFFF"
                        : card?.background_color === "#FFF5FD"
                        ? "#373A36"
                        : "#FFE9FF",
                    }}
                  >
                    {card?.title}
                  </h3>
                  <p
                    className="lab-cards-section-card-content"
                    style={{
                      color: card.background_video?.data?.attributes?.url
                        ? "#FFFFFF"
                        : card?.background_color === "#FFF5FD"
                        ? "#373A36"
                        : "#FFE9FF",
                    }}
                  >
                    {card?.description}
                  </p>
                  <a
                    className="lab-cards-section-card-btn"
                    style={{
                      color: card.background_video?.data?.attributes?.url
                        ? "#FFB7FE"
                        : card?.background_color === "#FFF5FD"
                        ? "#5B105A"
                        : "#FFFFFF",
                    }}
                    href={card?.button_link}
                    target="_blank"
                  >
                    Read More
                    <img
                      src="/images/labs/cards-sections/labs-card-btn-icon.svg"
                      alt="btn-icon"
                      className="default-icon"
                    />
                    <img
                      src="/images/labs/cards-sections/labs-card-btn-icon-hovered.svg"
                      alt="btn-icon-hover"
                      className="hover-icon"
                    />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {isMobile && (
        <div className="labs-cards-section-pagination">
          {data?.cards.map((_, index) => (
            <span
              key={index}
              className={
                currentPage === index
                  ? "labs-cards-section-pagination-active"
                  : "labs-cards-section-pagination-default"
              }
              onClick={() => handleDotClick(index)}
              style={{ cursor: "pointer" }}
            ></span>
          ))}
        </div>
      )}
    </section>
  );
}

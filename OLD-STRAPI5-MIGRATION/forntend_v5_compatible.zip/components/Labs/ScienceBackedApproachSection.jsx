import CKEditor from "@/utils/CkEditor";
import { replaceImageUrl } from "@/utils/replaceImageUrl";
import React from "react";

export default function ScienceBackedApproachSection({ data }) {
  const topCards = data?.cards?.slice(0, 3);
  const statsCards = data?.cards?.slice(3, 8);

  return (
    <section className="labs-science-backed-wrapper">
      <div className="container">
        <div className="labs-science-backed-wrap">
          <div className="labs-science-backed-top-content">
            {topCards?.map((card, index) =>
              card.show_content_or_image === "image" ? (
                <div key={index} className="labs-science-backed-image-card">
                  <img
                    src={replaceImageUrl(card?.image?.data?.attributes?.url)}
                    alt="image"
                  />
                </div>
              ) : (
                <div
                  key={index}
                  className="labs-science-backed-stat-card"
                  style={{ background: card.color }}
                >
                  <h3>{card?.title}</h3>
                  <CKEditor content={card?.description} />
                </div>
              )
            )}
          </div>
          <div className="labs-science-backed-bottom-content">
            <div className="labs-science-backed-text-content">
              <h2>{data?.title}</h2>
              <CKEditor content={data?.description} />
            </div>
            <div className="labs-science-backed-grid-container">
              {statsCards?.map((card, index) =>
                card.show_content_or_image === "image" ? (
                  <div key={index} className="labs-science-backed-image-card">
                    <img
                      src={replaceImageUrl(card?.image?.data?.attributes?.url)}
                      alt="image"
                    />
                  </div>
                ) : (
                  <div
                    key={index}
                    className="labs-science-backed-stat-card"
                    style={{ background: card.color }}
                  >
                    <h3>{card?.title}</h3>
                    <CKEditor content={card?.description} />
                  </div>
                )
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

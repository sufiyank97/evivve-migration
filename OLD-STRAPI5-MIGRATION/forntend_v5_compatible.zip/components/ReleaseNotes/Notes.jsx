import { AppContext } from "context/AppContextProvider";
import Link from "next/link";
import { useRouter } from "next/router";
import React, { useContext } from "react";
import { FaCaretDown } from "react-icons/fa";

export default function Notes({ versions, setShowNotes }) {
  const { navbarHeight } = useContext(AppContext);
  const router = useRouter();

  return (
    <div
      className="release-notes-wrap"
      style={{ top: `${navbarHeight + 20}px` }}
    >
      <h2 className="release-notes-title">
        {router.pathname.includes("/release-notes") ? "Release Notes" : "Topic"}
      </h2>
      <div className="release-notes-buttons-wrap">
        {versions?.map((baseVersion) => {
          const active =
            router.query?.slug === baseVersion?.slug ||
            baseVersion?.sub_versions?.some(
              (item) => item?.slug === router.query?.slug
            );
          const slug = `/${
            router.pathname.includes("/release-notes")
              ? "release-notes"
              : "knowledge-base"
          }/${baseVersion?.slug}`;
          if (active) {
            return (
              <div
                key={baseVersion?.id}
                className={`release-notes-button ${
                  router.pathname.includes("/release-notes")
                    ? "butterscoth-color-release-notes-button"
                    : ""
                } ${active ? "active" : ""}`}
              >
                <Link href={slug}>
                  <p
                    style={{
                      cursor: "pointer",
                      marginBottom:
                        baseVersion?.sub_versions?.length > 0 ? "10px" : "0px",
                    }}
                    onClick={() => setShowNotes && setShowNotes(false)}
                  >
                    {baseVersion?.version}
                    <FaCaretDown
                      style={{
                        rotate: active ? "-180deg" : "0deg",
                        transition: "all 0.3s ease",
                      }}
                    />
                  </p>
                </Link>
                {baseVersion?.sub_versions?.length > 0 && (
                  <div className="release-notes-subversion-buttons">
                    {baseVersion?.sub_versions
                      ?.sort(
                        (a, b) =>
                          new Date(b.created_at) - new Date(a.created_at)
                      )
                      ?.map((subVersion) => {
                        const subActive =
                          router.query?.slug === subVersion?.slug;
                        const subSlug = `/${
                          router.pathname.includes("/release-notes")
                            ? "release-notes"
                            : "knowledge-base"
                        }/${subVersion?.slug}`;
                        return (
                          <Link key={subVersion?.id} href={subSlug}>
                            <a
                              className={`release-notes-subversion-button ${
                                subActive ? "active" : ""
                              }`}
                              onClick={() =>
                                setShowNotes && setShowNotes(false)
                              }
                            >
                              {subVersion?.version}
                            </a>
                          </Link>
                        );
                      })}
                  </div>
                )}
              </div>
            );
          }
          return (
            <Link key={baseVersion?.id} href={slug}>
              <a
                className={`release-notes-button ${active ? "active" : ""}`}
                onClick={() => setShowNotes && setShowNotes(false)}
              >
                {baseVersion?.version}
                <FaCaretDown
                  style={{
                    rotate: active ? "-180deg" : "0deg",
                    transition: "all 0.3s ease",
                  }}
                />
              </a>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

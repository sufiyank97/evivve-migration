import React, { useEffect, useState } from "react";
import Notes from "./Notes";
import CKEditor from "@/utils/CkEditor";
import { useRouter } from "next/router";
import Link from "next/link";
import axios from "axios";
import LoadMoreButton from "../Newsroom/common/LoadMoreButton";

export default function ReleaseNotesDescription({
  description,
  versionsResponse,
  prev,
  next,
  topicsResponse,
  slug,
}) {
  const [topics, setTopics] = useState(topicsResponse);
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setTopics(topicsResponse);
  }, [topicsResponse]);

  const handleLoadMore = async () => {
    try {
      setIsLoading(true);

      const currentPage = topics.meta.pagination.page;

      const res = await axios.get(
        `${
          process.env.NEXT_PUBLIC_STRAPI_URL
        }api/knowledge-base/sub-versions?slug=${slug}&page=${
          currentPage + 1
        }&pageSize=6`
      );

      setTopics((prevTopics) => ({
        data: [...prevTopics.data, ...res.data.data],
        meta: res.data.meta,
      }));
    } catch (error) {
      console.error("Error fetching topics:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="release-notes-page-description-area">
        <Notes versions={versionsResponse} />
        <div className="release-notes-page-description">
          <CKEditor content={description} />

          {topics?.data?.length > 0 && (
            <>
              <h1
                className="release-notes-page-title"
                style={{ marginTop: "70px" }}
              >
                Topics
              </h1>
              <div className="knowledge-base-page-topics-cards">
                {topics?.data?.map((topic, index) => {
                  const base_version = topic?.base_version?.version || "";
                  return (
                    <Link href={`/knowledge-base/${topic?.slug}`} key={index}>
                      <a>
                        <p
                          style={{
                            color: "#5B105A",
                            textTransform: "capitalize",
                            fontWeight: "700",
                            opacity: base_version ? "1" : "0",
                          }}
                        >
                          // {base_version} //
                        </p>
                        <p style={{ color: "black" }}>{topic?.title}</p>
                      </a>
                    </Link>
                  );
                })}
              </div>
              {topics?.meta?.pagination?.hasMore && (
                <div style={{ marginTop: "50px" }}>
                  <LoadMoreButton
                    text={isLoading ? "Loading..." : "Load More"}
                    onClickFun={handleLoadMore}
                    disabled={isLoading}
                  />
                </div>
              )}
            </>
          )}
        </div>
      </div>
      {router.pathname === "/release-notes" ||
      router.pathname === "/knowledge-base" ? (
        <div className="pb-100"></div>
      ) : (
        <div className="release-notes-prev-next-wrap">
          {prev ? (
            <Link href={prev?.slug || ""}>
              <a>
                <img src="/images/release-notes-left-arrow.svg" alt="icon" />
                <p>{prev?.title}</p>
              </a>
            </Link>
          ) : (
            <div></div>
          )}
          {next && (
            <Link href={next?.slug || ""}>
              <a>
                <img src="/images/release-notes-right-arrow.svg" alt="icon" />
                <p>{next?.title}</p>
              </a>
            </Link>
          )}
        </div>
      )}
    </div>
  );
}

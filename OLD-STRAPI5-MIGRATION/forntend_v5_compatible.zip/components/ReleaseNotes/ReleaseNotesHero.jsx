import { AppContext } from "context/AppContextProvider";
import Link from "next/link";
import { useRouter } from "next/router";
import React, { useContext } from "react";

export default function ReleaseNotesHero({
  title,
  search,
  setSearch,
  searchResults,
  setSearchResults,
  onChangeFun,
}) {
  const router = useRouter();
  const { navbarHeight } = useContext(AppContext);
  return (
    <div className="release-notes-page-title-area">
      <div className="container">
        <div className="">
          <h1 className="release-notes-page-title">{title}</h1>
          <div
            className="release-notes-search-wrap"
            style={{ top: `${navbarHeight + 20}px` }}
          >
            <div className="release-notes-search-form-wrap">
              <input
                type="text"
                name="name"
                className="form-control"
                placeholder="Search..."
                value={search}
                autoComplete="off"
                onChange={onChangeFun}
              />
              <div className="release-notes-search-form-icon">
                <i className="bx bx-search" style={{ color: "#ffffff" }}></i>
              </div>
            </div>
            {searchResults.length > 0 && (
              <div className="search-dropdown">
                {searchResults?.map((item, i) => {
                  return (
                    <Link
                      href={`/${
                        router.pathname.includes("/release-notes")
                          ? "release-notes"
                          : "knowledge-base"
                      }/${item?.attributes?.slug}`}
                      key={i}
                    >
                      <a
                        onClick={() => {
                          setSearch("");
                          setSearchResults([]);
                        }}
                      >
                        {item?.attributes?.title}
                      </a>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

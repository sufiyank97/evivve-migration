const path = require("path");
const { BundleAnalyzerPlugin } = require("webpack-bundle-analyzer");

module.exports = {
  plugins: [
    "postcss-flexbugs-fixes",
    [
      "postcss-preset-env",
      {
        autoprefixer: {
          flexbox: "no-2009",
        },
        stage: 3,
        features: {
          "custom-properties": false,
        },
      },
    ],
    [
      "@fullhuman/postcss-purgecss",
      {
        content: [
          "./pages/**/*.{js,jsx,ts,tsx}",
          "./components/**/*.{js,jsx,ts,tsx}",
        ],
        defaultExtractor: (content) => content.match(/[\w-/:]+(?<!:)/g) || [],
        safelist: ["html", "body"],
      },
    ],
  ],
  trailingSlash: true,
  sassOptions: {
    includePaths: [path.join(__dirname, "styles")],
  },
  reactStrictMode: true,
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "evivve-strapi-admin.s3.ap-south-1.amazonaws.com",
      },
    ],
  },
  eslint: {
    // Warning: This allows production builds to successfully complete even if
    // your project has ESLint errors.
    ignoreDuringBuilds: true,
  },
  images: {
    // loader: "akamai",
    // path:
    //   process.env.NODE_ENV === "production"
    //     ? "https://abev-react.envytheme.com"
    //     : "http://localhost:3000",
    domains: [
      "evivve-strapi-admin.s3.ap-south-1.amazonaws.com",
      "d2eebkdj3dhq4s.cloudfront.net",
    ],
  },
  experimental: {
    images: {
      allowFutureImage: true,
    },
  },
  optimizeFonts: false,
  webpack: (config, { dev }) => {
    !dev && config.plugins.push(new BundleAnalyzerPlugin());
    return config;
  },
};

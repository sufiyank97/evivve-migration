export const getSeoData = `seo {
  metaTitle
  metaDescription
  metaImage {
    url
  }
  metaSocial {
    socialNetwork
    title
    description
    image {
      url
    }
  }
  keywords
  metaRobots
  structuredData
  metaViewport
  canonicalURL
}`;

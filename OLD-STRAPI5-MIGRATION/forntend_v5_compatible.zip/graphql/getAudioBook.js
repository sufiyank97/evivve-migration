import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";

export const fetchAudioBookData = async (slug, preview) => {
  const queryString = preview 
    ? `query getAudioBookData {
        audioBooks(publicationState: PREVIEW, filters: { slug: { eq: "${slug}" } }) {
          data {
            id
            attributes {
              title
              slug
              seo {
                metaTitle
                metaDescription
                keywords
                canonicalURL
                metaImage {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              templates {
                ... on ComponentCaseStudyAudiobookSeriesTemplate {
                  hero_section {
                    enabled
                    title
                    category
                    description
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    background_color
                    gradient_overlay
                  }
                  company_overview_section {
                    enabled
                    title
                    company_name
                    industry
                    location
                    description
                  }
                  key_challenges_section {
                    enabled
                    title
                    content
                    image_square {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    image_wide {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                  }
                  solutions_section {
                    enabled
                    title
                    content
                    testimonial {
                      enabled
                      quote
                      author_name
                      author_designation
                      author_image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    additional_content
                    additional_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  solutions_banner {
                    enabled
                    title
                    description
                    button {
                      button_text
                      button_icon
                      button_link
                      button_target
                    }
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    gradient_overlay
                  }
                  impact_section {
                    enabled
                    title
                    description
                    stats {
                      number
                      title
                      description
                      detailed_description
                    }
                  }
                  testimonial_section {
                    enabled
                    quote
                    author_name
                    author_designation
                    author_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  cta_header_section {
                    enabled
                    title
                    description
                    spacing {
                      top
                      bottom
                    }
                  }
                  cta_section {
                    data {
                      attributes {
                        title
                        description_type {
                          ... on ComponentCaseStudyCaseStudyCta {
                            title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            caseStudyBackgroundType: background_type
                            background_image_desktop {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            background_image_mobile {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            background_image {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            gradient_overlay
                            background_color
                            caseStudyTextColor: text_color
                            custom_text_color
                            enabled
                          }
                          ... on ComponentCaseStudyAferrCta {
                            title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            aferrBackgroundType: background_type
                            background_image_desktop {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            background_image_mobile {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            background_image {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            gradient_overlay
                            background_color
                            aferrTextColor: text_color
                            custom_text_color
                            enabled
                          }
                        }
                      }
                    }
                  }
                  references_section {
                    enabled
                    title
                    references {
                      reference_editor
                    }
                  }
                }
              }
            }
          }
        }
      }`
    : `query getAudioBookData {
        audioBooks(filters: { slug: { eq: "${slug}" } }) {
          data {
            id
            attributes {
              title
              slug
              seo {
                metaTitle
                metaDescription
                keywords
                canonicalURL
                metaImage {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              templates {
                ... on ComponentCaseStudyAudiobookSeriesTemplate {
                  hero_section {
                    enabled
                    title
                    category
                    description
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    background_color
                    gradient_overlay
                  }
                  company_overview_section {
                    enabled
                    title
                    company_name
                    industry
                    location
                    description
                  }
                  key_challenges_section {
                    enabled
                    title
                    content
                    image_square {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                    image_wide {
                      data {
                        attributes {
                          url
                          alternativeText
                        }
                      }
                    }
                  }
                  solutions_section {
                    enabled
                    title
                    content
                    testimonial {
                      enabled
                      quote
                      author_name
                      author_designation
                      author_image {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                    additional_content
                    additional_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  solutions_banner {
                    enabled
                    title
                    description
                    button {
                      button_text
                      button_icon
                      button_link
                      button_target
                    }
                    background_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    gradient_overlay
                  }
                  impact_section {
                    enabled
                    title
                    description
                    stats {
                      number
                      title
                      description
                      detailed_description
                    }
                  }
                  testimonial_section {
                    enabled
                    quote
                    author_name
                    author_designation
                    author_image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                  }
                  cta_header_section {
                    enabled
                    title
                    description
                    spacing {
                      top
                      bottom
                    }
                  }
                  cta_section {
                    data {
                      attributes {
                        title
                        description_type {
                          ... on ComponentCaseStudyCaseStudyCta {
                            title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            caseStudyBackgroundType: background_type
                            background_image_desktop {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            background_image_mobile {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            background_image {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            gradient_overlay
                            background_color
                            caseStudyTextColor: text_color
                            custom_text_color
                            enabled
                          }
                          ... on ComponentCaseStudyAferrCta {
                            title
                            description
                            button {
                              button_text
                              button_icon
                              button_link
                              button_target
                            }
                            aferrBackgroundType: background_type
                            background_image_desktop {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            background_image_mobile {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            background_image {
                              data {
                                attributes {
                                  url
                                  alternativeText
                                }
                              }
                            }
                            gradient_overlay
                            background_color
                            aferrTextColor: text_color
                            custom_text_color
                            enabled
                          }
                        }
                      }
                    }
                  }
                  references_section {
                    enabled
                    title
                    references {
                      reference_editor
                    }
                  }
                }
              }
            }
          }
        }
      }`;

  return await client.query({
    query: gql(queryString),
    errorPolicy: 'all'
  });
};

export const fetchAudioBooks = async () => {
  return await client.query({
    query: gql`
      query getAudioBooks {
        audioBooks {
          data {
            id
            attributes {
              title
              slug
              seo {
                metaTitle
                metaDescription
                keywords
                canonicalURL
                metaImage {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
            }
          }
        }
      }
    `,
    errorPolicy: 'all'
  });
};
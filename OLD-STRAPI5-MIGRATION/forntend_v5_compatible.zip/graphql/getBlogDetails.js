import client from "lib/apollo-client/ApolloClient";
import { gql } from "@apollo/client";
import { getSeoData } from "./getSeoData";

export const fetchBlogData = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getBlogData {
  blogs(
    filters: {
      slug: { eq: "${slug}" }
    }
  ) {
    documentId
    title
    slug

    image {
      url
    }

    description_type {
      __typename
      ... on ComponentCommonEditor {
        description
      }
      ... on ComponentButtonButtonImageText {
        image {
          url
        }
        title
        description
        button_image_text_button {
          button_text
          button_icon
          button_link
          button_target
        }
      }
      ... on ComponentButtonButtonText {
        description
        button_text_button {
          button_text
          button_icon
          button_link
          button_target
        }
      }
      ... on ComponentButtonNewsletter {
        description
        form_onload
        form_onsubmit
      }
      ... on ComponentCommonButton {
        button_text
        button_icon
        button_link
        button_target
      }
      ... on ComponentBlogKeyTakeaways {
        title
        description
      }
    }

    ctas {
      description_type {
        __typename
        ... on ComponentCommonButton {
          button_text
          button_icon
          button_link
          button_target
        }
        ... on ComponentButtonButtonImageText {
          image {
            url
          }
          title
          description
          button_image_text_button {
            button_text
            button_icon
            button_link
            button_target
          }
        }
        ... on ComponentButtonButtonText {
          description
          button_text_button {
            button_text
            button_icon
            button_link
            button_target
          }
        }
        ... on ComponentButtonNewsletter {
          description
          form_onload
          form_onsubmit
        }
        ... on ComponentCommonAppDownload {
          sectionTitle
          title
          image {
            url
          }
          playstoreButtonText
          playstoreButtonLink
          applestoreButtonText
          applestoreButtonLink
        }
        ... on ComponentPopupPopup {
          title
          description
          popup_button {
            button_text
            button_icon
            button_link
            button_target
          }
          image {
            url
          }
        }
        ... on ComponentKnowledgeBase3CardsCtas {
          card {
            title
            description
            image {
              url
            }
            link_title
            link_href
            link_target
          }
        }
      }
    }

    createdAt
    publish_date

    categories {
      title
      slug
    }
    tags {
      title
      slug
    }

    author {
      name
      image {
        url
      }
      skill
      location
      slug
      bio
      social_links {
        name
        link
      }
    }
schema
  ${getSeoData}
  }
}
`,
  });
};

export const fetchPopularBlogs = async () => {
  return await client.query({
    query: gql`
      query getPopularBlogs {
        popularBlogs {
          # FIX 1: Simplify nesting for the Single Type 'popularBlogs'
          data {
            attributes {
              # The 'blogs' field is a collection (relation) inside the Single Type.
              blogs {
                # FIX 2: Keep the collection wrapper 'data' for the blogs relation
                data {
                  attributes {
                    title

                    # FIX 3: Keep the standard V5 Media nesting for 'image'
                    image {
                      data {
                        attributes {
                          url
                        }
                      }
                    }
                    slug
                    createdAt
                    publish_date
                  }
                }
              }
            }
          }
        }
      }
    `,
  });
};
export const fetchUseCases = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getUseCases {
        useCases(
          ${preview ? "publicationState:PREVIEW," : ""} 
          filters: { slug: { eq: "${slug}" } }
        ) {
          data { 
            id
            attributes {
              slug
              
              # FIX 1: Component fields (like banner)
              banner {
                title
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                mobile_image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                description
              }
              
              # FIX 2: Repeatable Component field (like benefits_detials)
              benefits {
                title
                benefits_detials {
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  title
                  description
                }
              }
              
              # Dynamic Zone (description) - Adding __typename for safety
              description{
                __typename
                ... on ComponentUseCaseCkeditor{
                  description
                }
                ... on ComponentUseCaseSwiperDescription{
                  swiper{
                    title
                    description
                  }
                }
              }
              
              # FIX 3: Component field (like features)
              features {
                title
                subTitle
                subTitle_highlight
                description
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
              }
              
              # Component fields (ready_section, explore, faq_section)
              ready_section {
                title
                description
                ready_section_button {
                  button_text
                  button_icon
                  button_link
                  button_target
                }
              }
              explore {
                image {
                  data {
                    attributes {
                      url
                    }
                  }
                }
                title
                description
              }
              faq_section {
                title
                faq {
                  question
                  answer
                }
                heading_text
                link_text
                link_url
                link_target
              }
              
              # FIX 4: Another Dynamic Zone (description_type)
              description_type {
                __typename
                ... on ComponentButtonButtonImageText {
                  image {
                    data {
                      attributes {
                        url
                      }
                    }
                  }
                  title
                  description
                  button_image_text_button {
                    button_text
                    button_icon
                    button_link
                    button_target
                  }
                }
                ... on ComponentButtonButtonText {
                  description
                  button_text_button {
                    button_text
                    button_icon
                    button_link
                    button_target
                  }
                }
                ... on ComponentCommonButton {
                  button_text
                  button_icon
                  button_link
                  button_target
                }
                ... on ComponentButtonNewsletter {
                  description
                  form_onload
                  form_onsubmit
                }
              }
              
              # FIX 5: Repeatable Component/Relation (ctas)
              ctas{
                data{
                  attributes{
                    description_type {
                      __typename
                      ... on ComponentButtonButtonImageText {
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                        title
                        description
                        button_image_text_button {
                          button_text
                          button_icon
                          button_link
                          button_target
                        }
                      }
                      ... on ComponentButtonButtonText {
                        description
                        button_text_button {
                          button_text
                          button_icon
                          button_link
                          button_target
                        }
                      }
                      ... on ComponentButtonNewsletter {
                        description
                        form_onload
                        form_onsubmit
                      }
                      ... on ComponentCommonAppDownload {
                        sectionTitle
                        title
                        image {
                          data {
                            attributes {
                              url
                            }
                          }
                        }
                        playstoreButtonText
                        playstoreButtonLink
                        applestoreButtonText
                        applestoreButtonLink
                      }
                      ... on ComponentPopupPopup{
                        title
                        description
                        popup_button {
                          button_text
                          button_icon
                          button_link
                          button_target
                        }
                        image{
                          data{
                            attributes{
                              url
                            }
                          }
                        }
                      }
                      ... on ComponentCommonButton {
                        button_text
                        button_icon
                        button_link
                        button_target
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    `,
  });
};

export const fetchThankYouPages = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getThankYouPages {
        thankYouPages(
          ${preview ? "publicationState:PREVIEW," : ""} 
          filters: { slug: { eq: "${slug}" } }
        ) {
          # FIX 1: Keep the collection wrapper 'data' 
          data { 
            # FIX 2: Keep the attributes wrapper
            attributes {
              heading
              slug
              description
              ckeditor_description
              
              # FIX 3: Standard V5 Media Nesting
              image {
                data {
                  attributes {
                    url
                  }
                }
              }
              
              # Component field (thankyou_button) - structure is usually fine
              thankyou_button {
                button_text
                button_icon
                button_link
                button_target
              }
              button_type
              download_link
              schema
              ${getSeoData}
            }
          }
        }
      }
    `,
  });
};

export const fetchLandingPages = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getLandingPages {
        landingPages(
          ${preview ? "status: DRAFT," : ""}
          filters: { slug: { eq: "${slug}" } }
        ) {
          title
          slug
          ${getSeoData}
          templates {
            ... on ComponentLandingPageMasterclass {
              show_intro_animation
              animations {
                bg_img_1 {
                  url
                }
                bg_img_2 {
                  url
                }
                evivve_logo {
                  url
                }
                fav_logo {
                  url
                }
                e_logo {
                  url
                }
                masterclass_logo {
                  url
                }
                mobile_logo {
                  url
                }
                screen1 {
                  title
                  description
                  button_text
                  image {
                    url
                  }
                }
                screen2 {
                  title
                  description
                  button_text
                  image {
                    url
                  }
                }
                screen3 {
                  title
                  date
                  time
                  button_text
                  video {
                    url
                  }
                  video_thumbnail {
                    url
                  }
                }
                screen4_button_text
              }
              show_custom_navbar
              custom_navbar {
                links
              }
              agenda {
                title
                image {
                  url
                }
                what_you_can_expect_title
                what_you_can_expect_list {
                  list
                }
                time_and_date {
                  title
                  date
                  time
                  image {
                    url
                  }
                }
              }
              industry_experts {
                title
                experts_list {
                  name
                  designation
                  image {
                    url
                  }
                  description
                  linkedin_url
                }
              }
              count {
                count_number
                count_text
              }
              brands {
                title1
                title2
                title_icon
                brands1 {
                  image {
                    url
                  }
                }
                brands2 {
                  image {
                    url
                  }
                }
                brands3 {
                  image {
                    url
                  }
                }
              }
              certifications {
                title
                cards {
                  name
                  description
                  bg_color
                  image {
                    url
                  }
                }
              }
              register {
                title
                register_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                zoho_form_type
                register_form
                form_onload
                form_onsubmit
              }
              faq {
                title
                faq_list {
                  question
                  answer
                }
              }
            }
            ... on ComponentLandingPageTemplate2 {
              show_intro_animation
              animations {
                bg_img_1 {
                  url
                }
                bg_img_2 {
                  url
                }
                evivve_logo {
                  url
                }
                fav_logo {
                  url
                }
                e_logo {
                  url
                }
                masterclass_logo {
                  url
                }
                mobile_logo {
                  url
                }
                screen1 {
                  title
                  description
                  button_text
                  image {
                    url
                  }
                }
                screen2 {
                  title
                  description
                  button_text
                  image {
                    url
                  }
                }
                screen3 {
                  title
                  description
                  button_text
                  video {
                    url
                  }
                  video_thumbnail {
                    url
                  }
                }
                screen4_button_text
              }
              show_custom_navbar
              custom_navbar {
                links
              }
              agenda {
                title
                image {
                  url
                }
                what_you_can_expect_title
                what_you_can_expect_list {
                  list
                }
                time_and_date {
                  title
                  date
                  time
                  template2_date
                  image {
                    url
                  }
                }
              }
              content {
                title
                weeks_session_card {
                  title
                  list
                }
              }
              hosts {
                title
                experts_list {
                  name
                  designation
                  image {
                    url
                  }
                }
              }
              count {
                count_number
                count_text
              }
              brands {
                title1
                title2
                title_icon
                brands1 {
                  image {
                    url
                  }
                }
                brands2 {
                  image {
                    url
                  }
                }
                brands3 {
                  image {
                    url
                  }
                }
              }
              testimonials {
                title
                cards {
                  name
                  description
                  bg_color
                  image {
                    url
                  }
                }
              }
              get_certified_now {
                title
                list
                image {
                  url
                }
              }
              register {
                title
                register_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                zoho_form_type
                register_form
                form_onload
                form_onsubmit
              }
              new_register {
                form
                form_onload
                form_onsubmit
                title
                image {
                  url
                }
                quote
                company_image {
                  url
                }
                name
                designation
                brands_title
                brands {
                  image {
                    url
                  }
                }
              }
              faq {
                title
                faq_list {
                  question
                  answer
                }
              }
            }
            ... on ComponentLandingPageTemplate3 {
              aferr_model {
                title
                description
                aferr_model_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                image {
                  url
                }
              }
              advantages {
                title
                advantages_list {
                  title
                  description
                  image {
                    url
                  }
                }
              }
              preview {
                title
                preview_list
                preview_form
                form_onload
                form_onsubmit
                button_text
                image {
                  url
                }
              }
              dive_deep {
                title
                dive_deep_list {
                  title
                  description
                }
              }
              why_download {
                title
                why_dowload_list {
                  title
                  description
                }
                description
              }
              brands {
                title1
                title2
                title_icon
                brands1 {
                  image {
                    url
                  }
                }
                brands2 {
                  image {
                    url
                  }
                }
                brands3 {
                  image {
                    url
                  }
                }
              }
              faq {
                title
                faq_list {
                  question
                  answer
                }
              }
            }
            ... on ComponentLandingPageTemplate4 {
              form {
                form
                form_onload
                form_onsubmit
              }
              first_section {
                title
                description
                first_section_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                button_type
                image {
                  url
                }
              }
              why_choose {
                title
                description
                first_section_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                button_type
                image {
                  url
                }
              }
              agenda {
                title
                description
                image {
                  url
                }
                upcoming_programs_title
                upcoming_programs {
                  month
                  dates
                  location
                  time
                  show_tagline
                  tagline
                  level
                  button_type
                  upcoming_program_button {
                    button_text
                    button_link
                    button_target
                    button_icon
                  }
                  overwrite_bgcolor
                  bgcolor
                  divider_color
                }
              }
              hosts {
                title
                experts_list {
                  name
                  designation
                  image {
                    documentId
                    url
                  }
                }
              }
              count {
                count_number
                count_text
              }
              brands {
                title
                brands {
                  documentId
                  image {
                    documentId
                    url
                  }
                }
              }
              what_you_get {
                title
                what_you_get_list {
                  icon {
                    url
                  }
                  title
                  description
                  button {
                    button_text
                    button_link
                    button_target
                    button_icon
                  }
                }
              }
              content {
                title
                weeks_session_card {
                  title
                  list
                }
                display
              }
              testimonials {
                title
                cards {
                  name
                  description
                  bg_color
                  image {
                    documentId
                    url
                  }
                }
                display
              }
              get_certified_now {
                title
                list
                image {
                  documentId
                  url
                }
                get_certified_now_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                button_type
                display
              }
              faq {
                title
                faq_list {
                  question
                  answer
                }
                display
              }
              case_stalwart {
                title
                display
                case_study {
                  category
                  study_title
                  image {
                    url
                  }
                  description
                  read_more {
                    button_text
                    button_link
                    button_target
                    button_icon
                  }
                }
              }
              core {
                title
                display
                image {
                  url
                }
                list {
                  description
                }
                core_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              consult_section {
                title
                display
                default_images {
                  url
                }
                active_images {
                  url
                }
                cards {
                  card_title
                  image {
                    url
                  }
                  description
                  sub_title
                  list {
                    data
                  }
                }
              }
            }
            ... on ComponentLandingPageTemplate5 {
              content {
                title
                image {
                  url
                }
                description
                form
                form_onsubmit
                form_onload
                video
                video_description
              }
              pay_offs_section {
                title
                list {
                  title
                  description
                }
              }
              get_started {
                title
                case_study_get_started_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
            }
            ... on ComponentLandingPageLiveSession {
              form {
                title
                form
                form_onload
                form_onsubmit
              }
              Banner {
                title
                description
                images {
                  image {
                    url
                  }
                }
                banner_image {
                  url
                }
                button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                highlighted_title
              }
              brands {
                title
                brands {
                  image {
                    url
                  }
                }
              }
              experience {
                title
                experience_cards {
                  title
                  description
                  icon {
                    url
                  }
                }
              }
              join {
                title
                join_cards {
                  title
                  description
                  icon {
                    url
                  }
                }
              }
              stripe_image {
                url
              }
              adventure {
                title
                description
                image {
                  url
                }
                adventure_cards {
                  title
                  description
                  icon {
                    url
                  }
                }
              }
              join_stripe {
                title
                image {
                  url
                }
                button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              testimonial_section {
                title
                testimonials {
                  title
                  description
                  name
                  designation
                  image {
                    url
                  }
                  linkedin
                }
              }
              faq {
                title
                faq_list {
                  question
                  answer
                }
              }
            }
            ... on ComponentLandingPageAdventure {
              hero_section {
                title
                description
                adventure_hero_section_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
                image {
                  url
                }
                mobile_image {
                  url
                }
              }
              brands {
                title
                brands {
                  image {
                    url
                  }
                }
              }
              experience {
                title
                experience_cards {
                  title
                  description
                  icon {
                    url
                  }
                }
              }
              certified {
                title
                image {
                  url
                }
                cards {
                  title
                  description
                  icon {
                    url
                  }
                }
              }
              pay_offs_section {
                title
                list {
                  title
                  description
                }
              }
              stripe {
                title
                stripe_button {
                  button_text
                  button_link
                  button_target
                  button_icon
                }
              }
              testimonial_section {
                title
                testimonials {
                  title
                  description
                  name
                  designation
                  image {
                    url
                  }
                  linkedin
                }
              }
              faq {
                title
                faq_list {
                  question
                  answer
                }
              }
              form {
                form
                form_onload
                form_onsubmit
              }
            }
          }
        }
      }
    `,
  });
};

export const fetchScienceLabPages = async (slug, preview) => {
  return await client.query({
    query: gql`
      query getScienceLabsPages {
        scienceLabs(
          ${preview ? "status: DRAFT," : ""}
          filters: { slug: { eq: "${slug}" } }
        ) {
          title
          slug
          ${getSeoData}
          hero_section {
            sub_title
            title
            description
            labs_hero_section_button {
              button_text
              button_link
              button_target
              button_icon
            }
            background_video {
              url
            }
          }
          stats_section {
            sub_title
            title
            description
          }
          models_and_frameworks_section {
            title
            description
            list {
              title
              description
              icon {
                url
              }
              image {
                url
              }
            }
          }
          inside_labs_section {
            title
            description
            features {
              title
              description
              icon {
                url
              }
            }
          }
          neuro_science {
            title
            description
            features {
              title
              description
            }
          }
          evidence_based_strategy {
            title
            description
            features {
              icon {
                url
              }
              title
              pill
              image {
                url
              }
              description
            }
          }
          science_backed_approach {
            title
            description
            cards {
              show_content_or_image
              title
              description
              color
              image {
                url
              }
            }
          }
          approach_section {
            title
            description
            cards {
              background_video {
                url
              }
              background_color
              icon {
                url
              }
              title
              description
              button_link
            }
          }
          faq {
            title
            faq_list {
              question
              answer
            }
          }
          cta {
            title
            description
            labs_CTA_button {
              button_text
              button_link
              button_target
              button_icon
            }
            background_video {
              url
            }
          }
        }
      }
    `,
  });
};

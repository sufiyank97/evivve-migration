import { getSeoData } from "./getSeoData";

export const getAboutPage = (preview) => {
  return `
        query getAboutPageData {
  about {
    banner {
      title
    }
    second_section {
      heading
      title
      image {
        url
      }
      description
      description1
      points {
        title
        description
        image {
          url
        }
      }
    }
    vision_and_mission {
      title
      vision_and_mission_list {
        image {
          url
        }
        title
        description
      }
    }
    about_description
    third_section {
      image {
        url
      }
      isImageLeft
      title
      description
    }
    history_section {
      heading
      title
      points {
        title
        description
        image {
          url
        }
        date
        show_date
      }
    }
    member_section {
      heading
      title
      show_section
      description
      members {
        image {
          url
        }
        name
        role
        facebook_link
        instagram_link
        twiter_link
        linkedIn_link
      }
    }
    bottom_section {
      title
      description
      image {
        url
      }
      bottom_button {
        button_text
        button_icon
        button_link
        button_target
      }
    }
      schema
      ${getSeoData}
  }
}

    `;
};

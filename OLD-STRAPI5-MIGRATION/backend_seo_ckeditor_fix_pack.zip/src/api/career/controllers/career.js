'use strict';

/**
 * career controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::career.career');

'use strict';

/**
 * popular-blog service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::popular-blog.popular-blog');

'use strict';

/**
 * new-pricing controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::new-pricing.new-pricing');

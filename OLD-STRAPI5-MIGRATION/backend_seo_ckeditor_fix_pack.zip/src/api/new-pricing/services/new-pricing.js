'use strict';

/**
 * new-pricing service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::new-pricing.new-pricing');

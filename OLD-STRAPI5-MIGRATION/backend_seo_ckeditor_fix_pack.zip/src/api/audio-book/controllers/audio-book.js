'use strict';

/**
 * audio-book controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::audio-book.audio-book');

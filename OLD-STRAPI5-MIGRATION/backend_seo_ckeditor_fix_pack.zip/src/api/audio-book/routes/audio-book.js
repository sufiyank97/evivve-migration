'use strict';

/**
 * audio-book router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::audio-book.audio-book');

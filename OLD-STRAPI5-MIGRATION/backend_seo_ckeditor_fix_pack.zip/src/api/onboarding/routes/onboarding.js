'use strict';

/**
 * onboarding router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::onboarding.onboarding');

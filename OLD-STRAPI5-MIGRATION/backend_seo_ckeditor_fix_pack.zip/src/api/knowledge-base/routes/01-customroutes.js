module.exports = {
  routes: [
    {
      method: "GET",
      path: "/knowledge-base/base-versions",
      handler: "knowledge-base.getReleaseNotesData",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "GET",
      path: "/knowledge-base/sub-versions",
      handler: "knowledge-base.getSubVersions",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "GET",
      path: "/knowledge-base/search",
      handler: "knowledge-base.search",
      config: {
        policies: [],
      },
    },
  ],
};

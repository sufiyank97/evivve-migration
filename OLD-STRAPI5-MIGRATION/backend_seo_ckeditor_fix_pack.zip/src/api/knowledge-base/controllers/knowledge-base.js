"use strict";

/**
 * knowledge-base controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController(
  "api::knowledge-base.knowledge-base",
  ({ strapi }) => ({
    async getReleaseNotesData(ctx) {
      try {
        const baseReleaseNotes = await strapi.db.connection.raw(`
            SELECT rn.*
            FROM knowledge_bases rn
            LEFT JOIN knowledge_bases_base_version_links kbbvl
            ON rn.id = kbbvl.knowledge_base_id
            WHERE kbbvl.id IS NULL
          `);

        const subVersions = await strapi.db.connection.raw(`
            SELECT kbbvl.inv_knowledge_base_id AS base_id, rn.*
            FROM knowledge_bases rn
            JOIN knowledge_bases_base_version_links kbbvl
            ON rn.id = kbbvl.knowledge_base_id
          `);

        const subVersionsByBase = subVersions[0].reduce((acc, item) => {
          if (!acc[item.base_id]) {
            acc[item.base_id] = [];
          }
          acc[item.base_id].push({
            id: item.id,
            title: item.title,
            slug: item.slug,
            version: item.version,
            created_at: item.created_at,
            updated_at: item.updated_at,
            published_at: item.published_at,
          });
          return acc;
        }, {});

        // Combine base release notes with their subversions
        const result = baseReleaseNotes[0].map((baseNote) => ({
          ...baseNote,
          sub_versions: subVersionsByBase[baseNote.id] || [],
        }));

        // Send the combined response
        ctx.send({
          data: result,
        });
      } catch (error) {
        console.error("Error fetching knowledge base data:", error);
        ctx.throw(500, "Failed to fetch knowledge base data");
      }
    },

    async search(ctx) {
      const { searchingText } = ctx.query;

      // Sanitize the search input to prevent SQL injection
      const sanitizedSearchText = searchingText.replace(/'/g, "''");

      const query = `
      SELECT DISTINCT
       knowledge_bases.id,
       knowledge_bases.title,
       knowledge_bases.slug,
       knowledge_bases.description,
       knowledge_bases.version,
       knowledge_bases.published_at
       FROM
       knowledge_bases AS knowledge_bases
       WHERE
       (
      knowledge_bases.title LIKE '%${sanitizedSearchText}%' 
      OR knowledge_bases.description LIKE '%${sanitizedSearchText}%'
      OR knowledge_bases.version LIKE '%${sanitizedSearchText}%'
    )
    AND knowledge_bases.published_at IS NOT NULL;
    `;
      try {
        // Execute the query
        const results = await strapi.db.connection.raw(query);

        // Extract just the rows from the results (first element of the array)
        const rows = results[0];

        // Format the response according to Strapi's structure
        const formattedResponse = {
          data: rows.map((row) => ({
            id: row.id,
            attributes: {
              title: row.title,
              slug: row.slug,
            },
          })),
          meta: {
            pagination: {
              total: rows.length,
            },
          },
        };

        // Return the formatted response
        return formattedResponse;
      } catch (error) {
        console.error("Error executing query:", error);
        ctx.throw(500, {
          error: {
            status: 500,
            name: "Internal Server Error",
            message: "An error occurred while searching knowledge base",
            details: error.message,
          },
        });
      }
    },

    async getSubVersions(ctx) {
      try {
        const { slug, page = 1, pageSize = 6 } = ctx.query;
        const offset = (page - 1) * pageSize;

        if (!slug) {
          return ctx.throw(400, "Slug is required");
        }

        // Get the base knowledge base entry by slug
        const baseKnowledgeBase = await strapi.db.connection.raw(
          `SELECT id FROM knowledge_bases WHERE slug = ? LIMIT 1`,
          [slug]
        );

        if (!baseKnowledgeBase[0].length) {
          return ctx.throw(404, "Base knowledge base not found");
        }

        const baseId = baseKnowledgeBase[0][0].id;

        // Get subversions with pagination
        const subVersions = await strapi.db.connection.raw(
          `SELECT rn.id, rn.title, rn.slug, rn.version,
                  bv.title AS base_title, bv.slug AS base_slug, bv.version AS base_version
           FROM knowledge_bases rn
           JOIN knowledge_bases_base_version_links kbbvl
             ON rn.id = kbbvl.knowledge_base_id
           JOIN knowledge_bases bv
             ON kbbvl.inv_knowledge_base_id = bv.id
           WHERE kbbvl.inv_knowledge_base_id = ?
           LIMIT ? OFFSET ?`,
          [baseId, Number(pageSize), Number(offset)]
        );

        // Get total count for pagination
        const totalCountQuery = await strapi.db.connection.raw(
          `SELECT COUNT(*) AS total FROM knowledge_bases rn
           JOIN knowledge_bases_base_version_links kbbvl
           ON rn.id = kbbvl.knowledge_base_id
           WHERE kbbvl.inv_knowledge_base_id = ?`,
          [baseId]
        );

        const totalCount = Number(totalCountQuery[0][0].total);
        const totalPages = Math.ceil(totalCount / pageSize);
        const hasMore = page < totalPages;

        return ctx.send({
          data: subVersions[0].map((subVersion) => ({
            id: subVersion.id,
            title: subVersion.title,
            slug: subVersion.slug,
            version: subVersion.version,
            base_version: {
              title: subVersion.base_title,
              slug: subVersion.base_slug,
              version: subVersion.base_version,
            },
          })),
          meta: {
            pagination: {
              page: Number(page),
              pageSize: Number(pageSize),
              pageCount: totalPages,
              total: totalCount,
              hasMore,
            },
          },
        });
      } catch (error) {
        console.error("Error fetching subversions:", error);
        ctx.throw(500, "Failed to fetch subversions");
      }
    },
  })
);

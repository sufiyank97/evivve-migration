'use strict';

/**
 * play-now controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::play-now.play-now');

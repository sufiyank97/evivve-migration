'use strict';

/**
 * play-now service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::play-now.play-now');

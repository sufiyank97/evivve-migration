'use strict';

/**
 * blog-page service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::blog-page.blog-page');

'use strict';

/**
 * journal-landing controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::journal-landing.journal-landing');

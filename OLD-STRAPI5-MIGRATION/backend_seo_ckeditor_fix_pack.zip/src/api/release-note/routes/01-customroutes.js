module.exports = {
  routes: [
    {
      method: "GET",
      path: "/release-note/base-versions",
      handler: "release-note.getReleaseNotesData",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "GET",
      path: "/release-note/search",
      handler: "release-note.search",
      config: {
        policies: [],
      },
    },
  ],
};

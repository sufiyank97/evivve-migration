'use strict';

/**
 * testimonial-page controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::testimonial-page.testimonial-page');

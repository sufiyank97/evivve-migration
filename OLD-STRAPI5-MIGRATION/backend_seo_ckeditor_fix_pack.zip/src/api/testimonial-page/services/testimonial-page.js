'use strict';

/**
 * testimonial-page service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::testimonial-page.testimonial-page');

'use strict';

/**
 * audio-book-landing router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::audio-book-landing.audio-book-landing');

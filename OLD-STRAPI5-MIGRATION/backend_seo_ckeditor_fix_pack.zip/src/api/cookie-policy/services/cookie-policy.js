'use strict';

/**
 * cookie-policy service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::cookie-policy.cookie-policy');

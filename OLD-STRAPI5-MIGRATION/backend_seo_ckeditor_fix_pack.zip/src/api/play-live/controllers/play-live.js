'use strict';

/**
 * play-live controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::play-live.play-live');

'use strict';

/**
 * play-live router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::play-live.play-live');

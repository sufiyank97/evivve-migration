"use strict";

/**
 * knowledge-base-page controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController(
  "api::knowledge-base-page.knowledge-base-page",
  ({ strapi }) => ({
    async getKnowledgeBaseTopicsData(ctx) {
      try {
        const { start = 0, limit = 6 } = ctx.query; // Default start is 0 and limit is 6
        const startIndex = parseInt(start);
        const limitValue = parseInt(limit);

        // Adjust query for fetching the required data
        const topics = await strapi.db.connection.raw(`
          SELECT
            link.*,
            kb.title,
            kb.slug,
            kbv.inv_knowledge_base_id,
            inv_kb.version AS inv_version -- Fetch the version from the knowledge_bases table
        FROM
            evivve_2.knowledge_base_pages_knowledge_bases_links link
        JOIN
            evivve_2.knowledge_bases kb
        ON
            link.knowledge_base_id = kb.id
        LEFT JOIN
            evivve_2.knowledge_bases_base_version_links kbv
        ON
            kb.id = kbv.knowledge_base_id
        LEFT JOIN
            evivve_2.knowledge_bases inv_kb -- Joining to fetch version
        ON
            kbv.inv_knowledge_base_id = inv_kb.id
          LIMIT ${limitValue} OFFSET ${startIndex};
        `);

        // Fetch total count of entries for calculating meta data
        const countResult = await strapi.db.connection.raw(`
          SELECT Count (*) as total FROM evivve_2.knowledge_base_pages_knowledge_bases_links;
        `);

        const totalCount = countResult[0][0]?.total || 0;

        // Calculate if there are more entries
        const hasMore = startIndex + limitValue < totalCount;

        // Send response
        ctx.send({
          data: topics[0], // First array contains rows
          meta: {
            start: startIndex,
            limit: limitValue,
            total: totalCount,
            hasMore,
          },
        });
      } catch (error) {
        console.error("Error fetching knowledge base topics data:", error);
        ctx.throw(500, "Failed to fetch knowledge base topics data");
      }
    },
  })
);

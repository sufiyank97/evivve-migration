'use strict';

/**
 * knowledge-base-page service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::knowledge-base-page.knowledge-base-page');

module.exports = {
  routes: [
    {
      method: "GET",
      path: "/use-case/duplicate/:id", // Customize the route path as needed
      handler: "use-case.duplicateEntry", // Matches the controller's duplicate method
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};

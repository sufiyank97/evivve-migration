module.exports = {
  routes: [
    {
      method: "GET",
      path: "/newsroom/pressreleases",
      handler: "newsroom.getPressreleasesData",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "GET",
      path: "/newsroom/media-data",
      handler: "newsroom.getMediaData",
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};

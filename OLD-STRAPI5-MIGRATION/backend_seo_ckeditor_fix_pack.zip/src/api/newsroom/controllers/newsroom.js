"use strict";

/**
 * newsroom controller
 */

const { createCoreController } = require("@strapi/strapi").factories;
const axios = require("axios");

module.exports = createCoreController(
  "api::newsroom.newsroom",
  ({ strapi }) => ({
    async getPressreleasesData(ctx) {
      const { page, pageSize } = ctx?.query;
      try {
        const entry = await strapi.db.connection.raw(
          `SELECT COUNT (*) FROM evivve_2.components_newsroom_section_3_s_press_releases_links
        `
        );

        const graphlQuery = () => {
          return `
            query getNewsroom {
                newsroom {
                    data {
                    attributes {
                        section3 {
                        press_releases(pagination: { page: ${
                          page || 1
                        }, pageSize: ${pageSize || 6} },sort: ["date:desc"]) {
                            data {
                                id
                                attributes {
                                    title
                                    slug
                                    date
                                }
                            }
                        }
                        }
                    }
                    }
                }
            }
        `;
        };

        const url = process.env.STRAPI_URL;
        // const url = `http://localhost:1340/`;

        const graphqlData = await axios.post(`${url}graphql`, {
          query: graphlQuery(),
        });

        const pressReleasesData =
          graphqlData?.data?.data?.newsroom?.data?.attributes?.section3
            ?.press_releases?.data;

        const count = entry[0][0]["COUNT (*)"];

        ctx.send({
          count,
          pressReleasesData,
        });
      } catch (error) {
        console.error("Error fetching newsroom data:", error);
        ctx.throw(500, "Failed to fetch newsroom data");
      }
    },

    async getMediaData(ctx) {
      const { page, pageSize } = ctx?.query;
      try {
        const entry = await strapi.db.connection.raw(
          `SELECT COUNT (*) FROM evivve_2.components_newsroom_media_cards`
        );

        const graphlQuery = () => {
          return `
            query getNewsroomMediaData {
                newsroom {
                    data {
                    attributes {
                        section1 {
                        data(pagination: { page: ${page || 1}, pageSize: ${
            pageSize || 6
          } }) {
                            publisher_name
                            date
                            description
                            image {
                                data {
                                    attributes {
                                    url
                                    }
                                }
                            }
                            media_card_button {
                                button_text
                                button_link
                                button_target
                                button_icon
                            }
                        }
                        }
                    }
                    }
                }
            }
        `;
        };

        const url = process.env.STRAPI_URL;
        // const url = `http://localhost:1340/`;

        const graphqlData = await axios.post(`${url}graphql`, {
          query: graphlQuery(),
        });

        const data =
          graphqlData?.data?.data?.newsroom?.data?.attributes?.section1?.data;

        const count = entry[0][0]["COUNT (*)"];

        ctx.send({
          count,
          data,
        });
      } catch (error) {
        console.error("Error fetching newsroom data:", error);
        ctx.throw(500, "Failed to fetch newsroom data");
      }
    },
  })
);

'use strict';

/**
 * science-lab service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::science-lab.science-lab');

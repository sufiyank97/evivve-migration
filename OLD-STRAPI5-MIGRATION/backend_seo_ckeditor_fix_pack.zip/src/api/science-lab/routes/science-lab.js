'use strict';

/**
 * science-lab router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::science-lab.science-lab');

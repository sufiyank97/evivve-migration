"use strict";

/**
 * blog controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController("api::blog.blog", ({ strapi }) => ({
  async search(ctx) {
    const { searchingText } = ctx.query;

    if (!searchingText) {
      return { data: [], meta: { pagination: { total: 0 } } };
    }

    try {
      const query = `
      SELECT DISTINCT
        blog.id,
        blog.title,
        blog.slug,
        blog.published_at,
        description_type.description
      FROM
        blogs AS blog
      LEFT JOIN
        blogs_components AS bc
        ON blog.id = bc.entity_id
        AND bc.component_type = 'common.editor'
        AND bc.field = 'description_type'
      LEFT JOIN
        components_common_editors AS description_type
        ON bc.component_id = description_type.id
      WHERE
        (
          blog.title LIKE ?
          OR description_type.description LIKE ?
        )
        AND blog.published_at IS NOT NULL;
    `;

      const likePattern = `%${searchingText}%`;

      const results = await strapi.db.connection.raw(query, [
        likePattern,
        likePattern,
      ]);

      const rows = results[0];

      const formattedResponse = {
        data: rows.map((row) => ({
          id: row.id,
          attributes: {
            title: row.title,
            slug: row.slug,
          },
        })),
        meta: {
          pagination: {
            total: rows.length,
          },
        },
      };

      return formattedResponse;
    } catch (error) {
      console.error("Error executing query:", error);
      ctx.throw(500, {
        error: {
          status: 500,
          name: "Internal Server Error",
          message: "An error occurred while searching blogs",
          details: error.message,
        },
      });
    }
  },
}));

// to customize the output
// const response = await strapi
//   .service("api::blog.blog")
//   .find({
//     filters: {
//       user: {
//         // this filter linked user, you also can use createdBy
//         id: ctx.state.user.id,
//       },
//     },
//   })
//   .then((res) => {
//     console.log("res", res);
//     if (res.results.length >= 3) {
//       return "You have added 3 category";
//     }
//   });

// // if not great than 3, then create blog, if true return the message
// const finalRes = response ?? super.create(ctx);

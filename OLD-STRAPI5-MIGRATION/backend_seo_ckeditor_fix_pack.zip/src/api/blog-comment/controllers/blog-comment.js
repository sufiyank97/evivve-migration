'use strict';

/**
 * blog-comment controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::blog-comment.blog-comment');

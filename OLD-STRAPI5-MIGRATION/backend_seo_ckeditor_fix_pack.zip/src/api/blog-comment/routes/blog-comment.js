'use strict';

/**
 * blog-comment router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::blog-comment.blog-comment');

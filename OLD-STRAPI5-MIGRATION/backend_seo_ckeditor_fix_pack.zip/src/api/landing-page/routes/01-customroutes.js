module.exports = {
  routes: [
    {
      method: "GET",
      path: "/landing-page/duplicate/:id", // Customize the route path as needed
      handler: "landing-page.duplicateEntry", // Matches the controller's duplicate method
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};

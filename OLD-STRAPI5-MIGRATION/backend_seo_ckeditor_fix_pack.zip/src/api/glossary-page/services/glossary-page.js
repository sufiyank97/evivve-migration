'use strict';

/**
 * glossary-page service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::glossary-page.glossary-page');

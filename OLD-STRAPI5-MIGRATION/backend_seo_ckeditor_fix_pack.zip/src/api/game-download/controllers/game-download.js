'use strict';

/**
 * game-download controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::game-download.game-download');

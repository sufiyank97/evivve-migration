'use strict';

/**
 * privacy-policy controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::privacy-policy.privacy-policy');

'use strict';

/**
 * new-play-now service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::new-play-now.new-play-now');

"use strict";

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController(
  "api::thank-you-page.thank-you-page",
  ({ strapi }) => ({
    async duplicateEntry(ctx) {
      const paramId = ctx.params.id;

      // Your duplication logic here
      // For example, fetching original entry, creating new entry, etc.
      const originalEntry = await strapi.entityService.findOne(
        "api::thank-you-page.thank-you-page",
        paramId
      );

      if (!originalEntry) {
        return ctx.notFound("Entry not found");
      }

      const { id, createdAt, updatedAt, pubhlishedAt, ...restData } =
        originalEntry;
      // Example duplication logic (adjust fields as needed)
      const newEntryData = {
        ...restData,
        slug: `${restData.slug}-copy`, // Modify slug to be unique
      };

      const duplicatedEntry = await strapi.entityService.create(
        "api::thank-you-page.thank-you-page",
        {
          data: newEntryData,
        }
      );

      ctx.send(duplicatedEntry);
    },
  })
);

module.exports = {
  routes: [
    {
      method: "GET",
      path: "/thank-you-page/duplicate/:id", // Customize the route path as needed
      handler: "thank-you-page.duplicateEntry", // Matches the controller's duplicate method
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};

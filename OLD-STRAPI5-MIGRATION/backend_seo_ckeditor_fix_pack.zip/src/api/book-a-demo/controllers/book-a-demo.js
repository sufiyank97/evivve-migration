'use strict';

/**
 * book-a-demo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::book-a-demo.book-a-demo');

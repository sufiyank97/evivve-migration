'use strict';

/**
 * press-release router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::press-release.press-release');

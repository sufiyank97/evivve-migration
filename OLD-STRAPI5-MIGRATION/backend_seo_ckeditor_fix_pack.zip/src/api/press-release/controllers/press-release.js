'use strict';

/**
 * press-release controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::press-release.press-release');

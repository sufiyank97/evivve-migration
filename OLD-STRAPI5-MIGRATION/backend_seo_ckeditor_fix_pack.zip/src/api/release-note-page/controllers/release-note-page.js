'use strict';

/**
 * release-note-page controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::release-note-page.release-note-page');

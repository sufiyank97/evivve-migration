'use strict';

module.exports = {
  async all(ctx) {
    try {
      const knex = strapi.db.connection;

      const navigations = await knex("navigations");

      const response = [];

      for (const nav of navigations) {
        const navId = nav.id;

        const masterLinks = await knex("navigations_items_master_lnk")
          .where("navigation_id", navId);

        const allItemIds = masterLinks.map(m => m.navigation_item_id);

        const parentLinks = await knex("navigations_items_parent_lnk");

        const childIds = parentLinks.map(p => p.navigation_item_id);

        const rootItemIds = allItemIds.filter(id => !childIds.includes(id));

        const rootItems = [];
        for (const id of rootItemIds) {
          const item = await buildTree(id, knex);
          rootItems.push(item);
        }

        response.push({
          id: nav.id,
          attributes: {
            title: nav.name,
            slug: nav.slug,
            createdAt: nav.created_at,
            updatedAt: nav.updated_at,
            items: { data: rootItems }
          }
        });
      }

      ctx.send({
        data: response,
        meta: {
          total: response.length
        }
      });

    } catch (err) {
      console.error("NAVIGATION ERROR:", err);
      ctx.throw(500, "Failed to load navigation");
    }
  },
};



async function buildTree(itemId, knex) {
  const item = await knex("navigations_items")
    .where("id", itemId)
    .first();

  if (!item) return null;

  const childrenLinks = await knex("navigations_items_parent_lnk")
    .where("inv_navigation_item_id", itemId);

  const children = [];
  for (const link of childrenLinks) {
    const child = await buildTree(link.navigation_item_id, knex);
    if (child) children.push(child);
  }

  return {
    id: item.id,
    attributes: {
      order: item.order,
      title: item.title,
      url: item.path || "",
      target: null,
      createdAt: item.created_at,
      updatedAt: item.updated_at,
      children: {
        data: children
      }
    }
  };
}
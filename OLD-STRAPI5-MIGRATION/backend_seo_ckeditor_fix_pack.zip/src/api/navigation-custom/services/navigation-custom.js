'use strict';
const { createCoreService } = require('@strapi/strapi').factories;
module.exports = createCoreService('api::navigation-custom.navigation-custom');

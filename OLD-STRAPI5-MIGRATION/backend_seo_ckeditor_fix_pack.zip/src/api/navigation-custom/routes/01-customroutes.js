module.exports = {
  routes: [
    {
      method: 'GET',
      path: '/navigation/all',
      handler: 'navigation-custom.all',
      config: {
        policies: [],
        auth: false,
      },
    },
  ],
};






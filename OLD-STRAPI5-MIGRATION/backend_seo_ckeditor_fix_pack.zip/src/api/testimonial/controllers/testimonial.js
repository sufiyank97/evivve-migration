'use strict';

/**
 * testimonial controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::testimonial.testimonial');

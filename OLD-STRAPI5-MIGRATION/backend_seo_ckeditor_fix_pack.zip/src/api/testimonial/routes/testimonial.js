'use strict';

/**
 * testimonial router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::testimonial.testimonial');

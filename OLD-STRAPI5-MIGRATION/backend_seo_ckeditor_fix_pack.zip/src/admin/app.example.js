
import { 
  setPluginConfig,
  defaultHtmlPreset // Use this to get the plugin's built-in "standard" config
} from '@_sh/strapi-plugin-ckeditor';
const config = {
  locales: [
    // 'ar',
    // 'fr',
    // 'cs',
    // 'de',
    // 'dk',
    // 'es',
    // 'he',
    // 'id',
    // 'it',
    // 'ja',
    // 'ko',
    // 'ms',
    // 'nl',
    // 'no',
    // 'pl',
    // 'pt-BR',
    // 'pt',
    // 'ru',
    // 'sk',
    // 'sv',
    // 'th',
    // 'tr',
    // 'uk',
    // 'vi',
    // 'zh-Hans',
    // 'zh',
  ],
  editorConfig: {},
  presets: [
    // 3. Clone or modify the default HTML preset and name it "standard"
    {
      // The name must match the 'preset' option in your schema!
      name: 'standard', 
      
      // Spread the built-in default HTML settings
      ...defaultHtmlPreset, 
      
      // You can override/customize the editorConfig here if needed
      editorConfig: {
        ...defaultHtmlPreset.editorConfig,
        // Example: Add a simple placeholder to the editor
        // placeholder: 'Start writing your content here...',
      }
    },
    // You can add more custom presets here (e.g., 'minimal', 'advanced')
  ],
};

const bootstrap = (app) => {
  console.log(app);
};
export default {
  // 4. Call setPluginConfig inside the register function
  register(app) {
    setPluginConfig(config);
  },

  bootstrap(app) {},
};

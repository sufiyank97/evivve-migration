'use strict';

/* eslint-disable no-unused-vars */
module.exports = (config, webpack) => {
  // Note: we provide webpack above so you should not `require` it
  // Perform customizations to webpack config
  // Important: return the modified config
   // Force all packages to use the root project's installed styled-components
  config.resolve.alias = {
    ...config.resolve.alias,
    'styled-components': path.resolve(__dirname, 'node_modules', 'styled-components'),
  };
  return config;
};

import { 
  setPluginConfig,
  defaultHtmlPreset
} from '@_sh/strapi-plugin-ckeditor';

const config = {
  editorConfig: {}, 
  
  presets: [
    {
      ...defaultHtmlPreset, 
      name: 'standard', 
      editorConfig: {
         ...defaultHtmlPreset.editorConfig,
      }
    },
  ],
  locales: [], 
};

export default {
  register(app) {
    setPluginConfig(config);
  },

  bootstrap(app) {},
};
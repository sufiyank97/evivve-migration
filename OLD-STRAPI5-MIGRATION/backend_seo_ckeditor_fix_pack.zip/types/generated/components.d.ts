import type { Schema, Struct } from '@strapi/strapi';

export interface AboutBottomSection extends Struct.ComponentSchema {
  collectionName: 'components_about_bottom_sections';
  info: {
    description: '';
    displayName: 'bottom section';
  };
  attributes: {
    bottom_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface AboutHistoryPoints extends Struct.ComponentSchema {
  collectionName: 'components_about_history_points';
  info: {
    description: '';
    displayName: 'history points';
  };
  attributes: {
    date: Schema.Attribute.Date;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    show_date: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    title: Schema.Attribute.String;
  };
}

export interface AboutHistorySection extends Struct.ComponentSchema {
  collectionName: 'components_about_history_sections';
  info: {
    displayName: 'history section';
  };
  attributes: {
    heading: Schema.Attribute.String;
    points: Schema.Attribute.Component<'about.history-points', true>;
    title: Schema.Attribute.String;
  };
}

export interface AboutMember extends Struct.ComponentSchema {
  collectionName: 'components_about_members';
  info: {
    displayName: 'member';
  };
  attributes: {
    facebook_link: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    instagram_link: Schema.Attribute.String;
    linkedIn_link: Schema.Attribute.String;
    name: Schema.Attribute.String;
    role: Schema.Attribute.String;
    twiter_link: Schema.Attribute.String;
  };
}

export interface AboutMembersSection extends Struct.ComponentSchema {
  collectionName: 'components_about_members_sections';
  info: {
    description: '';
    displayName: 'Members section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    heading: Schema.Attribute.String;
    members: Schema.Attribute.Component<'about.member', true>;
    show_section: Schema.Attribute.Boolean &
      Schema.Attribute.Required &
      Schema.Attribute.DefaultTo<true>;
    title: Schema.Attribute.String;
  };
}

export interface AboutPoints extends Struct.ComponentSchema {
  collectionName: 'components_about_points';
  info: {
    displayName: 'points';
  };
  attributes: {
    description: Schema.Attribute.Text;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface AboutSecondSection extends Struct.ComponentSchema {
  collectionName: 'components_about_second_sections';
  info: {
    description: '';
    displayName: 'second section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    description1: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    points: Schema.Attribute.Component<'about.points', true>;
    title: Schema.Attribute.String;
  };
}

export interface AboutThirdSection extends Struct.ComponentSchema {
  collectionName: 'components_about_third_sections';
  info: {
    description: '';
    displayName: 'third section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    isImageLeft: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<false>;
    title: Schema.Attribute.String;
  };
}

export interface AboutVisionAndMission extends Struct.ComponentSchema {
  collectionName: 'components_about_vision_and_missions';
  info: {
    displayName: 'vision and mission';
  };
  attributes: {
    title: Schema.Attribute.String;
    vision_and_mission_list: Schema.Attribute.Component<
      'about.vision-and-mission-list',
      true
    >;
  };
}

export interface AboutVisionAndMissionList extends Struct.ComponentSchema {
  collectionName: 'components_about_vision_and_mission_lists';
  info: {
    displayName: 'vision and mission list';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface AdventureCertified extends Struct.ComponentSchema {
  collectionName: 'components_adventure_certifieds';
  info: {
    displayName: 'certified';
  };
  attributes: {
    cards: Schema.Attribute.Component<'live-session.live-card', true>;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface AdventureForm extends Struct.ComponentSchema {
  collectionName: 'components_adventure_form';
  info: {
    displayName: 'adventure form';
  };
  attributes: {
    form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
  };
}

export interface AdventureHeroSection extends Struct.ComponentSchema {
  collectionName: 'components_adventure_hero_sections';
  info: {
    displayName: 'Hero Section';
  };
  attributes: {
    adventure_hero_section_button: Schema.Attribute.Component<
      'common.button',
      false
    >;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    mobile_image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface AdventureStripe extends Struct.ComponentSchema {
  collectionName: 'components_adventure_stripes';
  info: {
    displayName: 'stripe';
  };
  attributes: {
    stripe_button: Schema.Attribute.Component<'common.button', false>;
    title: Schema.Attribute.String;
  };
}

export interface AuthorSocialLink extends Struct.ComponentSchema {
  collectionName: 'components_author_social_links';
  info: {
    description: '';
    displayName: 'Social Link';
  };
  attributes: {
    link: Schema.Attribute.String;
    name: Schema.Attribute.String;
  };
}

export interface BlogBottomSection extends Struct.ComponentSchema {
  collectionName: 'components_blog_bottom_sections';
  info: {
    description: '';
    displayName: 'Bottom section';
  };
  attributes: {
    description: Schema.Attribute.Text;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface BlogFollowUs extends Struct.ComponentSchema {
  collectionName: 'components_blog_follow_uses';
  info: {
    displayName: 'Follow us';
  };
  attributes: {
    link: Schema.Attribute.String;
    name: Schema.Attribute.String;
  };
}

export interface BlogKeyTakeaways extends Struct.ComponentSchema {
  collectionName: 'components_blog_key_takeaways';
  info: {
    displayName: 'Key takeaways';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface ButtonButton extends Struct.ComponentSchema {
  collectionName: 'components_button_buttons';
  info: {
    displayName: 'Button';
  };
  attributes: {
    buttonLink: Schema.Attribute.String;
    buttonText: Schema.Attribute.String;
  };
}

export interface ButtonButtonImageText extends Struct.ComponentSchema {
  collectionName: 'components_button_button_image_texts';
  info: {
    description: '';
    displayName: 'ButtonImageText';
  };
  attributes: {
    button_image_text_button: Schema.Attribute.Component<
      'common.button',
      false
    >;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface ButtonButtonText extends Struct.ComponentSchema {
  collectionName: 'components_button_button_texts';
  info: {
    description: '';
    displayName: 'ButtonText';
  };
  attributes: {
    button_text_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface ButtonNewsletter extends Struct.ComponentSchema {
  collectionName: 'components_button_newsletters';
  info: {
    description: '';
    displayName: 'Newsletter';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
  };
}

export interface CareersBottomSection extends Struct.ComponentSchema {
  collectionName: 'components_careers_bottom_sections';
  info: {
    description: '';
    displayName: 'bottom_section';
  };
  attributes: {
    career_bottom_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface CareersGlassdoorSection extends Struct.ComponentSchema {
  collectionName: 'components_careers_glassdoor_sections';
  info: {
    displayName: 'Glassdoor Section';
  };
  attributes: {
    image: Schema.Attribute.Media<'images'>;
    mobileImage: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface CareersHero extends Struct.ComponentSchema {
  collectionName: 'components_careers_heroes';
  info: {
    description: '';
    displayName: 'Hero';
  };
  attributes: {
    career_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface CareersHeroSection extends Struct.ComponentSchema {
  collectionName: 'components_careers_hero_sections';
  info: {
    description: '';
    displayName: 'Hero Section';
  };
  attributes: {
    button: Schema.Attribute.Component<'button.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface CareersProjectList extends Struct.ComponentSchema {
  collectionName: 'components_careers_project_lists';
  info: {
    displayName: 'Project list';
  };
  attributes: {
    buttonText: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface CareersWhyChooseUs extends Struct.ComponentSchema {
  collectionName: 'components_careers_why_choose_uses';
  info: {
    description: '';
    displayName: 'Why Choose us';
  };
  attributes: {
    description: Schema.Attribute.Text;
    project_list: Schema.Attribute.Component<'careers.project-list', true>;
    sectionTitle: Schema.Attribute.String;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface CareersWhyChooseUsList extends Struct.ComponentSchema {
  collectionName: 'components_careers_why_choose_us_lists';
  info: {
    displayName: 'why choose us list';
  };
  attributes: {
    description: Schema.Attribute.Text;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyAferrCaseStudiesSection
  extends Struct.ComponentSchema {
  collectionName: 'components_cs_case_studies';
  info: {
    description: 'Case studies section matching AferrMaster.jsx CaseStudiesSection component';
    displayName: 'Aferr Case Studies Section';
  };
  attributes: {
    case_study_categories: Schema.Attribute.Component<
      'case-study.case-study-category',
      true
    >;
    description: Schema.Attribute.Text;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyAferrCta extends Struct.ComponentSchema {
  collectionName: 'components_cs_aferr_cta';
  info: {
    description: 'CTA component following case study pattern for Aferr Master templates';
    displayName: 'Aferr CTA';
  };
  attributes: {
    background_color: Schema.Attribute.String;
    background_image: Schema.Attribute.Media<'images'>;
    background_image_desktop: Schema.Attribute.Media<'images'>;
    background_image_mobile: Schema.Attribute.Media<'images'>;
    background_type: Schema.Attribute.Enumeration<
      ['gradient', 'image', 'color']
    > &
      Schema.Attribute.DefaultTo<'gradient'>;
    button: Schema.Attribute.Component<'common.button', false>;
    custom_text_color: Schema.Attribute.String;
    description: Schema.Attribute.Text;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    gradient_overlay: Schema.Attribute.Text;
    text_color: Schema.Attribute.Enumeration<['white', 'black', 'custom']> &
      Schema.Attribute.DefaultTo<'white'>;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface CaseStudyAferrDetailsSection extends Struct.ComponentSchema {
  collectionName: 'components_cs_aferr_details';
  info: {
    description: 'Details section matching AferrMaster.jsx DetailsSection component';
    displayName: 'Aferr Details Section';
  };
  attributes: {
    button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    image: Schema.Attribute.Media<'images'>;
    stats_quadrants: Schema.Attribute.Component<
      'case-study.aferr-stats-quadrant',
      true
    > &
      Schema.Attribute.SetMinMax<
        {
          max: 4;
        },
        number
      >;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyAferrDetailsSection2 extends Struct.ComponentSchema {
  collectionName: 'components_cs_aferr_details_2';
  info: {
    description: 'Second details section without stats quadrants - clean image display';
    displayName: 'Aferr Details Section 2';
  };
  attributes: {
    button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyAferrFinalCta extends Struct.ComponentSchema {
  collectionName: 'components_cs_aferr_final_cta';
  info: {
    description: 'Final CTA section matching AferrMaster.jsx FinalCTASection component';
    displayName: 'Aferr Final CTA';
  };
  attributes: {
    background_image: Schema.Attribute.Media<'images'>;
    background_image_desktop: Schema.Attribute.Media<'images'>;
    background_image_mobile: Schema.Attribute.Media<'images'>;
    button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    gradient_overlay: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyAferrHeroSection extends Struct.ComponentSchema {
  collectionName: 'components_cs_aferr_hero';
  info: {
    description: 'Hero section matching AferrMaster.jsx HeroSection component';
    displayName: 'Aferr Hero Section';
  };
  attributes: {
    background_image: Schema.Attribute.Media<'images'>;
    button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.Text;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    gradient_overlay: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyAferrStatsQuadrant extends Struct.ComponentSchema {
  collectionName: 'components_cs_aferr_stats_quadrant';
  info: {
    description: 'Individual stats quadrant for the details section';
    displayName: 'Stats Quadrant';
  };
  attributes: {
    position: Schema.Attribute.Enumeration<
      ['top-left', 'top-right', 'bottom-left', 'bottom-right']
    > &
      Schema.Attribute.Required;
    stat_description: Schema.Attribute.String & Schema.Attribute.Required;
    stat_value: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface CaseStudyAferrStatsSection extends Struct.ComponentSchema {
  collectionName: 'components_cs_aferr_stats';
  info: {
    description: 'Statistics section matching AferrMaster.jsx StatsSection component';
    displayName: 'Aferr Stats Section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    stats_cards: Schema.Attribute.Component<'case-study.stat-card', true>;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyAferrVideoCarousel extends Struct.ComponentSchema {
  collectionName: 'components_cs_aferr_video';
  info: {
    description: 'Video carousel section matching AferrMaster.jsx VideoCarousel component';
    displayName: 'Aferr Video Carousel';
  };
  attributes: {
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    title: Schema.Attribute.String;
    video_cards: Schema.Attribute.Component<'newsroom.video-card', true>;
  };
}

export interface CaseStudyAudiobookSeriesTemplate
  extends Struct.ComponentSchema {
  collectionName: 'components_cs_audiobook_template';
  info: {
    description: 'Complete AudioBook Series template with all components from CaseStudyDetail.jsx';
    displayName: 'AudioBook Series Template';
  };
  attributes: {
    company_overview_section: Schema.Attribute.Component<
      'case-study.company-overview',
      false
    >;
    cta_header_section: Schema.Attribute.Component<
      'case-study.cta-header-section',
      false
    >;
    cta_section: Schema.Attribute.Relation<'manyToMany', 'api::cta.cta'>;
    hero_section: Schema.Attribute.Component<'case-study.hero-section', false>;
    impact_section: Schema.Attribute.Component<'case-study.impact', false>;
    key_challenges_section: Schema.Attribute.Component<
      'case-study.key-challenges',
      false
    >;
    references_section: Schema.Attribute.Component<
      'case-study.references',
      false
    >;
    solutions_banner: Schema.Attribute.Component<
      'case-study.solutions-banner',
      false
    >;
    solutions_section: Schema.Attribute.Component<
      'case-study.solutions',
      false
    >;
    testimonial_section: Schema.Attribute.Component<
      'case-study.testimonial',
      false
    >;
  };
}

export interface CaseStudyBrands extends Struct.ComponentSchema {
  collectionName: 'components_case_study_brands';
  info: {
    displayName: 'brands';
  };
  attributes: {
    brands: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyCaseStudyCategory extends Struct.ComponentSchema {
  collectionName: 'components_cs_case_study_category';
  info: {
    description: 'Individual case study category with case studies';
    displayName: 'Case Study Category';
  };
  attributes: {
    case_studies: Schema.Attribute.Component<
      'case-study.case-study-item',
      true
    >;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface CaseStudyCaseStudyCta extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_cta';
  info: {
    description: 'CTA component specifically for case study pages';
    displayName: 'Case Study CTA';
  };
  attributes: {
    background_color: Schema.Attribute.String;
    background_image: Schema.Attribute.Media<'images'>;
    background_image_desktop: Schema.Attribute.Media<'images'>;
    background_image_mobile: Schema.Attribute.Media<'images'>;
    background_type: Schema.Attribute.Enumeration<
      ['gradient', 'image', 'color']
    > &
      Schema.Attribute.DefaultTo<'gradient'>;
    button: Schema.Attribute.Component<'common.button', false>;
    custom_text_color: Schema.Attribute.String;
    description: Schema.Attribute.Text;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    gradient_overlay: Schema.Attribute.Text;
    spacing: Schema.Attribute.Component<'common.spacing', false>;
    text_color: Schema.Attribute.Enumeration<['white', 'black', 'custom']> &
      Schema.Attribute.DefaultTo<'white'>;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface CaseStudyCaseStudyItem extends Struct.ComponentSchema {
  collectionName: 'components_cs_case_study_item';
  info: {
    description: 'Individual case study item';
    displayName: 'Case Study Item';
  };
  attributes: {
    button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.Text;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface CaseStudyCaseStudySeriesTemplate
  extends Struct.ComponentSchema {
  collectionName: 'components_cs_case_study_template';
  info: {
    description: 'Template for Case Study Series with all components from CaseStudyDetail.jsx';
    displayName: 'Case Study Series Template';
  };
  attributes: {
    company_overview_section: Schema.Attribute.Component<
      'case-study.company-overview',
      false
    >;
    cta_header_section: Schema.Attribute.Component<
      'case-study.cta-header-section',
      false
    >;
    cta_section: Schema.Attribute.Relation<'manyToMany', 'api::cta.cta'>;
    hero_section: Schema.Attribute.Component<'case-study.hero-section', false>;
    impact_section: Schema.Attribute.Component<'case-study.impact', false>;
    key_challenges_section: Schema.Attribute.Component<
      'case-study.key-challenges',
      false
    >;
    references_section: Schema.Attribute.Component<
      'case-study.references',
      false
    >;
    solutions_banner: Schema.Attribute.Component<
      'case-study.solutions-banner',
      false
    >;
    solutions_section: Schema.Attribute.Component<
      'case-study.solutions',
      false
    >;
    testimonial_section: Schema.Attribute.Component<
      'case-study.testimonial',
      false
    >;
  };
}

export interface CaseStudyCompanyOverview extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_company';
  info: {
    description: 'Company overview section for case study pages with custom icons';
    displayName: 'Company Overview';
  };
  attributes: {
    company_card_enabled: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<true>;
    company_card_icon: Schema.Attribute.Media<'images'>;
    company_card_label: Schema.Attribute.String &
      Schema.Attribute.DefaultTo<'Company'>;
    company_name: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    industry: Schema.Attribute.String;
    industry_card_enabled: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<true>;
    industry_card_icon: Schema.Attribute.Media<'images'>;
    industry_card_label: Schema.Attribute.String &
      Schema.Attribute.DefaultTo<'Industry'>;
    location: Schema.Attribute.String;
    location_card_enabled: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<true>;
    location_card_icon: Schema.Attribute.Media<'images'>;
    location_card_label: Schema.Attribute.String &
      Schema.Attribute.DefaultTo<'Location'>;
    title: Schema.Attribute.String &
      Schema.Attribute.DefaultTo<'COMPANY OVERVIEW'>;
  };
}

export interface CaseStudyCtaHeaderSection extends Struct.ComponentSchema {
  collectionName: 'components_cs_cta_header';
  info: {
    description: 'Header and description section above CTAs';
    displayName: 'CTA Header Section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    spacing: Schema.Attribute.Component<'common.spacing', false>;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyFirstSectionSwiperList
  extends Struct.ComponentSchema {
  collectionName: 'components_case_study_first_section_swiper_lists';
  info: {
    displayName: 'first section swiper list';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
    video: Schema.Attribute.String;
  };
}

export interface CaseStudyGetStarted extends Struct.ComponentSchema {
  collectionName: 'components_case_study_get_starteds';
  info: {
    displayName: 'get started';
  };
  attributes: {
    case_study_get_started_button: Schema.Attribute.Component<
      'common.button',
      false
    >;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyHeroSection extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_hero';
  info: {
    description: 'Hero section for case study pages with background image or solid color support';
    displayName: 'Hero Section';
  };
  attributes: {
    background_color: Schema.Attribute.String & Schema.Attribute.DefaultTo<''>;
    background_image: Schema.Attribute.Media<'images'>;
    category: Schema.Attribute.String &
      Schema.Attribute.DefaultTo<'Success Story'>;
    description: Schema.Attribute.Text;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    gradient_overlay: Schema.Attribute.Text &
      Schema.Attribute.DefaultTo<'linear-gradient(to right, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0.3) 100%)'>;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface CaseStudyImpact extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_impact';
  info: {
    description: 'Impact section with text and statistics for case study pages';
    displayName: 'Impact Section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    spacing: Schema.Attribute.Component<'common.spacing', false>;
    stats: Schema.Attribute.Component<'case-study.impact-stat', true>;
    title: Schema.Attribute.String & Schema.Attribute.DefaultTo<'THE IMPACT'>;
  };
}

export interface CaseStudyImpactStat extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_stat';
  info: {
    description: 'Individual statistic for impact section';
    displayName: 'Impact Stat';
  };
  attributes: {
    description: Schema.Attribute.Text;
    detailed_description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    number: Schema.Attribute.String & Schema.Attribute.Required;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface CaseStudyJournalSeriesTemplate extends Struct.ComponentSchema {
  collectionName: 'components_cs_journal_template';
  info: {
    description: 'Template for Journal Series with all components from CaseStudyDetail.jsx';
    displayName: 'Journal Series Template';
  };
  attributes: {
    company_overview_section: Schema.Attribute.Component<
      'case-study.company-overview',
      false
    >;
    cta_header_section: Schema.Attribute.Component<
      'case-study.cta-header-section',
      false
    >;
    cta_section: Schema.Attribute.Relation<'manyToMany', 'api::cta.cta'>;
    hero_section: Schema.Attribute.Component<'case-study.hero-section', false>;
    impact_section: Schema.Attribute.Component<'case-study.impact', false>;
    key_challenges_section: Schema.Attribute.Component<
      'case-study.key-challenges',
      false
    >;
    references_section: Schema.Attribute.Component<
      'case-study.references',
      false
    >;
    solutions_banner: Schema.Attribute.Component<
      'case-study.solutions-banner',
      false
    >;
    solutions_section: Schema.Attribute.Component<
      'case-study.solutions',
      false
    >;
    testimonial_section: Schema.Attribute.Component<
      'case-study.testimonial',
      false
    >;
  };
}

export interface CaseStudyKeyChallenges extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_challenges';
  info: {
    description: 'Key challenges section for case study pages';
    displayName: 'Key Challenges';
  };
  attributes: {
    content: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    image: Schema.Attribute.Media<'images'>;
    image_square: Schema.Attribute.Media<'images'>;
    image_wide: Schema.Attribute.Media<'images'>;
    spacing: Schema.Attribute.Component<'common.spacing', false>;
    title: Schema.Attribute.String &
      Schema.Attribute.DefaultTo<'KEY CHALLENGES'>;
  };
}

export interface CaseStudyPayOffsList extends Struct.ComponentSchema {
  collectionName: 'components_case_study_pay_offs_lists';
  info: {
    displayName: 'pay offs list';
  };
  attributes: {
    description: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyPayOffsSection extends Struct.ComponentSchema {
  collectionName: 'components_case_study_pay_offs_sections';
  info: {
    displayName: 'pay offs section';
  };
  attributes: {
    list: Schema.Attribute.Component<'case-study.pay-offs-list', true>;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyReferences extends Struct.ComponentSchema {
  collectionName: 'components_cs_references';
  info: {
    description: 'References section for case study pages';
    displayName: 'References';
  };
  attributes: {
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    references: Schema.Attribute.Component<'glossary.reference', true>;
    spacing: Schema.Attribute.Component<'common.spacing', false>;
    title: Schema.Attribute.String & Schema.Attribute.DefaultTo<'References'>;
  };
}

export interface CaseStudyResearchSeriesTemplate
  extends Struct.ComponentSchema {
  collectionName: 'components_cs_research_template';
  info: {
    description: 'Template for Research Series with all components from CaseStudyDetail.jsx';
    displayName: 'Research Series Template';
  };
  attributes: {
    company_overview_section: Schema.Attribute.Component<
      'case-study.company-overview',
      false
    >;
    cta_section: Schema.Attribute.Relation<'manyToOne', 'api::cta.cta'>;
    hero_section: Schema.Attribute.Component<'case-study.hero-section', false>;
    impact_section: Schema.Attribute.Component<'case-study.impact', false>;
    key_challenges_section: Schema.Attribute.Component<
      'case-study.key-challenges',
      false
    >;
    references_section: Schema.Attribute.Component<
      'case-study.references',
      false
    >;
    solutions_banner: Schema.Attribute.Component<
      'case-study.solutions-banner',
      false
    >;
    solutions_section: Schema.Attribute.Component<
      'case-study.solutions',
      false
    >;
    testimonial_section: Schema.Attribute.Component<
      'case-study.testimonial',
      false
    >;
  };
}

export interface CaseStudySolutions extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_solutions';
  info: {
    description: 'Solutions section for case study pages';
    displayName: 'Solutions';
  };
  attributes: {
    additional_content: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    additional_image: Schema.Attribute.Media<'images'>;
    content: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    spacing: Schema.Attribute.Component<'common.spacing', false>;
    testimonial: Schema.Attribute.Component<'case-study.testimonial', false>;
    title: Schema.Attribute.String &
      Schema.Attribute.DefaultTo<'OUR SOLUTIONS'>;
  };
}

export interface CaseStudySolutionsBanner extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_banner';
  info: {
    description: 'Solutions banner section for case study pages';
    displayName: 'Solutions Banner';
  };
  attributes: {
    background_image: Schema.Attribute.Media<'images'>;
    button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.Text;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    gradient_overlay: Schema.Attribute.Text;
    spacing: Schema.Attribute.Component<'common.spacing', false>;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyStatCard extends Struct.ComponentSchema {
  collectionName: 'components_cs_stat_card';
  info: {
    description: 'Individual statistics card';
    displayName: 'Stat Card';
  };
  attributes: {
    stat_description: Schema.Attribute.String & Schema.Attribute.Required;
    stat_value: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface CaseStudyTeamSection extends Struct.ComponentSchema {
  collectionName: 'components_case_study_team_sections';
  info: {
    displayName: 'team section';
  };
  attributes: {
    team_section_list: Schema.Attribute.Component<
      'case-study.team-section-list',
      true
    >;
    title: Schema.Attribute.String;
  };
}

export interface CaseStudyTeamSectionList extends Struct.ComponentSchema {
  collectionName: 'components_case_study_team_section_lists';
  info: {
    displayName: 'team section list';
  };
  attributes: {
    image: Schema.Attribute.Media<'images'>;
    logo: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
    video: Schema.Attribute.String;
  };
}

export interface CaseStudyTestimonial extends Struct.ComponentSchema {
  collectionName: 'components_cs_detail_testimonial';
  info: {
    description: 'Testimonial component for case study pages';
    displayName: 'Testimonial';
  };
  attributes: {
    author_designation: Schema.Attribute.String;
    author_image: Schema.Attribute.Media<'images'>;
    author_name: Schema.Attribute.String;
    enabled: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    quote: Schema.Attribute.Text & Schema.Attribute.Required;
    spacing: Schema.Attribute.Component<'common.spacing', false>;
  };
}

export interface CaseStudyTestimonials extends Struct.ComponentSchema {
  collectionName: 'components_case_study_testimonials';
  info: {
    displayName: 'testimonials';
  };
  attributes: {
    testimonials: Schema.Attribute.Relation<
      'oneToMany',
      'api::testimonial.testimonial'
    >;
    title: Schema.Attribute.String;
  };
}

export interface CommonAppDownload extends Struct.ComponentSchema {
  collectionName: 'components_common_app_downloads';
  info: {
    description: '';
    displayName: 'app download';
  };
  attributes: {
    applestoreButtonLink: Schema.Attribute.Text;
    applestoreButtonText: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    playstoreButtonLink: Schema.Attribute.Text;
    playstoreButtonText: Schema.Attribute.String;
    sectionTitle: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface CommonBanner extends Struct.ComponentSchema {
  collectionName: 'components_contact_banners';
  info: {
    description: '';
    displayName: 'Banner';
  };
  attributes: {
    title: Schema.Attribute.String;
  };
}

export interface CommonButton extends Struct.ComponentSchema {
  collectionName: 'components_common_buttons';
  info: {
    description: '';
    displayName: 'Button';
  };
  attributes: {
    button_icon: Schema.Attribute.String;
    button_link: Schema.Attribute.String;
    button_target: Schema.Attribute.Enumeration<['_self', '_blank']> &
      Schema.Attribute.DefaultTo<'_self'>;
    button_text: Schema.Attribute.String;
  };
}

export interface CommonDownloadApp extends Struct.ComponentSchema {
  collectionName: 'components_common_download_apps';
  info: {
    description: '';
    displayName: 'Download app';
  };
  attributes: {
    android: Schema.Attribute.Media<'images'>;
    android_link: Schema.Attribute.String;
    ios: Schema.Attribute.Media<'images'>;
    ios_link: Schema.Attribute.String;
  };
}

export interface CommonEditor extends Struct.ComponentSchema {
  collectionName: 'components_common_editors';
  info: {
    displayName: 'Editor';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface CommonFooter extends Struct.ComponentSchema {
  collectionName: 'components_common_footers';
  info: {
    description: '';
    displayName: 'footer';
  };
  attributes: {
    copyright: Schema.Attribute.String;
    footer_description: Schema.Attribute.Text;
    logo: Schema.Attribute.Media<'images'>;
  };
}

export interface CommonFormField extends Struct.ComponentSchema {
  collectionName: 'components_common_form_fields';
  info: {
    displayName: 'formField';
  };
  attributes: {
    placeholder: Schema.Attribute.String;
    type: Schema.Attribute.Enumeration<['text', 'email', 'number', 'textarea']>;
  };
}

export interface CommonSocialMedia extends Struct.ComponentSchema {
  collectionName: 'components_common_social_medias';
  info: {
    displayName: 'Social media';
  };
  attributes: {
    link: Schema.Attribute.String;
    name: Schema.Attribute.String;
  };
}

export interface CommonSpacing extends Struct.ComponentSchema {
  collectionName: 'components_common_spacings';
  info: {
    description: 'Component for controlling section spacing';
    displayName: 'Spacing';
  };
  attributes: {
    bottom: Schema.Attribute.String & Schema.Attribute.DefaultTo<'80px'>;
    top: Schema.Attribute.String & Schema.Attribute.DefaultTo<'80px'>;
  };
}

export interface CommonThankYou extends Struct.ComponentSchema {
  collectionName: 'components_common_thank_yous';
  info: {
    description: '';
    displayName: 'Thank you';
  };
  attributes: {
    description: Schema.Attribute.Text;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
  };
}

export interface CommonTopStickyStripe extends Struct.ComponentSchema {
  collectionName: 'components_common_top_sticky_stripes';
  info: {
    description: '';
    displayName: 'Top Sticky Stripe';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    top_sticky_stripe_button: Schema.Attribute.Component<
      'common.button',
      false
    >;
    visible: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
  };
}

export interface CommonZohoForm extends Struct.ComponentSchema {
  collectionName: 'components_common_zoho_forms';
  info: {
    displayName: 'zoho_form';
  };
  attributes: {
    onload_function: Schema.Attribute.Text;
    onsubmit_function: Schema.Attribute.Text;
    zoho_form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    zoho_form_button: Schema.Attribute.Component<'common.button', false>;
    zoho_form_type: Schema.Attribute.Enumeration<['button', 'form']> &
      Schema.Attribute.DefaultTo<'button'>;
  };
}

export interface ContactSecondSection extends Struct.ComponentSchema {
  collectionName: 'components_contact_second_sections';
  info: {
    displayName: 'second section';
  };
  attributes: {
    description: Schema.Attribute.Text;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface GameDownloadAppDownload extends Struct.ComponentSchema {
  collectionName: 'components_game_download_app_downloads';
  info: {
    description: '';
    displayName: 'app download';
  };
  attributes: {
    applestoreButtonLink: Schema.Attribute.Text;
    applestoreButtonText: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    playstoreButtonLink: Schema.Attribute.Text;
    playstoreButtonText: Schema.Attribute.String;
    sectionTitle: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface GameDownloadAppDownloadButtons extends Struct.ComponentSchema {
  collectionName: 'components_game_download_app_download_buttons';
  info: {
    displayName: 'app download buttons';
  };
  attributes: {
    buttonLink: Schema.Attribute.Text;
    buttonText: Schema.Attribute.String;
  };
}

export interface GameDownloadFeatureList extends Struct.ComponentSchema {
  collectionName: 'components_game_download_feature_lists';
  info: {
    description: '';
    displayName: 'feature list';
  };
  attributes: {
    description: Schema.Attribute.Text;
    icon: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface GameDownloadFeatures extends Struct.ComponentSchema {
  collectionName: 'components_game_download_features';
  info: {
    displayName: 'features';
  };
  attributes: {
    featureList: Schema.Attribute.Component<'game-download.feature-list', true>;
    title: Schema.Attribute.String;
  };
}

export interface GameDownloadMinimalDashboard extends Struct.ComponentSchema {
  collectionName: 'components_game_download_minimal_dashboards';
  info: {
    displayName: 'minimal-dashboard';
  };
  attributes: {
    appDownloadButtons: Schema.Attribute.Component<
      'game-download.app-download-buttons',
      true
    >;
    image1: Schema.Attribute.Media<'images'>;
    image2: Schema.Attribute.Media<'images'>;
    overviewList: Schema.Attribute.Component<
      'game-download.overview-list',
      true
    >;
    sectionTitle: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface GameDownloadOverviewList extends Struct.ComponentSchema {
  collectionName: 'components_game_download_overview_lists';
  info: {
    displayName: 'overview-list';
  };
  attributes: {
    overviewPoint: Schema.Attribute.String;
  };
}

export interface GameBanner extends Struct.ComponentSchema {
  collectionName: 'components_game_banners';
  info: {
    description: '';
    displayName: 'Banner';
  };
  attributes: {
    subHeading: Schema.Attribute.Text;
    title: Schema.Attribute.String;
  };
}

export interface GameBrand extends Struct.ComponentSchema {
  collectionName: 'components_game_brands';
  info: {
    displayName: 'Brand';
  };
  attributes: {
    image: Schema.Attribute.Media<'images'>;
  };
}

export interface GameBrandSection extends Struct.ComponentSchema {
  collectionName: 'components_game_brand_sections';
  info: {
    description: '';
    displayName: 'Brand Section';
  };
  attributes: {
    brands: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands2: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands3: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    title: Schema.Attribute.String;
    title_icon: Schema.Attribute.String;
    title2: Schema.Attribute.String;
  };
}

export interface GameButton extends Struct.ComponentSchema {
  collectionName: 'components_game_buttons';
  info: {
    displayName: 'Button';
  };
  attributes: {
    link: Schema.Attribute.String;
    text: Schema.Attribute.String;
  };
}

export interface GameDownloadApp extends Struct.ComponentSchema {
  collectionName: 'components_game_download_apps';
  info: {
    description: '';
    displayName: 'Download App';
  };
  attributes: {
    applestoreButtonLink: Schema.Attribute.String;
    applestoreButtonText: Schema.Attribute.String;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    playstoreButtonLink: Schema.Attribute.String;
    playstoreButtonText: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface GameFacilitatorsLoveAboutEvivve
  extends Struct.ComponentSchema {
  collectionName: 'components_game_facilitators_love_about_evivves';
  info: {
    displayName: 'Facilitators love about Evivve';
  };
  attributes: {
    title: Schema.Attribute.String;
  };
}

export interface GamePlayCategory extends Struct.ComponentSchema {
  collectionName: 'components_game_play_categories';
  info: {
    description: '';
    displayName: 'Play Category';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    game_button: Schema.Attribute.Component<'common.button', false>;
    heading: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface GameTestimonial extends Struct.ComponentSchema {
  collectionName: 'components_game_testimonials';
  info: {
    description: '';
    displayName: 'Testimonial';
  };
  attributes: {
    testimonials: Schema.Attribute.Relation<
      'oneToMany',
      'api::testimonial.testimonial'
    >;
    title_icon: Schema.Attribute.String;
    title1: Schema.Attribute.String;
    title2: Schema.Attribute.String;
  };
}

export interface GlossaryDarkEditor extends Struct.ComponentSchema {
  collectionName: 'components_glossary_dark_editors';
  info: {
    displayName: 'dark_editor';
  };
  attributes: {
    dark_editor: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface GlossaryLightEditor extends Struct.ComponentSchema {
  collectionName: 'components_glossary_light_editors';
  info: {
    description: '';
    displayName: 'light_editor';
  };
  attributes: {
    light_editor: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface GlossaryReference extends Struct.ComponentSchema {
  collectionName: 'components_glossary_references';
  info: {
    displayName: 'reference';
  };
  attributes: {
    reference_editor: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface HomeBrand extends Struct.ComponentSchema {
  collectionName: 'components_home_brands';
  info: {
    description: '';
    displayName: 'Brand';
  };
  attributes: {
    client_logos: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    client_logos2: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    client_logos3: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    title_icon: Schema.Attribute.String;
    title1: Schema.Attribute.String;
    title2: Schema.Attribute.String;
  };
}

export interface HomeButton extends Struct.ComponentSchema {
  collectionName: 'components_home_buttons';
  info: {
    displayName: 'button';
  };
  attributes: {
    button_link: Schema.Attribute.String;
    button_text: Schema.Attribute.String;
  };
}

export interface HomeCommunity extends Struct.ComponentSchema {
  collectionName: 'components_home_communities';
  info: {
    description: '';
    displayName: 'Community';
  };
  attributes: {
    community_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    points: Schema.Attribute.Component<'home.community-points', true>;
    title: Schema.Attribute.String;
  };
}

export interface HomeCommunityPoints extends Struct.ComponentSchema {
  collectionName: 'components_home_community_points';
  info: {
    displayName: 'Community Points';
  };
  attributes: {
    icon: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface HomeEarning extends Struct.ComponentSchema {
  collectionName: 'components_home_earnings';
  info: {
    description: '';
    displayName: 'Earning';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    earning_button: Schema.Attribute.Component<'common.button', false>;
    title: Schema.Attribute.String;
  };
}

export interface HomeGetStarted extends Struct.ComponentSchema {
  collectionName: 'components_home_get_starteds';
  info: {
    displayName: 'Get Started';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    get_started_button: Schema.Attribute.Component<'common.button', false>;
    title: Schema.Attribute.String;
  };
}

export interface HomeHowItWorks extends Struct.ComponentSchema {
  collectionName: 'components_home_how_it_works';
  info: {
    displayName: 'How It Works';
  };
  attributes: {
    title: Schema.Attribute.String;
  };
}

export interface HomeHowItWorksStep extends Struct.ComponentSchema {
  collectionName: 'components_home_how_it_works_steps';
  info: {
    description: '';
    displayName: 'How It Works Step';
  };
  attributes: {
    description1: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    description2: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    how_it_work_buttons: Schema.Attribute.Component<'common.button', true>;
    image: Schema.Attribute.Media<'images'>;
    points: Schema.Attribute.Component<'home.how-it-works-step-points', true>;
    step_info: Schema.Attribute.String;
    textanimate: Schema.Attribute.Component<
      'home.how-it-works-step-animate-text',
      true
    >;
    title: Schema.Attribute.String;
    tooltip_text: Schema.Attribute.Text;
  };
}

export interface HomeHowItWorksStepAnimateText extends Struct.ComponentSchema {
  collectionName: 'components_home_how_it_works_step_animate_texts';
  info: {
    displayName: 'How It Works Step Animate Text';
  };
  attributes: {
    text: Schema.Attribute.String;
  };
}

export interface HomeHowItWorksStepPoints extends Struct.ComponentSchema {
  collectionName: 'components_home_how_it_works_step_points';
  info: {
    displayName: 'How It Works Step Points';
  };
  attributes: {
    icon: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface HomeTestimonial extends Struct.ComponentSchema {
  collectionName: 'components_home_testimonials';
  info: {
    displayName: 'Testimonial';
  };
  attributes: {
    testimonials: Schema.Attribute.Relation<
      'oneToMany',
      'api::testimonial.testimonial'
    >;
    title: Schema.Attribute.String;
  };
}

export interface HomeTopSection extends Struct.ComponentSchema {
  collectionName: 'components_home_top_sections';
  info: {
    description: '';
    displayName: 'Top section';
  };
  attributes: {
    background_image: Schema.Attribute.Media<'images'>;
    bg_video: Schema.Attribute.Media<'videos'>;
    button1_link: Schema.Attribute.String;
    button1_text: Schema.Attribute.String;
    button2_text: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    mobile_background_image: Schema.Attribute.Media<'images'>;
    show_video_or_image: Schema.Attribute.Enumeration<['video', 'image']> &
      Schema.Attribute.DefaultTo<'image'>;
    title: Schema.Attribute.String;
    videoUrl: Schema.Attribute.String;
  };
}

export interface KnowledgeBase3CardCtaItem extends Struct.ComponentSchema {
  collectionName: 'components_knowledge_base_3_card_cta_items';
  info: {
    description: '';
    displayName: '3 Card Cta Item';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    link_href: Schema.Attribute.Text;
    link_target: Schema.Attribute.Enumeration<['_blank', '_self']>;
    link_title: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface KnowledgeBase3CardsCtas extends Struct.ComponentSchema {
  collectionName: 'components_knowledge_base_3_cards_ctas';
  info: {
    description: '';
    displayName: '3 Cards Ctas';
  };
  attributes: {
    card: Schema.Attribute.Component<'knowledge-base.3-card-cta-item', true> &
      Schema.Attribute.SetMinMax<
        {
          max: 3;
          min: 1;
        },
        number
      >;
  };
}

export interface KnowledgeBaseFeaturedFaq extends Struct.ComponentSchema {
  collectionName: 'components_knowledge_base_featured_faqs';
  info: {
    displayName: 'Featured FAQ';
  };
  attributes: {
    faq: Schema.Attribute.Component<'knowledge-base.featured-faq-item', true>;
    title: Schema.Attribute.String;
  };
}

export interface KnowledgeBaseFeaturedFaqItem extends Struct.ComponentSchema {
  collectionName: 'components_knowledge_base_featured_faq_items';
  info: {
    displayName: 'Featured FAQ Item';
  };
  attributes: {
    answer: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    question: Schema.Attribute.Text;
  };
}

export interface KnowledgeBaseTopics extends Struct.ComponentSchema {
  collectionName: 'components_topics';
  info: {
    description: '';
    displayName: 'Knowledge Base Topics';
  };
  attributes: {
    knowledge_bases: Schema.Attribute.Relation<
      'oneToMany',
      'api::knowledge-base.knowledge-base'
    >;
    title: Schema.Attribute.String;
  };
}

export interface LabsApproachCards extends Struct.ComponentSchema {
  collectionName: 'components_labs_approach_cards';
  info: {
    description: '';
    displayName: 'Approach Cards';
  };
  attributes: {
    background_color: Schema.Attribute.Text;
    background_video: Schema.Attribute.Media<'videos'>;
    button_link: Schema.Attribute.String;
    description: Schema.Attribute.String;
    icon: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface LabsApproachSection extends Struct.ComponentSchema {
  collectionName: 'components_labs_approach_sections';
  info: {
    displayName: 'Approach Section';
  };
  attributes: {
    cards: Schema.Attribute.Component<'labs.approach-cards', true>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface LabsCta extends Struct.ComponentSchema {
  collectionName: 'components_labs_ctas';
  info: {
    displayName: 'CTA';
  };
  attributes: {
    background_video: Schema.Attribute.Media<'videos'>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    labs_CTA_button: Schema.Attribute.Component<'common.button', false>;
    title: Schema.Attribute.String;
  };
}

export interface LabsEvidenceBasedStrategy extends Struct.ComponentSchema {
  collectionName: 'components_labs_evidence_based_strategies';
  info: {
    displayName: 'Evidence Based Strategy';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    features: Schema.Attribute.Component<
      'labs.evidence-based-strategy-features',
      true
    >;
    title: Schema.Attribute.String;
  };
}

export interface LabsEvidenceBasedStrategyFeatures
  extends Struct.ComponentSchema {
  collectionName: 'components_labs_evidence_based_strategy_features';
  info: {
    displayName: 'Evidence Based Strategy Features';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    icon: Schema.Attribute.Media<'images'>;
    image: Schema.Attribute.Media<'images'>;
    pill: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface LabsFaq extends Struct.ComponentSchema {
  collectionName: 'components_labs_faqs';
  info: {
    displayName: 'FAQ';
  };
  attributes: {
    faq_list: Schema.Attribute.Component<'labs.faq-list', true>;
    title: Schema.Attribute.String;
  };
}

export interface LabsFaqList extends Struct.ComponentSchema {
  collectionName: 'components_labs_faq_lists';
  info: {
    displayName: 'faq_list';
  };
  attributes: {
    answer: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    question: Schema.Attribute.String;
  };
}

export interface LabsHeroSection extends Struct.ComponentSchema {
  collectionName: 'components_labs_hero_sections';
  info: {
    displayName: 'Hero Section';
  };
  attributes: {
    background_video: Schema.Attribute.Media<'videos'>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    labs_hero_section_button: Schema.Attribute.Component<
      'common.button',
      false
    >;
    sub_title: Schema.Attribute.String;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface LabsInsideLabsFeatures extends Struct.ComponentSchema {
  collectionName: 'components_labs_inside_labs_features';
  info: {
    displayName: 'Inside Labs Features';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    icon: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface LabsInsideLabsSection extends Struct.ComponentSchema {
  collectionName: 'components_labs_inside_labs_sections';
  info: {
    displayName: 'Inside Labs Section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    features: Schema.Attribute.Component<'labs.inside-labs-features', true>;
    title: Schema.Attribute.String;
  };
}

export interface LabsModelsAndFrameworksList extends Struct.ComponentSchema {
  collectionName: 'components_labs_m_f_lists';
  info: {
    displayName: 'Models and Frameworks List';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    icon: Schema.Attribute.Media<'images'>;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface LabsModelsAndFrameworksSection extends Struct.ComponentSchema {
  collectionName: 'components_labs_m_f_sections';
  info: {
    displayName: 'Models and Frameworks Section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    list: Schema.Attribute.Component<'labs.models-and-frameworks-list', true>;
    title: Schema.Attribute.String;
  };
}

export interface LabsNeuroScience extends Struct.ComponentSchema {
  collectionName: 'components_labs_neuro_sciences';
  info: {
    displayName: 'Neuro Science';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    features: Schema.Attribute.Component<'labs.neuro-scince-features', true>;
    title: Schema.Attribute.String;
  };
}

export interface LabsNeuroScinceFeatures extends Struct.ComponentSchema {
  collectionName: 'components_labs_neuro_scince_features';
  info: {
    displayName: 'Neuro Scince Features';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface LabsScienceBackedApproach extends Struct.ComponentSchema {
  collectionName: 'components_labs_science_backed_approaches';
  info: {
    displayName: 'Science Backed Approach';
  };
  attributes: {
    cards: Schema.Attribute.Component<
      'labs.science-backed-approach-cards',
      true
    > &
      Schema.Attribute.SetMinMax<
        {
          max: 8;
          min: 8;
        },
        number
      >;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface LabsScienceBackedApproachCards extends Struct.ComponentSchema {
  collectionName: 'components_labs_science_backed_approach_cards';
  info: {
    displayName: 'Science Backed Approach Cards';
  };
  attributes: {
    color: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    show_content_or_image: Schema.Attribute.Enumeration<['content', 'image']> &
      Schema.Attribute.DefaultTo<'content'>;
    title: Schema.Attribute.String;
  };
}

export interface LabsStatsSection extends Struct.ComponentSchema {
  collectionName: 'components_labs_stats_sections';
  info: {
    displayName: 'Stats Section';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    sub_title: Schema.Attribute.String;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface LandingPageAdventure extends Struct.ComponentSchema {
  collectionName: 'components_landing_page_adventures';
  info: {
    displayName: 'Adventure';
  };
  attributes: {
    brands: Schema.Attribute.Component<'masterclass.template-4-brands', false>;
    certified: Schema.Attribute.Component<'adventure.certified', false>;
    experience: Schema.Attribute.Component<
      'live-session.experience-section',
      false
    >;
    faq: Schema.Attribute.Component<'masterclass.faq', false>;
    form: Schema.Attribute.Component<'adventure.form', false>;
    hero_section: Schema.Attribute.Component<'adventure.hero-section', false>;
    pay_offs_section: Schema.Attribute.Component<
      'case-study.pay-offs-section',
      false
    >;
    stripe: Schema.Attribute.Component<'adventure.stripe', false>;
    testimonial_section: Schema.Attribute.Component<'home.testimonial', false>;
  };
}

export interface LandingPageLiveSession extends Struct.ComponentSchema {
  collectionName: 'components_landing_page_live_sessions';
  info: {
    displayName: 'Live-Session';
  };
  attributes: {
    adventure: Schema.Attribute.Component<
      'live-session.adventure-section',
      false
    >;
    Banner: Schema.Attribute.Component<'live-session.hero-banner', false>;
    brands: Schema.Attribute.Component<'masterclass.template-4-brands', false>;
    experience: Schema.Attribute.Component<
      'live-session.experience-section',
      false
    >;
    faq: Schema.Attribute.Component<'masterclass.faq', false>;
    form: Schema.Attribute.Component<'live-session.form', false>;
    join: Schema.Attribute.Component<'live-session.join-section', false>;
    join_stripe: Schema.Attribute.Component<'live-session.join-stripe', false>;
    stripe_image: Schema.Attribute.Media<'images'> & Schema.Attribute.Required;
    testimonial_section: Schema.Attribute.Component<'home.testimonial', false>;
  };
}

export interface LandingPageMasterclass extends Struct.ComponentSchema {
  collectionName: 'components_landing_page_masterclasses';
  info: {
    description: '';
    displayName: 'masterclass';
  };
  attributes: {
    agenda: Schema.Attribute.Component<'masterclass.join', false>;
    animations: Schema.Attribute.Component<'masterclass.animations', false>;
    brands: Schema.Attribute.Component<'masterclass.brands', false>;
    certifications: Schema.Attribute.Component<
      'masterclass.certifications',
      false
    >;
    count: Schema.Attribute.Component<'masterclass.count', true>;
    custom_navbar: Schema.Attribute.Component<
      'masterclass.custom-navbar',
      false
    >;
    faq: Schema.Attribute.Component<'masterclass.faq', false>;
    industry_experts: Schema.Attribute.Component<
      'masterclass.industry-experts',
      false
    >;
    register: Schema.Attribute.Component<'masterclass.register', false>;
    show_custom_navbar: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<false>;
    show_intro_animation: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<true>;
  };
}

export interface LandingPageTemplate2 extends Struct.ComponentSchema {
  collectionName: 'components_landing_page_template_2s';
  info: {
    displayName: 'template-2';
  };
  attributes: {
    agenda: Schema.Attribute.Component<'masterclass.join', false>;
    animations: Schema.Attribute.Component<
      'masterclass.template-2-animations',
      false
    >;
    brands: Schema.Attribute.Component<'masterclass.brands', false>;
    content: Schema.Attribute.Component<'masterclass.weeks-session', false>;
    count: Schema.Attribute.Component<'masterclass.count', true>;
    custom_navbar: Schema.Attribute.Component<
      'masterclass.custom-navbar',
      false
    >;
    faq: Schema.Attribute.Component<'masterclass.faq', false>;
    get_certified_now: Schema.Attribute.Component<
      'masterclass.get-certified-now',
      false
    >;
    hosts: Schema.Attribute.Component<'masterclass.industry-experts', false>;
    new_register: Schema.Attribute.Component<'masterclass.new-register', false>;
    register: Schema.Attribute.Component<'masterclass.register', false>;
    show_custom_navbar: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<false>;
    show_intro_animation: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<true>;
    testimonials: Schema.Attribute.Component<
      'masterclass.certifications',
      false
    >;
  };
}

export interface LandingPageTemplate4 extends Struct.ComponentSchema {
  collectionName: 'components_landing_page_template_4s';
  info: {
    displayName: 'template-4';
  };
  attributes: {
    agenda: Schema.Attribute.Component<'masterclass.template-4-agenda', false>;
    brands: Schema.Attribute.Component<'masterclass.template-4-brands', false>;
    case_stalwart: Schema.Attribute.Component<
      'masterclass.case-study-stalwart',
      false
    >;
    consult_section: Schema.Attribute.Component<'masterclass.consult', false>;
    content: Schema.Attribute.Component<'masterclass.weeks-session', false>;
    core: Schema.Attribute.Component<'masterclass.core-advantage', false>;
    count: Schema.Attribute.Component<'masterclass.count', true>;
    faq: Schema.Attribute.Component<'masterclass.faq', false>;
    first_section: Schema.Attribute.Component<
      'masterclass.template-4-first-section',
      false
    >;
    form: Schema.Attribute.Component<'masterclass.template-4-form', false>;
    get_certified_now: Schema.Attribute.Component<
      'masterclass.get-certified-now',
      false
    >;
    hosts: Schema.Attribute.Component<'masterclass.industry-experts', false>;
    testimonials: Schema.Attribute.Component<
      'masterclass.certifications',
      false
    >;
    what_you_get: Schema.Attribute.Component<'masterclass.what-you-get', false>;
    why_choose: Schema.Attribute.Component<
      'masterclass.template-4-first-section',
      false
    >;
  };
}

export interface LandingPageTemplate5 extends Struct.ComponentSchema {
  collectionName: 'components_landing_page_template_5s';
  info: {
    displayName: 'template-5';
  };
  attributes: {
    content: Schema.Attribute.Component<'masterclass.template5-content', false>;
    get_started: Schema.Attribute.Component<'case-study.get-started', false>;
    pay_offs_section: Schema.Attribute.Component<
      'case-study.pay-offs-section',
      false
    >;
  };
}

export interface LandingPageTemplate3 extends Struct.ComponentSchema {
  collectionName: 'components_landing_page_template3s';
  info: {
    displayName: 'template3';
  };
  attributes: {
    advantages: Schema.Attribute.Component<
      'masterclass.template-3-advantages',
      false
    >;
    aferr_model: Schema.Attribute.Component<'masterclass.aferr-model', false>;
    brands: Schema.Attribute.Component<'masterclass.brands', false>;
    dive_deep: Schema.Attribute.Component<'masterclass.dive-deep', false>;
    faq: Schema.Attribute.Component<'masterclass.faq', false>;
    preview: Schema.Attribute.Component<'masterclass.template3-preview', false>;
    why_download: Schema.Attribute.Component<'masterclass.why-download', false>;
  };
}

export interface LiveSessionAdventureSection extends Struct.ComponentSchema {
  collectionName: 'components_live_session_adventure_sections';
  info: {
    displayName: 'adventure_section';
    icon: 'arrowRight';
  };
  attributes: {
    adventure_cards: Schema.Attribute.Component<'live-session.live-card', true>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'> & Schema.Attribute.Required;
    title: Schema.Attribute.Text;
  };
}

export interface LiveSessionExperienceSection extends Struct.ComponentSchema {
  collectionName: 'components_live_session_experience_sections';
  info: {
    displayName: 'experience_section';
    icon: 'arrowRight';
  };
  attributes: {
    experience_cards: Schema.Attribute.Component<
      'live-session.live-card',
      true
    >;
    title: Schema.Attribute.Text;
  };
}

export interface LiveSessionForm extends Struct.ComponentSchema {
  collectionName: 'components_live_session_form';
  info: {
    displayName: 'live session form';
  };
  attributes: {
    form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface LiveSessionHeroBanner extends Struct.ComponentSchema {
  collectionName: 'components_live_session_hero_banners';
  info: {
    description: '';
    displayName: 'hero-banner';
    icon: 'arrowUp';
  };
  attributes: {
    banner_image: Schema.Attribute.Media<'images'> & Schema.Attribute.Required;
    button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    highlighted_title: Schema.Attribute.String;
    images: Schema.Attribute.Component<'live-session.swiper-images', true>;
    title: Schema.Attribute.Text;
  };
}

export interface LiveSessionJoinSection extends Struct.ComponentSchema {
  collectionName: 'components_live_session_join_sections';
  info: {
    displayName: 'join_section';
    icon: 'arrowRight';
  };
  attributes: {
    join_cards: Schema.Attribute.Component<'live-session.live-card', true>;
    title: Schema.Attribute.Text;
  };
}

export interface LiveSessionJoinStripe extends Struct.ComponentSchema {
  collectionName: 'components_live_session_join_stripes';
  info: {
    displayName: 'join-stripe';
    icon: 'arrowUp';
  };
  attributes: {
    button: Schema.Attribute.Component<'common.button', false>;
    image: Schema.Attribute.Media<'images'> & Schema.Attribute.Required;
    title: Schema.Attribute.Text;
  };
}

export interface LiveSessionLiveCard extends Struct.ComponentSchema {
  collectionName: 'components_live_session_live_cards';
  info: {
    displayName: 'live_card';
    icon: 'arrowRight';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    icon: Schema.Attribute.Media<'images'> & Schema.Attribute.Required;
    title: Schema.Attribute.Text;
  };
}

export interface LiveSessionSwiperImages extends Struct.ComponentSchema {
  collectionName: 'components_live_session_swiper_images';
  info: {
    displayName: 'swiper-images';
    icon: 'arrowRight';
  };
  attributes: {
    image: Schema.Attribute.Media<'images'> & Schema.Attribute.Required;
  };
}

export interface MasterclassAdvantages extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_advantages';
  info: {
    displayName: 'advantages';
    icon: 'connector';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface MasterclassAdvantagesList extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_advantages_lists';
  info: {
    displayName: 'advantages_list';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassAferrHero extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_aferr_heroes';
  info: {
    description: 'Hero section for Aferr Master landing page';
    displayName: 'Aferr Hero';
  };
  attributes: {
    cta_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    hero_image: Schema.Attribute.Media<'images'>;
    hero_stats: Schema.Attribute.Component<'masterclass.count', true>;
    hero_video: Schema.Attribute.String;
    secondary_button: Schema.Attribute.Component<'common.button', false>;
    subtitle: Schema.Attribute.String;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface MasterclassAferrModel extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_aferr_model_s';
  info: {
    displayName: 'Aferr Model ';
  };
  attributes: {
    aferr_model_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassAnimations extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_animations';
  info: {
    description: '';
    displayName: 'Animations';
  };
  attributes: {
    bg_img_1: Schema.Attribute.Media<'images'>;
    bg_img_2: Schema.Attribute.Media<'images'>;
    e_logo: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    evivve_logo: Schema.Attribute.Media<'images'>;
    fav_logo: Schema.Attribute.Media<'images'>;
    masterclass_logo: Schema.Attribute.Media<'images'>;
    mobile_logo: Schema.Attribute.Media<'images'>;
    screen1: Schema.Attribute.Component<'masterclass.screen1', false>;
    screen2: Schema.Attribute.Component<'masterclass.screen2', false>;
    screen3: Schema.Attribute.Component<'masterclass.screen3', false>;
    screen4_button_text: Schema.Attribute.String;
  };
}

export interface MasterclassBrands extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_brands';
  info: {
    description: '';
    displayName: 'brands';
  };
  attributes: {
    brands1: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands2: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands3: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    title_icon: Schema.Attribute.String;
    title1: Schema.Attribute.String;
    title2: Schema.Attribute.String;
  };
}

export interface MasterclassCaseStudy extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_case_studies';
  info: {
    displayName: 'Case Study';
    icon: 'cog';
  };
  attributes: {
    category: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    read_more: Schema.Attribute.Component<'common.button', false>;
    study_title: Schema.Attribute.String;
  };
}

export interface MasterclassCaseStudyStalwart extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_case_study_stalwarts';
  info: {
    displayName: 'Case study stalwart';
    icon: 'cog';
  };
  attributes: {
    case_study: Schema.Attribute.Component<'masterclass.case-study', true>;
    display: Schema.Attribute.Boolean;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassCertifications extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_certifications';
  info: {
    displayName: 'certifications';
  };
  attributes: {
    cards: Schema.Attribute.Component<'masterclass.certifications-card', true>;
    display: Schema.Attribute.Boolean;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface MasterclassCertificationsCard extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_certifications_cards';
  info: {
    displayName: 'certifications_card';
  };
  attributes: {
    bg_color: Schema.Attribute.String;
    description: Schema.Attribute.Text;
    image: Schema.Attribute.Media<'images'>;
    name: Schema.Attribute.String;
  };
}

export interface MasterclassConsult extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_consults';
  info: {
    displayName: 'consult';
    icon: 'check';
  };
  attributes: {
    active_images: Schema.Attribute.Media<'images', true>;
    cards: Schema.Attribute.Component<'masterclass.consult-cards', true>;
    default_images: Schema.Attribute.Media<'images', true>;
    display: Schema.Attribute.Boolean;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassConsultCards extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_consult_cards';
  info: {
    displayName: 'consult cards';
    icon: 'earth';
  };
  attributes: {
    card_title: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    list: Schema.Attribute.Component<'masterclass.phase-list', true>;
    sub_title: Schema.Attribute.String;
  };
}

export interface MasterclassCoreAdvantage extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_core_advantage';
  info: {
    description: '';
    displayName: 'Core advantage';
    icon: 'command';
  };
  attributes: {
    core_button: Schema.Attribute.Component<'common.button', false>;
    display: Schema.Attribute.Boolean;
    image: Schema.Attribute.Media<'images'>;
    list: Schema.Attribute.Component<'masterclass.advantages', true>;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassCount extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_counts';
  info: {
    displayName: 'count';
  };
  attributes: {
    count_number: Schema.Attribute.String;
    count_text: Schema.Attribute.String;
  };
}

export interface MasterclassCustomNavbar extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_custom_navbars';
  info: {
    displayName: 'custom navbar';
  };
  attributes: {
    links: Schema.Attribute.JSON;
  };
}

export interface MasterclassDiveDeep extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_dive_deeps';
  info: {
    displayName: 'dive deep';
  };
  attributes: {
    dive_deep_list: Schema.Attribute.Component<
      'masterclass.dive-deep-list',
      true
    >;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassDiveDeepList extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_dive_deep_lists';
  info: {
    displayName: 'dive deep list';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassExpertsList extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_experts_lists';
  info: {
    description: '';
    displayName: 'experts list';
  };
  attributes: {
    description: Schema.Attribute.Text;
    designation: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    linkedin_url: Schema.Attribute.String;
    name: Schema.Attribute.String;
  };
}

export interface MasterclassFaq extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_faqs';
  info: {
    displayName: 'faq';
  };
  attributes: {
    display: Schema.Attribute.Boolean;
    faq_list: Schema.Attribute.Component<'masterclass.faq-list', true>;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassFaqList extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_faq_lists';
  info: {
    displayName: 'faq list';
  };
  attributes: {
    answer: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    question: Schema.Attribute.String;
  };
}

export interface MasterclassGetCertifiedNow extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_get_certified_nows';
  info: {
    description: '';
    displayName: 'get certified now';
  };
  attributes: {
    button_type: Schema.Attribute.Enumeration<['link', 'popup']> &
      Schema.Attribute.DefaultTo<'link'>;
    display: Schema.Attribute.Boolean;
    get_certified_now_button: Schema.Attribute.Component<
      'common.button',
      false
    >;
    image: Schema.Attribute.Media<'images'>;
    list: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassIndustryExperts extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_industry_experts';
  info: {
    displayName: 'industry experts';
  };
  attributes: {
    experts_list: Schema.Attribute.Component<'masterclass.experts-list', true>;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface MasterclassJoin extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_joins';
  info: {
    displayName: 'join';
  };
  attributes: {
    image: Schema.Attribute.Media<'images'>;
    time_and_date: Schema.Attribute.Component<
      'masterclass.when-and-where',
      false
    >;
    title: Schema.Attribute.String;
    what_you_can_expect_list: Schema.Attribute.Component<
      'masterclass.what-you-can-expect-list',
      true
    >;
    what_you_can_expect_title: Schema.Attribute.String;
  };
}

export interface MasterclassNewRegister extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_new_register_s';
  info: {
    displayName: 'new register ';
  };
  attributes: {
    brands: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands_title: Schema.Attribute.String;
    company_image: Schema.Attribute.Media<'images'>;
    designation: Schema.Attribute.String;
    form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    name: Schema.Attribute.String;
    quote: Schema.Attribute.Text;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassPhaseList extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_phase_lists';
  info: {
    displayName: 'phase list';
    icon: 'bold';
  };
  attributes: {
    data: Schema.Attribute.Text;
  };
}

export interface MasterclassRegister extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_registers';
  info: {
    description: '';
    displayName: 'register';
  };
  attributes: {
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
    register_button: Schema.Attribute.Component<'common.button', false>;
    register_form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
    zoho_form_type: Schema.Attribute.Enumeration<['button', 'form']> &
      Schema.Attribute.DefaultTo<'button'>;
  };
}

export interface MasterclassScreen1 extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_screen1s';
  info: {
    displayName: 'screen1';
  };
  attributes: {
    button_text: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface MasterclassScreen2 extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_screen2s';
  info: {
    displayName: 'screen2';
  };
  attributes: {
    button_text: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface MasterclassScreen3 extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_screen3s';
  info: {
    description: '';
    displayName: 'screen3';
  };
  attributes: {
    button_text: Schema.Attribute.String;
    date: Schema.Attribute.Date;
    time: Schema.Attribute.String;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    video: Schema.Attribute.Media<'videos'>;
    video_thumbnail: Schema.Attribute.Media<'images'>;
  };
}

export interface MasterclassTemplate2Animations extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_t_2_animations';
  info: {
    description: '';
    displayName: 't-2-animations';
  };
  attributes: {
    bg_img_1: Schema.Attribute.Media<'images'>;
    bg_img_2: Schema.Attribute.Media<'images'>;
    e_logo: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    evivve_logo: Schema.Attribute.Media<'images'>;
    fav_logo: Schema.Attribute.Media<'images'>;
    masterclass_logo: Schema.Attribute.Media<'images'>;
    mobile_logo: Schema.Attribute.Media<'images'>;
    screen1: Schema.Attribute.Component<'masterclass.screen1', false>;
    screen2: Schema.Attribute.Component<'masterclass.screen2', false>;
    screen3: Schema.Attribute.Component<'template-2.screen-3', false>;
    screen4_button_text: Schema.Attribute.String;
  };
}

export interface MasterclassTemplate3Advantages extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_template3_advantages';
  info: {
    displayName: 'Template 3 Advantages';
  };
  attributes: {
    advantages_list: Schema.Attribute.Component<
      'masterclass.advantages-list',
      true
    >;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassTemplate4Agenda extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_template_4_agenda';
  info: {
    description: '';
    displayName: 'template 4 agenda';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
    upcoming_programs: Schema.Attribute.Component<
      'masterclass.upcoming-program',
      true
    >;
    upcoming_programs_title: Schema.Attribute.String;
  };
}

export interface MasterclassTemplate4Animations extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_t_4_animations';
  info: {
    description: '';
    displayName: 't-4-animations';
  };
  attributes: {
    bg_img_1: Schema.Attribute.Media<'images'>;
    bg_img_2: Schema.Attribute.Media<'images'>;
    e_logo: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    evivve_logo: Schema.Attribute.Media<'images'>;
    fav_logo: Schema.Attribute.Media<'images'>;
    masterclass_logo: Schema.Attribute.Media<'images'>;
    mobile_logo: Schema.Attribute.Media<'images'>;
    screen1: Schema.Attribute.Component<'masterclass.screen1', false>;
    screen2: Schema.Attribute.Component<'masterclass.screen2', false>;
  };
}

export interface MasterclassTemplate4Brands extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_template_4_brands';
  info: {
    displayName: 'template 4 brands';
  };
  attributes: {
    brands: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassTemplate4FirstSection
  extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_t4_first_sections';
  info: {
    displayName: 'template-4-first-section';
  };
  attributes: {
    button_type: Schema.Attribute.Enumeration<['link', 'popup']> &
      Schema.Attribute.DefaultTo<'link'>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    first_section_button: Schema.Attribute.Component<'common.button', false>;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface MasterclassTemplate4Form extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_t_4_form';
  info: {
    displayName: 'template 4 form';
  };
  attributes: {
    form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
  };
}

export interface MasterclassTemplate3Preview extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_template3_previews';
  info: {
    displayName: 'template3 preview';
  };
  attributes: {
    button_text: Schema.Attribute.String;
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images'>;
    preview_form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    preview_list: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassTemplate5Content extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_template5_contents';
  info: {
    displayName: 'template5 content';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    title: Schema.Attribute.String;
    video: Schema.Attribute.String;
    video_description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface MasterclassUpcomingProgram extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_upcoming_programs';
  info: {
    description: '';
    displayName: 'upcoming program';
  };
  attributes: {
    bgcolor: Schema.Attribute.String;
    button_type: Schema.Attribute.Enumeration<['link', 'popup']> &
      Schema.Attribute.DefaultTo<'link'>;
    dates: Schema.Attribute.String;
    divider_color: Schema.Attribute.String;
    level: Schema.Attribute.String;
    location: Schema.Attribute.String;
    month: Schema.Attribute.String;
    overwrite_bgcolor: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<false>;
    show_tagline: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<false>;
    tagline: Schema.Attribute.String;
    time: Schema.Attribute.String;
    upcoming_program_button: Schema.Attribute.Component<'common.button', false>;
  };
}

export interface MasterclassWeeksSession extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_weeks_sessions';
  info: {
    displayName: 'weeks session';
  };
  attributes: {
    display: Schema.Attribute.Boolean;
    title: Schema.Attribute.String;
    weeks_session_card: Schema.Attribute.Component<
      'masterclass.weeks-session-card',
      true
    >;
  };
}

export interface MasterclassWeeksSessionCard extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_weeks_session_cards';
  info: {
    displayName: 'weeks session card';
  };
  attributes: {
    list: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassWhatYouCanExpectList
  extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_what_you_can_expect_lists';
  info: {
    displayName: 'what you can expect list';
  };
  attributes: {
    list: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface MasterclassWhatYouGet extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_what_you_gets';
  info: {
    displayName: 'what you get';
  };
  attributes: {
    title: Schema.Attribute.String;
    what_you_get_list: Schema.Attribute.Component<
      'masterclass.what-you-get-list',
      true
    >;
  };
}

export interface MasterclassWhatYouGetList extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_what_you_get_lists';
  info: {
    displayName: 'what you get list';
  };
  attributes: {
    button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    icon: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassWhenAndWhere extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_when_and_wheres';
  info: {
    displayName: 'when and where';
  };
  attributes: {
    date: Schema.Attribute.Date;
    image: Schema.Attribute.Media<'images'>;
    template2_date: Schema.Attribute.Text;
    time: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface MasterclassWhyDownload extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_why_downloads';
  info: {
    displayName: 'why download';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
    why_dowload_list: Schema.Attribute.Component<
      'masterclass.why-download-list',
      true
    >;
  };
}

export interface MasterclassWhyDownloadList extends Struct.ComponentSchema {
  collectionName: 'components_masterclass_why_download_lists';
  info: {
    displayName: 'why download list';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface NewPlayNowBottomSection extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_bottom_sections';
  info: {
    description: '';
    displayName: 'Bottom Section';
  };
  attributes: {
    button_type: Schema.Attribute.Enumeration<['form', 'link']> &
      Schema.Attribute.DefaultTo<'link'>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    new_play_now_bottom_section_button: Schema.Attribute.Component<
      'common.button',
      false
    >;
    title: Schema.Attribute.String;
    title_highlight: Schema.Attribute.String;
  };
}

export interface NewPlayNowFeatureCard extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_feature_cards';
  info: {
    displayName: 'Feature Card';
  };
  attributes: {
    description: Schema.Attribute.Text;
    icon: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface NewPlayNowFeatureSection extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_feature_sections';
  info: {
    displayName: 'Feature Section';
  };
  attributes: {
    cards: Schema.Attribute.Component<'new-play-now.feature-card', true>;
    title: Schema.Attribute.String;
  };
}

export interface NewPlayNowForm extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_forms';
  info: {
    displayName: 'Form';
  };
  attributes: {
    form: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    form_onload: Schema.Attribute.String;
    form_onsubmit: Schema.Attribute.String;
  };
}

export interface NewPlayNowGameListCard extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_game_list_cards';
  info: {
    description: '';
    displayName: 'Game List Card';
  };
  attributes: {
    bg_design: Schema.Attribute.Media<'images'>;
    bg_linear_color: Schema.Attribute.String;
    description: Schema.Attribute.Text;
    image: Schema.Attribute.Media<'images'>;
    text_shadow_color: Schema.Attribute.String;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface NewPlayNowGameListSection extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_game_list_sections';
  info: {
    displayName: 'Game List Section';
  };
  attributes: {
    Cards: Schema.Attribute.Component<'new-play-now.game-list-card', true>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface NewPlayNowHeroSection extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_hero_sections';
  info: {
    description: '';
    displayName: 'Hero Section';
  };
  attributes: {
    button_type: Schema.Attribute.Enumeration<['form', 'link']> &
      Schema.Attribute.DefaultTo<'link'>;
    image: Schema.Attribute.Media<'images'>;
    new_play_now_hero_button: Schema.Attribute.Component<
      'common.button',
      false
    >;
    sub_title: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface NewPlayNowStepsCard extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_steps_cards';
  info: {
    displayName: 'Steps Card';
  };
  attributes: {
    description: Schema.Attribute.Text;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface NewPlayNowStepsSection extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_steps_sections';
  info: {
    displayName: 'Steps Section';
  };
  attributes: {
    cards: Schema.Attribute.Component<'new-play-now.steps-card', true>;
    title: Schema.Attribute.String;
  };
}

export interface NewPlayNowWelcome extends Struct.ComponentSchema {
  collectionName: 'components_new_play_now_welcomes';
  info: {
    displayName: 'Welcome';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
    video: Schema.Attribute.Media<'videos'>;
  };
}

export interface NewPricingCredits extends Struct.ComponentSchema {
  collectionName: 'components_new_pricing_credits';
  info: {
    description: '';
    displayName: 'credits';
  };
  attributes: {
    discount: Schema.Attribute.String;
    discount_green_color_text: Schema.Attribute.Boolean &
      Schema.Attribute.DefaultTo<true>;
    price: Schema.Attribute.String;
    segment: Schema.Attribute.String;
  };
}

export interface NewPricingCreditsHeader extends Struct.ComponentSchema {
  collectionName: 'components_new_pricing_credits_headers';
  info: {
    displayName: 'credits header';
  };
  attributes: {
    icon: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface NewPricingFaq extends Struct.ComponentSchema {
  collectionName: 'components_new_pricing_faqs';
  info: {
    displayName: 'faq';
  };
  attributes: {
    answer: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    question: Schema.Attribute.Text;
  };
}

export interface NewPricingGetInTouch extends Struct.ComponentSchema {
  collectionName: 'components_new_pricing_get_in_touches';
  info: {
    displayName: 'get in touch';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    get_in_touch_button: Schema.Attribute.Component<'common.button', false>;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface NewPricingHowCreditsWork extends Struct.ComponentSchema {
  collectionName: 'components_new_pricing_how_credits_works';
  info: {
    displayName: 'how credits work';
  };
  attributes: {
    description: Schema.Attribute.Text;
    desktop_image: Schema.Attribute.Media<'images'>;
    how_credits_work_button: Schema.Attribute.Component<'common.button', false>;
    mobile_image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface NewPricingList extends Struct.ComponentSchema {
  collectionName: 'components_new_pricing_lists';
  info: {
    description: '';
    displayName: 'list';
  };
  attributes: {
    text: Schema.Attribute.String;
  };
}

export interface NewPricingNewPricingCard extends Struct.ComponentSchema {
  collectionName: 'components_new_pricing_new_pricing_cards';
  info: {
    description: '';
    displayName: 'new pricing card';
  };
  attributes: {
    list: Schema.Attribute.Component<'new-pricing.list', true>;
    most_popular: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<false>;
    new_pricing_card_button: Schema.Attribute.Component<'common.button', false>;
    price_and_credits: Schema.Attribute.String;
    tag_line: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface NewsroomAward extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_awards';
  info: {
    description: '';
    displayName: 'award';
  };
  attributes: {
    award_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    name: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface NewsroomBrands extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_brands';
  info: {
    displayName: 'brands';
  };
  attributes: {
    brands_button: Schema.Attribute.Component<'common.button', false>;
    brands1: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands2: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands3: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    title_icon: Schema.Attribute.String;
    title1: Schema.Attribute.String;
    title2: Schema.Attribute.String;
  };
}

export interface NewsroomFeatureData extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_feature_data';
  info: {
    displayName: 'feature data';
  };
  attributes: {
    date: Schema.Attribute.Date;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    feature_button: Schema.Attribute.Component<'common.button', false>;
    image: Schema.Attribute.Media<'images'>;
    publisher_name: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface NewsroomMediaCard extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_media_cards';
  info: {
    description: '';
    displayName: 'media card';
  };
  attributes: {
    date: Schema.Attribute.Date;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    media_card_button: Schema.Attribute.Component<'common.button', false>;
    publisher_name: Schema.Attribute.String;
  };
}

export interface NewsroomSection1 extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_section1s';
  info: {
    displayName: 'Section1';
  };
  attributes: {
    data: Schema.Attribute.Component<'newsroom.media-card', true>;
    feature_data: Schema.Attribute.Component<'newsroom.feature-data', false>;
    title: Schema.Attribute.String;
  };
}

export interface NewsroomSection2 extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_section2s';
  info: {
    displayName: 'section2';
  };
  attributes: {
    award: Schema.Attribute.Component<'newsroom.award', true>;
    title: Schema.Attribute.String;
  };
}

export interface NewsroomSection3 extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_section3s';
  info: {
    description: '';
    displayName: 'section3';
  };
  attributes: {
    press_releases: Schema.Attribute.Relation<
      'oneToMany',
      'api::press-release.press-release'
    >;
    title: Schema.Attribute.String;
  };
}

export interface NewsroomSection4 extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_section4s';
  info: {
    displayName: 'section4';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    section4_button: Schema.Attribute.Component<'common.button', false>;
    title: Schema.Attribute.String;
  };
}

export interface NewsroomVideoCard extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_video_cards';
  info: {
    displayName: 'video card';
  };
  attributes: {
    title: Schema.Attribute.String;
    video_embed_src_link: Schema.Attribute.Text;
  };
}

export interface NewsroomVideosSection extends Struct.ComponentSchema {
  collectionName: 'components_newsroom_videos_sections';
  info: {
    displayName: 'videos section';
  };
  attributes: {
    title: Schema.Attribute.String;
    video_card: Schema.Attribute.Component<'newsroom.video-card', true>;
  };
}

export interface OnboardingScreen1 extends Struct.ComponentSchema {
  collectionName: 'components_onboarding_screen1s';
  info: {
    displayName: 'Screen1';
  };
  attributes: {
    background_image: Schema.Attribute.Media<'images'>;
    button_text: Schema.Attribute.String;
    mobile_background_image: Schema.Attribute.Media<'images'>;
    mobile_persons_image: Schema.Attribute.Media<'images'>;
    persons_image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface OnboardingScreen2 extends Struct.ComponentSchema {
  collectionName: 'components_onboarding_screen2s';
  info: {
    description: '';
    displayName: 'Screen2';
  };
  attributes: {
    background_image: Schema.Attribute.Media<'images'>;
    button_text: Schema.Attribute.String;
    mobile_background_image: Schema.Attribute.Media<'images'>;
    mobile_persons_image: Schema.Attribute.Media<'images'>;
    persons_image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface OnboardingScreen3 extends Struct.ComponentSchema {
  collectionName: 'components_onboarding_screen3s';
  info: {
    description: '';
    displayName: 'Screen3';
  };
  attributes: {
    background_image: Schema.Attribute.Media<'images'>;
    button1_text: Schema.Attribute.String;
    button2_text: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    mobile_background_image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface PopupPopup extends Struct.ComponentSchema {
  collectionName: 'components_popup_popups';
  info: {
    description: '';
    displayName: 'Popup';
  };
  attributes: {
    description: Schema.Attribute.Text;
    image: Schema.Attribute.Media<'images'>;
    popup_button: Schema.Attribute.Component<'common.button', false>;
    title: Schema.Attribute.String;
  };
}

export interface PricingBrand extends Struct.ComponentSchema {
  collectionName: 'components_pricing_brands';
  info: {
    displayName: 'brand';
  };
  attributes: {
    image: Schema.Attribute.Media<'images'>;
  };
}

export interface PricingBrandSection extends Struct.ComponentSchema {
  collectionName: 'components_pricing_brand_sections';
  info: {
    description: '';
    displayName: 'Brand section';
  };
  attributes: {
    brands: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands2: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands3: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    description: Schema.Attribute.Text;
    pricing_brands_button: Schema.Attribute.Component<'common.button', false>;
    title: Schema.Attribute.String;
    title_icon: Schema.Attribute.String;
    title2: Schema.Attribute.String;
  };
}

export interface PricingCommitment extends Struct.ComponentSchema {
  collectionName: 'components_pricing_commitments';
  info: {
    description: '';
    displayName: 'commitment';
  };
  attributes: {
    description: Schema.Attribute.String;
    icon: Schema.Attribute.String & Schema.Attribute.Required;
    name: Schema.Attribute.String;
  };
}

export interface PricingContact extends Struct.ComponentSchema {
  collectionName: 'components_pricing_contacts';
  info: {
    description: '';
    displayName: 'Contact';
  };
  attributes: {
    contact_section_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.Text;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface PricingCustomPlan extends Struct.ComponentSchema {
  collectionName: 'components_pricing_custom_plans';
  info: {
    description: '';
    displayName: 'Custom Plan';
  };
  attributes: {
    custom_plan_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.Text;
    title: Schema.Attribute.String;
  };
}

export interface PricingFaq extends Struct.ComponentSchema {
  collectionName: 'components_pricing_faqs';
  info: {
    description: '';
    displayName: 'Faq';
  };
  attributes: {
    answer: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    question: Schema.Attribute.String;
  };
}

export interface PricingFaqSection extends Struct.ComponentSchema {
  collectionName: 'components_pricing_faq_sections';
  info: {
    description: '';
    displayName: 'faq section';
  };
  attributes: {
    faq: Schema.Attribute.Component<'pricing.faq', true>;
    heading_text: Schema.Attribute.String;
    link_target: Schema.Attribute.Enumeration<['_self', '_blank']>;
    link_text: Schema.Attribute.String;
    link_url: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface PricingPlan extends Struct.ComponentSchema {
  collectionName: 'components_pricing_plans';
  info: {
    description: '';
    displayName: 'Plan';
  };
  attributes: {
    description: Schema.Attribute.String;
    isYearly: Schema.Attribute.Boolean &
      Schema.Attribute.Required &
      Schema.Attribute.DefaultTo<true>;
    most_popular: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<false>;
    plan_features: Schema.Attribute.Component<'pricing.plan-features', true>;
    plan_name: Schema.Attribute.String;
    price: Schema.Attribute.Component<'pricing.price', true>;
    price_text: Schema.Attribute.String;
    pricing_button: Schema.Attribute.Component<'common.button', false>;
  };
}

export interface PricingPlanFeatures extends Struct.ComponentSchema {
  collectionName: 'components_pricing_plan_features';
  info: {
    description: '';
    displayName: 'Plan features';
  };
  attributes: {
    applicable: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<true>;
    name: Schema.Attribute.String;
    show_tooltip: Schema.Attribute.Boolean & Schema.Attribute.DefaultTo<false>;
    tooltip_text: Schema.Attribute.Text;
  };
}

export interface PricingPrice extends Struct.ComponentSchema {
  collectionName: 'components_pricing_prices';
  info: {
    displayName: 'price';
  };
  attributes: {
    plan_type: Schema.Attribute.String;
    price: Schema.Attribute.Integer;
  };
}

export interface PricingTestimonial extends Struct.ComponentSchema {
  collectionName: 'components_pricing_testimonials';
  info: {
    description: '';
    displayName: 'testimonial';
  };
  attributes: {
    by: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    role: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface PricingTestimonialSection extends Struct.ComponentSchema {
  collectionName: 'components_pricing_testimonial_sections';
  info: {
    displayName: 'Testimonial section';
  };
  attributes: {
    heading: Schema.Attribute.String;
    testimonials: Schema.Attribute.Component<'pricing.testimonial', true>;
    title: Schema.Attribute.String;
  };
}

export interface SharedMetaSocial extends Struct.ComponentSchema {
  collectionName: 'components_shared_meta_socials';
  info: {
    description: '';
    displayName: 'metaSocial';
    icon: 'project-diagram';
  };
  attributes: {
    description: Schema.Attribute.String &
      Schema.Attribute.Required &
      Schema.Attribute.SetMinMaxLength<{
        maxLength: 65;
      }>;
    image: Schema.Attribute.Media<'images' | 'files' | 'videos'>;
    socialNetwork: Schema.Attribute.Enumeration<
      ['Facebook', 'Twitter', 'LinkedIn']
    > &
      Schema.Attribute.Required;
    title: Schema.Attribute.String &
      Schema.Attribute.Required &
      Schema.Attribute.SetMinMaxLength<{
        maxLength: 60;
      }>;
  };
}

export interface SharedSeo extends Struct.ComponentSchema {
  collectionName: 'components_shared_seos';
  info: {
    displayName: 'seo';
    icon: 'search';
  };
  attributes: {
    canonicalURL: Schema.Attribute.String;
    keywords: Schema.Attribute.Text;
    metaDescription: Schema.Attribute.String &
      Schema.Attribute.Required &
      Schema.Attribute.SetMinMaxLength<{
        maxLength: 160;
        minLength: 50;
      }>;
    metaImage: Schema.Attribute.Media<'images' | 'files' | 'videos'>;
    metaRobots: Schema.Attribute.String;
    metaSocial: Schema.Attribute.Component<'shared.meta-social', true>;
    metaTitle: Schema.Attribute.String &
      Schema.Attribute.Required &
      Schema.Attribute.SetMinMaxLength<{
        maxLength: 60;
      }>;
    metaViewport: Schema.Attribute.String;
    structuredData: Schema.Attribute.JSON;
  };
}

export interface Template2Screen3 extends Struct.ComponentSchema {
  collectionName: 'components_template_2_screen_3s';
  info: {
    displayName: 'screen 3';
  };
  attributes: {
    button_text: Schema.Attribute.String;
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    video: Schema.Attribute.Media<'videos'>;
    video_thumbnail: Schema.Attribute.Media<'images'>;
  };
}

export interface TestimonialBottomSection extends Struct.ComponentSchema {
  collectionName: 'components_testimonial_bottom_sections';
  info: {
    description: '';
    displayName: 'Bottom section';
  };
  attributes: {
    bottom_button: Schema.Attribute.Component<'common.button', false>;
    description: Schema.Attribute.Text;
    title: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

export interface TestimonialBrands extends Struct.ComponentSchema {
  collectionName: 'components_testimonial_brands';
  info: {
    displayName: 'Brands';
  };
  attributes: {
    image: Schema.Attribute.Media<'images'>;
  };
}

export interface TestimonialBrandsSection extends Struct.ComponentSchema {
  collectionName: 'components_testimonial_brands_sections';
  info: {
    description: '';
    displayName: 'Brands Section';
  };
  attributes: {
    brands: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands2: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    brands3: Schema.Attribute.Relation<'oneToMany', 'api::logo.logo'>;
    title_icon: Schema.Attribute.String;
    title1: Schema.Attribute.String;
    title2: Schema.Attribute.String;
  };
}

export interface TestimonialTestimonialsSection extends Struct.ComponentSchema {
  collectionName: 'components_testimonial_testimonials_sections';
  info: {
    displayName: 'Testimonials section';
  };
  attributes: {
    title: Schema.Attribute.String;
  };
}

export interface UseCaseBanner extends Struct.ComponentSchema {
  collectionName: 'components_use_case_banners';
  info: {
    description: '';
    displayName: 'banner';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    mobile_image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface UseCaseBenefits extends Struct.ComponentSchema {
  collectionName: 'components_use_case_benefits';
  info: {
    displayName: 'benefits';
  };
  attributes: {
    benefits_detials: Schema.Attribute.Component<
      'use-case.benefits-details',
      true
    >;
    title: Schema.Attribute.String;
  };
}

export interface UseCaseBenefitsDetails extends Struct.ComponentSchema {
  collectionName: 'components_use_case_benefits_details';
  info: {
    displayName: 'benefits-details';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface UseCaseCkeditor extends Struct.ComponentSchema {
  collectionName: 'components_use_case_ckeditors';
  info: {
    displayName: 'ckeditor';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
  };
}

export interface UseCaseExplore extends Struct.ComponentSchema {
  collectionName: 'components_use_case_explores';
  info: {
    displayName: 'explore';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    title: Schema.Attribute.String;
  };
}

export interface UseCaseFeatures extends Struct.ComponentSchema {
  collectionName: 'components_use_case_features';
  info: {
    displayName: 'features';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    image: Schema.Attribute.Media<'images'>;
    subTitle: Schema.Attribute.String;
    subTitle_highlight: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface UseCaseReadySection extends Struct.ComponentSchema {
  collectionName: 'components_use_case_ready_sections';
  info: {
    description: '';
    displayName: 'ready-section';
  };
  attributes: {
    description: Schema.Attribute.Text;
    ready_section_button: Schema.Attribute.Component<'common.button', false>;
    title: Schema.Attribute.String;
  };
}

export interface UseCaseSwiper extends Struct.ComponentSchema {
  collectionName: 'components_use_case_swipers';
  info: {
    displayName: 'swiper';
  };
  attributes: {
    description: Schema.Attribute.RichText &
      Schema.Attribute.CustomField<
        'plugin::ckeditor5.CKEditor',
        {
          preset: 'standard';
        }
      >;
    title: Schema.Attribute.String;
  };
}

export interface UseCaseSwiperDescription extends Struct.ComponentSchema {
  collectionName: 'components_use_case_swiper_descriptions';
  info: {
    description: '';
    displayName: 'swiper descriptions';
  };
  attributes: {
    swiper: Schema.Attribute.Component<'use-case.swiper', true>;
  };
}

declare module '@strapi/strapi' {
  export module Public {
    export interface ComponentSchemas {
      'about.bottom-section': AboutBottomSection;
      'about.history-points': AboutHistoryPoints;
      'about.history-section': AboutHistorySection;
      'about.member': AboutMember;
      'about.members-section': AboutMembersSection;
      'about.points': AboutPoints;
      'about.second-section': AboutSecondSection;
      'about.third-section': AboutThirdSection;
      'about.vision-and-mission': AboutVisionAndMission;
      'about.vision-and-mission-list': AboutVisionAndMissionList;
      'adventure.certified': AdventureCertified;
      'adventure.form': AdventureForm;
      'adventure.hero-section': AdventureHeroSection;
      'adventure.stripe': AdventureStripe;
      'author.social-link': AuthorSocialLink;
      'blog.bottom-section': BlogBottomSection;
      'blog.follow-us': BlogFollowUs;
      'blog.key-takeaways': BlogKeyTakeaways;
      'button.button': ButtonButton;
      'button.button-image-text': ButtonButtonImageText;
      'button.button-text': ButtonButtonText;
      'button.newsletter': ButtonNewsletter;
      'careers.bottom-section': CareersBottomSection;
      'careers.glassdoor-section': CareersGlassdoorSection;
      'careers.hero': CareersHero;
      'careers.hero-section': CareersHeroSection;
      'careers.project-list': CareersProjectList;
      'careers.why-choose-us': CareersWhyChooseUs;
      'careers.why-choose-us-list': CareersWhyChooseUsList;
      'case-study.aferr-case-studies-section': CaseStudyAferrCaseStudiesSection;
      'case-study.aferr-cta': CaseStudyAferrCta;
      'case-study.aferr-details-section': CaseStudyAferrDetailsSection;
      'case-study.aferr-details-section-2': CaseStudyAferrDetailsSection2;
      'case-study.aferr-final-cta': CaseStudyAferrFinalCta;
      'case-study.aferr-hero-section': CaseStudyAferrHeroSection;
      'case-study.aferr-stats-quadrant': CaseStudyAferrStatsQuadrant;
      'case-study.aferr-stats-section': CaseStudyAferrStatsSection;
      'case-study.aferr-video-carousel': CaseStudyAferrVideoCarousel;
      'case-study.audiobook-series-template': CaseStudyAudiobookSeriesTemplate;
      'case-study.brands': CaseStudyBrands;
      'case-study.case-study-category': CaseStudyCaseStudyCategory;
      'case-study.case-study-cta': CaseStudyCaseStudyCta;
      'case-study.case-study-item': CaseStudyCaseStudyItem;
      'case-study.case-study-series-template': CaseStudyCaseStudySeriesTemplate;
      'case-study.company-overview': CaseStudyCompanyOverview;
      'case-study.cta-header-section': CaseStudyCtaHeaderSection;
      'case-study.first-section-swiper-list': CaseStudyFirstSectionSwiperList;
      'case-study.get-started': CaseStudyGetStarted;
      'case-study.hero-section': CaseStudyHeroSection;
      'case-study.impact': CaseStudyImpact;
      'case-study.impact-stat': CaseStudyImpactStat;
      'case-study.journal-series-template': CaseStudyJournalSeriesTemplate;
      'case-study.key-challenges': CaseStudyKeyChallenges;
      'case-study.pay-offs-list': CaseStudyPayOffsList;
      'case-study.pay-offs-section': CaseStudyPayOffsSection;
      'case-study.references': CaseStudyReferences;
      'case-study.research-series-template': CaseStudyResearchSeriesTemplate;
      'case-study.solutions': CaseStudySolutions;
      'case-study.solutions-banner': CaseStudySolutionsBanner;
      'case-study.stat-card': CaseStudyStatCard;
      'case-study.team-section': CaseStudyTeamSection;
      'case-study.team-section-list': CaseStudyTeamSectionList;
      'case-study.testimonial': CaseStudyTestimonial;
      'case-study.testimonials': CaseStudyTestimonials;
      'common.app-download': CommonAppDownload;
      'common.banner': CommonBanner;
      'common.button': CommonButton;
      'common.download-app': CommonDownloadApp;
      'common.editor': CommonEditor;
      'common.footer': CommonFooter;
      'common.form-field': CommonFormField;
      'common.social-media': CommonSocialMedia;
      'common.spacing': CommonSpacing;
      'common.thank-you': CommonThankYou;
      'common.top-sticky-stripe': CommonTopStickyStripe;
      'common.zoho-form': CommonZohoForm;
      'contact.second-section': ContactSecondSection;
      'game-download.app-download': GameDownloadAppDownload;
      'game-download.app-download-buttons': GameDownloadAppDownloadButtons;
      'game-download.feature-list': GameDownloadFeatureList;
      'game-download.features': GameDownloadFeatures;
      'game-download.minimal-dashboard': GameDownloadMinimalDashboard;
      'game-download.overview-list': GameDownloadOverviewList;
      'game.banner': GameBanner;
      'game.brand': GameBrand;
      'game.brand-section': GameBrandSection;
      'game.button': GameButton;
      'game.download-app': GameDownloadApp;
      'game.facilitators-love-about-evivve': GameFacilitatorsLoveAboutEvivve;
      'game.play-category': GamePlayCategory;
      'game.testimonial': GameTestimonial;
      'glossary.dark-editor': GlossaryDarkEditor;
      'glossary.light-editor': GlossaryLightEditor;
      'glossary.reference': GlossaryReference;
      'home.brand': HomeBrand;
      'home.button': HomeButton;
      'home.community': HomeCommunity;
      'home.community-points': HomeCommunityPoints;
      'home.earning': HomeEarning;
      'home.get-started': HomeGetStarted;
      'home.how-it-works': HomeHowItWorks;
      'home.how-it-works-step': HomeHowItWorksStep;
      'home.how-it-works-step-animate-text': HomeHowItWorksStepAnimateText;
      'home.how-it-works-step-points': HomeHowItWorksStepPoints;
      'home.testimonial': HomeTestimonial;
      'home.top-section': HomeTopSection;
      'knowledge-base.3-card-cta-item': KnowledgeBase3CardCtaItem;
      'knowledge-base.3-cards-ctas': KnowledgeBase3CardsCtas;
      'knowledge-base.featured-faq': KnowledgeBaseFeaturedFaq;
      'knowledge-base.featured-faq-item': KnowledgeBaseFeaturedFaqItem;
      'knowledge-base.topics': KnowledgeBaseTopics;
      'labs.approach-cards': LabsApproachCards;
      'labs.approach-section': LabsApproachSection;
      'labs.cta': LabsCta;
      'labs.evidence-based-strategy': LabsEvidenceBasedStrategy;
      'labs.evidence-based-strategy-features': LabsEvidenceBasedStrategyFeatures;
      'labs.faq': LabsFaq;
      'labs.faq-list': LabsFaqList;
      'labs.hero-section': LabsHeroSection;
      'labs.inside-labs-features': LabsInsideLabsFeatures;
      'labs.inside-labs-section': LabsInsideLabsSection;
      'labs.models-and-frameworks-list': LabsModelsAndFrameworksList;
      'labs.models-and-frameworks-section': LabsModelsAndFrameworksSection;
      'labs.neuro-science': LabsNeuroScience;
      'labs.neuro-scince-features': LabsNeuroScinceFeatures;
      'labs.science-backed-approach': LabsScienceBackedApproach;
      'labs.science-backed-approach-cards': LabsScienceBackedApproachCards;
      'labs.stats-section': LabsStatsSection;
      'landing-page.adventure': LandingPageAdventure;
      'landing-page.live-session': LandingPageLiveSession;
      'landing-page.masterclass': LandingPageMasterclass;
      'landing-page.template-2': LandingPageTemplate2;
      'landing-page.template-4': LandingPageTemplate4;
      'landing-page.template-5': LandingPageTemplate5;
      'landing-page.template3': LandingPageTemplate3;
      'live-session.adventure-section': LiveSessionAdventureSection;
      'live-session.experience-section': LiveSessionExperienceSection;
      'live-session.form': LiveSessionForm;
      'live-session.hero-banner': LiveSessionHeroBanner;
      'live-session.join-section': LiveSessionJoinSection;
      'live-session.join-stripe': LiveSessionJoinStripe;
      'live-session.live-card': LiveSessionLiveCard;
      'live-session.swiper-images': LiveSessionSwiperImages;
      'masterclass.advantages': MasterclassAdvantages;
      'masterclass.advantages-list': MasterclassAdvantagesList;
      'masterclass.aferr-hero': MasterclassAferrHero;
      'masterclass.aferr-model': MasterclassAferrModel;
      'masterclass.animations': MasterclassAnimations;
      'masterclass.brands': MasterclassBrands;
      'masterclass.case-study': MasterclassCaseStudy;
      'masterclass.case-study-stalwart': MasterclassCaseStudyStalwart;
      'masterclass.certifications': MasterclassCertifications;
      'masterclass.certifications-card': MasterclassCertificationsCard;
      'masterclass.consult': MasterclassConsult;
      'masterclass.consult-cards': MasterclassConsultCards;
      'masterclass.core-advantage': MasterclassCoreAdvantage;
      'masterclass.count': MasterclassCount;
      'masterclass.custom-navbar': MasterclassCustomNavbar;
      'masterclass.dive-deep': MasterclassDiveDeep;
      'masterclass.dive-deep-list': MasterclassDiveDeepList;
      'masterclass.experts-list': MasterclassExpertsList;
      'masterclass.faq': MasterclassFaq;
      'masterclass.faq-list': MasterclassFaqList;
      'masterclass.get-certified-now': MasterclassGetCertifiedNow;
      'masterclass.industry-experts': MasterclassIndustryExperts;
      'masterclass.join': MasterclassJoin;
      'masterclass.new-register': MasterclassNewRegister;
      'masterclass.phase-list': MasterclassPhaseList;
      'masterclass.register': MasterclassRegister;
      'masterclass.screen1': MasterclassScreen1;
      'masterclass.screen2': MasterclassScreen2;
      'masterclass.screen3': MasterclassScreen3;
      'masterclass.template-2-animations': MasterclassTemplate2Animations;
      'masterclass.template-3-advantages': MasterclassTemplate3Advantages;
      'masterclass.template-4-agenda': MasterclassTemplate4Agenda;
      'masterclass.template-4-animations': MasterclassTemplate4Animations;
      'masterclass.template-4-brands': MasterclassTemplate4Brands;
      'masterclass.template-4-first-section': MasterclassTemplate4FirstSection;
      'masterclass.template-4-form': MasterclassTemplate4Form;
      'masterclass.template3-preview': MasterclassTemplate3Preview;
      'masterclass.template5-content': MasterclassTemplate5Content;
      'masterclass.upcoming-program': MasterclassUpcomingProgram;
      'masterclass.weeks-session': MasterclassWeeksSession;
      'masterclass.weeks-session-card': MasterclassWeeksSessionCard;
      'masterclass.what-you-can-expect-list': MasterclassWhatYouCanExpectList;
      'masterclass.what-you-get': MasterclassWhatYouGet;
      'masterclass.what-you-get-list': MasterclassWhatYouGetList;
      'masterclass.when-and-where': MasterclassWhenAndWhere;
      'masterclass.why-download': MasterclassWhyDownload;
      'masterclass.why-download-list': MasterclassWhyDownloadList;
      'new-play-now.bottom-section': NewPlayNowBottomSection;
      'new-play-now.feature-card': NewPlayNowFeatureCard;
      'new-play-now.feature-section': NewPlayNowFeatureSection;
      'new-play-now.form': NewPlayNowForm;
      'new-play-now.game-list-card': NewPlayNowGameListCard;
      'new-play-now.game-list-section': NewPlayNowGameListSection;
      'new-play-now.hero-section': NewPlayNowHeroSection;
      'new-play-now.steps-card': NewPlayNowStepsCard;
      'new-play-now.steps-section': NewPlayNowStepsSection;
      'new-play-now.welcome': NewPlayNowWelcome;
      'new-pricing.credits': NewPricingCredits;
      'new-pricing.credits-header': NewPricingCreditsHeader;
      'new-pricing.faq': NewPricingFaq;
      'new-pricing.get-in-touch': NewPricingGetInTouch;
      'new-pricing.how-credits-work': NewPricingHowCreditsWork;
      'new-pricing.list': NewPricingList;
      'new-pricing.new-pricing-card': NewPricingNewPricingCard;
      'newsroom.award': NewsroomAward;
      'newsroom.brands': NewsroomBrands;
      'newsroom.feature-data': NewsroomFeatureData;
      'newsroom.media-card': NewsroomMediaCard;
      'newsroom.section1': NewsroomSection1;
      'newsroom.section2': NewsroomSection2;
      'newsroom.section3': NewsroomSection3;
      'newsroom.section4': NewsroomSection4;
      'newsroom.video-card': NewsroomVideoCard;
      'newsroom.videos-section': NewsroomVideosSection;
      'onboarding.screen1': OnboardingScreen1;
      'onboarding.screen2': OnboardingScreen2;
      'onboarding.screen3': OnboardingScreen3;
      'popup.popup': PopupPopup;
      'pricing.brand': PricingBrand;
      'pricing.brand-section': PricingBrandSection;
      'pricing.commitment': PricingCommitment;
      'pricing.contact': PricingContact;
      'pricing.custom-plan': PricingCustomPlan;
      'pricing.faq': PricingFaq;
      'pricing.faq-section': PricingFaqSection;
      'pricing.plan': PricingPlan;
      'pricing.plan-features': PricingPlanFeatures;
      'pricing.price': PricingPrice;
      'pricing.testimonial': PricingTestimonial;
      'pricing.testimonial-section': PricingTestimonialSection;
      'shared.meta-social': SharedMetaSocial;
      'shared.seo': SharedSeo;
      'template-2.screen-3': Template2Screen3;
      'testimonial.bottom-section': TestimonialBottomSection;
      'testimonial.brands': TestimonialBrands;
      'testimonial.brands-section': TestimonialBrandsSection;
      'testimonial.testimonials-section': TestimonialTestimonialsSection;
      'use-case.banner': UseCaseBanner;
      'use-case.benefits': UseCaseBenefits;
      'use-case.benefits-details': UseCaseBenefitsDetails;
      'use-case.ckeditor': UseCaseCkeditor;
      'use-case.explore': UseCaseExplore;
      'use-case.features': UseCaseFeatures;
      'use-case.ready-section': UseCaseReadySection;
      'use-case.swiper': UseCaseSwiper;
      'use-case.swiper-description': UseCaseSwiperDescription;
    }
  }
}
